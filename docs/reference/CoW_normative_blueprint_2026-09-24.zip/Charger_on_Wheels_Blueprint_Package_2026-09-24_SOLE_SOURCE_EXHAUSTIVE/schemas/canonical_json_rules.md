# Canonical JSON and Schema Rules

**Status:** Normative machine-contract companion.

- JSON keys use `snake_case`.
- Unknown request fields are rejected unless a versioned extensibility field explicitly permits them.
- Money uses integer minor units plus ISO currency; never JSON binary-float authority.
- Energy uses integer Wh unless an explicitly declared measurement field requires exact decimal scale.
- Instants are RFC3339 UTC.
- Public entity IDs are canonical lowercase UUID strings unless a contract declares another opaque identity.
- Unknown is represented by nullable/absent fields according to the schema, never fabricated zero/empty truth.
- Envelopes in this directory are authoritative for their cross-cutting shape. Domain-specific payloads remain governed by the core blueprint, Annex 24, Annex 34, and repository OpenAPI when implemented.
