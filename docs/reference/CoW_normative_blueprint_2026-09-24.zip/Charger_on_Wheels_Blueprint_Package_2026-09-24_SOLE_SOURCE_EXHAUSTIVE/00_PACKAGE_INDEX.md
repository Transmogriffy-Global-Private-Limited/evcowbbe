# Charger on Wheels Sole-Source Blueprint Package - Exhaustive Edition

**Generated:** 2026-09-24  
**Status:** Pre-implementation sole-source project authority  
**Goal:** An engineer or coding agent should be able to execute the project burner-by-burner without consulting old chats/repositories or inventing architecture. Only genuine future business/legal/provider/hardware/runtime facts may remain behind explicit decision gates.

## Authority and read order

1. `01_CANONICAL_FULL_BLUEPRINT.md` - core architecture, domain truth, invariants, state machines, implementation program, and authority rules.
2. `normative/` - exact scoped contracts incorporated by canonical Section 0.1. Read the annexes touched by the burner.
3. `registries/` and `schemas/` - machine-readable exact vocabularies/inventories/envelopes synchronized to normative prose.
4. `09_BURNER_EXECUTION_INDEX.md` - generated lower-context copy of canonical Appendix H.
5. `02`-`05` - non-normative focused convenience views only.
6. `07`-`08` - byte-preserved provenance snapshots only.

## Normative annexes

- `normative/10_REALTIME_SSE_AND_NOTIFICATION_CONTRACTS.md` - Realtime SSE and Notification Contracts
- `normative/11_HTTP_API_AUTH_AND_PAYLOAD_STANDARD.md` - HTTP API, Authentication, and Payload Standard
- `normative/12_PERSISTENCE_SCHEMA_AND_DATA_DICTIONARY.md` - Persistence Schema and Data Dictionary
- `normative/13_STATE_AUTHORIZATION_AND_TRANSITION_REGISTRY.md` - State Authorization and Transition Registry
- `normative/14_WORKERS_SCHEDULERS_IDEMPOTENCY_AND_RECOVERY.md` - Workers, Schedulers, Idempotency, and Recovery Contract
- `normative/15_SECURITY_PRIVACY_RATE_LIMIT_AND_ABUSE_MODEL.md` - Security, Privacy, Rate Limit, and Abuse Model
- `normative/16_OBSERVABILITY_SLO_ALERTING_AND_RUNBOOK_CONTRACT.md` - Observability, SLO, Alerting, and Runbook Contract
- `normative/17_CONFIGURATION_SECRETS_AND_ENVIRONMENT_CATALOG.md` - Configuration, Secrets, and Environment Catalog
- `normative/18_TEST_FIXTURE_SIMULATOR_AND_ACCEPTANCE_SPEC.md` - Test, Fixture, Simulator, and Acceptance Specification
- `normative/19_DEPLOYMENT_BACKUP_RESTORE_AND_RELEASE_RUNBOOK.md` - Deployment, Backup, Restore, and Release Runbook
- `normative/20_FRONTEND_PROJECTION_AND_INTEGRATION_CONTRACTS.md` - Frontend Projection and Integration Contracts
- `normative/21_PROVIDER_ADAPTER_AND_EXTERNAL_DEPENDENCY_CONTRACTS.md` - Provider Adapter and External Dependency Contracts
- `normative/22_REPOSITORY_BOOTSTRAP_CODING_AND_MIGRATION_STANDARD.md` - Repository Bootstrap, Coding, and Migration Standard
- `normative/23_DOMAIN_GLOSSARY_NAMING_AND_ENUM_REGISTRY.md` - Domain Glossary, Naming, and Enum Registry
- `normative/24_API_ENDPOINT_AND_PAYLOAD_CATALOG.md` - API Endpoint and Payload Catalog
- `normative/25_DURABLE_EVENT_AND_OUTBOX_REGISTRY.md` - Durable Domain Event and Outbox Registry
- `normative/26_NOTIFICATION_TEMPLATE_AND_TRIGGER_REGISTRY.md` - Notification Template and Trigger Registry
- `normative/27_BUSINESS_DECISION_GATES_AND_POLICY_REGISTER.md` - Business Decision Gates and Policy Register
- `normative/28_REFERENCE_SEQUENCES_AND_FAILURE_SCENARIOS.md` - Reference Sequences and Failure Scenarios
- `normative/29_PROJECT_EXECUTION_PLAYBOOK.md` - Project Execution Playbook
- `normative/30_OPERATIONS_ADMIN_SUPPORT_PLAYBOOK.md` - Operations, Admin, and Support Playbook
- `normative/31_DATA_RETENTION_EXPORT_AND_PRIVACY_LIFECYCLE.md` - Data Retention, Export, and Privacy Lifecycle
- `normative/32_PHYSICAL_HARDWARE_CERTIFICATION_AND_PROTOCOL_MATRIX.md` - Physical Hardware Certification and Protocol Matrix
- `normative/33_PACKAGE_CHANGE_CONTROL_AND_TRACEABILITY.md` - Package Change Control and Traceability
- `normative/34_CMS_HAL_WIRE_CONTRACT_AND_RECONCILIATION.md` - CMS-HAL Wire Contract and Reconciliation Specification
- `normative/35_DISPATCH_LOCATION_GEOFENCE_AND_ETA_CONTRACT.md` - Dispatch, Location, Geofence, and ETA Contract
- `normative/36_PRICING_TAX_PAYMENT_REFUND_INVOICE_CONTRACT.md` - Pricing, Tax, Payment, Refund, and Invoice Contract
- `normative/37_DRIVER_COMPENSATION_ENGINE_CONTRACT.md` - Driver Compensation Engine Contract
- `normative/38_RATINGS_SUPPORT_INCIDENT_CONTRACT.md` - Ratings, Support, and Incident Contract
- `normative/39_DRIVER_WORKFORCE_FLEET_DUTY_CONTRACT.md` - Driver Workforce, Fleet, Scheduling, and Duty Contract
- `normative/40_CUSTOMER_SERVICE_REQUEST_AND_JOB_CONTRACT.md` - Customer, Service Request, Quote, and ServiceJob Contract
- `normative/41_AUDIT_PROVENANCE_CORRECTION_AND_MANUAL_ACTION_CONTRACT.md` - Audit, Provenance, Correction, and Manual Action Contract
- `normative/42_TRANSACTION_LOCKING_CONCURRENCY_AND_ISOLATION_CONTRACT.md` - Transaction, Locking, Concurrency, and Isolation Contract
- `normative/43_TIME_TIMEZONE_CALENDAR_PRECISION_AND_IDENTIFIER_CONTRACT.md` - Time, Timezone, Calendar, Precision, and Identifier Contract
- `normative/44_ADMIN_CAPABILITY_ROLE_AND_AUTHORIZATION_CATALOG.md` - Admin Capability, Role, and Authorization Catalog
- `normative/45_QUERY_FILTER_SORT_SEARCH_AND_EXPORT_CONTRACT.md` - Query, Filter, Sort, Search, and Export Contract
- `normative/46_SOLE_SOURCE_COVERAGE_AND_TRACEABILITY_MATRIX.md` - Sole-Source Coverage and Traceability Matrix

## Machine registries

```text
registries/api_endpoints.csv
registries/realtime_events.csv
registries/notifications.csv
registries/domain_events.csv
registries/config_keys.csv
registries/error_codes.csv
registries/admin_capabilities.csv
registries/workers.csv
registries/decision_gates.csv
registries/burners.csv
registries/state_transitions.csv
registries/package_manifest.json
```

## Exact envelope schemas

```text
schemas/realtime_event.schema.json
schemas/hal_fact_envelope.schema.json
schemas/notification_resource.schema.json
schemas/api_error.schema.json
schemas/canonical_json_rules.md
```

## Realtime/event-plane rule

Never collapse these four planes:

1. HAL -> CMS fact/trace service ingress.
2. CMS durable domain-event/outbox processing.
3. Client SSE realtime replay/live projection.
4. Durable human notification inbox + push/email delivery.

Success on one plane is not evidence of success on another. Annex 10 owns client SSE/notifications; Annex 34 owns CMS-HAL wire semantics.

## Execution rule

Start at B00.1. For every burner, use Appendix H/`09_BURNER_EXECUTION_INDEX.md`, then load all annexes/registries named by the burner's surfaces. Perform preflight, implementation, verification, documentation, and evidence capture before advancing. A genuinely unresolved external fact must map to Annex 27/`registries/decision_gates.csv`; otherwise it is not permission to invent a policy.

## Integrity gate

Run:

```bash
python3 tools/verify_package.py
```

Do not hand off or build from a package that fails this verifier.
