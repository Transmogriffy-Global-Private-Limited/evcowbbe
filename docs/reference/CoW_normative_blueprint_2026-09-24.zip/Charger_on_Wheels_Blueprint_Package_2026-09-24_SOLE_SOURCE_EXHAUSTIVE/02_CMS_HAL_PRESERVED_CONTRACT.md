> PACKAGE STATUS: NON-NORMATIVE FOCUSED VIEW. `01_CANONICAL_FULL_BLUEPRINT.md` is the only design authority in this ZIP. This file exists for lower-context reading and provenance; it MUST NOT introduce a requirement that is absent from the canonical blueprint. If wording differs, canonical wins.

# Charger on Wheels - CMS/HAL Preserved Contract and Charging Reliability Blueprint

This is a focused, standalone extraction from the canonical Charger-on-Wheels blueprint. It hydrates the mature EV-CMS <-> ocpp-hal-go-new behavior directly into the new project contract so an implementer does not need the old repositories merely to understand the required semantics.

Authority rule: the canonical full blueprint in this package is the project-wide authority. This focused file is an ergonomic view of the same required design. The reference repositories are provenance/evidence, not runtime dependencies of Charger on Wheels.

---

# 3. Architectural Laws and Invariants

These rules are global and must hold across every module.

## 3.1 Separate different kinds of truth

The system MUST preserve these as distinct concepts:

- Administrative/intended state.
- Observed real-world operational state.
- Physical charger/protocol truth.
- Historical snapshot state.
- Customer commercial truth.
- Driver compensation truth.
- Derived/realtime projections.

No convenience field may silently collapse them.

Examples:

- Admin pairing says Vehicle V1 carries Charger C1.
- Driver reports Vehicle V1 actually carries Charger C2.
- Current duty may proceed with observed C2 if policy permits.
- Admin sees a mismatch requiring reconciliation.
- Master pairing remains unchanged until deliberately corrected.
- Historical duty remains permanently tied to the actual observed combination used.

## 3.2 History does not mutate because master data changes

Every historical ServiceJob MUST preserve its own vehicle, service-address, pricing, tax, assignment, and relevant identity snapshots.

Every DriverDutySession MUST preserve its actual vehicle/charger context.

Every finalized compensation result MUST preserve the policy/rule versions and source facts used.

Every invoice MUST preserve the commercial facts used to create it.

Editing a CustomerVehicle, CustomerAddress, ServiceVehicle, Charger, pricing policy, compensation policy, driver profile, or admin assignment later MUST NOT rewrite historical records.

## 3.3 Physical charging truth comes from HAL facts

UI intent, CMS command dispatch, socket write success, or charger command acceptance MUST NOT be represented as a physical charging start.

Physical charging start requires normalized HAL transaction evidence.

Energy delivered requires normalized meter evidence.

Physical charging end requires normalized HAL transaction-end evidence or an explicit reconciled equivalent.

## 3.4 Service lifecycle and charging lifecycle are independent

A ServiceJob may be ARRIVED or SERVICE_PREPARING before physical charging starts.

A physical transaction may end while the ServiceJob remains in WRAP_UP.

A charger fault may end one ChargingSession while the same ServiceJob later starts another ChargingSession.

## 3.5 Customer price and driver compensation are separate engines

They may consume overlapping facts, but they MUST have independent policies, snapshots, ledgers, correction semantics, and administrative permissions.

Customer price changes MUST NOT implicitly change driver compensation.

Driver compensation changes MUST NOT change customer invoices.

## 3.6 External mutations are idempotent or reconcilable

Any mutation that can be retried across network boundaries MUST have one of:

- durable idempotency key semantics;
- a stable operation identity plus exact reconciliation;
- a provider-native idempotency mapping stored durably.

In-memory dedupe is never sufficient for externally retried business mutations.

## 3.7 Realtime is advisory, durable state is recoverable

Realtime messages tell clients that state changed and MAY carry a safe projection.

The client MUST be able to recover authoritative current state using HTTP APIs after disconnect/reconnect.

No critical state transition exists only in WebSocket memory.

## 3.8 Feature completeness remains invariant under extension

Adding a new adapter, vehicle type, charger protocol, pricing component, compensation component, user role, or realtime consumer MUST NOT degrade already-supported correctness properties.

Existing paths retain authorization, idempotency, auditability, verification, and documentation guarantees after extension.

## 3.9 Every actor is a real user

Customer, driver, dispatcher, recruiter, finance operator, support operator, technical/HAL operator, read-only observer, automated worker, CMS, HAL, and external payment provider are all first-class actors with explicit contracts and failure modes.

---

# 4. Chosen Technical Shape

## 4.1 CMS/backend

The initial Charger-on-Wheels CMS SHOULD be a modular monolith because the domains are strongly transactional and still one product boundary.

Chosen baseline:

- Go 1.25.
- Gin HTTP stack.
- PostgreSQL as durable truth.
- Versioned SQL migrations.
- OpenAPI 3.x as machine contract.
- Structured JSON logging.
- Durable database outbox workers for externally visible side effects.
- WebSocket or SSE realtime fanout built from durable/authoritative state changes, not as a source of truth.

The implementation MUST keep package boundaries strong enough that later extraction remains possible without changing domain semantics.

## 4.2 HAL

HAL is a separate Go service/repository/process with its own persistence and deployment lifecycle.

It MUST be protocol-neutral in the core and adapter-driven at the edges.

The first physical-protocol adapter is OCPP 1.6 unless hardware requirements force another initial protocol.

OCPP 2.0.1, OCPP 2.1, vendor adapters, and simulator adapters are additive extensions of the same normalized core.

## 4.3 Databases

CMS and HAL MUST use separate PostgreSQL databases and MUST NOT share tables or database credentials.

Cross-service communication uses authenticated HTTP and/or durable callback/fact delivery contracts.

## 4.4 Recommended repositories

Logical repository identities:

- `charger-on-wheels-backend`
- `charger-on-wheels-hal`

The exact Git organization/remote may be chosen during bootstrap. Once created, repository identity becomes part of the deployment contract and must be documented.

---

# 5. System Context and Deployment Topology

## 5.1 Logical topology

```text
User App -----------\
Driver App ----------> Charger-on-Wheels CMS/API -----> PostgreSQL (CMS)
Admin App -----------/          |   |   |
                               |   |   +--> Mail/notification providers
                               |   +------> Razorpay customer payments
                               +----------> Dedicated HAL API
                                              |
                                              +--> PostgreSQL (HAL)
                                              +--> charger WebSocket/OCPP/proprietary links
```

## 5.2 Trust boundaries

- User/Driver/Admin clients are untrusted network clients.
- CMS auth context is authoritative for human identity.
- CMS MUST NOT trust arbitrary client-supplied actor IDs, driver IDs, or admin capability claims.
- HAL is a trusted service only after service-to-service authentication succeeds.
- Charger-provided data is physical evidence but still untrusted input and must be validated/normalized.
- Razorpay/webhook payloads are trusted only after signature verification and replay/idempotency handling.

## 5.3 Environment tiers

At minimum:

- local development;
- shared development/integration;
- staging/pre-production;
- production.

Development and staging MUST use separate databases and separate HAL identities from production.

No production database may be used as an automated test database.

---

# 6. Repository and Module Ownership

Recommended CMS package layout:

```text
cmd/
  api/
  migrate/
  worker/                 # optional split entrypoint later

internal/
  platform/
    config/
    db/
    httpx/
    authn/
    authz/
    idempotency/
    outbox/
    audit/
    observability/
    realtime/

  users/
  customerprofiles/
  customervehicles/
  customeraddresses/

  driverrecruitment/
  drivers/
  schedules/
  duty/
  availability/

  fleet/
  vehicles/
  chargers/
  connectors/
  pairings/
  assignments/
  maintenance/

  dispatch/
  servicejobs/
  locations/

  charging/
  halclient/
  halfacts/

  pricing/
  payments/
  refunds/
  invoices/
  tax/

  compensation/

  ratings/
  support/
  incidents/
  notifications/

  admin/
```

The package names can be refined during bootstrap, but ownership MUST remain domain-oriented rather than one giant handlers/services/models structure.

Recommended HAL layout:

```text
cmd/
  hal/
  simulator/
  migrate/

internal/
  core/
    charger/
    connection/
    capability/
    transaction/
    command/
    metering/
    state/
    faults/
    operations/
    recovery/
    reconciliation/
    facts/
    trace/

  protocols/
    ocpp16/
    ocpp201/
    ocpp21/

  vendors/
  simulator/
  cmsclient/
  platform/
```

---

# 8. Universal HTTP/API Contract

## 8.1 Versioning

Initial public API prefix:

```text
/api/v1
```

Internal CMS-only service API prefix:

```text
/internal/v1
```

The separately hosted HAL is its own service and deliberately uses its own service-major root:

```text
/v1
```

Therefore `HAL_ORIGIN + /v1/...` is not a public CMS route and does not conflict with CMS `/internal/v1/...`. Browser/mobile clients never receive the HAL origin or service credentials.

Breaking contract changes require a new version or a backwards-compatible migration strategy.

## 8.2 Envelope

Success responses SHOULD use the resource directly unless pagination/metadata requires an envelope.

Errors use one canonical shape:

```json
{
  "error": {
    "code": "JOB_INVALID_TRANSITION",
    "message": "The job cannot move from ARRIVED to COMPLETED.",
    "request_id": "...",
    "details": {}
  }
}
```

`message` is safe for the client. Internal stack traces, SQL text, secrets, and provider payloads MUST NOT be returned.

## 8.3 Pagination

Use keyset pagination for growing operational/history collections.

Default page size: 20. Maximum: 100 unless an endpoint explicitly documents otherwise.

Ordering must be deterministic, typically:

```text
created_at DESC, id DESC
```

Cursor fields must encode every sort key required to avoid duplicates/skips.

## 8.4 Filtering and sorting

Filtering happens in SQL before LIMIT.

Every list endpoint documents:

- allowed filters;
- allowed sort keys;
- default sort;
- null ordering where relevant;
- full-text/search fields if `q` is accepted.

## 8.5 Idempotency header

Business-create and side-effecting retryable endpoints use:

```text
Idempotency-Key: <client-generated opaque key>
```

Scope is at least authenticated principal + HTTP operation + idempotency key.

Same key + semantically same request returns the same committed result.

Same key + conflicting request returns `409 IDEMPOTENCY_KEY_REUSED`.

## 8.6 Optimistic concurrency

Admin edits of mutable configuration SHOULD use either:

- `version` integer checked in the mutation; or
- strong ETag/If-Match.

Conflicts return 409 rather than silently overwriting a newer edit.

---

# 9. Global Persistence Conventions

## 9.1 IDs

Use UUID primary keys generated server-side, preferably UUIDv7 where implementation support is stable.

Provider IDs, charger protocol IDs, registration numbers, and human-readable job numbers are alternate identifiers, not primary keys.

## 9.2 Time

- Store all event timestamps as timezone-aware PostgreSQL `timestamptz` in UTC.
- Store an explicit IANA timezone on policies where local time affects behavior.
- Default business timezone for India deployment: `Asia/Kolkata`.
- Never compute compensation/time-window rules using server-local implicit timezone.

## 9.3 Money

Store monetary minor units as integers plus ISO currency code.

For INR:

```text
amount_minor = paise
currency = INR
```

Do not use binary floating point for money.

## 9.4 Energy and measurements

Choose canonical internal units and document them:

- energy: Wh integer where possible;
- power: W integer where possible;
- distance: meters integer;
- duration: milliseconds or seconds integer;
- latitude/longitude: decimal numeric precision sufficient for location;
- percentage/SoC: numeric/decimal with explicit range.

API may expose convenient derived units, but durable facts remain canonical.

## 9.5 Soft deletion

Use soft deactivation for identities/assets/configuration that must remain referentially visible to history.

Do not physically delete a driver, vehicle, charger, pricing policy, compensation policy, or saved customer object while history references it unless an explicit anonymization/retention process exists.

## 9.6 Audit columns

Mutable administrative/master tables SHOULD include:

```text
created_at
created_by
updated_at
updated_by
version
```

Historical event tables normally append new rows instead of updating semantic history.

---

# 18. Charging CMS Domain Blueprint - Preserved Mature Flow

This section is deliberately based on the proven behavioral architecture in `ev-cms-backend-new` and `ocpp-hal-go-new`, adapted to Charger on Wheels rather than copied mechanically.

The inheritance rule is:

1. Preserve the truth boundaries, identifier discipline, idempotency, ambiguity handling, projection/freshness rules, and recovery model.
2. Replace CPO-specific and fixed-station assumptions with Charger-on-Wheels ServiceJob, DriverDutySession, ServiceVehicle, and mobile Charger context.
3. Do not make the new services wire-compatible with EV-CMS merely for familiarity. The new contract is free to rename additive fields where the new domain genuinely differs, but semantic safety MUST remain equivalent or stronger.
4. A future simplification is allowed only if it can prove that the removed distinction cannot exist in Charger-on-Wheels reality.

## 18.1 Separate start intent, physical session, stop request, and general charger operation

Do not use one generic `ChargingIntent` row to mean all of the following:

- commercial/admission request to start charging;
- a physical charging session;
- a stop request;
- an administrative charger operation such as reset/unlock/availability;
- a HAL transport attempt.

Those are different concepts and have different recovery rules.

The CMS MUST model at least:

```text
ChargingStartIntent
ChargingSession
ChargingStopRequest
ChargerOperation        # non-start/stop administrative/technical commands
HALCommandRecord        # CMS projection of the HAL command identity/state
HALFactReceipt
HALChargerMapping
HALChargerRuntime
HALConnectorRuntime
```

`ServiceJob` remains the business parent. A physical charging session does not replace the ServiceJob.

## 18.2 Identifier chain

The following identities are distinct and MUST never be inferred from one another:

```text
service_job_id
assignment_id
duty_session_id
cms_charger_id
public/display charger identity
charger_protocol_identity
cms_connector_id
protocol_connector_number
cms_start_intent_id
cms_charging_session_id
cms_command_id
app_charging_credential / protocol authorization token
hal_command_id
hal_transaction_id
protocol_transaction_id
hal_fact_id
```

Rules:

- CMS owns all `cms_*`, ServiceJob, assignment, duty, customer, driver, and commercial identities.
- HAL owns `hal_command_id`, `hal_transaction_id`, protocol connection state, and the protocol transaction identity allocated/accepted by the protocol runtime.
- `charger_protocol_identity` is mapping evidence, not the CMS primary key.
- Connector number is protocol addressing, not a CMS connector UUID.
- A public/display charger ID is not a protocol identity unless the mapping explicitly says so.
- No recovery may correlate by "latest transaction", charger plus time window, display ID, or guessed connector.
- Zero UUIDs, empty identifiers, malformed UUIDs, and inconsistent identity chains are invalid rather than aliases for unknown.
- Unknown is represented by NULL/absence, never an all-zero UUID.

For OCPP 1.6, the exact `transactionId` is allocated by the Central System/HAL only when the charger-originated `StartTransaction` is accepted. CMS MUST never fabricate or substitute it.

## 18.3 One-use charging credential

The initial app-controlled charging vertical SHOULD preserve the proven one-use credential model.

Before requesting remote start, CMS creates a short-lived opaque credential, for example:

```text
cowv1_<random>
```

The credential is:

- generated by CMS;
- bound to one ChargingStartIntent;
- bound to the intended charger and connector where connector selection is known;
- associated with the owning customer and ServiceJob inside CMS;
- optionally associated with the current assignment/duty session for audit;
- short-lived;
- one-use;
- replay-resistant;
- never equal to a customer, driver, job, session, or database UUID;
- secret operational material and therefore redacted from logs, traces, analytics, errors, and external notifications.

CMS SHOULD persist only the credential hash after successful command construction whenever raw-value replay is not required. The raw value crosses to HAL only through the authenticated start-command boundary.

If the new HAL adapter/protocol does not require an idTag-like value, the semantic credential still remains useful as the one-use authorization/correlation token between CMS admission and physical-start evidence. An adapter may translate or omit the protocol representation, but the CMS intent still has a distinct authorization identity.

## 18.4 Commercial/admission boundary before start

A ChargingStartIntent is created only after CMS has established everything that must be true before asking hardware to energize.

The exact customer payment strategy is intentionally a pre-burner product decision elsewhere in this blueprint. Therefore Charger-on-Wheels MUST preserve the mature ordering without hard-coding the old wallet model.

In one CMS transaction, as applicable:

1. authenticate the initiating actor;
2. load and lock the ServiceJob/current assignment where required;
3. prove the job is in a start-eligible state;
4. prove the driver/duty session/actual vehicle/charger context is the current operational context;
5. validate customer EV versus connector/charger compatibility;
6. derive trusted customer/service scope server-side;
7. resolve the effective customer pricing policy and active tax configuration;
8. freeze the charging-relevant pricing/tax snapshot or reference the already-frozen ServiceJob commercial snapshot according to the selected pricing design;
9. calculate any required affordability, deposit, authorization, prepaid balance, or spending-safety boundary according to the chosen payment strategy;
10. create the corresponding durable funding reservation/hold only if that strategy actually has one;
11. generate the one-use charging credential;
12. create the immutable ChargingStartIntent;
13. create the CMS command identity and immutable dispatch envelope;
14. emit only the internal domain/outbox records that belong to the committed CMS transaction.

No network call to HAL occurs inside that database transaction.

If the eventual business model is post-service collection with no funding reservation, step 9 records admission policy and step 10 is absent. Do not invent a fake wallet hold simply to imitate EV-CMS.

## 18.5 Mapping synchronization and race closure

CMS owns the intended charger/connector inventory and mapping. HAL owns protocol connectivity and validates that command destinations match an approved mapping.

Before a first start can be attempted on a mapping revision, CMS MUST ensure HAL knows the committed mapping.

Recommended ordering, preserving the mature system:

```text
committed CMS charger/connector inventory
-> mapping state PENDING/RECONCILIATION_REQUIRED if not synchronized
-> authenticated idempotent mapping PUT to HAL
-> mapping SYNCHRONIZED
-> create/freeze charging admission transaction
-> reconfirm mapping revision immediately before RequestStart
-> send start only if the exact frozen destination is still valid
```

The second confirmation closes the race where the physical/admin mapping changes between commercial admission and network dispatch.

If the prerequisite mapping fails before any commercial/start-intent transaction is committed:

```text
reject start
no ChargingStartIntent
no funding hold/reservation
no command record
```

If post-commit mapping confirmation fails before HAL start invocation:

```text
terminalize the unattempted command
release only the still-unspent funding reservation if one exists
terminalize the start intent as REJECTED or EXPIRED as appropriate
return a stable mapping-unavailable error
```

Do not leave a durable funding reservation attached to a command proven never to have crossed the HAL boundary.

## 18.6 ChargingStartIntent lifecycle

Use an explicit state machine equivalent to the mature flow:

```text
REQUESTED
ACCEPTED_FOR_DELIVERY
PROTOCOL_ACKNOWLEDGED
ACTUALLY_STARTED
REJECTED
EXPIRED
RECONCILIATION_REQUIRED
```

Meaning:

| State | Durable meaning |
| --- | --- |
| `REQUESTED` | CMS admission, immutable start intent, commercial snapshot, credential, and any required funding reservation are committed. HAL has not yet durably accepted the logical start command. |
| `ACCEPTED_FOR_DELIVERY` | HAL durably knows the logical start command. This does not mean OCPP/protocol acceptance and does not mean charging started. |
| `PROTOCOL_ACKNOWLEDGED` | The charger/protocol accepted the remote-start command. This still does not prove physical charging start. |
| `ACTUALLY_STARTED` | Authoritative charger-originated transaction-start evidence passed the complete identifier/correlation checks and materialized one CMS ChargingSession. |
| `REJECTED` | The start cannot proceed and no authoritative start evidence exists. |
| `EXPIRED` | The approved start window ended without authoritative physical-start evidence. |
| `RECONCILIATION_REQUIRED` | Delivery, identity, mapping, late evidence, or correlation is ambiguous and truth cannot safely be concluded. |

Allowed transition principles:

```text
REQUESTED -> ACCEPTED_FOR_DELIVERY | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
ACCEPTED_FOR_DELIVERY -> PROTOCOL_ACKNOWLEDGED | ACTUALLY_STARTED | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
PROTOCOL_ACKNOWLEDGED -> ACTUALLY_STARTED | EXPIRED | RECONCILIATION_REQUIRED
REJECTED -> RECONCILIATION_REQUIRED only on contrary late evidence
EXPIRED -> RECONCILIATION_REQUIRED only on contrary late evidence
RECONCILIATION_REQUIRED -> evidence-backed state only
```

A remote-start timeout after possible transmission is never `REJECTED` merely because CMS did not receive a response.

## 18.7 No CMS ChargingSession before physical-start evidence

There MUST be no normal materialized ChargingSession just because:

- the user/driver tapped Start;
- CMS created a start intent;
- CMS sent an HTTP request;
- HAL persisted the command;
- HAL returned `202`;
- the protocol returned RemoteStart accepted.

A CMS ChargingSession is materialized only from authoritative normalized transaction-start evidence with a valid identifier chain.

Initial CMS ChargingSession states:

```text
ACTIVE
STOP_PENDING
RECONCILIATION_REQUIRED
COMPLETED
FAILED             # only for evidence-backed non-commercial failure semantics
```

`ACTIVE` requires the real transaction-start fact. `STOP_PENDING` is a CMS projection indicating a durable stop request exists while physical completion remains absent. `RECONCILIATION_REQUIRED` preserves occupancy and blocks unsafe duplicate settlement/starts when physical truth is incomplete.

## 18.8 Materializing transaction-start evidence

For `transaction.started`, CMS MUST validate before session creation:

- immutable fact ID/digest integrity;
- known supported schema version;
- exact CMS charger mapping;
- exact CMS connector mapping;
- charger protocol identity;
- connector number;
- nonzero HAL command identity where contract requires it;
- exact CMS command identity;
- exact ChargingStartIntent identity;
- one-use credential/hash correlation;
- HAL transaction identity;
- protocol transaction identity where present;
- receipt/order/timestamp policy;
- current start intent has not already materialized a different transaction;
- no conflicting nonzero identity was previously accepted.

One accepted start fact materializes exactly one CMS session for that start intent.

A duplicate identical fact is a no-op success. A same fact ID with altered immutable content is an integrity violation. A different fact claiming a conflicting transaction identity moves the affected CMS truth to reconciliation rather than choosing whichever arrived last.

## 18.9 ChargingSession persistence

`charging_sessions` SHOULD include at least:

```text
id
service_job_id
assignment_id
duty_session_id
customer_id
charger_id
connector_id
start_intent_id UNIQUE
start_command_id
hal_command_id nullable
hal_transaction_id UNIQUE nullable
protocol_transaction_id nullable
state
started_at
completed_at nullable
meter_start_wh
latest_meter_wh nullable
meter_stop_wh nullable
consumed_wh nullable
latest_meter_sequence nullable
latest_meter_observed_at nullable
initial_soc_percent nullable
latest_soc_percent nullable
latest_soc_sequence nullable
latest_soc_observed_at nullable
final_soc_percent nullable
settlement_state
reconciliation_reason nullable
created_at
updated_at
```

The exact schema may split projection tables, but uniqueness and identity-chain semantics MUST remain enforceable at the database/service boundary.

## 18.10 Meter evidence

Energy across CMS/HAL uses integer Wh as the durable cross-service unit unless a future measurement explicitly requires a different exact representation.

HAL emits immutable `transaction.meter` facts only from accepted protocol evidence.

Each accepted meter fact carries enough information to prove:

```text
hal_transaction_id
protocol_transaction_id
cms_start_intent_id
cms_charger_id / mapped identity chain
cms_connector_id / connector number chain
meter_sequence
meter_value_wh
consumed_wh
meter_observed_at
```

Rules:

- Never interpolate a missing meter reading.
- Never estimate authoritative energy from charger rated power and elapsed time.
- CMS may compute UI projections from measured facts, but the displayed result must remain distinguishable from authoritative final settlement values.
- CMS advances the current meter projection only on a strictly newer accepted sequence.
- Delayed older facts remain receipts/evidence and MUST NOT regress the live projection.
- Consumption cannot silently become negative because a register rolled backward.
- Completion uses an evidence-backed nondecreasing final meter policy.
- The inherited one-Wh quantization exception MAY be retained for adapters/hardware where proven relevant: a raw final register exactly one Wh below the latest temporally eligible accepted sample may be preserved as raw evidence while the normalized billable cumulative meter remains nondecreasing and the normalization is explicitly tagged. Do not generalize this tolerance without evidence.

## 18.11 SoC evidence is independent from energy

State of Charge is a separate optional evidence stream.

Rules:

- Missing SoC means unknown, never zero.
- SoC MUST NOT be derived from delivered Wh and nominal battery capacity as if it were charger truth.
- SoC-only evidence does not invent an energy sample.
- Energy-only evidence does not copy a cached SoC into a new observation.
- SoC has its own sequence and observed timestamp.
- SoC freshness is calculated independently even if it uses the same configured stale duration initially.
- A completed session's `final_soc_percent` is the last accepted observation, not necessarily a stop-time measurement unless its timestamp proves that.

A future target-SOC stop rule is allowed only when the chosen charger/protocol evidence is trustworthy enough for that rule. Otherwise target SOC is advisory rather than a guaranteed physical cutoff.

## 18.12 Stop request and completion are different truths

Stop may be initiated by:

- assigned Driver;
- Customer if enabled by product policy;
- authorized Admin technical/operations capability;
- CMS automatic charging target logic;
- funding/commercial safety logic;
- HAL deadline/energy threshold derived from CMS instructions;
- charger/local hardware/operator without any CMS stop request.

A stop request creates/reuses a durable `ChargingStopRequest` and CMS command identity.

The HAL response to RemoteStop or equivalent is command evidence only.

The ChargingSession remains `ACTIVE` or `STOP_PENDING` until authoritative transaction-completion evidence is accepted.

A spontaneous charger-originated end MUST be processed even if there is no CMS stop command.

## 18.13 Stop provenance

Preserve business/request provenance separately from protocol completion reason.

The session/completion projection may include:

```text
requested_stop_initiator
requested_stop_reason
protocol_stop_reason
```

Examples:

```text
requested_stop_initiator = SYSTEM
requested_stop_reason    = ENERGY_LIMIT
protocol_stop_reason     = Remote
```

`Remote` is protocol evidence, not the business reason the platform decided to stop.

If the charger stopped locally, `requested_stop_*` may be NULL while `protocol_stop_reason` is present.

## 18.14 Completion and settlement

Only authoritative `transaction.completed` evidence, or an exact HAL transaction-reconciliation snapshot satisfying the same evidence requirements, can physically complete a CMS ChargingSession.

CMS validates:

- exact HAL transaction identity;
- exact protocol transaction identity where applicable;
- exact start-intent/charger/connector chain;
- final meter non-regression;
- completion time not earlier than accepted start;
- no conflicting terminal evidence;
- optional stop provenance fields as provenance only.

Then one CMS transaction performs the idempotent completion side effects that are enabled for the selected business model:

1. lock session and commercial/funding rows in canonical order;
2. persist final physical metrics;
3. finalize pricing from frozen commercial terms and accepted physical facts;
4. perform the allowed payment/capture/debit/release operation exactly once;
5. record commercial ledger/adjustment records;
6. mark settlement result;
7. finalize or enqueue invoice generation according to invoice design;
8. emit durable domain/operational events;
9. transition the ServiceJob toward `WRAP_UP` only when field-service invariants allow it.

Repeated fact delivery or reconciliation MUST NOT create a second payment, debit, capture, refund, invoice, or compensation source fact.

## 18.15 Start ambiguity recovery

A network error after RequestStart may mean any of:

- HAL never received the command;
- HAL persisted it but CMS lost the response;
- HAL transmitted to the charger and the response was lost;
- charging physically started and the fact is delayed.

Therefore:

```text
possible RequestStart delivery
-> RECONCILIATION_REQUIRED
-> exact GET by original cms_command_id
```

Exact command lookup outcomes:

```text
command exists
    -> project HAL command state
    -> retain admission/funding reservation
    -> do not create a new command

canonical 404 / confirmed absent
    -> only if no materialized session exists and identity locks prove absence
    -> mark command CONFIRMED_ABSENT
    -> release unspent funding reservation if any
    -> REJECTED, or EXPIRED if the start window has elapsed

401/403/409/422/5xx/timeout/malformed response
    -> retain RECONCILIATION_REQUIRED
    -> retain occupancy/funding safety
    -> bounded retry of the same exact lookup
```

For an accepted/unmaterialized start that remains unresolved beyond a configured threshold, CMS SHOULD also query the exact transaction by `cms_start_intent_id`. A valid returned HAL transaction is fed through the same locked materializer as a normal `transaction.started` fact.

A 404 transaction lookup is not enough by itself to prove the command never crossed the boundary. Reconcile the exact command too.

Late physical-start evidence after CMS believed the intent rejected/expired is never discarded. Preserve it and move the intent to reconciliation; do not silently create a normal session or automatically send a stop unless separately authorized by safety policy.

## 18.16 Completion recovery for missing/delayed fact delivery

For a materialized CMS session with known `hal_transaction_id` and no completion:

```text
GET exact HAL transaction by hal_transaction_id
```

Possible outcomes:

```text
matching terminal transaction with valid completion evidence
    -> reuse the exact same locked finalization path as transaction.completed fact ingress

active/nonterminal transaction
    -> keep session open; no synthetic completion

404 / timeout / HAL unavailable / 5xx
    -> keep occupancy and financial state unchanged; retry later

malformed/conflicting identity, meter, or time evidence
    -> mark session RECONCILIATION_REQUIRED
    -> do not settle or clear occupancy by guesswork
```

A bounded fair cursor SHOULD prevent one old failing session from monopolizing every recovery pass.

## 18.17 Multiple physical starts within one ServiceJob

Charger-on-Wheels retains the plan that one ServiceJob may have multiple physical charging attempts.

The safe initial rule is:

- one accepted physical transaction start creates one CMS ChargingSession;
- if that physical session completes/fails and a later recovery start occurs, create a new ChargingStartIntent and a new ChargingSession under the same ServiceJob;
- do not mutate the first session into a second physical transaction merely to make the UI look continuous;
- the final ServiceJob commercial and driver-compensation engines aggregate the explicitly eligible physical facts across those sessions.

If a future protocol supports one logical transaction surviving transport reconnection, HAL keeps one HAL transaction and the CMS session remains one session. Transport reconnect alone is not a reason to split a charging session.

## 18.18 Customer/Driver initiation policy

Who is allowed to request physical charging start is a product policy, but the backend contract is not duplicated per actor.

For the initial field-service flow:

- Driver start is expected after arrival and preparation.
- Customer MAY be allowed to confirm/readiness-authorize start if product UX requires it.
- Admin MAY request start only under an explicitly capability-gated operational intervention flow with reason/audit.

All actors converge on the same CMS `RequestChargingStart` domain method, which derives trusted IDs from current ServiceJob/assignment context rather than accepting arbitrary charger/driver/customer ownership IDs from the client.

---

# 19. Dedicated HAL Exact Blueprint - Preserved Reliability Model

## 19.1 Authority

HAL owns:

- charger transport and connection/reconnection;
- protocol negotiation and framing through protocol libraries/adapters;
- exact protocol charger identity;
- current protocol connector evidence;
- remote command persistence and delivery;
- exact physical transaction identity;
- meter/SoC/protocol evidence;
- normalized physical facts;
- command and transaction reconciliation;
- raw/sanitized technical trace evidence;
- durable fact/trace outboxes.

HAL does not own:

- Customer identity semantics;
- Driver/assignment/duty semantics;
- ServiceJob lifecycle;
- customer price/tax;
- payment/funding policy;
- invoice generation;
- compensation;
- customer-visible business conclusions.

CMS and HAL have separate PostgreSQL databases and credentials.

## 19.2 Protocol-neutral core, protocol-specific adapters

Preserve the new project's protocol-neutral goal while carrying forward the existing OCPP reliability semantics.

Core concepts:

```text
HAL Core
  ChargerRegistry
  ConnectionRuntime
  MappingRegistry
  CapabilityProjection
  CommandStore
  CommandDispatcher
  TransactionStore
  MeterNormalizer
  StopWorkflow
  FactOutbox
  TraceOutbox
  Reconciler

Adapters
  OCPP 1.6
  OCPP 2.0.1
  OCPP 2.1
  vendor/proprietary
  simulator
```

Protocol-specific names such as `RemoteStartTransaction`, `RequestStartTransaction`, or `SetChargingProfile` stay inside adapters. CMS speaks semantic operations.

For OCPP, use a maintained protocol library rather than hand-building WebSocket/OCPP framing. The existing HAL uses `github.com/lorenzodonini/ocpp-go`; the new repository may retain it for OCPP 1.6 if it remains the best supported choice, but adapter boundaries MUST permit replacement without changing CMS contracts.

## 19.3 Charger mapping contract

HAL persists the approved CMS mapping rather than accepting arbitrary command destinations.

Conceptual mapping:

```text
cms_charger_id
charger_protocol_identity
expected_serial nullable
enabled
connectors[]:
  cms_connector_id
  protocol_connector_number
  enabled
mapping_revision / updated_at
```

Mapping synchronization is authenticated and idempotent.

Expected serial is additional physical evidence, never a substitute for canonical protocol identity.

## 19.4 Start/stop HAL command lifecycle

Preserve these durable states for start/stop:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED        # or protocol-equivalent accepted
OCPP_REJECTED        # or protocol-equivalent rejected
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Semantics:

- `PERSISTED`: command exists durably and no network transmission has occurred.
- `PENDING_DELIVERY`: a worker exclusively owns a known pre-network delivery window. Startup recovery may return this state to `PERSISTED` because the network boundary was not crossed.
- `DELIVERY_ATTEMPTED`: HAL has crossed or may have crossed the transport boundary. It is no longer blindly replayable.
- `OCPP_ACCEPTED`: charger accepted the protocol command. It does not prove physical start/end.
- `OCPP_REJECTED`: explicit protocol rejection.
- `AMBIGUOUS`: timeout/lost response/uncertain result after possible delivery.
- `EXPIRED`: command was no longer eligible before a safe result.
- `SUPERSEDED`: later physical/command truth makes this retry ineligible.
- `MATERIALIZED`: resulting physical transaction identity has been correlated. It still does not mean CMS commercial completion.

Same `cms_command_id` plus identical immutable command returns the same HAL command. Same identity plus altered immutable command is an idempotency conflict.

## 19.5 HAL delivery fence

The database record MUST prove whether a command is still safely sendable.

Before network I/O:

1. select a `PERSISTED` command;
2. atomically claim it with a unique claim token/lease;
3. verify it is still eligible and mapped;
4. commit a delivery-attempt marker before the network call if the implementation cannot otherwise prove no transmission;
5. perform network I/O outside the database transaction;
6. persist the result with state/token fencing.

After the delivery-attempt marker is committed, a process crash cannot turn the row back into replayable `PERSISTED` state.

If final result persistence fails after the OCPP call, leave the durable row in attempted/ambiguous state and reconcile rather than resending.

## 19.6 Generic charger operations inherit the same no-replay safety

Administrative/technical operations such as:

```text
Reset
UnlockConnector
ChangeAvailability
SetChargingLimit
TriggerMessage / diagnostics request
future adapter-specific safe operations
```

use a durable operation model separate from ChargingStartIntent/ChargingStopRequest.

CMS-side states SHOULD preserve the mature operation-dispatch distinction:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

Important rules:

- CMS freezes destination and immutable request parameters at admission.
- Recovery never rebuilds destination from current mappings.
- CMS commits `DELIVERY_ATTEMPTED` before HAL I/O.
- No database transaction spans HAL network I/O.
- After possible delivery, CMS performs exact-ID HAL lookup only.
- `CONFIRMED_ABSENT` means HAL's durable exact lookup proves the operation was not accepted; it does not prove a physical effect and does not authorize automatic replay.
- A genuinely new operator instruction is a new operation with new authorization, reason, audit, and idempotency identity.

## 19.7 HAL recovery worker isolation

Preserve the currently hardened worker separation from `ocpp-hal-go-new`.

The dedicated generic charger-operation recovery worker MUST be separate from:

- charging deadline enforcement;
- automatic energy/time/funding stop workflows;
- pending charging-stop recovery;
- core connection handling.

A slow Reset/Unlock/diagnostic operation MUST NOT delay an automatic charging stop or transaction-lifecycle recovery.

Recommended worker behavior:

- sequential per process initially;
- bounded batch per pass;
- rotate fairly across active charger identities;
- avoid polling offline chargers for safely `PERSISTED` work;
- use the same atomic claim and typed dispatcher as immediate HTTP acceptance;
- no unbounded goroutines;
- request-detached final bookkeeping with a bounded deadline, still cancelled on HAL shutdown;
- startup converts any possibly sent `DELIVERY_ATTEMPTED` work to reconciliation rather than replay.

The exact interval/batch/timeout are configuration, not semantic constants.

## 19.8 Command payload contract

The Charger-on-Wheels internal start command SHOULD contain:

```json
{
  "cms_command_id": "<uuid>",
  "cms_start_intent_id": "<uuid>",
  "cms_charger_id": "<uuid>",
  "cms_connector_id": "<uuid>",
  "charger_protocol_identity": "<string>",
  "protocol_connector_number": 1,
  "id_tag": "cowv1_<opaque>",
  "credential_expires_at": "<rfc3339 utc>",
  "command_expires_at": "<rfc3339 utc>",
  "limit_type": "AUTO|ENERGY|TIME|MONEY",
  "energy_limit_wh": 0,
  "energy_limit_source": "NONE|CUSTOMER_ENERGY|CUSTOMER_MONEY|FUNDING_SAFETY",
  "max_duration_seconds": 0,
  "duration_limit_source": "NONE|CUSTOMER_TIME|CUSTOMER_MONEY|FUNDING_SAFETY"
}
```

The final field vocabulary MAY differ, but preserve these semantics:

- customer preference classification and enforcement thresholds are separate;
- energy and duration thresholds are independent;
- zero means no threshold, not zero entitlement;
- threshold provenance is explicit;
- HAL receives no tariff rates, GST, customer balance, payment credentials, or pricing formula;
- HAL reports why its stop workflow fired but CMS owns the business/commercial interpretation.

If Charger-on-Wheels later supports a trusted SoC stop threshold, add it compositionally as another capability/source. Do not overload `energy_limit_wh`.

## 19.9 Fact envelope and integrity

HAL facts are immutable protocol evidence.

Every authoritative fact includes at least:

```text
fact_id
fact_type
schema_version
occurred_at
producer
immutable_content_sha256
payload
```

The digest is calculated over the canonical immutable envelope with the digest field excluded. Use an explicit canonical JSON rule, such as RFC 8785 JCS, on both sides.

HAL sends:

```http
Authorization: Bearer <hal-to-cms-fact-token>
Idempotency-Key: <fact_id>
```

CMS behavior:

```text
new fact ID + valid digest -> durable receipt + projection transaction
same fact ID + same digest -> idempotent success/no-op
same fact ID + different digest -> integrity violation, no projection mutation
```

Do not use mutable payload reserialization as the dedupe identity.

## 19.10 Normalized facts

Initial required fact vocabulary:

```text
charger.connection.updated
connector.status.updated
command.updated
transaction.started
transaction.meter
transaction.soc          # optional when evidence exists
transaction.completed
fault.observed
capability.changed       # as needed
```

`command.updated` can advance command/recovery state but NEVER creates/completes a physical ChargingSession by itself.

## 19.11 Connection truth, restart behavior, and heartbeat

HAL is authoritative for current charger connection evidence.

Preserve these semantics:

- process-local connection generation fences stale callbacks only inside one process lifetime;
- durable `connection_sequence` orders projections across reconnects and process restarts;
- on HAL startup, prior connection state is first treated as `UNKNOWN` until new-process evidence establishes current truth;
- an accepted Heartbeat from the currently tracked connection is liveness evidence, advances the durable sequence/observed time, and preserves `ONLINE`;
- Heartbeat cannot create or resurrect a connection that the transport layer does not own;
- charger-supplied clocks are evidence, not authority for credential expiry or security deadlines;
- trusted HAL receipt time is used for expiry/deadline decisions subject to explicit bounded clock-skew validation.

CMS has a longer configurable connection stale horizon than HAL's requested heartbeat cadence.

## 19.12 Connector status projection

HAL accepts mapped `StatusNotification`/equivalent evidence and publishes a monotonic `connector_status_sequence`.

CMS stores historical status but derives live availability only when parent connection evidence is current.

Baseline mapping:

```text
no connector observation                         -> UNKNOWN
parent OFFLINE / UNKNOWN / stale                 -> STALE or UNAVAILABLE with stale reason
fresh ONLINE + protocol Available                -> AVAILABLE
fresh ONLINE + Preparing/Charging/Finishing      -> CHARGING/IN_USE category
fresh ONLINE + Faulted                           -> FAULTED
other fresh protocol status                      -> UNAVAILABLE
```

Inventory/admin state remains a separate overlay. A technically `Available` connector on an inactive/out-of-service charger is not dispatchable.

## 19.13 Fact acceptance classes

HAL input handling MUST distinguish evidence criticality:

- transaction start and transaction end are irreplaceable lifecycle truth and MUST commit with durable outbox evidence before protocol acknowledgement where protocol timing allows;
- accepted active-transaction MeterValues and mapped connector status SHOULD persist their normalized durable fact before acknowledgement where required for guaranteed evidence;
- Heartbeat is refreshable liveness evidence;
- socket connect/disconnect callbacks are transport evidence;
- stale/unsupported/unmapped/unrelatable observations do not advance authoritative projections.

Fail-safe boundary behavior beats guesswork.

## 19.14 Completion meter integrity

HAL accepts completion only for the exact active transaction and connector/protocol identity chain.

The effective cumulative final meter is nondecreasing.

A conflicting duplicate StopTransaction/completion is rejected and MUST NOT create a second terminal fact.

Concurrent stop lifecycle mutations lock durable rows in one documented canonical order, for example:

```text
transaction
-> stop workflow
-> remote command rows
-> outbox fact reservation
```

A local PostgreSQL deadlock/serialization failure may retry the uncommitted database transaction. It MUST NOT replay the OCPP network command.

## 19.15 Durable fact outbox

HAL facts are delivered with a durable outbox.

Delivery guarantees:

- same immutable fact ID/body retried until CMS durably acknowledges or a terminal receiver error requires operator reconciliation;
- delivery may be duplicate or out of order;
- one delivery lease belongs to one worker/token;
- expired lease may be reclaimed using a new token;
- stale worker result cannot overwrite a later claim;
- a retry never creates a replacement fact identity;
- per-call timeout stays inside lease budget;
- poison/terminal rows do not block unrelated facts.

The baseline implementation MAY serialize fact delivery initially to minimize ordering/concurrency complexity; scale only when measurement requires it.

## 19.16 Diagnostic trace plane is separate from fact truth

Preserve the mature split:

```text
Authoritative fact outbox -> CMS HAL fact ingress
Diagnostic trace outbox   -> CMS HAL trace ingress
```

Trace events:

- are sanitized immutable technical evidence;
- use a separate bearer/credential;
- have their own worker and retry budget;
- may contain CALL/CALLRESULT/CALLERROR and bounded follow-on evidence;
- NEVER establish charging lifecycle, connector availability, meter, settlement, or command truth;
- MUST NOT consume fact-delivery worker capacity or delay authoritative fact delivery.

A diagnostic "accepted but no follow-on observed" result remains a diagnostic conclusion, not proof that physical state did or did not change.

## 19.17 Raw evidence retention

HAL retains sufficient raw or sanitized protocol evidence to investigate:

- connection chronology;
- commands and responses;
- Start/Stop transaction evidence;
- MeterValues/SoC;
- connector status;
- adapter/vendor behavior;
- mapping/identity conflicts.

Requirements:

- no bearer tokens, credentials, passwords, or app charging credential in logs;
- access limited to technical/admin capability;
- retention configurable;
- immutable correlation links to normalized facts/commands where possible;
- ordinary User/Driver APIs never expose raw protocol payloads.

## 19.18 Simulator contract

The simulator is a protocol adapter/test system, not a toy.

It MUST support deterministic scripts for:

- initial connect and boot/registration;
- Heartbeat/liveness;
- mapped connector status;
- accepted/rejected start;
- command timeout before and after possible delivery;
- charger-originated transaction start;
- integer-Wh MeterValues;
- SoC-only and energy-only observations;
- local stop without CMS request;
- remote stop accepted but completion delayed;
- transaction completion;
- duplicate facts/messages;
- out-of-order meter/SoC sequence;
- reconnect during active transaction;
- HAL process restart and connection state reset to unknown;
- lost CMS fact receiver and outbox retry;
- conflicting duplicate evidence;
- generic administrative operation recovery;
- multiple charging sessions inside one ServiceJob.

CI scenarios MUST be reproducible from source-controlled fixtures.

---

# 20. CMS-HAL Cross-Repository Integration Contract

This section is intentionally self-contained. An implementer should not need the old EV-CMS or HAL repositories to understand the required Charger-on-Wheels integration behavior.

## 20.1 Source inheritance snapshot

This blueprint was hydrated on 2026-09-24 from the following current reference state:

```text
Reference CMS repo:
  Transmogriffy-Global-Private-Limited/ev-cms-backend-new
  observed main: dafcab3f11f403f4a70fd0d9f24064f3b873f3af

Reference HAL repo:
  Transmogriffy-Global-Private-Limited/ocpp-hal-go-new
  observed main: 1908c934c0e2570b81523e8ef3fe20be1e519da0
```

Important reference documents/code lines of behavior were:

```text
ev-cms-backend-new/docs/USERAPP_FE_HANDOFF.md
ev-cms-backend-new/docs/integrations/ocpp-hal-boundary.md
ev-cms-backend-new/docs/integrations/charger-operation-recovery.md
ev-cms-backend-new/docs/integrations/cpo-hal-operational-capability-manual.md

ocpp-hal-go-new/docs/ARCHITECTURE_BOUNDARY.md
ocpp-hal-go-new/docs/contracts/CMS_HAL_CHARGING_V1.md
ocpp-hal-go-new/docs/PROJECT_STATE.md
ocpp-hal-go-new current charger-operation recovery implementation
```

These repositories are provenance, not runtime dependencies. Charger-on-Wheels owns its own source and contract after implementation. Future upstream changes are reviewed deliberately rather than silently inherited.

### 20.1.1 Inheritance/adaptation matrix

The reference repositories are not copied wholesale. The following classification is normative for Charger on Wheels.

| Reference behavior | Charger-on-Wheels decision | Reason |
| --- | --- | --- |
| CMS and HAL have separate databases | **PRESERVE** | Keeps business truth and physical protocol truth independently recoverable. |
| Start intent exists before a charging session | **PRESERVE** | Command intent is not physical-start truth. |
| One-use short-lived app charging credential, distinct from customer identity | **PRESERVE** | Prevents identity leakage/replay and gives exact start correlation. |
| Exact CMS command -> HAL command -> HAL transaction -> OCPP transaction identity chain | **PRESERVE** | Recovery must never correlate by time/latest/guesswork. |
| Mapping synchronization plus pre-dispatch reconfirmation | **PRESERVE** | Closes inventory/mapping races before physical action. |
| Commit delivery fence before uncertain network I/O; exact-ID reconciliation after possible delivery | **PRESERVE** | Prevents duplicate physical commands after crash/timeout. |
| HAL durable fact outbox, immutable fact identity/digest, duplicate/out-of-order-safe CMS ingest | **PRESERVE** | Cross-service delivery is at-least-once in reality. |
| HAL raw evidence + normalized semantic facts | **PRESERVE** | Business code needs stable semantics while technical investigation retains protocol truth. |
| Independent connection, connector, meter, and SoC sequences/freshness | **PRESERVE** | Delayed evidence must not regress current projection. |
| User App talks only to CMS; CMS REST/snapshot is recovery authority | **PRESERVE** | Browser/mobile state cannot become a second business authority. |
| Rotating one-use refresh tokens and single-refresh client mutex | **PRESERVE** | Prevents refresh-token replay/races. |
| Realtime events are replayable hints/full snapshots, not sole truth | **PRESERVE** | App must recover after disconnect/background/token rotation. |
| Existing CPO tenancy and `X-CPO-App-ID` | **DO NOT INHERIT** | Charger on Wheels is one platform with User/Driver/Admin surfaces, not a CPO product. |
| CPO-vs-Platform support channels | **ADAPT** to `CUSTOMER_PLATFORM` and `DRIVER_PLATFORM` | Keeps actor separation without inventing CPO tenancy. |
| Stationary hub/charger discovery assumptions | **ADAPT/REPLACE** | This product dispatches a mobile ServiceVehicle + Charger through ServiceJob. |
| CPO subscription admission rule | **DO NOT INHERIT** | It is not part of this product model. Any future entitlement rule must be explicit. |
| Existing wallet requirement as the only start-funding model | **ADAPT** | Preserve commercial freeze/reservation ordering, but funding mechanism follows the selected customer payment strategy. |
| Generic administrative charger-operation recovery | **PRESERVE AS A SEPARATE PLANE** | Reset/unlock/diagnostics have different semantic completion than customer charging start/stop. |

When an inherited mechanism conflicts with the Charger-on-Wheels domain, preserve the safety/correctness property and adapt the domain vocabulary, not the old tenant/product assumption.

## 20.2 No shared database

CMS and HAL:

- have separate PostgreSQL databases;
- never read/write each other's tables;
- never share DB credentials;
- communicate only through authenticated versioned service contracts;
- reconcile using durable public service identities, never direct SQL.

## 20.3 Service authentication

Use separate opaque service credentials for at least:

```text
CMS -> HAL commands/mappings/reconciliation
HAL -> CMS authoritative facts
HAL -> CMS diagnostic traces
```

Do not reuse:

- customer access tokens;
- driver tokens;
- admin tokens;
- public API keys;
- one-use charging credentials.

Secrets are never included in OpenAPI examples, traces, logs, issue transcripts, or browser configuration.

Constant-time bearer comparison SHOULD be used where applicable.

## 20.4 Correlation and idempotency headers

Every mutating cross-service call uses:

```http
Idempotency-Key: <canonical durable mutation identity>
X-Correlation-ID: <canonical request/correlation uuid>
```

For command creation, `Idempotency-Key` equals the canonical `cms_command_id` carried in the body.

For fact/trace delivery, `Idempotency-Key` equals the immutable fact/event identity.

CMS-generated request/correlation identity is the service-to-service correlation authority. Clients may have their own request IDs for UI diagnostics but MUST NOT be able to choose cross-service business command identity.

## 20.5 Canonical internal API surface

The Charger-on-Wheels HAL v1 contract uses the following canonical service-only routes. These names are part of the blueprint and MUST change only through an explicit contract revision.

### CMS -> HAL

```text
PUT  /v1/mappings/chargers/{cms_charger_id}
POST /v1/remote-commands/start
POST /v1/remote-commands/stop
GET  /v1/remote-commands?cms_command_id={uuid}
GET  /v1/transactions?cms_start_intent_id={uuid}
GET  /v1/transactions/{hal_transaction_id}
```

Generic administrative charger operations use a separate service surface:

```text
POST /v1/charger-operations
GET  /v1/charger-operations?cms_operation_id={uuid}
```

Charging start/stop and generic administrative operations remain separate because their semantic completion truths differ.

### HAL -> CMS

```text
POST /internal/v1/hal-facts
POST /internal/v1/hal-trace-events
```

The HAL calls those paths on the private CMS service origin. They are not registered in the public User/Driver/Admin route groups.

A batch fact endpoint is optional only if it preserves per-fact immutable identity, response semantics, and retry isolation. Do not introduce batching merely for appearance.

## 20.6 Cross-service response semantics

`202` from HAL means the logical command is durably accepted/known by HAL according to the command contract. It never means:

- protocol command was accepted by the charger;
- transaction started;
- transaction completed;
- charging energy flowed;
- customer payment is final;
- ServiceJob is complete.

Stable error categories:

| HTTP | Meaning | Automatic behavior |
| --- | --- | --- |
| 400 | malformed envelope/header/identity/timestamp/integer | fix request; no blind retry |
| 401/403 | bad service identity or scope | repair auth/config first |
| 404 | exact durable resource absent | apply resource-specific reconciliation rule; never guess |
| 409 | idempotency/integrity/correlation/state conflict | stop automatic mutation and reconcile |
| 410 | command/credential/window expired | do not revive automatically |
| 422 | semantic mapping/connector/limit invalid | correct source state |
| 429/500/502/503/504 | transient service/capacity/transport | retry same immutable identity only where operation's replay rules permit; otherwise exact-ID reconcile |

## 20.7 Immutable CMS command record

CMS stores an immutable dispatch envelope before HAL I/O.

For start/stop it includes, as relevant:

```text
cms_command_id
kind
start_intent_id / charging_session_id
service_job_id
charger_id
connector_id
dispatch_charger_protocol_identity
dispatch_connector_number
request_digest
correlation_id
idempotency_key
command_expires_at
requested limits + provenance
created_at
```

A database guard or service-level invariant MUST prevent an attempted command's frozen destination/immutable input from being edited into a different physical action.

## 20.8 CMS start request exact sequence

The intended cross-repo sequence is:

```text
User/Driver action
-> CMS auth and ServiceJob authorization
-> validate current assignment/duty/assets/compatibility
-> ensure exact HAL mapping exists
-> CMS transaction:
     freeze charging commercial/admission terms
     create any required funding reservation
     create one-use credential
     create ChargingStartIntent REQUESTED
     create immutable CMS START command record
-> commit
-> reconfirm exact mapping revision/destination
-> RequestStart to HAL using same cms_command_id
-> project returned durable HAL command state
-> return start-progress object, not a ChargingSession unless already materialized concurrently

later:
HAL protocol RemoteStart accepted/rejected/ambiguous
-> command.updated fact / exact lookup can update command/start-progress

later:
charger-originated transaction start
-> HAL transaction.started immutable fact
-> CMS validates entire identity chain
-> create ChargingSession ACTIVE exactly once
-> start intent ACTUALLY_STARTED
-> ServiceJob CHARGING when field-service transition is valid
-> durable operational event
-> User/Driver/Admin projections refresh
```

## 20.9 CMS stop request exact sequence

```text
User/Driver/Admin/system stop request
-> authorize against existing materialized ChargingSession
-> create/reuse durable ChargingStopRequest and STOP command
-> RequestStop to HAL using exact cms_command_id
-> project durable HAL command state
-> session ACTIVE/STOP_PENDING
-> return accepted-stop-progress

later:
charger-originated transaction completion
-> HAL transaction.completed fact
-> CMS validates exact transaction identity/final meter/time
-> locked exactly-once session finalization + commercial settlement
-> ServiceJob wrap-up transition only when other operational invariants permit
```

An exact HAL lookup returning a missing STOP command does not prove the physical transaction stopped. A materialized session remains open/reconciling until transaction evidence says otherwise.

## 20.10 HAL fact ingress transaction

CMS fact ingestion ordering:

1. authenticate the HAL fact service bearer;
2. validate `Idempotency-Key == fact_id`;
3. validate schema version and envelope;
4. recompute immutable canonical digest;
5. begin DB transaction;
6. lock/read existing fact receipt by `fact_id`;
7. exact same digest -> idempotent success;
8. same ID/different digest -> integrity conflict, no projection change;
9. validate mapping and identity chain for the fact type;
10. insert immutable receipt;
11. apply monotonic projection/business transition;
12. insert durable operational/domain event when state actually changes;
13. commit;
14. only then return success to HAL.

A receiver crash before COMMIT results in HAL retrying the same fact. A receiver crash after COMMIT but before HTTP response results in a duplicate that becomes a no-op success.

## 20.11 Monotonic runtime projection

CMS maintains projections with explicit sequence and freshness:

```text
charger connection:
  state
  connection_sequence
  observed_at

connector status:
  status
  connector_status_sequence
  observed_at

session meter:
  meter_sequence
  meter_value_wh
  consumed_wh
  observed_at

session SoC:
  soc_sequence
  soc_percent
  observed_at
```

Only advancing sequence updates the current projection.

A delayed old fact remains evidence but cannot move the UI backward.

Freshness is derived at read time or through a rebuildable projection using configured stale horizons. A stale connection makes retained connector/meter/SoC evidence historical rather than fresh.

## 20.12 Runtime reads never synchronously depend on HAL

Ordinary User, Driver, and Admin list/detail/live reads query CMS durable projections.

They MUST NOT synchronously call HAL for:

- customer live job screen;
- charging history;
- driver current job screen;
- fleet list;
- charger list;
- meter display;
- connector availability list.

Exact HAL reads are reconciliation/technical operations, not ordinary presentation dependencies.

This keeps UI available during HAL outage and prevents N+1 provider calls.

## 20.13 Operational events and realtime

When an authoritative CMS transaction changes a projection, CMS writes notification-sized durable operational events in the same transaction.

Representative event types:

```text
service_job.changed
dispatch.changed
driver.location.changed
charger.live_state_changed
connector.live_state_changed
charging.command_changed
charging.session_changed
charging.meter_changed
charging.soc_changed
payment.changed
invoice.changed
support.changed
```

Events tell consumers that state changed. They are not the state authority.

## 20.14 Exact-ID reconciler ownership

A CMS reconciler owns unresolved cross-service truth.

It handles at least:

- start command ambiguity;
- accepted start with missing transaction-start fact;
- open materialized session with missing completion fact;
- generic charger operation ambiguity;
- mapping synchronization retry.

Requirements:

- bounded batch;
- stable cursor/fair ordering;
- persistent backoff/recovery-after time;
- no unbounded goroutine per row;
- no new logical command identity for recovery;
- poison row isolation;
- structured safe diagnostics;
- stop/shutdown joins worker before DB close.

## 20.15 Mapping reconciler

Mapping synchronization is its own durable concern.

States SHOULD include:

```text
PENDING
SYNCHRONIZED
RECONCILIATION_REQUIRED
DISABLED / RETIRED where appropriate
```

Inventory edits commit CMS first. Mapping delivery occurs post-commit and can fail independently.

A failed mapping never causes CMS to silently rewrite local inventory to match stale HAL state.

## 20.16 Restart and outage behavior

### CMS restart

- durable start/stop/operation/fact state survives;
- unresolved rows remain unresolved;
- reconcilers resume from durable cursor/backoff;
- no command is replayed simply because the process restarted;
- User/Driver/Admin recover current state through CMS REST/snapshot APIs.

### HAL restart

- durable command/transaction/fact/outbox state survives;
- possibly sent commands become reconciliation candidates, not replay candidates;
- prior connection projection becomes unknown until new connection evidence arrives;
- active transaction recovery uses protocol/device evidence where possible;
- fact delivery resumes with same immutable fact IDs.

### CMS unavailable while HAL continues

- HAL retains authoritative facts in its outbox;
- it retries with same identity;
- physical transaction handling/deadline safety continues according to HAL-owned workflow;
- no CMS availability assumption is allowed to corrupt OCPP lifecycle.

### HAL unavailable while CMS continues

- CMS read surfaces remain available from durable projections with stale/unknown truth shown honestly;
- new charging starts fail/queue according to explicit admission policy, never pretend success;
- active-session stop intent is retained/retried/reconciled without declaring physical completion;
- business settlement waits for authoritative completion evidence.

## 20.17 Cross-repository contract tests

The new project MUST have versioned consumer/provider fixtures so contract drift is found without relying only on deployed end-to-end tests.

At minimum:

```text
CMS request fixture -> HAL request parser
HAL response fixture -> CMS parser
HAL fact fixture -> CMS fact ingestor
CMS mapping fixture -> HAL mapping store
exact command lookup fixtures
exact transaction lookup fixtures
error/status fixtures
immutable digest fixtures
```

CI should run these in both repositories against the same versioned fixture package/artifact or duplicated generated fixture with digest/version verification.

## 20.18 Full virtual charger acceptance

Before calling charging integration complete, a disposable CMS PostgreSQL + HAL PostgreSQL + virtual charge point test proves:

```text
CMS inventory/mapping
-> HAL mapping synchronized
-> ServiceJob start-eligible
-> ChargingStartIntent committed
-> HAL start command durably accepted
-> protocol start accepted
-> charger-originated transaction start
-> CMS ChargingSession materialized
-> connection/status projection fresh
-> meter facts ordered
-> optional SoC independent
-> stop request
-> physical completion
-> exactly-once finalization
-> invoice/payment/commercial result consistent
-> User REST/history consistent
-> Driver live/history consistent
-> Admin projection consistent
-> restart/outage reconciliation converges
```

Also prove:

- lost start response;
- command exact-lookup absent/present;
- delayed start fact;
- late start after local expiry/rejection;
- missing completion fact recovered by exact transaction lookup;
- duplicate fact;
- altered same-ID fact conflict;
- out-of-order meter;
- HAL restart during active charge;
- CMS outage during meter/completion;
- generic charger operation does not starve automatic stop worker;
- realtime disconnect does not lose recoverability.

Physical charger acceptance is a separate later gate and MUST be reported separately from virtual integration success.

---

# 29. Realtime Blueprint

## 29.1 Purpose

Realtime improves responsiveness. It does not replace durable HTTP state.

## 29.2 Subscription scope

A client may subscribe only to resources it is authorized to read.

Suggested channels/topics:

```text
user:{customer_id}
job:{service_job_id}
driver:{driver_id}
duty:{duty_session_id}
admin:operations
admin:hal
```

Server authorization derives IDs from auth context and resource permissions. Clients cannot subscribe to arbitrary user/driver topics by guessing IDs.

## 29.3 Event envelope

```json
{
  "event_id": "...",
  "type": "service_job.updated",
  "resource_type": "service_job",
  "resource_id": "...",
  "occurred_at": "...",
  "version": 17,
  "request_id": "...",
  "data": { }
}
```

For important state, `data` may be only a compact projection. REST remains recovery authority.

## 29.4 Ordering

Per-resource version or sequence is recommended so clients can detect missed/out-of-order events.

Clients receiving version 15 after version 17 ignore stale data.

A gap can trigger REST refresh.

## 29.5 User realtime

User may receive:

- request/quote expiry;
- dispatch progress;
- assignment;
- driver/mobile unit public projection;
- ETA/location updates;
- arrival;
- charging readiness;
- physical charging start;
- live energy/power/SoC where available;
- projected cost;
- charging end;
- wrap-up/completion;
- payment/invoice changes;
- support updates.

## 29.6 Driver realtime

Driver may receive:

- schedule changes;
- offer created/withdrawn/expired;
- assignment changes;
- job/customer service-location projection;
- admin correction of pairing;
- HAL readiness/fault state;
- charging state;
- compensation calculation completion;
- support/incident updates.

## 29.7 Admin realtime

Admin may receive broad operational invalidations/projections by capability:

- online drivers;
- duty sessions;
- locations;
- dispatch queues;
- jobs;
- asset mismatch;
- charger/HAL connectivity;
- faults;
- payment exceptions;
- invoice failures;
- support/incident queues.

Do not push secrets or full sensitive records over a generic operations stream.

# 34. API Consumer Contracts and Projection Rules

## 34.1 User projection

User job projection may expose:

- job number/status;
- service location snapshot;
- own vehicle snapshot;
- public driver identity subset after assignment;
- public service vehicle identity subset;
- ETA/location only while operationally relevant;
- charging metrics;
- pricing/payment/invoice state;
- own support/rating.

It MUST NOT expose:

- driver KYC;
- driver phone/email unless explicitly required by product policy;
- Admin identities;
- internal dispatch scores;
- raw HAL traces;
- internal incident notes;
- internal compensation.

## 34.2 Driver projection

Driver may see only data necessary for current/own work:

- assigned customer display/contact information required for service;
- exact service location/instructions;
- customer vehicle snapshot;
- charging preference;
- job/payment information only to the extent operationally required;
- own compensation.

Driver MUST NOT see full customer account/security history.

## 34.3 Admin projection

Admin receives data by capability and need, not one giant universal object.

High-sensitivity KYC, payment, raw trace, and audit data should have separately authorized endpoints/fields.

---

# 35. Idempotency Matrix

At minimum, these operations require durable idempotency or stable operation identity:

| Operation | Mechanism |
| --- | --- |
| Quote acceptance / ServiceJob creation | `Idempotency-Key` |
| Driver duty start | `Idempotency-Key` + unique active-duty constraint |
| Driver offer accept | offer identity + transactional winner |
| Driver job transition actions | action idempotency / current-state same-result semantics |
| Charging start | `Idempotency-Key` -> `ChargingStartIntent` -> immutable `cms_command_id` -> one HAL start command |
| Charging stop | `Idempotency-Key` -> `ChargingStopRequest` -> immutable `cms_command_id` -> one HAL stop command; completion still requires physical completion evidence |
| Payment order creation | `Idempotency-Key` + provider order identity |
| Payment verification/webhook | provider event/payment identity |
| Refund | `Idempotency-Key` + provider refund identity |
| Invoice generation intent | unique invoice/job/version key |
| Support reply | `Idempotency-Key` |
| Notification/outbox delivery | outbox row/event identity |
| HAL fact ingest | immutable `fact_id` |
| HAL start/stop command | immutable `cms_command_id` plus durable `hal_command_id`; retry/reconcile same identity |
| Generic administrative HAL operation | immutable `cms_operation_id` plus durable HAL operation identity; no automatic replay after possible delivery |
| Promotion of temp vehicle/address | `Idempotency-Key` / unique promotion record |
| Compensation finalization | unique job/assignment calculation version |
| Compensation adjustment | `Idempotency-Key` |

Idempotency records MUST have a retention policy long enough to cover realistic mobile retry behavior and external provider retries.

---

# 36. Concurrency and Transaction Boundaries

## 36.1 Database as concurrency authority

Use PostgreSQL constraints/locking for invariants that must survive multiple API instances.

Do not rely on process mutexes for cross-instance business invariants.

## 36.2 Required protected races

Must explicitly handle:

- two duty starts for same driver;
- two drivers claiming same vehicle;
- two drivers claiming same charger;
- two offer acceptances;
- driver accepts offer while Admin reassigns/cancels;
- customer cancels while driver accepts;
- charging start retried during unknown HAL delivery;
- duplicate HAL transaction/fact;
- simultaneous payment callback + webhook;
- simultaneous rating PUT;
- simultaneous policy activation;
- invoice worker duplicate claim;
- compensation worker duplicate finalization.

## 36.3 Row locking

Use `SELECT ... FOR UPDATE` or equivalent narrowly around mutable aggregate roots where transition serialization is required.

Avoid holding DB transactions open across slow external network calls.

Correct pattern:

1. transactionally create durable intent/claim;
2. commit;
3. perform external I/O;
4. transactionally record outcome;
5. reconcile uncertainty asynchronously if needed.

## 36.4 Outbox atomicity

Any external side effect that must correspond to a committed business mutation is enqueued in the same DB transaction as that mutation.

No pattern of "commit DB, then maybe remember to send notification" is allowed for critical side effects.

---

# 37. Durable Domain Events and Outbox

## 37.1 Event purpose

Domain events support:

- realtime invalidation;
- notifications;
- projections;
- asynchronous commercial workflows;
- audit correlation;
- integration with HAL/provider workers.

They do not replace normalized domain tables.

## 37.2 Event envelope

```text
id
aggregate_type
aggregate_id
event_type
occurred_at
actor_type
actor_id nullable
request_id
payload_version
payload jsonb
```

## 37.3 Important CMS events

Examples:

```text
DriverApplicationSubmitted
DriverApproved
DriverSuspended
DriverDutyStarted
DriverDutyEnded
AssetMismatchReported

ServiceRequestCreated
QuoteCreated
QuoteAccepted
ServiceJobCreated
DispatchStarted
DispatchOfferCreated
JobAssigned
JobReassigned
DriverEnRoute
DriverArrived
ServicePreparationStarted
ServiceJobChargingStarted
ServiceJobChargingEnded
ServiceJobCompleted
ServiceJobCancelled
ServiceJobFailed

ChargingStartIntentCreated
ChargingStartCommandStateChanged
ChargingSessionMaterialized
ChargingStopRequested
ChargingCommandStateChanged
ChargingMeterObserved
ChargingSoCObserved
ChargingSessionCompleted
ChargingReconciliationRequired

PriceFinalized
PaymentCaptured
PaymentFailed
RefundSucceeded
InvoiceReady

CompensationCalculated
CompensationAdjusted

SupportTicketCreated
SupportReplyAdded
IncidentOpened
IncidentResolved
```

## 37.4 Event payload discipline

Events contain only what downstream consumers need plus stable identifiers.

Avoid duplicating complete mutable entities or sensitive data into every event.

Payloads are versioned.

---

# 38. Background Workers

Initial CMS worker set SHOULD be explicit and independently observable:

1. **Outbox dispatcher**: claims domain/notification work.
2. **Realtime publisher**: publishes authorized projections/invalidations from committed events.
3. **Notification delivery worker**: push/email/SMS providers.
4. **Dispatch scheduler/retry worker**: scheduled-job dispatch windows and retry when no candidates.
5. **Payment reconciliation worker**: provider status for uncertain/pending payment operations.
6. **Invoice generation worker**.
7. **Compensation finalization/reconciliation worker**.
8. **Projection reconciliation worker**: repair/rebuild derived current state if needed.
9. **Retention/cleanup worker**: expires temporary/idempotency/raw location data according to policy.

HAL worker set:

1. connection supervisor;
2. charging command dispatcher;
3. charging deadline/automatic-stop worker;
4. pending charging-stop recovery worker;
5. dedicated sequential generic charger-operation recovery worker;
6. reconnect/transaction reconciliation worker;
7. authoritative fact outbox delivery worker;
8. independent diagnostic trace outbox/retention worker;
9. health/liveness ticker.

The generic charger-operation recovery worker MUST NOT share a sequential execution loop with charging deadline enforcement, automatic stops, or pending charging-stop recovery. Slow Reset/Unlock/diagnostic work cannot delay safety/commercial charging lifecycle work.

Every worker must have:

- bounded batch size;
- claim/lease or transactional ownership;
- retry classification;
- backoff;
- max-attempt/dead-letter visibility where appropriate;
- metrics for pending/oldest age/failures;
- graceful shutdown behavior.

---

# 39. Failure Classification and Recovery

Failures MUST be classified so retries do not make reality worse.

## 39.1 Classes

```text
VALIDATION
AUTHORIZATION
CONFLICT
TRANSIENT_INTERNAL
TRANSIENT_EXTERNAL
TERMINAL_EXTERNAL
OUTCOME_UNKNOWN
INTEGRITY_VIOLATION
```

## 39.2 Retry policy

- Validation/auth/conflict: caller must change state/input; no blind server retry.
- Transient internal: bounded automatic retry if operation is safe/idempotent.
- Transient external before known delivery: bounded retry.
- Outcome unknown after possible physical/payment side effect: reconcile by stable identity before retry.
- Integrity violation: stop, alert, preserve evidence.

## 39.3 Stop conditions

Workers MUST stop automatic retries and surface operational attention when:

- semantic conflict appears;
- same identity maps to conflicting payload;
- repeated failures exceed policy;
- physical command outcome remains unknown beyond reconciliation horizon;
- provider/charger reports impossible transition;
- database constraint indicates an unexpected invariant breach.

---

# 42. Observability Blueprint

## 42.1 Structured logs

All services log structured fields such as:

```text
timestamp
level
service
environment
request_id
trace_id where available
actor_type safe
actor_id safe when appropriate
cms_command_id/cms_operation_id/hal_command_id/hal_transaction_id/fact_id/job_id where relevant
event
error_code
```

No raw request/response bodies by default.

## 42.2 Metrics

CMS metrics should include:

- HTTP rate/latency/error by route template;
- DB pool saturation/latency;
- active duties by status;
- jobs by status and oldest age;
- dispatch attempt success/time-to-assignment;
- offer accept/reject/expire rate;
- stale driver locations;
- payments pending/failed/reconciliation age;
- invoice queue depth/failure;
- notification queue depth/failure;
- compensation backlog/failure;
- support/incident queue age;
- realtime connections/publish failures.

HAL metrics should include:

- connected chargers;
- connection churn;
- stale chargers;
- operations by state;
- oldest queued operation;
- unknown outcomes;
- fact outbox backlog/oldest age;
- reconnect reconciliations;
- protocol errors;
- meter sample rate/drop/invalid counts.

## 42.3 Health and readiness

Each service exposes:

```text
/health/live
/health/ready
```

Liveness means process is alive.

Readiness checks dependencies required to safely accept traffic, without making fragile third-party APIs mandatory if requests can queue/reconcile safely.

## 42.4 Alerts

Alert on actionable conditions, including:

- service down/restart loop;
- DB unavailable;
- worker oldest age exceeds threshold;
- dispatch backlog/assignment time breach;
- payment reconciliation backlog;
- HAL fact backlog;
- charger unknown command outcomes;
- unusually high charger disconnect rate;
- invoice generation repeated failure;
- storage nearing capacity;
- migration/runtime mismatch.

---

# 45. Configuration Blueprint

Configuration is environment-driven with an example key contract.

Categories:

```text
APP_ENV
HTTP_LISTEN_ADDR
PUBLIC_BASE_URL
DATABASE_URL
LOG_LEVEL

AUTH_*
SESSION_*
RATE_LIMIT_*

RAZORPAY_*
PAYMENT_*

HAL_V1_BASE_URL
HAL_V1_CMS_BEARER_TOKEN
HAL_V1_CMS_FACT_BEARER_TOKEN
HAL_V1_TRACE_BEARER_TOKEN
HAL_V1_REQUEST_TIMEOUT
HAL_V1_START_RECONCILE_AFTER
HAL_V1_CONNECTION_STALE_AFTER
HAL_V1_METER_STALE_AFTER
HAL_V1_RECONCILE_INTERVAL

INVOICE_STORAGE_ROOT or object-storage configuration
MAIL_*
PUSH_*

DISPATCH_*
LOCATION_*
SERVICE_AREA_*

OUTBOX_*
WORKER_*

REALTIME_*
```

The HAL repository has its own independent configuration contract. At minimum:

```text
DATABASE_URL
HTTP_LISTEN_ADDR
OCPP_LISTEN_ADDR
CMS_V1_FACTS_URL
CMS_V1_FACT_BEARER_TOKEN
CMS_V1_TRACE_EVENTS_URL
CMS_V1_TRACE_BEARER_TOKEN
FACT_OUTBOX_*
TRACE_OUTBOX_*
COMMAND_WORKER_*
CHARGER_OPERATION_RECOVERY_*
CONNECTION_*
OCPP_*
```

`HAL_V1_CMS_BEARER_TOKEN`, `HAL_V1_CMS_FACT_BEARER_TOKEN`, and `HAL_V1_TRACE_BEARER_TOKEN` are three distinct secret purposes. The CMS-to-HAL command credential MUST NOT be reused for HAL-to-CMS fact or trace delivery.

Rules:

- `.env` never committed;
- `.env.example` contains names and safe descriptions/defaults, never secrets;
- startup validates required configuration;
- no secret values printed in logs;
- pre-deploy key-name parity check detects missing/extra/blank keys safely.

Business pricing/compensation rules belong in versioned database policies, not environment variables.

---

# 47. End-to-End User Flow

## 47.1 Immediate service, normal path

```text
User authenticates
-> chooses saved or temporary EV
-> chooses saved or temporary location
-> chooses charging preference
-> creates ServiceRequest
-> backend validates serviceability
-> backend creates Quote from active PricingPolicy
-> user accepts Quote
-> ServiceJob created with immutable snapshots
-> dispatch attempt starts
-> eligible drivers determined
-> ranked candidate offered
-> driver accepts
-> assignment frozen/current
-> user sees assigned driver/mobile unit
-> driver begins EN_ROUTE
-> driver location updates User/Admin projection
-> driver arrives
-> backend records arrival validation
-> driver enters SERVICE_PREPARING
-> actual charger/connector compatibility revalidated
-> authorized User/Driver policy requests charging start
-> CMS validates job/duty/asset/readiness and commercial admission
-> CMS durably creates ChargingStartIntent + frozen commercial inputs + one-use credential hash + immutable cms_command_id
-> CMS confirms the committed charger/connector mapping and submits that exact start command to HAL
-> start progresses through REQUESTED / ACCEPTED_FOR_DELIVERY / PROTOCOL_ACKNOWLEDGED or RECONCILIATION_REQUIRED; none means charging started
-> authoritative HAL `transaction.started` fact with the exact identity chain arrives
-> CMS materializes exactly one ACTIVE ChargingSession and marks the start intent ACTUALLY_STARTED
-> ServiceJob enters CHARGING from materialized physical-start evidence
-> monotonic meter/SoC/connection/connector facts update durable CMS projections
-> user/driver/admin see CMS projection; realtime is recoverable from REST/snapshot
-> stop request creates one durable ChargingStopRequest/command, or the charger may stop spontaneously
-> RemoteStop acknowledgement leaves the session open
-> authoritative HAL `transaction.completed` fact, or exact completed-transaction reconciliation, finalizes the session exactly once
-> ServiceJob enters WRAP_UP
-> final physical/source facts collected
-> PricingEngine finalizes customer line items
-> payment settlement/reconciliation reaches required boundary
-> invoice generated from frozen facts
-> CompensationEngine calculates driver line items
-> driver completes closeout
-> ServiceJob becomes COMPLETED when completion invariants pass
-> User history/payment/invoice/rating surfaces agree
-> Driver history/earnings agree
-> Admin sees same durable truth through broader projection
```

## 47.2 Scheduled service

Scheduled request adds:

- `requested_for` window;
- dispatch worker begins within configured lead window;
- quote validity/repricing policy explicitly determines whether original quote remains valid until service;
- scheduled dispatch respects driver schedules and asset availability at the target time;
- customer is notified on material assignment/availability changes.

No fake assignment is created hours early merely to reserve appearance of certainty unless an explicit reservation mechanism owns that truth.

---

# 50. Completion Invariants

A ServiceJob may transition to `COMPLETED` only when all applicable invariants are true.

Minimum invariants:

1. Job is in `WRAP_UP`.
2. No active physical charging transaction remains for the job.
3. No `ChargingStartIntent`, `ChargingStopRequest`, or physical-delivery command remains unresolved without an explicit reconciliation disposition. A start in `RECONCILIATION_REQUIRED` blocks replacement start on the same job/asset until exact evidence resolves it; an unresolved stop never allows CMS to claim physical completion. Generic administrative charger-operation ambiguity is tracked separately and blocks job completion only when that specific operation is defined as a safety prerequisite.
4. Final charging metrics have been frozen or explicitly marked unavailable with reason.
5. Final pricing has been calculated or a deliberate zero/exception commercial disposition exists.
6. The current assignment has a closeout disposition.
7. Required driver closeout fields are present.
8. Any mandatory incident/blocking exception is resolved or explicitly transferred to post-service handling.
9. Job history/event write succeeds in the same transaction.

Payment capture and invoice readiness SHOULD NOT be required to mark physical field service complete unless the business explicitly chooses a pre-completion collection rule. Their state remains visible independently.

Driver compensation MAY be calculated asynchronously after completion but must be derived from frozen source facts and eventually converge.

---

# 54. Derived Projections and Rebuildability

Derived projections improve read performance but cannot become hidden sources of truth.

Candidate projections:

- current driver location;
- driver current duty summary;
- current job live projection;
- charger runtime projection;
- admin operations dashboard counters;
- driver earnings summaries;
- customer rating aggregates.

For each projection, document:

- source tables/events;
- update trigger/worker;
- staleness semantics;
- rebuild/reconciliation method;
- what happens if projection update fails.

A failed projection update must not roll back already committed physical/commercial truth unless the projection itself is part of the transaction intentionally.

---

# 57. Testing Strategy

Testing is layered by the kind of claim being made.

## 57.1 Unit tests

Mandatory areas:

- every state transition table;
- customer pricing rule evaluation;
- compensation rule evaluation;
- time-window/interval prorating;
- dispatch eligibility;
- dispatch ranking deterministic tie-break;
- geofence intersection;
- snapshot construction;
- authorization decisions;
- cancellation/no-show rules;
- HAL adapter normalization;
- payment/refund state transitions;
- invoice calculation inputs;
- privacy projection shaping.

## 57.2 PostgreSQL integration tests

Run against explicit disposable PostgreSQL.

Must test:

- migrations from empty DB;
- up/down where down is safe;
- uniqueness/exclusion constraints;
- active DutySession uniqueness;
- asset claim race;
- offer acceptance race;
- idempotency duplicate/conflict;
- outbox atomicity;
- duplicate HAL fact ingest;
- transaction rollback;
- version/optimistic concurrency;
- historical FK behavior;
- policy version immutability.

## 57.3 Service integration

CMS-HAL:

- mapping create/update and post-commit reconfirmation;
- start command durable acceptance without session materialization;
- protocol acknowledgement without session materialization;
- authoritative `transaction.started` materializes exactly one session;
- command explicit rejection;
- HTTP timeout before HAL durable acceptance;
- HTTP timeout after HAL persisted/possibly delivered command;
- exact `cms_command_id` reconciliation and confirmed absence;
- exact `cms_start_intent_id` transaction reconciliation;
- late start fact after rejected/expired intent;
- duplicate identical fact is success/no-op;
- same fact ID with changed digest is integrity conflict;
- out-of-order connection/connector/meter/SoC sequence cannot regress projection;
- stop acknowledgement does not complete session;
- spontaneous charger-originated completion is accepted when identity chain validates;
- missing completion fact recovered by exact `hal_transaction_id` and same finalizer;
- reconnect/restart during active transaction;
- CMS outage while HAL fact outbox accumulates;
- HAL outage while CMS preserves durable intent/session truth;
- generic admin charger operation uses pre-I/O delivery fence and no-replay exact-ID recovery;
- slow generic operation recovery cannot delay charging deadline/automatic-stop worker;
- multiple physical sessions under one ServiceJob.

Payments:

- order retry;
- callback success + webhook duplicate;
- webhook before client verify;
- provider timeout;
- captured payment with lost API response;
- refund timeout/reconciliation.

## 57.4 End-to-end simulator tests

At minimum script these flows:

### E2E-01 happy path saved data

Saved EV + saved address -> quote -> dispatch -> charge -> payment -> invoice -> compensation -> rating.

### E2E-02 temporary customer data

Temporary EV/address -> completed job -> history retains snapshots -> promote both -> old history unchanged.

### E2E-03 scheduled driver

Admin schedule + assigned assets -> driver starts occurrence -> job -> planned vs actual times preserved.

### E2E-04 unscheduled driver

Driver self-starts duty under permitted policy -> selects eligible assets -> receives job.

### E2E-05 pairing mismatch

Admin expects C1, driver observes C2 -> report -> allowed temporary operation -> job uses C2 snapshot -> Admin reconciles later -> old duty remains C2.

### E2E-06 no compatible charger

Nearby drivers exist but connector/capability incompatible -> no invalid offer -> Admin diagnostic explains exclusion.

### E2E-07 start response lost after possible physical success

CMS creates one ChargingStartIntent/command -> HAL durably persists and sends start -> response is lost -> CMS enters `RECONCILIATION_REQUIRED` without a replacement command -> exact command/transaction lookup or immutable `transaction.started` fact proves the same attempt -> exactly one ChargingSession materializes.

### E2E-08 charger fault and restart

Transaction S1 ends unexpectedly -> same ServiceJob remains active -> recovery -> S2 starts -> final billing aggregates eligible facts.

### E2E-09 driver reassignment

D1 en route then breaks down -> assignment closes -> D2 assigned -> one ServiceJob -> compensation split by authoritative intervals.

### E2E-10 customer cancel after dispatch

Cancellation policy line item applied, assignment closed, no charging started, no fake energy/invoice facts.

### E2E-11 customer no-show

Arrival evidence + waiting threshold -> no-show -> policy charge -> compensation rule as configured.

### E2E-12 policy changes mid-job

Pricing and compensation policy edited/activated after job started -> job uses frozen versions defined by snapshot boundary.

### E2E-13 time boundary compensation

Driver work crosses night-rate boundary -> interval-prorated line items match exact minutes/distance basis.

### E2E-14 payment duplicate/recovery

Captured payment, lost response, duplicate webhook -> one captured logical payment.

### E2E-15 realtime disconnect

User/Driver/Admin lose realtime -> reconnect -> REST current state is correct -> subsequent versioned events converge.

## 57.5 Physical hardware acceptance

Before production readiness for a charger model/protocol:

- connect/disconnect;
- remote start/stop;
- transaction IDs;
- meter values;
- SoC if claimed;
- faults;
- reconnect during transaction;
- network loss;
- charger reboot;
- uncertain command outcome;
- connector mapping;
- max power/capability reporting;
- repeated sessions;
- time synchronization behavior;
- vendor deviations.

Simulator acceptance is not physical hardware acceptance.

---

# 58. Verification Gates for Every Work Item

Every meaningful burner/work item has four separate gates.

## Gate A: semantic/design

- scope and non-goals explicit;
- domain owner clear;
- state transition defined;
- persistence/constraints defined;
- authorization defined;
- idempotency defined;
- failure/recovery defined;
- history/realtime/audit impact defined.

## Gate B: source

- formatting/lint;
- focused tests;
- broad unit/integration tests;
- OpenAPI/runtime parity;
- documentation verifier;
- migration checks;
- `git diff --check`;
- no unrelated changes.

## Gate C: integration/runtime

- migrations applied to target environment intentionally;
- service healthy/readiness;
- changed routes behave under auth boundaries;
- workers healthy;
- logs clean of new panics/fatals;
- external integration tested or explicitly marked unverified.

## Gate D: physical/external acceptance where relevant

- real Razorpay provider behavior;
- real email/push provider acceptance;
- real HAL-to-charger behavior;
- real hardware acceptance.

A feature can be source-complete but not physically accepted. The completion statement must say which gate was reached.

---

# 59. CI Pipeline Blueprint

Every repository pull/merge validation SHOULD include, as applicable:

CMS:

```text
format check
go test focused critical packages
go test ./...
go vet ./...
go build ./...
go mod verify
migration parse/check
OpenAPI schema validation
runtime-route vs OpenAPI parity test
documentation verifier
git diff --check
disposable PostgreSQL integration suite
```

HAL:

```text
format check
go test ./...
go vet ./...
go build ./...
go mod verify
migration checks
adapter contract tests
scripted simulator scenarios
CMS-HAL schema compatibility tests
```

Never run DB integration suites against shared development/production databases.

---

# 60. Deployment Blueprint

## 60.1 Deployment order principle

Choose deployment order based on schema/contract compatibility, not habit.

Prefer backwards-compatible additive releases:

1. additive DB migration;
2. deploy code that understands old+new where transition requires;
3. switch behavior/config;
4. remove old support only in later release when safe.

## 60.2 CMS deployment preflight

Before activation:

- verify intended Git SHA;
- clean/understood worktree;
- verify migrations pending/current;
- validate configuration key parity without printing secrets;
- verify disk/storage;
- verify service unit and listener;
- verify reverse proxy routing;
- verify DB backup/recovery plan if schema mutation is consequential;
- build candidate;
- run source verification;
- identify old binary/rollback asset;
- inspect currently active jobs/operations if maintenance may disrupt them.

## 60.3 HAL deployment preflight

Additionally:

- inspect active charger connections;
- inspect active transactions;
- inspect queued/unknown operations;
- confirm restart recovery can reconcile active physical sessions;
- avoid deployment when a known non-recoverable hardware operation is in a dangerous boundary unless necessary.

## 60.4 Activation

Use managed service deployment/rehost procedure.

Do not improvise kill/start commands when a controlled framework exists.

## 60.5 Post-deploy verification

CMS:

- service active/restart count;
- local/public health/readiness;
- OpenAPI/Swagger;
- migration ledger;
- worker health/backlogs;
- auth rejection on protected routes;
- changed feature smoke path;
- payment/notification/invoice external boundary if included;
- logs.

HAL:

- service active/restart count;
- internal health/readiness;
- charger reconnection;
- active transaction reconciliation;
- operation queue;
- fact outbox;
- simulator smoke;
- real charger smoke where deployment claims physical acceptance.

## 60.6 Rollback

Rollback decision considers:

- whether schema down is safe;
- whether new historical rows make destructive down unsafe;
- whether a forward fix is safer;
- active physical transactions;
- payment/invoice facts created by new release.

Binary rollback must never be described as complete if database/state semantics are incompatible with the older binary.

---

# 61. Backup, Recovery, and Disaster Principles

## 61.1 CMS database

- automated backups;
- tested restore procedure;
- pre-migration backup for high-risk schema/data changes;
- retention appropriate to business/legal importance;
- periodic restore drill.

## 61.2 HAL database

HAL persistent operations/facts are operational evidence and need backups as appropriate.

However, recovery design must also tolerate losing rebuildable connection projections while preserving operation/fact integrity.

## 61.3 Artifact storage

Invoice/KYC/export storage requires backup/retention consistent with database references.

Database restore without corresponding artifacts must be detectable, not silently produce broken downloads.

Store checksums and perform integrity checks.

---

# 64. Exact Implementation Program

The implementation sequence below converts architecture into buildable burners. It intentionally front-loads contracts and stable primitives that later domains depend on.

## Program 0 - Repository and engineering authority

### B00.1 CMS repository bootstrap

Deliver:

- Go module/repo structure;
- config loader;
- structured logging;
- graceful shutdown;
- health/readiness;
- PostgreSQL connection;
- migration command;
- request IDs;
- base error contract;
- OpenAPI serving/Swagger;
- CI baseline;
- AGENTS/project docs.

Exit gate: clean empty service deploys to dev, migration 1 applies, OpenAPI/runtime route test passes.

### B00.2 HAL repository bootstrap

Deliver same platform foundations separately, plus protocol adapter interfaces and simulator skeleton.

Exit gate: HAL dev service runs independently, simulator adapter can connect logically, CMS-HAL auth contract stub works.

### B00.3 Disposable integration DB harness

Deliver isolated PostgreSQL test database orchestration for CMS and HAL.

Exit gate: concurrency/migration tests can run without touching shared dev DB.

---

## Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

### B01.1 Account/session authentication

Customer/Driver/Admin principal separation, session revocation/refresh, security tests.

### B01.2 Admin capability engine

Capability catalog, role bundles, effective authorization, explicit endpoint middleware.

### B01.3 Audit foundation

Append-only audit API/service and Admin query.

### B01.4 Durable idempotency primitive

Reusable idempotency storage/response binding for HTTP mutations.

### B01.5 Durable outbox and worker framework

Claim/lease/retry/backoff/metrics with one harmless test event.

Exit gate: later domains use these primitives instead of inventing local variants.

---

## Program 2 - Customer master data

### B02.1 Customer profile
### B02.2 Saved vehicles
### B02.3 Saved addresses/default handling
### B02.4 Snapshot schemas/builders
### B02.5 Temporary object and promotion behavior

Exit gate: API can create saved/temporary data, snapshot it, edit master data, and prove historical snapshot immutability.

---

## Program 3 - Driver recruitment and workforce

### B03.1 Driver application lifecycle
### B03.2 Secure document storage + versioned KYC review
### B03.3 Driver profile creation/onboarding
### B03.4 Eligibility engine + blocking reasons
### B03.5 Suspension/reinstatement/offboarding

Exit gate: an applicant can progress end-to-end and only an ACTIVE eligible driver reaches operational APIs.

---

## Program 4 - Fleet and inventory

### B04.1 Vehicle inventory/history
### B04.2 Charger inventory/connectors
### B04.3 Pairing history
### B04.4 Maintenance/lifecycle intervals
### B04.5 Admin asset assignment
### B04.6 Derived availability projection

Exit gate: Admin can answer current and historical vehicle/charger/assignment questions without overwriting history.

---

## Program 5 - Scheduling, duty, location

### B05.1 Schedules and materialized occurrences
### B05.2 DutySession lifecycle
### B05.3 Exclusive asset claim constraints/concurrency tests
### B05.4 Driver asset mismatch reporting
### B05.5 Break/availability intervals
### B05.6 Location ingestion/current projection/freshness
### B05.7 Driver geofence and effective area

Exit gate: scheduled and unscheduled eligible drivers can start duty safely, become dispatchable, move, pause, and end duty with exact asset history.

---

## Program 6 - Service request, pricing foundation, ServiceJob core

### B06.1 ServiceRequest
### B06.2 Serviceability validation
### B06.3 First production slice of the final pricing interface
### B06.4 Quote acceptance -> ServiceJob snapshots
### B06.5 ServiceJob state machine/event history
### B06.6 Cancellation/no-show reason framework

Exit gate: customer can create a job independent of dispatch and history is correct.

---

## Program 7 - Dispatch

### B07.1 Eligibility engine
### B07.2 Ranking engine
### B07.3 DispatchAttempt/Candidate persistence
### B07.4 Sequential offer workflow
### B07.5 Atomic offer acceptance
### B07.6 Assignment and Driver current-job contract
### B07.7 Reassignment
### B07.8 No-candidate retry/scheduled dispatch worker
### B07.9 Admin diagnostics/direct assignment

Exit gate: simulator drivers/duties can be dispatched under race, rejection, expiry, reassignment, and no-candidate tests.

---

## Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

This program begins only after CMS charger/connector identity and the internal contract version are frozen enough that both repositories can implement against the same fixtures. It may run in parallel with late dispatch work, but not before the identifier crosswalk and mapping semantics in Sections 18-20 are settled.

### B08.1 HAL repository/bootstrap contract

- independent Go module/service/database;
- configuration loader with fail-safe production PostgreSQL requirement;
- health/readiness split;
- migration runner/explicit migration command;
- structured logging with secret/body exclusions;
- worker lifecycle and graceful shutdown framework.

Exit: empty HAL starts against disposable PostgreSQL, migrations apply, readiness reflects DB/worker health, shutdown joins workers.

### B08.2 CMS-HAL service authentication

- distinct CMS->HAL command bearer;
- distinct HAL->CMS fact bearer;
- distinct HAL->CMS trace bearer;
- constant-time credential validation where applicable;
- no human/customer token reuse;
- configuration parity/docs/tests.

Exit: each credential can call only its intended plane; cross-use fails.

### B08.3 Charger/connector mapping registry

- `PUT /v1/mappings/chargers/{cms_charger_id}` or final equivalent;
- exact CMS charger/connector UUIDs;
- protocol identity and connector-number mapping;
- enabled state and optional expected serial;
- idempotent same-content replay;
- conflicting immutable identity change semantics;
- CMS durable mapping state + post-commit reconciler.

Exit: mapping create/replay/conflict/recovery pass across both services.

### B08.4 Connection runtime and restart fencing

- tracked transport connection identity;
- process-scoped generation guard for stale callbacks;
- durable connection sequence;
- startup projection to UNKNOWN until new evidence;
- Heartbeat/liveness renewal;
- connection fact outbox;
- CMS monotonic projection/freshness.

Exit: connect, stale disconnect callback, heartbeat, HAL restart, reconnect, delayed old fact all converge correctly.

### B08.5 Connector status runtime

- mapped protocol status ingestion;
- monotonic connector status sequence;
- parent connection freshness overlay;
- CMS historical-vs-live distinction;
- inventory eligibility overlay.

Exit: Available/Preparing/Charging/Finishing/Faulted/offline/stale scenarios produce truthful CMS projection.

### B08.6 Durable HAL command store and start/stop lifecycle

Implement exact states from Section 19.4:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED
OCPP_REJECTED
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Include immutable request digest, exact CMS command identity, destination, expiry, attempts, result/error category, optional resulting transaction IDs, and database guards.

Exit: crash at every boundary cannot cause an unsafe replay.

### B08.7 One-use charging credential and OCPP authorization bridge

- CMS generation/hash persistence;
- HAL durable start-command value handling/redaction;
- OCPP 1.6 idTag translation;
- Authorize/StartTransaction correlation;
- expiry using trusted HAL receipt time and bounded charger clock-skew handling;
- replay prevention.

Exit: valid credential starts once; expired/replayed/wrong-mapping credential fails without identity leakage.

### B08.8 OCPP 1.6 transaction materialization

- charger-originated StartTransaction only;
- Central System exact transaction ID allocation;
- durable HAL transaction row;
- exact command/start-intent/credential/mapping chain;
- one immutable `transaction.started` fact reservation in the same durable operation.

Exit: RemoteStart accepted without StartTransaction never materializes transaction; duplicate StartTransaction cannot create a second logical transaction.

### B08.9 MeterValues normalization

- cumulative integer Wh selection;
- accepted-measurand rules;
- exact HAL transaction binding;
- monotonic meter sequence;
- consumed Wh relative to accepted start meter;
- invalid/decreasing/out-of-order evidence handling;
- immutable `transaction.meter` facts;
- optional instantaneous measurements kept non-authoritative.

Exit: valid, duplicate, delayed, decreasing, malformed, and unrelated meter samples are covered.

### B08.10 Independent SoC normalization

- OCPP SoC extraction when present;
- canonical decimal percent 0..100;
- independent SoC sequence/time;
- SoC-only fact allowed;
- no energy invention/cached SoC replay.

Exit: missing SoC remains unknown and energy/SoC streams cannot regress one another.

### B08.11 Stop workflow and automatic limit sources

- remote stop request persistence;
- spontaneous/local stop support;
- energy limit;
- duration limit;
- funding/commercial safety threshold only as an opaque CMS-derived bound;
- explicit threshold provenance;
- shared controlled idempotent stop workflow;
- no pricing/GST/payment interpretation in HAL.

Exit: customer/driver/admin/system/local/threshold stops preserve requested-vs-protocol provenance.

### B08.12 Transaction completion truth

- exact active transaction identity check;
- StopTransaction ordering;
- nondecreasing final meter;
- documented one-Wh quantization normalization only if retained/tested;
- duplicate/conflicting terminal evidence handling;
- canonical row-lock order;
- exactly one terminal fact aggregate.

Exit: retransmitted StopTransaction cannot produce duplicate completion fact; conflicting evidence enters reconciliation.

### B08.13 Durable fact outbox

- immutable fact envelope + canonical digest;
- per-fact idempotency identity;
- lease/claim token;
- retry/backoff;
- same identity on retry;
- stale worker fencing;
- terminal receiver error classification;
- poison isolation;
- worker health/readiness.

Exit: CMS outage/restart and HAL worker crash preserve exactly the same logical facts.

### B08.14 CMS fact ingress and projection transaction

- separate fact bearer;
- `Idempotency-Key == fact_id` validation;
- canonical digest recomputation;
- durable receipt/dedupe;
- same-ID altered-content conflict;
- type-specific mapping/identity checks;
- monotonic connection/connector/meter/SoC projection;
- session materialization/completion integration seam;
- operational event emitted in same CMS transaction.

Exit: crash-before/after commit, exact replay, altered replay, delayed sequence, unsupported fact all behave deterministically.

### B08.15 Exact command and transaction reconciliation APIs

- exact command GET by `cms_command_id`;
- exact transaction GET by `cms_start_intent_id`;
- exact transaction GET by `hal_transaction_id`;
- strict response shape/identity validation;
- canonical 404 semantics;
- no "latest" lookup.

Exit: CMS can recover start ambiguity and missing completion without direct HAL DB access or a new command.

### B08.16 Generic administrative charger operation boundary

Implement separate Reset/Unlock/Availability/diagnostic operation surface with frozen immutable destination and exact operation identity.

CMS states:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

HAL preserves pre-network replayability and post-attempt ambiguity rules.

Exit: generic operation uncertainty never mutates charging/commercial truth and never blindly replays.

### B08.17 Isolated charger-operation recovery worker

- independent from deadline/automatic-stop/pending-stop workers;
- bounded fair rotation across connected chargers;
- same atomic claim/dispatcher as immediate operation;
- request-detached bounded result persistence;
- shutdown cancellation/join;
- restart classification of attempted work to reconciliation.

Exit: intentionally slow admin OCPP command cannot delay charging stop deadline processing.

### B08.18 Diagnostic trace plane

- separate trace envelope/outbox/worker/bearer;
- sanitized CALL/CALLRESULT/CALLERROR evidence;
- bounded follow-on diagnostic windows if retained;
- CMS trace store/read capability;
- hard guarantee trace failure cannot block fact worker or mutate lifecycle state.

Exit: trace receiver outage has zero authoritative charging effect.

### B08.19 Scriptable simulator

Source-controlled scenarios cover every Section 19.18 case and expose deterministic timing/failure knobs.

Exit: CI can reproduce all command/fact/reconnect/ambiguity scenarios without physical hardware.

### B08.20 Cross-repository contract fixtures

- request/response/fact/error fixtures;
- canonical digest fixtures;
- schema version fixtures;
- CMS parser tests against HAL provider fixtures;
- HAL parser tests against CMS consumer fixtures;
- fixture version/digest guard.

Exit: incompatible drift fails CI before deployment.

Program 8 exit gate: disposable CMS + HAL PostgreSQL and virtual charger prove mapping, start command durability, real transaction start, meter/SoC, stop/completion, fact idempotency, restart/outage recovery, generic-operation worker isolation, and exact-ID reconciliation. This gate is not physical charger acceptance.

---

## Program 9 - CMS charging integration and app projections

### B09.1 Charging admission model

- ServiceJob/assignment/duty/asset authorization;
- compatibility revalidation;
- mapping prerequisite;
- frozen pricing/tax/admission context;
- selected funding-safety strategy integration without hard-coded wallet assumption;
- one-use credential generation;
- database constraints.

### B09.2 ChargingStartIntent state machine

Implement exact states/transitions from Section 18.6 plus DB/service guards and history/audit.

### B09.3 Immutable CMS START command record

Freeze command ID, start intent, HAL destination, connector number, request digest, correlation, expiry, limits/provenance before HAL I/O.

### B09.4 Start orchestration and post-commit mapping reconfirmation

Implement the exact sequence in Section 20.8, including safe cleanup when the post-commit mapping prerequisite fails before RequestStart.

### B09.5 Start ambiguity reconciler

- exact command lookup;
- confirmed-absence cleanup;
- exact transaction-by-start-intent lookup after threshold;
- late evidence handling;
- durable cursor/backoff/fairness;
- no blind new start.

### B09.6 `transaction.started` -> ChargingSession materialization

- full identity chain validation;
- exactly one session per start intent;
- exact HAL/protocol transaction IDs;
- ServiceJob transition to CHARGING only when legal;
- operational event/realtime invalidation.

### B09.7 Meter/SoC CMS projection

- independent sequences/freshness;
- accepted fact receipts;
- historical observation retention;
- user/driver/admin safe projections;
- stale parent connection semantics.

### B09.8 Charging stop request

- actor policy for Driver/User/Admin/system;
- durable stop request/command;
- optional bounded reason;
- `STOP_PENDING` projection;
- no completion from HAL/OCPP command acknowledgement.

### B09.9 `transaction.completed` finalization

- full identity/meter/time validation;
- requested-vs-protocol stop provenance;
- exactly-once session completion;
- final pricing source binding;
- payment/funding settlement seam;
- invoice intent seam;
- ServiceJob WRAP_UP gate;
- durable events.

### B09.10 Missing-completion recovery

- exact HAL transaction lookup by `hal_transaction_id`;
- same locked finalization path as normal fact;
- active/404/unavailable/malformed/conflict behaviors from Section 18.16;
- fair durable cursor.

### B09.11 Multiple ChargingSessions per ServiceJob

- separate start intent/session for later physical restart after prior session ended;
- aggregation for final pricing and compensation;
- UI/history representation;
- no transport-reconnect-induced false split.

### B09.12 Runtime availability and chargeability

- CMS inventory status;
- HAL connection freshness;
- connector protocol status/freshness;
- unresolved occupancy/start/session state;
- compatibility;
- asset mismatch;
- stable machine reason codes.

### B09.13 User charging read/progress contract

Implement Section 31.14-31.19: start progress distinct from session, exact unknown/stale behavior, materialized-session-only history, stop provenance, bounded pagination.

### B09.14 Driver charging contract

Driver Start/Stop/prepare UI consumes the same CMS domain methods and receives explicit requested/accepted/physical/reconciling states. Driver cannot force physical state by status mutation.

### B09.15 Admin technical charging views

Expose safe command/fact/runtime/trace projections with capability boundaries. Diagnostic trace is visibly labeled non-authoritative.

### B09.16 User live-job snapshot/SSE integration

- durable REST snapshot;
- full-replacement live jobs/session stream;
- generic event replay cursor;
- reconnect/token rotation/cursor expiry recovery;
- realtime outage fallback.

### B09.17 End-to-end charging acceptance

Run Section 20.18 matrix plus User/Driver/Admin projection agreement tests.

Program 9 exit gate: a virtual charger can drive a full ServiceJob charging lifecycle while every application sees the same CMS durable truth, all ambiguity is recoverable by exact identity, and no command acknowledgement is mistaken for physical charging state.

---

## Program 10 - Full pricing engine

### B10.1 Versioned pricing policy/rule persistence
### B10.2 Deterministic rule evaluator
### B10.3 Quote estimation line items
### B10.4 Final source-fact binding
### B10.5 Final pricing line items/snapshot
### B10.6 Cancellation/no-show components
### B10.7 Time/date/zone modifiers
### B10.8 Admin policy editor contract

Exit gate: fixed test fixtures prove same inputs + versions produce same result and historical jobs survive policy changes.

---

## Program 11 - Payments, refunds, tax, invoices

### B11.1 Razorpay order/payment integration
### B11.2 webhook/idempotent reconciliation
### B11.3 refund workflow
### B11.4 GST snapshot calculation
### B11.5 invoice renderer/storage/version/checksum
### B11.6 invoice worker/retry/download
### B11.7 mail/notification intent for invoice

Exit gate: provider sandbox/test environment and local artifact flow accepted end-to-end, with external acceptance boundary documented.

---

## Program 12 - Driver compensation

### B12.1 Versioned policy/rules
### B12.2 deterministic evaluator
### B12.3 time-boundary/interval prorating
### B12.4 source-fact binding
### B12.5 line-item ledger
### B12.6 reassignment allocation
### B12.7 adjustments
### B12.8 Driver summary/history
### B12.9 Admin views/exports

Exit gate: fixtures cover base, distance, time, night modifier, date bonus, driver override, minimum, cap, reassignment, and correction.

---

## Program 13 - Product completeness

### B13.1 User ratings/reviews
### B13.2 Customer support
### B13.3 Driver support
### B13.4 Incident management
### B13.5 Notification preferences/delivery
### B13.6 Admin operational dashboard
### B13.7 Async exports
### B13.8 retention/cleanup jobs

---

## Program 14 - Realtime hardening

Realtime basics may exist earlier, but this program makes it complete:

### B14.1 authenticated subscriptions
### B14.2 per-resource versioning
### B14.3 reconnect/catch-up guidance
### B14.4 user projections
### B14.5 driver projections
### B14.6 admin projections
### B14.7 backpressure/disconnect behavior
### B14.8 realtime-vs-REST consistency E2E tests

---

## Program 15 - Production hardening

### B15.1 security review
### B15.2 DB backup/restore drill
### B15.3 worker/backlog alerting
### B15.4 load tests for location/realtime/dispatch
### B15.5 Razorpay production-readiness checks
### B15.6 mail/push production acceptance
### B15.7 physical charger certification matrix
### B15.8 operational runbooks/on-call drills
### B15.9 staging full-day/long-session soak
### B15.10 release/rollback drill

---

## Program 16 - Protocol expansion

Only after core semantics are stable:

### B16.1 OCPP 2.0.1 adapter
### B16.2 adapter parity matrix
### B16.3 OCPP 2.1 if hardware/business requires
### B16.4 vendor-specific extensions behind adapter capability interfaces

Protocol expansion MUST NOT change CMS business semantics unless a genuinely new business capability is introduced deliberately.

---

# 65. Dependency Graph

High-level dependency order:

```text
Repository foundations
  -> auth/capability/audit/idempotency/outbox
     -> customer master data
     -> driver recruitment
        -> fleet
           -> schedule/duty/location
              -> service request/job
                 -> dispatch
                    -> charging integration

HAL foundations
  -> protocol-neutral core
     -> OCPP16/simulator
        -> CMS charging integration

ServiceJob + charging source facts
  -> final pricing
     -> payment/tax/invoice
  -> compensation

Core lifecycle
  -> ratings/support/incidents
  -> realtime completeness
  -> production hardening
```

The first production slice of the final pricing contract may begin before charging, but final pricing requires authoritative source facts.

HAL work can proceed in parallel after charger identity and CMS-HAL semantic contracts are frozen.

---

# 66. Phase Entrance and Exit Criteria

A later program may start only when its upstream semantic contracts are stable enough that proceeding will not force known rework.

Examples:

- Dispatch does not begin before DutySession + asset claim semantics exist.
- Charging integration does not begin before stable ServiceJob/assignment IDs and charger-HAL identity mapping exist.
- Compensation finalization does not begin before source facts/time boundaries are defined.
- Invoice generation does not begin before pricing/tax snapshots are frozen.
- Protocol 2.x adapters do not begin by duplicating OCPP 1.6 code before protocol-neutral core contracts are proven.

Parallel development is allowed when dependencies are interfaces already fixed and independently testable.

---

# 67. Definition of Done - Project Level

The project is not production-ready merely because all endpoints exist.

Production readiness requires:

1. User flow accepted end-to-end.
2. Driver recruitment + operational flow accepted end-to-end.
3. Admin can operate and recover abnormal flows.
4. Dispatch handles eligibility/races/reassignment.
5. Dedicated HAL survives reconnect/restart/uncertain operation tests.
6. At least one target physical charger model is hardware-accepted.
7. Pricing fixtures and real job calculations agree.
8. Razorpay production integration is verified at the intended flow boundary.
9. Refund flow verified.
10. Invoice artifact + download + delivery path verified.
11. Compensation ledger is explainable and stable across policy changes.
12. Realtime reconnects recover from REST.
13. Authorization/privacy tests cover all three human planes.
14. Backups and restore are tested.
15. Deployment/rollback runbook is exercised.
16. Monitoring alerts on critical backlogs/failures.
17. Documentation and OpenAPI match runtime.
18. No known unresolved integrity issue is hidden behind UI workarounds.
19. Known external/unverified boundaries are documented explicitly.

---

# 69. Decisions That Must Be Resolved Before Their Burner

These are genuine external/business/hardware inputs that cannot be truthfully invented in architecture:

1. Exact Charger-on-Wheels physical hardware models and connector configurations.
2. Whether the mobile unit has onboard energy storage and how its SoC/capacity is obtained.
3. Exact customer payment capture strategy supported/desired with Razorpay: upfront, deposit, authorization-like pattern, or post-service collection.
4. Legal/business invoice and GST classification details for mobility/service vs energy components.
5. Required KYC document set and storage/compliance retention requirements.
6. Client platform decisions that affect push provider/device token implementation.
7. Exact navigation/maps provider if server-side ETA/routing is required.
8. Production infrastructure/hostnames/secrets/storage provider.

The implementation program does not wait on these globally. It defers only the burner whose exact behavior depends on them, using explicit interfaces in the meantime.

---

# 71. Final Build Principle

Charger on Wheels must make the normal path easy without forcing abnormal real-world conditions into false data.

The implementation therefore preserves, separately and explicitly:

```text
what Admin intended
what Driver actually used
what the charger physically did
what the customer commercially owes
what the driver compensation engine calculated
what happened historically
what realtime currently projects
```

Then it composes those truths into User, Driver, and Admin experiences through explicit contracts.

The stable center is the ServiceJob. The operational driver context is the DriverDutySession. The physical charging authority is the dedicated HAL. PostgreSQL-backed durable state is the recovery authority. Realtime is an accelerator. Policies are versioned. History is not rewritten for convenience. Physical side effects are never inferred from optimistic UI actions.

That is the implementation blueprint.

---

# Appendix A. Normative State Machine Registry

This appendix is normative. Implementations must not add ad hoc transitions outside these graphs without updating the domain contract, tests, OpenAPI behavior, and this blueprint.

## A.1 DriverApplication

```text
DRAFT
  -> SUBMITTED
  -> WITHDRAWN

SUBMITTED
  -> UNDER_REVIEW
  -> WITHDRAWN

UNDER_REVIEW
  -> ACTION_REQUIRED
  -> APPROVED
  -> REJECTED

ACTION_REQUIRED
  -> SUBMITTED
  -> WITHDRAWN

APPROVED
  -> ONBOARDING

ONBOARDING
  -> ACTIVE

ACTIVE      terminal recruitment success state
REJECTED    terminal recruitment decision
WITHDRAWN   terminal applicant decision
```

Operational suspension/offboarding is not a recruitment-state transition.

## A.2 DriverDutySession

```text
STARTING
  -> AVAILABLE
  -> ABORTED

AVAILABLE
  -> OFFERED
  -> BREAK
  -> UNAVAILABLE
  -> ENDING

OFFERED
  -> ASSIGNED       accepted offer
  -> AVAILABLE      rejected/expired/withdrawn offer

ASSIGNED
  -> EN_ROUTE
  -> AVAILABLE      assignment ended before departure/reassigned/cancelled

EN_ROUTE
  -> AT_CUSTOMER
  -> AVAILABLE      job cancelled/reassigned/failed and assignment ended

AT_CUSTOMER
  -> SERVICING
  -> AVAILABLE      job terminal before service starts

SERVICING
  -> AVAILABLE      job terminal/completed and assignment ended

BREAK
  -> AVAILABLE
  -> ENDING

UNAVAILABLE
  -> AVAILABLE
  -> ENDING

ENDING
  -> ENDED

ABORTED             terminal emergency/failed start state
ENDED               terminal normal state
```

Rules:

- `ENDING` requires no active blocking assignment.
- `ABORTED` from an already operational state is an Admin/system emergency path only and requires active jobs/assets to be reconciled explicitly.
- Offer withdrawal occurs before entering BREAK/UNAVAILABLE if the driver is currently OFFERED.

## A.3 DispatchAttempt

```text
RUNNING
  -> OFFERING
  -> EXHAUSTED
  -> CANCELLED

OFFERING
  -> ASSIGNED
  -> RUNNING         recompute/continue after candidate result
  -> EXHAUSTED
  -> CANCELLED

ASSIGNED             terminal success
EXHAUSTED            terminal no-candidate result for this attempt
CANCELLED            terminal because job no longer needs this attempt
```

## A.4 DispatchOffer

```text
PENDING
  -> ACCEPTED
  -> REJECTED
  -> EXPIRED
  -> WITHDRAWN
```

All terminal. Exactly one ACCEPTED offer can become the current assignment for a given assignment cycle.

## A.5 ServiceJob

```text
DISPATCHING
  -> ASSIGNED         one sequential offer is live
  -> CANCELLED
  -> EXPIRED
  -> FAILED

ASSIGNED
  -> ACCEPTED         selected driver accepts; JobAssignment is created
  -> DISPATCHING      offer rejected/expired/withdrawn before acceptance
  -> REASSIGNING      provisional selection invalidated by operational change
  -> CANCELLED
  -> FAILED

ACCEPTED
  -> EN_ROUTE
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

EN_ROUTE
  -> ARRIVED
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

ARRIVED
  -> SERVICE_PREPARING
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

SERVICE_PREPARING
  -> CHARGING
  -> WRAP_UP          explicit zero-charge/aborted-service closeout only
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

CHARGING
  -> WRAP_UP
  -> FAILED

WRAP_UP
  -> COMPLETED
  -> FAILED

REASSIGNING
  -> DISPATCHING
  -> ASSIGNED
  -> CANCELLED
  -> FAILED

COMPLETED            terminal
CANCELLED            terminal
FAILED               terminal
NO_SHOW              terminal
EXPIRED              terminal
```

No reopening a terminal ServiceJob. Corrections are separate records/workflows.

## A.6 ChargingStartIntent

```text
REQUESTED
  -> ACCEPTED_FOR_DELIVERY
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

ACCEPTED_FOR_DELIVERY
  -> PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

REJECTED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

EXPIRED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

RECONCILIATION_REQUIRED
  -> ACTUALLY_STARTED           exact authoritative transaction evidence
  -> REJECTED                   exact command absence/rejection proves safe terminal result
  -> EXPIRED                    exact absence plus elapsed start window

ACTUALLY_STARTED               terminal for the start-intent state machine
```

No normal ChargingSession exists before `ACTUALLY_STARTED`. RemoteStart/protocol acknowledgement never creates one.

## A.7 ChargingSession and ChargingStopRequest

ChargingSession:

```text
ABSENT
  -> ACTIVE                    only from authoritative `transaction.started` evidence

ACTIVE
  -> STOP_PENDING              durable stop requested; physical transaction still open
  -> RECONCILIATION_REQUIRED  contradictory/missing predecessor/final evidence
  -> COMPLETED                 spontaneous authoritative physical completion is valid
  -> FAILED                    only under explicitly defined non-settleable failure semantics

STOP_PENDING
  -> ACTIVE                    stop command definitively rejected while physical session remains active
  -> RECONCILIATION_REQUIRED
  -> COMPLETED                 authoritative physical completion

RECONCILIATION_REQUIRED
  -> ACTIVE                    exact evidence proves still active
  -> STOP_PENDING              exact evidence proves stop still pending
  -> COMPLETED                 exact completed transaction passes full identity/meter/time validation

COMPLETED                     terminal immutable physical/commercial completion
FAILED                        terminal only when policy explicitly permits; raw evidence remains retained
```

ChargingStopRequest is a separate durable command/request record. A RemoteStop acknowledgement can advance stop-command progress but cannot set the ChargingSession to `COMPLETED`.

## A.8 HAL Start/Stop Command and Generic Charger Operation

HAL charging command:

```text
PERSISTED
  -> PENDING_DELIVERY
  -> EXPIRED

PENDING_DELIVERY
  -> PERSISTED                 startup recovery only while transmission is proven not attempted
  -> DELIVERY_ATTEMPTED

DELIVERY_ATTEMPTED
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> AMBIGUOUS
  -> MATERIALIZED              authoritative start correlation may race command-result bookkeeping

OCPP_ACCEPTED
  -> MATERIALIZED
  -> AMBIGUOUS                 only when later command-result bookkeeping becomes uncertain

OCPP_REJECTED
  -> MATERIALIZED              contradictory later physical start is reconciliation evidence, never silently discarded

AMBIGUOUS
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> MATERIALIZED
  -> EXPIRED                   only when exact evidence proves no physical materialization and contract permits terminalization

SUPERSEDED / EXPIRED / MATERIALIZED are non-dispatchable.
```

Generic administrative charger operations use the separate CMS dispatch states:

```text
PERSISTED
-> DISPATCH_CLAIMED
-> DELIVERY_ATTEMPTED
-> HAL_ACCEPTED | OCPP_CONFIRMED | RECONCILIATION_REQUIRED | CONFIRMED_ABSENT
```

A deadline or process restart MUST NOT make `DELIVERY_ATTEMPTED`, `HAL_ACCEPTED`, `AMBIGUOUS`, or `RECONCILIATION_REQUIRED` replayable. Exact-ID evidence resolves uncertainty.

## A.9 Payment

```text
CREATED
  -> PENDING
  -> FAILED
  -> CANCELLED

PENDING
  -> AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

CAPTURED
  -> REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED

REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED
  -> CAPTURED          refund attempt failed; captured payment remains

PARTIALLY_REFUNDED
  -> REFUND_PENDING
  -> REFUNDED

FAILED                terminal payment attempt
CANCELLED             terminal payment attempt
REFUNDED              terminal fully refunded state
```

Provider events may arrive out of order. Transition logic uses provider identity and reconciled facts, not arrival order alone.

## A.10 Refund

```text
REQUESTED
  -> SUBMITTED
  -> CANCELLED

SUBMITTED
  -> SUCCEEDED
  -> FAILED

SUCCEEDED             terminal
FAILED                terminal for this refund operation; a new reconciled retry uses controlled identity semantics
CANCELLED             terminal
```

## A.11 Invoice

```text
PENDING
  -> GENERATING
  -> VOIDED

GENERATING
  -> READY
  -> FAILED

FAILED
  -> GENERATING       explicit retry
  -> VOIDED

READY
  -> VOIDED           only if business/legal process permits; artifact remains historical

VOIDED                terminal
```

READY artifact bytes are immutable.

## A.12 PricingPolicy and CompensationPolicy

```text
DRAFT -> ACTIVE -> RETIRED
```

A RETIRED policy is not reactivated. Create/activate a new version instead.

## A.13 SupportTicket

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> OPEN | CLOSED
CLOSED -> OPEN
```

Same-state mutation is side-effect-free.

## A.14 Incident

```text
OPEN
  -> INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

MITIGATED
  -> INVESTIGATING
  -> RESOLVED
  -> CLOSED

RESOLVED
  -> CLOSED
  -> INVESTIGATING    explicit reopen with reason

CLOSED
  -> INVESTIGATING    explicit reopen with reason
```

Reopen events are auditable.

## A.15 AssetMismatchReport

```text
MISMATCH_REPORTED
  -> ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

CONFIRMED_CORRECTION -> RESOLVED
EXPECTED_RESTORED    -> RESOLVED
REASSIGNED           -> RESOLVED
REJECTED_REPORT      -> RESOLVED
RESOLVED             terminal
```

---

# Appendix B. Mandatory Database Constraints and Indexes

Application validation improves errors. PostgreSQL constraints preserve truth under concurrency.

## B.1 Identity/session

- unique normalized login identifier according to chosen auth strategy;
- session token identifiers unique;
- revoked/expired session indexes for cleanup;
- admin role/capability foreign keys;
- no capability name duplicates.

## B.2 Customer

- `customer_profiles.account_id` unique;
- active saved vehicle belongs to exactly one customer;
- active saved address belongs to exactly one customer;
- partial unique index: at most one active default address per customer;
- registration number uniqueness is not globally assumed for incomplete/temporary customer metadata unless business verification requires it.

## B.3 Driver

- `driver_profiles.account_id` unique;
- one driver profile per source application unless explicit migration path says otherwise;
- only one nonterminal application per account if repeat applications are not supported;
- licence/document identifiers may have uniqueness checks where legally/business appropriate, with careful privacy handling.

## B.4 Fleet

- service vehicle registration number unique among non-retired canonical inventory;
- charger asset tag unique;
- charger serial number unique where manufacturer serial is trusted/required;
- HAL identity unique among active charger mappings;
- `(charger_id, connector_number)` unique;
- no overlapping active exclusive charger-to-vehicle pairing periods when physical exclusivity applies.

## B.5 Duty/claims

- partial unique: one nonterminal DutySession per driver;
- partial unique: one unreleased exclusive vehicle claim per vehicle;
- partial unique: one unreleased exclusive charger claim per charger;
- claim foreign key to active DutySession;
- one open break/unavailability interval of the same incompatible class if semantics require.

## B.6 Dispatch

- `dispatch_attempts(service_job_id, attempt_number)` unique;
- one candidate row per attempt + duty session;
- one offer identity unique;
- one live provisional offer per ServiceJob in the initial sequential strategy;
- one current accepted/active assignment enforced through serialized job update + partial unique current-assignment constraint;
- offer acceptance cannot reference a different driver/duty than the offer row.

## B.7 ServiceJob

- `job_number` unique;
- immutable ownership customer ID after creation unless a dedicated migration/correction framework explicitly exists;
- current assignment FK nullable but must point to same ServiceJob, enforced using composite unique/FK pattern where practical;
- event IDs unique;
- event transition data check constraints for required fields where practical.

## B.8 Charging

- ChargingStartIntent idempotency unique in actor/job/start-attempt scope;
- at most one unresolved start intent for the same ServiceJob + effective charger/connector when policy forbids parallel starts;
- one immutable `cms_command_id` per logical start or stop command;
- one durable `hal_command_id` maps to only its originating CMS command identity;
- one-use charging credential hash is unique and cannot be rebound to another start intent;
- HAL `fact_id` unique; same fact ID with different immutable digest/content is an integrity violation, never overwrite;
- accepted fact receipt and its CMS projection/event commit atomically;
- connection, connector, meter, and SoC projections advance only on their own monotonic sequences;
- one `hal_transaction_id` and one exact OCPP transaction ID chain cannot materialize multiple CMS ChargingSessions;
- one ChargingSession belongs to exactly one ServiceJob, while one ServiceJob may own multiple sequential ChargingSessions;
- meter observation dedupe uses immutable fact/sample identity and sequence, not timestamp alone;
- completed session final meter cannot regress below accepted start/latest eligible cumulative meter except the explicitly documented one-Wh quantization normalization rule if that rule is implemented;
- generic administrative charger-operation dispatch destination/parameters become immutable before possible delivery.

## B.9 Pricing

- policy version unique per policy lineage/name as modeled;
- no mutation of ACTIVE/RETIRED rule version through normal update API;
- no overlapping ACTIVE policy effective windows for the same global scope unless the engine explicitly supports scoped multiple policies;
- finalized line items immutable.

## B.10 Payments/refunds

- provider order ID unique when non-null;
- provider payment ID unique when non-null;
- provider webhook event ID unique;
- idempotency key unique in actor/operation scope;
- refund provider reference unique when non-null;
- database or transactional check prevents cumulative successful/pending refundable amount from exceeding captured amount.

## B.11 Invoice

- one active canonical invoice per ServiceJob/document type unless version/corrective-document semantics explicitly allow more;
- READY invoice has non-null storage ref, checksum, renderer version, issued timestamp;
- artifact metadata immutable after READY except delivery metadata.

## B.12 Compensation

- one finalized compensation snapshot per ServiceJob + assignment + calculation version;
- line item belongs to snapshot driver/job;
- finalized line items immutable;
- adjustments append only.

## B.13 Rating

- unique `(service_job_id, customer_id)`;
- rating check `1 <= rating <= 5`.

## B.14 Support

- channel/owner checks ensure CUSTOMER_PLATFORM requires customer owner and no driver owner;
- DRIVER_PLATFORM requires driver owner and no customer owner;
- message actor ownership is tied to ticket owner where applicable;
- reply idempotency key unique within ticket/actor scope.

## B.15 Query indexes

Create indexes from actual query plans, but baseline indexes must support:

- jobs by status + updated/created time;
- jobs by customer/driver/current assignment;
- duty sessions by driver/status;
- active claims by asset;
- location projection by geospatial search strategy;
- schedules/occurrences by driver/time;
- offers by driver/status/expiry;
- payments by job/status/provider IDs;
- invoices by job/status;
- compensation by driver/date/job;
- support by owner/status/updated time;
- incidents by status/severity/job/asset;
- HAL facts by charger/time/transaction;
- HAL operations by charger/state/created time.

Use PostGIS only if geospatial complexity/query scale justifies it. If adopted, make it an explicit project dependency and use proper geography indexes rather than handwritten distance SQL everywhere.

---

# Appendix C. Canonical Error Code Registry

HTTP status and machine error code are both part of the contract.

## C.1 Common

```text
400 INVALID_REQUEST
400 VALIDATION_FAILED
401 UNAUTHENTICATED
403 FORBIDDEN
404 RESOURCE_NOT_FOUND
409 VERSION_CONFLICT
409 IDEMPOTENCY_KEY_REUSED
409 STATE_CONFLICT
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE
```

Privacy-sensitive ownership failures SHOULD use `404 RESOURCE_NOT_FOUND` instead of revealing that another user's resource exists.

## C.2 Driver/duty

```text
409 DRIVER_NOT_ELIGIBLE
409 DRIVER_ALREADY_ON_DUTY
409 DUTY_NOT_ACTIVE
409 DUTY_HAS_ACTIVE_JOB
409 VEHICLE_ALREADY_CLAIMED
409 CHARGER_ALREADY_CLAIMED
409 ASSET_NOT_OPERATIONAL
409 ASSET_PAIRING_MISMATCH_BLOCKED
409 CHARGER_HAL_IDENTITY_UNKNOWN
409 DRIVER_LOCATION_STALE
```

## C.3 Dispatch/job

```text
409 OFFER_EXPIRED
409 OFFER_NO_LONGER_AVAILABLE
409 JOB_NOT_ASSIGNABLE
409 JOB_INVALID_TRANSITION
409 JOB_ALREADY_TERMINAL
409 JOB_HAS_ACTIVE_CHARGING
422 NO_ELIGIBLE_DRIVER
422 CUSTOMER_LOCATION_UNSERVICEABLE
422 CUSTOMER_VEHICLE_INCOMPATIBLE
```

`NO_ELIGIBLE_DRIVER` may be represented as job/dispatch state rather than direct request failure depending on operation.

## C.4 Charging/HAL

```text
409 CHARGING_ALREADY_ACTIVE
409 CHARGING_NOT_ACTIVE
409 CHARGING_START_IN_PROGRESS
409 RECONCILIATION_REQUIRED
409 HAL_COMMAND_IDEMPOTENCY_CONFLICT
409 HAL_FACT_INTEGRITY_VIOLATION
409 HAL_START_EVIDENCE_CONFLICT
409 CHARGING_STOP_IN_PROGRESS
410 CHARGING_START_EXPIRED
422 CHARGER_CAPABILITY_UNSUPPORTED
422 CONNECTOR_INCOMPATIBLE
503 HAL_UNAVAILABLE
503 CHARGER_MAPPING_UNAVAILABLE
```

## C.5 Payments/invoices

```text
409 PAYMENT_ALREADY_CAPTURED
409 PAYMENT_AMOUNT_MISMATCH
409 REFUND_EXCEEDS_REFUNDABLE_AMOUNT
409 REFUND_ALREADY_IN_PROGRESS
422 PAYMENT_VERIFICATION_FAILED
503 PAYMENT_PROVIDER_UNAVAILABLE
409 INVOICE_NOT_READY
409 INVOICE_ALREADY_READY
```

## C.6 Policies

```text
409 POLICY_VERSION_CONFLICT
409 POLICY_EFFECTIVE_RANGE_CONFLICT
409 ACTIVE_POLICY_IMMUTABLE
422 RULE_CONFIGURATION_INVALID
```

---

# Appendix D. Initial Operational Defaults and Knobs

These values are implementation defaults, not eternal business rules. They live in validated configuration or Admin policy and can be changed without changing semantics.

## D.1 API

```text
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100
DEFAULT_TIMEZONE=Asia/Kolkata
```

## D.2 Dispatch

Initial normal strategy:

```text
SEQUENTIAL
```

`DIRECT_ASSIGNMENT` is an explicit Admin action. `BATCHED` is not implemented initially.

No hard-coded offer timeout or scheduled dispatch lead time is mandated by architecture because those materially affect field operations. They MUST be explicit configuration before shared staging is enabled. Startup should reject an environment that enables dispatch without required timing values.

Required knobs:

```text
DISPATCH_OFFER_TTL_SECONDS
DISPATCH_RETRY_MIN_SECONDS
DISPATCH_RETRY_MAX_SECONDS
SCHEDULED_DISPATCH_LEAD_MINUTES
DISPATCH_MAX_LOCATION_AGE_SECONDS
ARRIVAL_VALIDATION_RADIUS_METERS
```

## D.3 Location

Client reporting cadence is a mobile-product/battery tradeoff, so the server defines freshness/maximum ingest rate, while Driver App chooses cadence within contract.

Server MUST reject abusive/implausible rates and accept batch recovery for offline periods.

## D.4 Workers

Every worker has configurable:

```text
BATCH_SIZE
POLL_INTERVAL
LEASE_DURATION
MAX_ATTEMPTS or terminal policy
BACKOFF_MIN
BACKOFF_MAX
```

No worker may use an unbounded immediate retry loop.

## D.5 Realtime

Required knobs:

```text
MAX_CONNECTIONS_PER_ACCOUNT
HEARTBEAT_INTERVAL
CLIENT_IDLE_TIMEOUT
MAX_OUTBOUND_QUEUE_PER_CONNECTION
```

Backpressure disconnects a slow client rather than consuming unbounded memory. Client recovers with REST.

---

# Appendix E. Operational Recovery Playbooks

These are behavioral playbooks. Exact shell commands belong in environment-specific operations docs.

## E.1 Driver app loses connectivity while en route

1. Server keeps assignment/job authoritative.
2. Location becomes stale after configured threshold.
3. Admin sees stale-location warning.
4. Driver app reconnects and fetches current duty/job via REST.
5. Buffered valid location samples may upload in batch.
6. No assignment is automatically cancelled solely because one realtime socket dropped.
7. Escalation/reassignment follows dispatch operations policy if staleness exceeds business threshold.

## E.2 Driver app loses connectivity during charging

1. HAL continues owning physical charger truth independently of Driver App.
2. CMS continues ingesting HAL facts.
3. User/Admin can still see charging projection if CMS/HAL links remain healthy.
4. Reconnected Driver App fetches job/charging state.
5. Never infer stop/start from Driver App reconnect state.

## E.3 CMS temporarily unavailable during active charging

1. HAL persists operation/transaction/facts locally.
2. Charger session continues according to physical/protocol reality.
3. HAL fact outbox retries delivery.
4. CMS restart recovers database state.
5. HAL delivers missed facts idempotently.
6. CMS reconciles transaction links/projections.
7. No new physical command is replayed unless operation identity proves it safe.

## E.4 HAL restarts during active charging

1. HAL reconnect supervisor restores charger connection.
2. Protocol adapter reconciles active transaction state.
3. Existing stable HAL transaction is recovered or a reconciliation record explains identity change where protocol makes exact restoration impossible.
4. CMS receives no duplicate semantic start if same transaction is proven.
5. Raw evidence links restart/reconnect chain.

## E.5 Start command times out

1. CMS marks the existing ChargingStartIntent/command `RECONCILIATION_REQUIRED` when RequestStart may have crossed the boundary.
2. Keep the original `cms_command_id`, hold/reservation, start intent, one-use credential binding, and immutable destination evidence. Do not create a replacement start automatically.
3. Reconcile `GET /v1/remote-commands?cms_command_id={uuid}` by the exact original command identity.
4. If HAL returns the exact command, project that command state and continue waiting/reconciling for authoritative transaction evidence.
5. If HAL returns canonical `404` for that exact durable command and CMS proves no materialized session exists, atomically release only the still-reserved commercial hold/reservation and terminalize the intent `REJECTED` or `EXPIRED` according to its window.
6. For an accepted/unmaterialized start past the reconcile threshold, query `GET /v1/transactions?cms_start_intent_id={uuid}`. A matching transaction uses the same locked materializer as a normal `transaction.started` fact.
7. Any non-404 lookup failure or conflicting/malformed evidence keeps reconciliation state; it never becomes absence by timeout.
8. Late physical-start evidence after `REJECTED`/`EXPIRED` is retained and moves the attempt into reconciliation rather than silently fabricating a normal session.
9. If unresolved beyond the operational horizon, alert Technical Admin while continuing safe exact-ID recovery according to retention policy.

## E.6 Payment API response lost after capture

1. Keep logical payment identity/provider order.
2. Do not create a second charge automatically.
3. Reconcile provider state by provider identity/webhook/API.
4. Mark CAPTURED idempotently if proven.
5. User client retry returns same logical payment result.

## E.7 Invoice generation fails

1. Payment/job truth remains untouched.
2. Invoice stays FAILED/PENDING with error classification.
3. Worker retries retryable renderer/storage errors.
4. Admin sees failure and may explicitly retry.
5. READY is never set without verified artifact metadata/checksum.

## E.8 No drivers available

1. DispatchAttempt becomes EXHAUSTED.
2. Job remains truthfully unassigned/dispatching subject to policy.
3. User receives availability/delay state.
4. Retry worker reevaluates fresh candidates, not stale ranking.
5. Admin sees reason/age.
6. Job expires only under explicit policy/deadline.

## E.9 Assigned driver breaks down

1. Driver reports problem/incident.
2. Current assignment ends with reason.
3. Duty becomes UNAVAILABLE or ends depending reality.
4. Job enters REASSIGNING.
5. New dispatch attempt selects another eligible duty.
6. Historical assignment remains.
7. Compensation uses facts attributable to each assignment.

## E.10 Customer location changes after assignment

1. User cannot silently overwrite ServiceJob service-address snapshot.
2. Submit relocation/change request.
3. Backend assesses serviceability, price impact, and current assignment feasibility.
4. If accepted, create an explicit address-change event/new operational snapshot version while preserving original request snapshot.
5. Requote/reassign if required.
6. If not supported initially, customer must cancel and create a new request; API says so explicitly.

The initial implementation SHOULD choose one of these semantics before enabling mid-job relocation. Do not silently mutate coordinates.

---

# Appendix F. Acceptance Evidence Matrix

A claim of completion should name evidence level.

| Claim | Minimum evidence |
| --- | --- |
| Domain implemented | source + unit tests |
| DB invariant enforced | disposable PostgreSQL integration test |
| API contract implemented | OpenAPI/runtime parity + auth tests |
| Worker reliable | retry/lease/integration tests + runtime backlog metrics |
| CMS-HAL command flow works | service integration test |
| OCPP adapter works logically | scripted simulator acceptance |
| Charger model works physically | real hardware acceptance |
| Payment flow works | provider test/live acceptance at claimed boundary |
| Refund works | provider acceptance |
| Invoice generation works | generated artifact checksum + authorized download |
| Email/push works | provider accepted delivery request; do not claim recipient read |
| Deployment works | target runtime health + changed-feature smoke + logs |
| Rollback works | exercised compatible rollback/recovery path |
| Production ready | project-level Definition of Done plus all critical external boundaries accepted |

---

# Appendix G. Blueprint Change Control

Once implementation starts, this blueprint itself follows change discipline.

A semantic change must identify:

1. reason/new evidence;
2. affected actors;
3. affected state machines;
4. persistence/migration impact;
5. API/OpenAPI impact;
6. worker/realtime impact;
7. security/privacy impact;
8. historical compatibility;
9. rollout/rollback plan;
10. affected tests/docs;
11. whether existing mobile/frontends remain compatible.

Do not update only this document while leaving runtime semantics unchanged, and do not change runtime semantics without updating the authoritative contract set.

