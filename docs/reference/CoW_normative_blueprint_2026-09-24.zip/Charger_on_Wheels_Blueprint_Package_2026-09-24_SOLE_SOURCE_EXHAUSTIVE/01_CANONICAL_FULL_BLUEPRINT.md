# Charger on Wheels
## Complete Product, Backend, HAL, Data, Operations, and Delivery Blueprint

**Status:** Sole-source core implementation authority / build blueprint  
**Prepared:** 2026-09-24  
**Scope:** Charger on Wheels platform CMS/backend, dedicated charger HAL, User application contract, Driver application contract, unified Admin application contract, data model, workflows, operations, deployment, verification, and delivery program.  
**Package contract:** This file is the only normative design source required to build the project before repository-native contracts exist. The complete supplied planning baseline and EV-CMS continuity source are retained inside this ZIP as non-normative provenance snapshots. No prior chat, external handoff file, or old EV-CMS/HAL repository is required to discover a Charger-on-Wheels requirement.

**Source hydration:** This edition incorporates the supplied consolidated Charger-on-Wheels planning baseline, the supplied EV-CMS Go New full continuity handoff, and the previous Charger-on-Wheels blueprint package. Mature EV-CMS/HAL behavior is preserved here only where it is semantically applicable. Historical repository SHAs remain provenance facts, not dependencies. Charger-on-Wheels owns its own contracts, code, databases, deployment, and recovery.

---

# 0. How to Use This Document

This is not a pitch, product brochure, architecture sketch, or backlog dump. It is the intended engineering authority for taking Charger on Wheels from an agreed plan to an implementable system.

A team should be able to use this document to answer, before writing code:

- What each actor is allowed to do.
- Which service owns each truth.
- Which records are mutable master data and which records are immutable history.
- Which state machines exist and what transitions are legal.
- Which database records must exist.
- Which invariants must be enforced by PostgreSQL rather than only by application code.
- Which API surfaces must exist for User, Driver, Admin, and HAL integration.
- Which mutations require idempotency.
- What happens when networks, workers, payments, chargers, drivers, or APIs fail halfway through an operation.
- Which side effects are durable and replayable.
- What clients may infer from realtime events and what they must recover through REST.
- How pricing and compensation are calculated and frozen.
- How a ServiceJob relates to dispatch, charging transactions, payment, invoice, compensation, rating, support, and incidents.
- How to deploy, verify, roll back, recover, and prove a change is complete.
- In what order the project should actually be built.

## 0.1 Authority order

Before the first Charger-on-Wheels repository exists, the **normative package set** is the sole design authority:

1. this `01_CANONICAL_FULL_BLUEPRINT.md` for product/domain architecture, ownership, invariants, state machines, implementation program, and cross-domain semantics;
2. `normative/10_...` through `normative/46_...` for exact scoped mechanics that this core blueprint explicitly incorporates by reference;
3. machine-readable `registries/` and `schemas/` when they restate an exact registry/schema owned by the core or a normative annex.

Conflict rule before implementation: this core blueprint wins on fundamental domain semantics and ownership; the most specifically scoped normative annex wins on mechanics inside its declared `Owns:` scope **only when it does not contradict the core**. A machine registry/schema must agree with its owning prose. Any detected conflict is a package defect and MUST be corrected before implementation proceeds. Provenance snapshots and focused views are never normative.

After implementation exists, observed system truth can supersede stale design text for claims about behavior that has actually been implemented. Use this order:

1. observed current runtime/database/physical evidence for claims about what is actually running or physically happening;
2. current repository source and immutable/applied migrations for implemented behavior;
3. current machine-readable repository contracts, especially OpenAPI and CMS-HAL schemas, when verified to match source/runtime;
4. current repository-native human contracts/tests/work items that agree with 1-3;
5. this ZIP's normative package set for intended semantics and behavior not yet implemented.

No old chat, external handoff, old repository, or omitted design note is an authority tier. If implementation intentionally changes a package semantic, the change is not complete until the affected source, migrations/constraints, machine contracts, human contracts, tests, repository state docs, and the normative package set are reconciled.

## 0.2 Language convention

Normative terms:

- **MUST / MUST NOT**: correctness or product invariant.
- **SHOULD / SHOULD NOT**: strong engineering default; deviation requires a documented reason.
- **MAY**: supported optional behavior or policy knob.
- **Derived**: computed from other authoritative state and not itself the durable authority.
- **Snapshot**: immutable historical representation captured at a boundary in time.
- **Fact**: observed or accepted durable evidence, not UI intent.

## 0.3 Core completion rule

A feature is complete only when the domain semantics, persistence, constraints, API contract, authorization, idempotency, failure behavior, recovery, observability, tests, documentation, consumer guidance, and runtime evidence agree.

Compilation is not completion. A 200 response is not physical charger proof. Outbox insertion is not mail delivery. Payment intent creation is not payment settlement. Command acceptance is not charging start.

## 0.4 Sole-source package contract

This ZIP MUST be sufficient to bootstrap and continue the project without retrieving the two supplied source documents, old chat history, EV-CMS, the mature HAL repository, or a corporate-shuttle repository merely to discover required semantics.

Therefore:

- every requirement needed for Charger-on-Wheels correctness MUST exist in this core blueprint or a normative annex explicitly incorporated by Section 0.1;
- source snapshots retained in the ZIP are evidence/provenance only and are never a hidden second authority;
- focused manuals are convenience views and MUST NOT introduce unique normative requirements;
- `registries/` and `schemas/` make repeated exact vocabularies/contracts mechanically consumable and MUST remain synchronized with their owning normative prose;
- external repositories MAY be consulted for code examples or historical reasoning, but their behavior is not inherited unless stated in the normative package set;
- implementation-time external facts that cannot truthfully be known yet are listed explicitly in Section 69 and Annex 27 and block only the burner that genuinely needs them;
- if a future engineer discovers a required semantic only in an external source, that semantic MUST first be promoted into the normative package set through package/repository change control before implementation relies on it.

This rule makes absence meaningful: behavior absent from the normative package set, not derivable from an explicit contract there, and not an observed runtime fact after implementation begins is not silently required merely because an older system happened to do it.

## 0.5 Evidence vocabulary

Completion and review notes MUST distinguish evidence classes instead of using a generic "verified" claim:

- `SOURCE_VERIFIED`: source/contracts statically inspected.
- `TEST_VERIFIED`: automated tests executed and passed.
- `DB_VERIFIED`: real disposable PostgreSQL behavior/constraints exercised.
- `SERVICE_VERIFIED`: inter-service behavior exercised across CMS/HAL or provider boundary.
- `RUNTIME_VERIFIED`: deployed process, configuration, migrations, health, workers, and routes checked.
- `PROVIDER_VERIFIED`: external provider accepted the intended operation, such as Razorpay/SMTP/push.
- `SIMULATOR_VERIFIED`: end-to-end charger behavior accepted against the project simulator.
- `PHYSICAL_VERIFIED`: real charger/mobile-unit behavior physically observed.
- `INFERRED_UNVERIFIED`: reasoned expectation without the relevant execution evidence.

A stronger evidence class does not automatically imply a different boundary. For example, `RUNTIME_VERIFIED` CMS health does not prove `PHYSICAL_VERIFIED` charging.

---

# 1. Product Definition

Charger on Wheels is a mobile EV charging field-service platform.

A customer requests charging at a real-world location. The platform identifies a compatible operational driver/mobile charging unit, dispatches it, tracks movement and arrival, controls charging through a dedicated charger HAL, records physical charging evidence, settles customer commercial obligations, calculates driver compensation, creates invoices, and exposes the complete lifecycle to User, Driver, and Admin applications.

The platform is one business platform, not a CPO marketplace and not a multi-tenant EV-CMS product.

## 1.1 First-class product surfaces

There are exactly three human application planes:

1. **User**: customer-facing mobile/web product.
2. **Driver**: workforce and field-operation product.
3. **Admin**: unified internal administration and operations product.

There is no CPO-vs-SuperAdmin product split.

## 1.2 First-class machine service

There is one separately deployed charging-control service:

4. **Dedicated HAL**: protocol-neutral charger connection, command, transaction, metering, recovery, and raw-evidence authority.

## 1.3 Central objects

- Central business object: **ServiceJob**.
- Central driver runtime object: **DriverDutySession**.
- Central physical charging authority: **Dedicated HAL**.
- Central customer commercial snapshot: **PricingSnapshot** attached to a ServiceJob/quote/finalization boundary.
- Central driver compensation snapshot: **CompensationSnapshot** attached to finalized source facts.

A ServiceJob may outlive an assignment, contain more than one ChargingSession, and contain more than one physical HAL transaction.

---

# 2. Explicit Non-Goals

The current system MUST NOT implement the following unless scope is explicitly changed:

- CPO tenancy.
- SuperAdmin/CPO product separation.
- Customer charging-network roaming.
- Selling this backend as a generic multi-tenant CPO CMS.
- Driver payout execution through Razorpay Route or equivalent.
- Driver linked-account onboarding for payouts.
- Automated external wage/payout transfer retries.
- Treating calculated driver compensation as paid money.
- Route/seat/stop semantics from the corporate shuttle product where they do not apply.
- Protocol-specific OCPP request names in CMS business APIs.
- A shared database between CMS and HAL.

The absence of payout execution does not prevent compensation calculation, ledgers, adjustments, summaries, exports, or later accounting integration.

---

# 3. Architectural Laws and Invariants

These rules are global and must hold across every module.

## 3.1 Separate different kinds of truth

The system MUST preserve these as distinct concepts:

- Administrative/intended state.
- Observed real-world operational state.
- Physical charger/protocol truth.
- Historical snapshot state.
- Customer commercial truth.
- Driver compensation truth.
- Derived/realtime projections.

No convenience field may silently collapse them.

Examples:

- Admin pairing says Vehicle V1 carries Charger C1.
- Driver reports Vehicle V1 actually carries Charger C2.
- Current duty may proceed with observed C2 if policy permits.
- Admin sees a mismatch requiring reconciliation.
- Master pairing remains unchanged until deliberately corrected.
- Historical duty remains permanently tied to the actual observed combination used.

## 3.2 History does not mutate because master data changes

Every historical ServiceJob MUST preserve its own vehicle, service-address, pricing, tax, assignment, and relevant identity snapshots.

Every DriverDutySession MUST preserve its actual vehicle/charger context.

Every finalized compensation result MUST preserve the policy/rule versions and source facts used.

Every invoice MUST preserve the commercial facts used to create it.

Editing a CustomerVehicle, CustomerAddress, ServiceVehicle, Charger, pricing policy, compensation policy, driver profile, or admin assignment later MUST NOT rewrite historical records.

## 3.3 Physical charging truth comes from HAL facts

UI intent, CMS command dispatch, socket write success, or charger command acceptance MUST NOT be represented as a physical charging start.

Physical charging start requires normalized HAL transaction evidence.

Energy delivered requires normalized meter evidence.

Physical charging end requires normalized HAL transaction-end evidence or an explicit reconciled equivalent.

## 3.4 Service lifecycle and charging lifecycle are independent

A ServiceJob may be ARRIVED or SERVICE_PREPARING before physical charging starts.

A physical transaction may end while the ServiceJob remains in WRAP_UP.

A charger fault may end one ChargingSession while the same ServiceJob later starts another ChargingSession.

## 3.5 Customer price and driver compensation are separate engines

They may consume overlapping facts, but they MUST have independent policies, snapshots, ledgers, correction semantics, and administrative permissions.

Customer price changes MUST NOT implicitly change driver compensation.

Driver compensation changes MUST NOT change customer invoices.

## 3.6 External mutations are idempotent or reconcilable

Any mutation that can be retried across network boundaries MUST have one of:

- durable idempotency key semantics;
- a stable operation identity plus exact reconciliation;
- a provider-native idempotency mapping stored durably.

In-memory dedupe is never sufficient for externally retried business mutations.

## 3.7 Realtime is advisory, durable state is recoverable

Realtime messages tell clients that state changed and MAY carry a safe projection.

The client MUST be able to recover authoritative current state using HTTP APIs after disconnect/reconnect.

No critical state transition exists only in WebSocket memory.

## 3.8 Feature completeness remains invariant under extension

Adding a new adapter, vehicle type, charger protocol, pricing component, compensation component, user role, or realtime consumer MUST NOT degrade already-supported correctness properties.

Existing paths retain authorization, idempotency, auditability, verification, and documentation guarantees after extension.

## 3.9 Every actor is a real user

Customer, driver, dispatcher, recruiter, finance operator, support operator, technical/HAL operator, read-only observer, automated worker, CMS, HAL, and external payment provider are all first-class actors with explicit contracts and failure modes.

---

# 4. Chosen Technical Shape

## 4.1 CMS/backend

The initial Charger-on-Wheels CMS SHOULD be a modular monolith because the domains are strongly transactional and still one product boundary.

Chosen baseline:

- Go 1.25.
- Gin HTTP stack.
- PostgreSQL as durable truth.
- Versioned SQL migrations.
- OpenAPI 3.x as machine contract.
- Structured JSON logging.
- Durable database outbox workers for externally visible side effects.
- WebSocket or SSE realtime fanout built from durable/authoritative state changes, not as a source of truth.

The implementation MUST keep package boundaries strong enough that later extraction remains possible without changing domain semantics.

## 4.2 HAL

HAL is a separate Go service/repository/process with its own persistence and deployment lifecycle.

It MUST be protocol-neutral in the core and adapter-driven at the edges.

The first physical-protocol adapter is OCPP 1.6 unless hardware requirements force another initial protocol.

OCPP 2.0.1, OCPP 2.1, vendor adapters, and simulator adapters are additive extensions of the same normalized core.

## 4.3 Databases

CMS and HAL MUST use separate PostgreSQL databases and MUST NOT share tables or database credentials.

Cross-service communication uses authenticated HTTP and/or durable callback/fact delivery contracts.

## 4.4 Recommended repositories

Logical repository identities:

- `charger-on-wheels-backend`
- `charger-on-wheels-hal`

The exact Git organization/remote may be chosen during bootstrap. Once created, repository identity becomes part of the deployment contract and must be documented.

---

# 5. System Context and Deployment Topology

## 5.1 Logical topology

```text
User App -----------\
Driver App ----------> Charger-on-Wheels CMS/API -----> PostgreSQL (CMS)
Admin App -----------/          |   |   |
                               |   |   +--> Mail/notification providers
                               |   +------> Razorpay customer payments
                               +----------> Dedicated HAL API
                                              |
                                              +--> PostgreSQL (HAL)
                                              +--> charger WebSocket/OCPP/proprietary links
```

## 5.2 Trust boundaries

- User/Driver/Admin clients are untrusted network clients.
- CMS auth context is authoritative for human identity.
- CMS MUST NOT trust arbitrary client-supplied actor IDs, driver IDs, or admin capability claims.
- HAL is a trusted service only after service-to-service authentication succeeds.
- Charger-provided data is physical evidence but still untrusted input and must be validated/normalized.
- Razorpay/webhook payloads are trusted only after signature verification and replay/idempotency handling.

## 5.3 Environment tiers

At minimum:

- local development;
- shared development/integration;
- staging/pre-production;
- production.

Development and staging MUST use separate databases and separate HAL identities from production.

No production database may be used as an automated test database.

---

# 6. Repository and Module Ownership

Recommended CMS package layout:

```text
cmd/
  api/
  migrate/
  worker/                 # optional split entrypoint later

internal/
  platform/
    config/
    db/
    httpx/
    authn/
    authz/
    idempotency/
    outbox/
    audit/
    observability/
    realtime/

  users/
  customerprofiles/
  customervehicles/
  customeraddresses/

  driverrecruitment/
  drivers/
  schedules/
  duty/
  availability/

  fleet/
  vehicles/
  chargers/
  connectors/
  pairings/
  assignments/
  maintenance/

  dispatch/
  servicejobs/
  locations/

  charging/
  halclient/
  halfacts/

  pricing/
  payments/
  refunds/
  invoices/
  tax/

  compensation/

  ratings/
  support/
  incidents/
  notifications/

  admin/
```

The package names can be refined during bootstrap, but ownership MUST remain domain-oriented rather than one giant handlers/services/models structure.

Recommended HAL layout:

```text
cmd/
  hal/
  simulator/
  migrate/

internal/
  core/
    charger/
    connection/
    capability/
    transaction/
    command/
    metering/
    state/
    faults/
    operations/
    recovery/
    reconciliation/
    facts/
    trace/

  protocols/
    ocpp16/
    ocpp201/
    ocpp21/

  vendors/
  simulator/
  cmsclient/
  platform/
```

---

# 7. Identity, Authentication, Authorization, and Sessions

## 7.1 Principal types

Use distinct authenticated principal types:

- `CUSTOMER`
- `DRIVER`
- `ADMIN`
- `SERVICE`

A customer ID must never be interpreted as a driver/admin user ID even if UUID types are identical.

## 7.2 Accounts - frozen v1 decision

V1 MUST use one credential-bearing `accounts` layer for human authentication while keeping Customer, Driver, and Admin domain principals strictly separate. This is not a shared-role shortcut: it separates "who can authenticate" from "which product plane/domain identity is active."

Durable model:

```text
accounts
account_sessions
account_devices
customer_profiles
driver_profiles
admin_memberships
roles
capabilities
role_capabilities
admin_capability_overrides
```

Rules:

- `accounts.id` is the credential identity and MUST NOT be used as a substitute for `customer_profiles.id`, `driver_profiles.id`, or an Admin membership/principal ID.
- one account MAY legitimately own more than one domain persona over its lifetime; each persona keeps its own lifecycle, eligibility, authorization, and history;
- an authenticated session is plane-scoped and carries the explicit active principal type plus the corresponding domain-principal ID;
- Customer authorization is derived from the authenticated Customer principal, Driver authorization from the Driver principal/eligibility state, and Admin authorization from capability evaluation;
- possession of another profile attached to the same account MUST NOT grant cross-plane access automatically;
- suspension/offboarding of one persona revokes or blocks only the sessions/operations that policy says it should, while full account compromise/security actions MAY revoke all account sessions;
- customer-facing identifiers, driver identifiers, Admin actor identifiers, audit actor IDs, and account IDs remain semantically distinct even when joined internally.

This decision is frozen before B01.1 so later APIs and foreign keys never need to migrate from separate ad-hoc credential stores.

## 7.3 Session requirements

Human sessions MUST support:

- revocation;
- expiration;
- device/session listing;
- refresh rotation if refresh tokens are used;
- server-side invalidation on suspension/offboarding where required;
- last-used metadata without logging secrets.

## 7.4 Admin RBAC

Admin access is capability-based. Role names are convenience bundles only.

Initial role bundles:

- `FULL_ADMIN`
- `OPERATIONS`
- `DRIVER_RECRUITMENT`
- `FINANCE_COMMERCIAL`
- `SUPPORT`
- `TECHNICAL_HAL`
- `READ_ONLY`

Capabilities, not role names, authorize endpoints.

Suggested capability namespace:

```text
users.read
users.manage

drivers.read
drivers.review
drivers.manage
drivers.suspend

fleet.read
fleet.manage
fleet.maintenance
fleet.assign

schedules.read
schedules.manage

dispatch.read
dispatch.manage
dispatch.override

jobs.read
jobs.manage
jobs.cancel
jobs.reassign

charging.read
charging.command
charging.reconcile
charging.trace.read

pricing.read
pricing.manage

payments.read
payments.manage
refunds.manage
invoices.read
invoices.manage

compensation.read
compensation.manage
compensation.adjust

ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage

system.settings.read
system.settings.manage
audit.read
```

V1 supports Admin membership-level capability overrides. Explicit `DENY` overrides role-bundle defaults and any `ALLOW` for the same capability. Authorization uses effective capability evaluation, never role-name checks where a capability exists.

## 7.5 Service authentication - frozen v1 decision

CMS <-> HAL MUST use service credentials independent of human auth.

V1 uses TLS plus three separate high-entropy opaque bearer credentials:

1. CMS -> HAL command/operation plane;
2. HAL -> CMS normalized fact plane;
3. HAL -> CMS diagnostic trace plane.

Rules:

- credentials are configured as secrets, never exposed to User/Driver/Admin clients, committed to source, or written to normal logs;
- each credential is authorized only for its intended plane; cross-use MUST fail;
- validation uses constant-time comparison where the implementation compares secret material directly;
- requests additionally carry request/correlation identity and the stable operation/fact identity required by the relevant idempotency contract;
- bearer rotation MUST support an explicit controlled overlap window or atomic coordinated cutover so rotation does not require weakening authorization;
- human access/refresh tokens MUST NOT be accepted by service endpoints;
- service credentials MUST NOT authorize browser/mobile/public API routes;
- transport TLS validation is mandatory in non-local environments; production MUST NOT silently downgrade to plaintext because certificate configuration is inconvenient.

Mutual TLS MAY be added later as defense in depth without changing the semantic service identities or the three-plane authorization boundary. B08.2 implements and verifies this exact v1 choice.

---

# 8. Universal HTTP/API Contract

## 8.1 Versioning

Initial public API prefix:

```text
/api/v1
```

Internal CMS-only service API prefix:

```text
/internal/v1
```

The separately hosted HAL is its own service and deliberately uses its own service-major root:

```text
/v1
```

Therefore `HAL_ORIGIN + /v1/...` is not a public CMS route and does not conflict with CMS `/internal/v1/...`. Browser/mobile clients never receive the HAL origin or service credentials.

Breaking contract changes require a new version or a backwards-compatible migration strategy.

## 8.2 Envelope

Success responses SHOULD use the resource directly unless pagination/metadata requires an envelope.

Errors use one canonical shape:

```json
{
  "error": {
    "code": "JOB_INVALID_TRANSITION",
    "message": "The job cannot move from ARRIVED to COMPLETED.",
    "request_id": "...",
    "details": {}
  }
}
```

`message` is safe for the client. Internal stack traces, SQL text, secrets, and provider payloads MUST NOT be returned.

## 8.3 Pagination

Use keyset pagination for growing operational/history collections.

Default page size: 20. Maximum: 100 unless an endpoint explicitly documents otherwise.

Ordering must be deterministic, typically:

```text
created_at DESC, id DESC
```

Cursor fields must encode every sort key required to avoid duplicates/skips.

## 8.4 Filtering and sorting

Filtering happens in SQL before LIMIT.

Every list endpoint documents:

- allowed filters;
- allowed sort keys;
- default sort;
- null ordering where relevant;
- full-text/search fields if `q` is accepted.

## 8.5 Idempotency header

Business-create and side-effecting retryable endpoints use:

```text
Idempotency-Key: <client-generated opaque key>
```

Scope is at least authenticated principal + HTTP operation + idempotency key.

Same key + semantically same request returns the same committed result.

Same key + conflicting request returns `409 IDEMPOTENCY_KEY_REUSED`.

## 8.6 Optimistic concurrency

Admin edits of mutable configuration SHOULD use either:

- `version` integer checked in the mutation; or
- strong ETag/If-Match.

Conflicts return 409 rather than silently overwriting a newer edit.

---

# 9. Global Persistence Conventions

## 9.1 IDs

Use UUID primary keys generated server-side, preferably UUIDv7 where implementation support is stable.

Provider IDs, charger protocol IDs, registration numbers, and human-readable job numbers are alternate identifiers, not primary keys.

## 9.2 Time

- Store all event timestamps as timezone-aware PostgreSQL `timestamptz` in UTC.
- Store an explicit IANA timezone on policies where local time affects behavior.
- Default business timezone for India deployment: `Asia/Kolkata`.
- Never compute compensation/time-window rules using server-local implicit timezone.

## 9.3 Money

Store monetary minor units as integers plus ISO currency code.

For INR:

```text
amount_minor = paise
currency = INR
```

Do not use binary floating point for money.

## 9.4 Energy and measurements

Choose canonical internal units and document them:

- energy: Wh integer where possible;
- power: W integer where possible;
- distance: meters integer;
- duration: milliseconds or seconds integer;
- latitude/longitude: decimal numeric precision sufficient for location;
- percentage/SoC: numeric/decimal with explicit range.

API may expose convenient derived units, but durable facts remain canonical.

## 9.5 Soft deletion

Use soft deactivation for identities/assets/configuration that must remain referentially visible to history.

Do not physically delete a driver, vehicle, charger, pricing policy, compensation policy, or saved customer object while history references it unless an explicit anonymization/retention process exists.

## 9.6 Audit columns

Mutable administrative/master tables SHOULD include:

```text
created_at
created_by
updated_at
updated_by
version
```

Historical event tables normally append new rows instead of updating semantic history.

---

# 10. Customer Domain Blueprint

## 10.1 Customer profile

`customer_profiles` minimum fields:

```text
id
account_id
full_name
primary_email
primary_phone
status              # ACTIVE, SUSPENDED, CLOSED
created_at
updated_at
```

Phone/email verification state belongs in auth/contact records rather than inferred from non-null values.

## 10.2 Saved customer vehicles

`customer_vehicles`:

```text
id
customer_id
make
model
variant
registration_number
battery_capacity_wh
supports_ac
supports_dc
max_ac_power_w
max_dc_power_w
connector_types[] or normalized relation
is_saved
is_active
created_at
updated_at
version
```

`is_saved=false` may represent a previously temporary object promoted into a reusable normalized record only if the chosen model preserves history. The authoritative history remains the ServiceJob snapshot.

## 10.3 Saved addresses

`customer_addresses`:

```text
id
customer_id
label
line1
line2
locality
city
state
postal_code
country_code
latitude
longitude
landmark
building_instructions
floor
contact_instructions
geocode_provider
geocode_provider_place_id
is_default
is_active
created_at
updated_at
version
```

Only one active default address per customer should be enforced transactionally.

## 10.4 Temporary data

A request can use:

- existing saved vehicle ID;
- inline temporary vehicle object;
- existing saved address ID;
- inline temporary address object.

The backend snapshots the resolved representation into the ServiceJob regardless of source.

A temporary object does not need to become saved master data merely because a job exists.

## 10.5 Promotion

Promotion endpoints copy eligible historical snapshot fields into new or existing saved master data under the customer account.

Promotion MUST NOT replace the historical snapshot or make history refer to the newly saved row as its source of truth.

Recommended endpoints:

```text
POST /api/v1/app/jobs/{job_id}/vehicle/promote
POST /api/v1/app/jobs/{job_id}/address/promote
```

Idempotency is required because clients may retry after timeout.

---

# 11. Driver Recruitment and Workforce Blueprint

## 11.1 Recruitment state machine

Canonical `DriverApplication.status`:

```text
DRAFT
SUBMITTED
UNDER_REVIEW
ACTION_REQUIRED
APPROVED
ONBOARDING
ACTIVE
REJECTED
WITHDRAWN
```

Operational suspension/offboarding is NOT represented by mutating an old application back out of APPROVED/ACTIVE.

## 11.2 Allowed recruitment transitions

```text
DRAFT -> SUBMITTED | WITHDRAWN
SUBMITTED -> UNDER_REVIEW | WITHDRAWN
UNDER_REVIEW -> ACTION_REQUIRED | APPROVED | REJECTED
ACTION_REQUIRED -> SUBMITTED | WITHDRAWN
APPROVED -> ONBOARDING
ONBOARDING -> ACTIVE
```

Any exceptional administrative correction requires a dedicated audited override action, not arbitrary status PATCH.

## 11.3 Driver profile

Created when the application reaches the configured onboarding boundary.

`driver_profiles`:

```text
id
account_id
source_application_id
full_name
phone
email
base_operating_area_id
employment_classification
operational_status
eligibility_status
suspended_at
offboarded_at
created_at
updated_at
version
```

## 11.4 KYC/document records

Documents are separate durable records with type, secure storage reference, verification state, expiry, and review history.

Sensitive documents MUST NOT be exposed in list endpoints by default.

Recommended states:

```text
SUBMITTED
UNDER_REVIEW
VERIFIED
REJECTED
EXPIRED
REPLACED
```

A replacement creates a new document version/record; it does not erase historical review evidence.

## 11.5 Eligibility

Driver eligibility is a derived decision backed by explicit durable reasons.

A driver is dispatch-eligible only if all mandatory conditions are true, including:

- profile active;
- not suspended/offboarded;
- required KYC verified and not expired;
- required driving licence valid;
- training/terms requirements met;
- no blocking compliance issue;
- active duty session in dispatchable state.

The API SHOULD expose both overall eligibility and machine-readable blocking reasons.

---

# 12. Fleet, Vehicle, Charger, Connector, and Pairing Blueprint

## 12.1 ServiceVehicle

`service_vehicles` master fields:

```text
id
registration_number
asset_tag
make
model
variant
vehicle_type
ownership_type
registration_valid_until
insurance_valid_until
inspection_status
operational_status
maintenance_status
is_active
notes
created_at
updated_at
version
```

Recommended operational status enum:

```text
AVAILABLE
OUT_OF_SERVICE
RETIRED
```

Do not overload this field with transient claimed/assigned state.

## 12.2 Charger

`chargers` master fields:

```text
id
asset_tag
serial_number
manufacturer
model
rated_power_w
protocol_family
protocol_version
hal_identity
operational_status
maintenance_status
is_active
notes
created_at
updated_at
version
```

Live HAL connectivity is projected separately.

## 12.3 Charger connectors

`charger_connectors`:

```text
id
charger_id
connector_number
connector_type
max_power_w
supports_ac
supports_dc
is_active
created_at
updated_at
```

One charger may have multiple connectors.

## 12.4 Runtime capability projection

CMS stores a HAL-derived projection, not the protocol source of truth:

```text
charger_capability_projection
  charger_id
  observed_at
  protocol
  supports_remote_start
  supports_remote_stop
  supports_unlock
  supports_smart_charging
  supports_soc
  supports_iso15118
  supports_reservation
  connector capability snapshot
  source_hal_fact_id
```

Staleness is explicit. A capability observation has an `observed_at`; it is never treated as timeless truth.

## 12.5 Vehicle-Charger pairing history

`vehicle_charger_pairings` is effective-dated:

```text
id
vehicle_id
charger_id
effective_from
effective_to
status              # ACTIVE, ENDED, INVALIDATED
source               # ADMIN, RECONCILIATION
created_by
created_at
reason
```

Only one active exclusive vehicle pairing per charger is allowed if hardware is physically exclusive.

If future hardware permits multiple chargers per vehicle, the schema supports it without changing charger identity.

## 12.6 Driver asset assignment

`driver_asset_assignments` represents admin intent, not actual use:

```text
id
driver_id
schedule_id nullable
schedule_occurrence_id nullable
vehicle_id nullable
charger_id nullable
assignment_mode       # REQUIRED, SUGGESTED
valid_from
valid_to
created_by
created_at
ended_at
```

## 12.7 Derived inventory availability

Admin inventory APIs derive one of:

```text
AVAILABLE
RESERVED
ASSIGNED
IN_USE
MAINTENANCE
OUT_OF_SERVICE
RETIRED
```

Derivation inputs include master operational state, maintenance intervals, active reservations/claims, active duty sessions, and current assignments.

No single mutable field is allowed to pretend to be all of these truths.


# 13. Schedule, Duty, Availability, and Asset Claim Blueprint

## 13.1 Schedule model

A DriverSchedule represents planned work. It does not itself make the driver online or dispatchable.

Recommended structure:

```text
driver_schedules
  id
  driver_id
  timezone
  recurrence_type        # ONE_OFF, RECURRING
  recurrence_rule nullable
  planned_start
  planned_end
  service_zone_id nullable
  assigned_vehicle_id nullable
  assigned_charger_id nullable
  assignment_mode         # REQUIRED, SUGGESTED, NONE
  status                  # DRAFT, ACTIVE, CANCELLED, RETIRED
  notes
  created_by
  created_at
  updated_at
  version
```

Recurring schedules MUST materialize bounded occurrences so actual work can reference a stable occurrence rather than an ever-changing recurrence expression.

`driver_schedule_occurrences`:

```text
id
schedule_id
driver_id
planned_start
planned_end
status                    # PLANNED, STARTED, MISSED, CANCELLED, COMPLETED
actual_duty_session_id nullable
created_at
```

A later edit to the recurring schedule MUST NOT rewrite an occurrence that has started or completed.

## 13.2 DutySession state machine

Canonical `DriverDutySession.status`:

```text
STARTING
AVAILABLE
OFFERED
ASSIGNED
EN_ROUTE
AT_CUSTOMER
SERVICING
BREAK
UNAVAILABLE
ENDING
ENDED
ABORTED
```

`OFF_DUTY` is represented by absence of an active duty session, not by keeping a permanent row in OFF_DUTY.

A driver may have at most one nonterminal duty session at a time.

## 13.3 DutySession record

`driver_duty_sessions` MUST snapshot actual operational context:

```text
id
driver_id
schedule_occurrence_id nullable
started_at
ended_at nullable
status

expected_vehicle_id nullable
expected_charger_id nullable
actual_vehicle_id nullable
actual_charger_id nullable
pairing_source         # ADMIN_ASSIGNED, DRIVER_SELECTED, OBSERVED_TEMPORARY, RECONCILED
pairing_mismatch       boolean

vehicle_snapshot jsonb
charger_snapshot jsonb
connector_snapshot jsonb
eligibility_snapshot jsonb
service_area_snapshot jsonb

start_location_lat nullable
start_location_lon nullable
last_location_at nullable
end_reason nullable
created_at
updated_at
version
```

The snapshots are historical support, not substitutes for normalized foreign keys.

## 13.4 Starting duty / going online

The backend MUST run the following as one logical transaction plus external HAL checks where required:

1. Authenticate Driver principal.
2. Lock driver operational row/advisory key to prevent concurrent starts.
3. Verify no active duty session already exists.
4. Verify driver profile is active and not suspended/offboarded.
5. Verify eligibility and mandatory document expiry.
6. Resolve schedule requirement and active occurrence.
7. Resolve intended/admin asset assignment.
8. Resolve driver-selected or observed actual assets.
9. Verify vehicle master operational state.
10. Verify charger master operational state.
11. Verify required inspection/registration/insurance constraints.
12. Verify vehicle and charger are not actively claimed by another duty session.
13. Verify selected/observed vehicle-charger combination is permitted, or create mismatch workflow if policy permits deviation.
14. Verify charger identity is known to HAL.
15. If online HAL reachability is a hard policy requirement, query current HAL projection and reject if too stale/offline.
16. Derive effective service area as intersection of platform, admin, and driver constraints.
17. Atomically create the DutySession and exclusive asset claims.
18. Emit durable `DriverDutyStarted` domain event.
19. Publish realtime invalidations/projections.

If a HAL reachability check occurs before the DB transaction and the result can go stale, the persisted row MUST record the observation timestamp. Do not represent it as a permanent fact.

## 13.5 Asset claims

Use a dedicated table instead of trusting status flags:

```text
asset_claims
  id
  duty_session_id
  asset_type          # VEHICLE, CHARGER
  asset_id
  claim_mode          # EXCLUSIVE
  claimed_at
  released_at nullable
```

A PostgreSQL uniqueness/exclusion mechanism MUST prevent two live exclusive claims for the same asset.

The application must treat a uniqueness conflict as a normal concurrency result, not an internal server error.

## 13.6 Driver-selected vs observed temporary assets

If policy allows a driver to declare an asset not yet in master inventory:

- the duty session stores the observed asset snapshot;
- the system creates an `AssetMismatchReport` or `ObservedAssetReport`;
- dispatch eligibility can be reduced or blocked depending on missing compatibility evidence;
- Admin can later promote/reconcile it into master inventory;
- the historical duty session remains unchanged.

Unknown charger hardware MUST NOT become dispatchable for charging merely because a driver typed a label. It requires sufficient technical identity/capability and HAL recognition.

## 13.7 Breaks and availability intervals

Duty presence and dispatch availability are distinct.

Use append-only intervals/events to preserve why the driver was unavailable:

```text
driver_availability_intervals
  id
  duty_session_id
  type                # BREAK, UNAVAILABLE, ADMIN_HOLD, EMERGENCY
  started_at
  ended_at nullable
  reason_code nullable
  note nullable
  created_by_actor_type
  created_by_actor_id
```

An active interval blocks dispatch unless its type is explicitly configured otherwise.

## 13.8 Ending duty

A driver cannot normally end duty while responsible for an active ServiceJob.

The API returns a conflict with blocking job identifiers and recovery guidance.

Admin emergency override MAY terminate duty only after one of:

- active jobs are reassigned;
- active jobs are failed/cancelled under explicit reason;
- a technical incident workflow owns the unresolved job.

Ending duty:

- records actual end time;
- releases asset claims;
- closes active availability interval;
- finalizes duty-level aggregates asynchronously if needed;
- preserves all snapshots;
- emits durable event.

---

# 14. Location and Geospatial Blueprint

## 14.1 Location authority

Driver device location is an observation, not guaranteed truth.

Location samples MUST include:

```text
id
driver_id
duty_session_id
recorded_at        # device/source timestamp if trusted enough
received_at        # server timestamp
latitude
longitude
accuracy_m nullable
speed_mps nullable
heading_deg nullable
source             # DRIVER_APP, VEHICLE_GPS, ADMIN_CORRECTION, OTHER
```

Server receipt time is mandatory even when source timestamp is present.

## 14.2 Current location projection

Maintain a derived current row for efficient dispatch:

```text
driver_location_projection
  driver_id
  duty_session_id
  latest_sample_id
  latitude
  longitude
  accuracy_m
  recorded_at
  received_at
```

This projection is replaceable and rebuildable from durable samples within the chosen retention window.

## 14.3 Freshness

Dispatch policy MUST define a maximum location age, e.g. configuration:

```text
DISPATCH_MAX_LOCATION_AGE_SECONDS
```

The default should be conservative and environment-configurable. A stale driver is ineligible rather than assigned based on old location.

## 14.4 Effective service area

Effective dispatch area is:

```text
platform service eligibility
INTERSECT admin restriction
INTERSECT driver voluntary preference
```

Driver preference may narrow but never expand the platform/admin area.

Supported initial geometry modes:

- NONE
- RADIUS
- ADMIN_ZONE

Polygon support can be added without changing the conceptual contract.

## 14.5 Location privacy

User clients receive only the assigned operational unit/driver location needed for their current job.

Users MUST NOT query arbitrary driver locations.

Historical raw driver traces are Admin-only with explicit capability and retention policy.

---

# 15. Dispatch Blueprint

Dispatch is a durable business workflow, not a stateless nearest-driver query.

## 15.1 Inputs

A dispatch attempt is based on a frozen request context containing at least:

- ServiceJob ID.
- requested service location.
- customer vehicle snapshot.
- requested charging preference.
- connector requirements.
- minimum capability requirements.
- scheduling window/immediacy.
- customer priority if applicable.
- dispatch policy version.

## 15.2 Eligibility pipeline

Candidate eligibility MUST evaluate all relevant hard constraints before ranking:

1. Driver active and eligible.
2. Active DutySession.
3. DutySession dispatchable status.
4. No blocking break/unavailable interval.
5. Location fresh enough.
6. Within effective service area.
7. Vehicle active, not under blocking maintenance.
8. Charger active, not under blocking maintenance.
9. Exclusive claims valid.
10. Actual duty assets known.
11. Customer connector compatibility.
12. AC/DC compatibility.
13. Power/capability threshold.
14. HAL capability/connectivity policy satisfied.
15. No conflicting active assignment.
16. Mobile unit energy/capacity satisfies the Section 53 activation state: sufficient and reserved when `REQUIRED`; explicitly not applicable when `NOT_APPLICABLE`; or handled under the documented restricted policy when `TEMPORARILY_UNAVAILABLE`.
17. Schedule commitment permits the job.
18. Any special customer/service requirement satisfied.

Eligibility result SHOULD store reason codes for rejected candidates during bounded diagnostic windows, at least in trace/audit form, so operations can explain why a nearby driver was skipped.

## 15.3 Ranking

Only eligible candidates are ranked.

Initial ranking function SHOULD be deterministic and explicit, for example lexicographic or weighted scoring over:

- ETA.
- route distance.
- current workload/queued jobs.
- schedule slack.
- asset capability fit.
- mobile energy reserve.
- job priority.
- admin priority.
- optional driver rating policy.

The exact coefficients are configuration/policy data and MUST be versioned if they materially affect operations.

Tie-breaking MUST be deterministic, e.g. `score DESC, estimated_eta ASC, driver_id ASC`.

## 15.4 DispatchAttempt

Persist every assignment cycle:

```text
dispatch_attempts
  id
  service_job_id
  attempt_number
  policy_version
  status              # RUNNING, OFFERING, ASSIGNED, EXHAUSTED, CANCELLED
  started_at
  ended_at nullable
  created_reason
```

## 15.5 DispatchCandidate

Persist the candidates selected for an attempt if offers are durable:

```text
dispatch_candidates
  id
  dispatch_attempt_id
  driver_id
  duty_session_id
  rank
  score_components jsonb
  eligibility_snapshot jsonb
  status              # ELIGIBLE, OFFERED, ACCEPTED, REJECTED, EXPIRED, SKIPPED
```

Do not store every ineligible driver forever. Diagnostic ineligibility may be logged/traced with bounded retention.

## 15.6 Offer strategy

The initial platform MUST use one normal dispatch strategy:

```text
SEQUENTIAL
```

Admin may also use an explicit `DIRECT_ASSIGNMENT` action for exceptional operations.

`BATCHED` multi-driver offers are a future extension, not part of the initial semantic contract. They may be added only with an explicit multi-offer race model and without changing the meaning of existing states. This avoids making `ASSIGNED` mean different things under different strategies.

Each DispatchOffer has:

```text
id
dispatch_attempt_id
service_job_id
driver_id
duty_session_id
sent_at
expires_at
status            # PENDING, ACCEPTED, REJECTED, EXPIRED, WITHDRAWN
response_at nullable
```

A driver MUST NOT accept an expired/withdrawn offer.

While one sequential offer is live, the ServiceJob is `ASSIGNED`: one specific driver has been selected and given the right to accept within the offer window, but the driver has not yet committed. The active DispatchOffer is the provisional assignment.

## 15.7 Acceptance race

Offer acceptance is transactionally serialized on the ServiceJob/DispatchAttempt.

On valid acceptance:

1. lock the ServiceJob and live DispatchOffer;
2. revalidate job, duty, driver, and asset state;
3. mark offer ACCEPTED;
4. create the durable JobAssignment;
5. set `current_assignment_id`;
6. clear `current_offer_id`;
7. transition ServiceJob `ASSIGNED -> ACCEPTED`;
8. transition DutySession `OFFERED -> ASSIGNED`;
9. commit one coherent result.

A concurrent or late second acceptance is impossible in the initial sequential strategy and must return `409 OFFER_NO_LONGER_AVAILABLE` if a duplicate/stale request reaches the server.

## 15.8 Rejection/timeout

A rejection or expiry advances the same dispatch attempt to the next candidate or starts a new attempt after re-evaluation if enough state has changed.

Do not indefinitely reuse a stale candidate list after location, duty, capability, or job state changes.

## 15.9 No candidates

When no eligible candidate exists:

- ServiceJob remains in `DISPATCHING` or enters a distinct operational wait condition represented by event/reason, not a fake assignment.
- User receives a truthful availability state.
- Admin receives an actionable queue item.
- retry cadence/backoff is bounded and observable.
- scheduled jobs may remain pending until their dispatch window.
- immediate jobs eventually expire or require admin intervention under explicit policy.

## 15.10 Reassignment

Reassignment does not create a new ServiceJob.

Create a new JobAssignment record and preserve the old one.

Reasons include:

- driver rejected/cancelled;
- driver unreachable;
- breakdown;
- charger incompatibility/fault;
- admin override;
- customer relocation beyond current assignment feasibility.

Current assignment changes atomically with ServiceJob transition to/from `REASSIGNING`.

---

# 16. Service Request, Quote, and ServiceJob Blueprint

## 16.1 ServiceRequest

A ServiceRequest is the customer's expressed request before an operational job is fully committed.

Fields:

```text
id
customer_id
request_type            # IMMEDIATE, SCHEDULED
requested_for nullable
requested_vehicle_source # SAVED, TEMPORARY
requested_address_source # SAVED, TEMPORARY
vehicle_input jsonb
address_input jsonb
charging_preference jsonb
status                  # DRAFT, QUOTED, CONFIRMED, EXPIRED, CANCELLED
created_at
updated_at
```

## 16.2 Quote

A Quote is a time-bounded commercial offer derived from current request facts and pricing policy.

`quotes`:

```text
id
service_request_id
customer_id
pricing_policy_id
pricing_policy_version
currency
estimated_components jsonb
estimated_total_minor
valid_until
assumptions jsonb
status                 # ACTIVE, ACCEPTED, EXPIRED, SUPERSEDED
created_at
```

A quote is an estimate unless the component is explicitly guaranteed.

The quote MUST disclose important non-guaranteed dimensions, for example energy/time finalization based on actual charging.

## 16.3 Job creation boundary

Accepting a valid quote creates the ServiceJob transactionally or through an idempotent orchestration boundary.

At creation, snapshot:

- customer identity relevant to service/invoice;
- service address;
- customer EV;
- requested charging preference;
- accepted quote/pricing inputs;
- initial tax context if applicable;
- scheduling target;
- source request and quote IDs.

## 16.4 ServiceJob record

`service_jobs` minimum durable shape:

```text
id
job_number
customer_id
service_request_id
accepted_quote_id
status
status_reason nullable
request_type
requested_for nullable

service_address_snapshot jsonb
customer_vehicle_snapshot jsonb
charging_preference_snapshot jsonb

current_offer_id nullable
current_assignment_id nullable
current_duty_session_id nullable
current_vehicle_id nullable
current_charger_id nullable

pricing_snapshot_id nullable
final_price_minor nullable
currency

created_at
confirmed_at
dispatch_started_at nullable
assigned_at nullable
accepted_at nullable
en_route_at nullable
arrived_at nullable
service_preparing_at nullable
charging_started_at nullable
charging_ended_at nullable
wrap_up_at nullable
completed_at nullable
cancelled_at nullable
failed_at nullable

version
```

Timestamps are facts for the first/authoritative transition where semantically appropriate; event history preserves all transitions.

## 16.5 ServiceJob state machine

Canonical states:

```text
REQUESTED
QUOTED
DISPATCHING
ASSIGNED
ACCEPTED
EN_ROUTE
ARRIVED
SERVICE_PREPARING
CHARGING
WRAP_UP
COMPLETED
REASSIGNING
CANCELLED
FAILED
NO_SHOW
EXPIRED
```

In the persisted implementation, `REQUESTED` and `QUOTED` may remain pre-Job request states if ServiceJob is only created on quote acceptance. If so, the ServiceJob itself begins at `DISPATCHING` (or scheduled equivalent). The public product lifecycle may still show request/quote phases. Do not duplicate objects merely to satisfy a label.

## 16.6 Required transition graph

Minimum legal path:

```text
DISPATCHING -> ASSIGNED | CANCELLED | EXPIRED | FAILED
ASSIGNED -> ACCEPTED | DISPATCHING | REASSIGNING | CANCELLED | FAILED
ACCEPTED -> EN_ROUTE | REASSIGNING | CANCELLED | FAILED
EN_ROUTE -> ARRIVED | REASSIGNING | CANCELLED | FAILED | NO_SHOW
ARRIVED -> SERVICE_PREPARING | REASSIGNING | CANCELLED | FAILED | NO_SHOW
SERVICE_PREPARING -> CHARGING | REASSIGNING | CANCELLED | FAILED
CHARGING -> WRAP_UP | FAILED
WRAP_UP -> COMPLETED | FAILED
REASSIGNING -> DISPATCHING | ASSIGNED | CANCELLED | FAILED
```

Additional transition from `ARRIVED` directly to `WRAP_UP` is permitted only for an explicit zero-charge/aborted-service closeout reason and commercial policy that can finalize it.

`COMPLETED`, `CANCELLED`, `FAILED`, `NO_SHOW`, `EXPIRED` are terminal for the job lifecycle. Corrections use administrative correction records, refunds/adjustments, support, or incident workflows rather than reopening history casually.

## 16.7 Transition authorization

Every transition declares allowed actor(s):

- Customer.
- Assigned Driver.
- Admin capability.
- System worker.
- HAL fact handler.

No generic `PATCH status` endpoint is allowed for User or Driver.

Admin overrides use explicit action endpoints with reason and audit trail.

## 16.8 Job event history

`service_job_events` is append-only:

```text
id
service_job_id
event_type
from_status nullable
to_status nullable
actor_type
actor_id nullable
occurred_at
reason_code nullable
metadata jsonb
request_id
```

This is not a substitute for domain-specific records such as assignments, payments, or charging sessions; it is the high-level job timeline.

---

# 17. Assignment, Arrival, and Field-Service Flow

## 17.1 JobAssignment

A JobAssignment is created when a driver accepts a live offer or when an authorized Admin performs a direct assignment. A pending offer is not yet a JobAssignment. Each created assignment is immutable identity/history with a lifecycle status:

```text
job_assignments
  id
  service_job_id
  dispatch_attempt_id nullable
  source_offer_id nullable
  driver_id
  duty_session_id
  vehicle_id
  charger_id
  status              # ACCEPTED, ACTIVE, REPLACED, CANCELLED, COMPLETED
  assigned_at
  accepted_at nullable
  ended_at nullable
  end_reason nullable
  asset_snapshot jsonb
```

Only one current active assignment per ServiceJob. While the ServiceJob is `ASSIGNED` awaiting driver acceptance, `current_offer_id` identifies the provisional selected driver and `current_assignment_id` remains null.

## 17.2 Driver acceptance

Acceptance of the live DispatchOffer MUST revalidate at commit time:

- offer still valid;
- job still assignable;
- same duty session still active;
- driver not already in incompatible active job;
- asset claims unchanged;
- essential compatibility still valid.

Do not rely solely on eligibility checked when the offer was generated.

## 17.3 En route

Driver action `start_navigation` or equivalent moves accepted assignment/job to EN_ROUTE.

Navigation itself may use an external maps provider on the client. The backend stores operational facts, not third-party turn-by-turn state.

## 17.4 Arrival

Driver can mark arrival only when assigned and EN_ROUTE.

The backend SHOULD compare current location to service location and record validation result:

```text
arrival_validation = WITHIN_RADIUS | OUTSIDE_RADIUS | LOCATION_STALE | LOCATION_UNAVAILABLE
```

Product policy MAY allow manual arrival outside radius with reason. It must remain auditable.

## 17.5 Service preparation

Preparation includes physical steps such as parking, cable/connector setup, safety checks, charger readiness, and customer confirmation as product requires.

The backend must not model these as charging facts.

Preparation is the correct place to resolve:

- actual connector chosen;
- actual charger availability;
- any final asset mismatch;
- inability to safely/technically charge;
- cancellation/failed-service reason before charging.

---

# 18. Charging CMS Domain Blueprint - Preserved Mature Flow

This section is deliberately based on the proven behavioral architecture in `ev-cms-backend-new` and `ocpp-hal-go-new`, adapted to Charger on Wheels rather than copied mechanically.

The inheritance rule is:

1. Preserve the truth boundaries, identifier discipline, idempotency, ambiguity handling, projection/freshness rules, and recovery model.
2. Replace CPO-specific and fixed-station assumptions with Charger-on-Wheels ServiceJob, DriverDutySession, ServiceVehicle, and mobile Charger context.
3. Do not make the new services wire-compatible with EV-CMS merely for familiarity. The new contract is free to rename additive fields where the new domain genuinely differs, but semantic safety MUST remain equivalent or stronger.
4. A future simplification is allowed only if it can prove that the removed distinction cannot exist in Charger-on-Wheels reality.

## 18.1 Separate start intent, physical session, stop request, and general charger operation

Do not use one generic `ChargingIntent` row to mean all of the following:

- commercial/admission request to start charging;
- a physical charging session;
- a stop request;
- an administrative charger operation such as reset/unlock/availability;
- a HAL transport attempt.

Those are different concepts and have different recovery rules.

The CMS MUST model at least:

```text
ChargingStartIntent
ChargingSession
ChargingStopRequest
ChargerOperation        # non-start/stop administrative/technical commands
HALCommandRecord        # CMS projection of the HAL command identity/state
HALFactReceipt
HALChargerMapping
HALChargerRuntime
HALConnectorRuntime
```

`ServiceJob` remains the business parent. A physical charging session does not replace the ServiceJob.

## 18.2 Identifier chain

The following identities are distinct and MUST never be inferred from one another:

```text
service_job_id
assignment_id
duty_session_id
cms_charger_id
public/display charger identity
charger_protocol_identity
cms_connector_id
protocol_connector_number
cms_start_intent_id
cms_charging_session_id
cms_command_id
app_charging_credential / protocol authorization token
hal_command_id
hal_transaction_id
protocol_transaction_id
hal_fact_id
```

Rules:

- CMS owns all `cms_*`, ServiceJob, assignment, duty, customer, driver, and commercial identities.
- HAL owns `hal_command_id`, `hal_transaction_id`, protocol connection state, and the protocol transaction identity allocated/accepted by the protocol runtime.
- `charger_protocol_identity` is mapping evidence, not the CMS primary key.
- Connector number is protocol addressing, not a CMS connector UUID.
- A public/display charger ID is not a protocol identity unless the mapping explicitly says so.
- No recovery may correlate by "latest transaction", charger plus time window, display ID, or guessed connector.
- Zero UUIDs, empty identifiers, malformed UUIDs, and inconsistent identity chains are invalid rather than aliases for unknown.
- Unknown is represented by NULL/absence, never an all-zero UUID.

For OCPP 1.6, the exact `transactionId` is allocated by the Central System/HAL only when the charger-originated `StartTransaction` is accepted. CMS MUST never fabricate or substitute it.

## 18.3 One-use charging credential

The initial app-controlled charging vertical SHOULD preserve the proven one-use credential model.

Before requesting remote start, CMS creates a short-lived opaque credential, for example:

```text
cowv1_<random>
```

The credential is:

- generated by CMS;
- bound to one ChargingStartIntent;
- bound to the intended charger and connector where connector selection is known;
- associated with the owning customer and ServiceJob inside CMS;
- optionally associated with the current assignment/duty session for audit;
- short-lived;
- one-use;
- replay-resistant;
- never equal to a customer, driver, job, session, or database UUID;
- secret operational material and therefore redacted from logs, traces, analytics, errors, and external notifications.

CMS SHOULD persist only the credential hash after successful command construction whenever raw-value replay is not required. The raw value crosses to HAL only through the authenticated start-command boundary.

If the new HAL adapter/protocol does not require an idTag-like value, the semantic credential still remains useful as the one-use authorization/correlation token between CMS admission and physical-start evidence. An adapter may translate or omit the protocol representation, but the CMS intent still has a distinct authorization identity.

## 18.4 Commercial/admission boundary before start

A ChargingStartIntent is created only after CMS has established everything that must be true before asking hardware to energize.

The exact customer payment strategy is intentionally a pre-burner product decision elsewhere in this blueprint. Therefore Charger-on-Wheels MUST preserve the mature ordering without hard-coding the old wallet model.

In one CMS transaction, as applicable:

1. authenticate the initiating actor;
2. load and lock the ServiceJob/current assignment where required;
3. prove the job is in a start-eligible state;
4. prove the driver/duty session/actual vehicle/charger context is the current operational context;
5. validate customer EV versus connector/charger compatibility;
6. derive trusted customer/service scope server-side;
7. resolve the effective customer pricing policy and active tax configuration;
8. freeze the charging-relevant pricing/tax snapshot or reference the already-frozen ServiceJob commercial snapshot according to the selected pricing design;
9. calculate any required affordability, deposit, authorization, prepaid balance, or spending-safety boundary according to the chosen payment strategy;
10. create the corresponding durable funding reservation/hold only if that strategy actually has one;
11. generate the one-use charging credential;
12. create the immutable ChargingStartIntent;
13. create the CMS command identity and immutable dispatch envelope;
14. emit only the internal domain/outbox records that belong to the committed CMS transaction.

No network call to HAL occurs inside that database transaction.

If the eventual business model is post-service collection with no funding reservation, step 9 records admission policy and step 10 is absent. Do not invent a fake wallet hold simply to imitate EV-CMS.

## 18.5 Mapping synchronization and race closure

CMS owns the intended charger/connector inventory and mapping. HAL owns protocol connectivity and validates that command destinations match an approved mapping.

Before a first start can be attempted on a mapping revision, CMS MUST ensure HAL knows the committed mapping.

Recommended ordering, preserving the mature system:

```text
committed CMS charger/connector inventory
-> mapping state PENDING/RECONCILIATION_REQUIRED if not synchronized
-> authenticated idempotent mapping PUT to HAL
-> mapping SYNCHRONIZED
-> create/freeze charging admission transaction
-> reconfirm mapping revision immediately before RequestStart
-> send start only if the exact frozen destination is still valid
```

The second confirmation closes the race where the physical/admin mapping changes between commercial admission and network dispatch.

If the prerequisite mapping fails before any commercial/start-intent transaction is committed:

```text
reject start
no ChargingStartIntent
no funding hold/reservation
no command record
```

If post-commit mapping confirmation fails before HAL start invocation:

```text
terminalize the unattempted command
release only the still-unspent funding reservation if one exists
terminalize the start intent as REJECTED or EXPIRED as appropriate
return a stable mapping-unavailable error
```

Do not leave a durable funding reservation attached to a command proven never to have crossed the HAL boundary.

## 18.6 ChargingStartIntent lifecycle

Use an explicit state machine equivalent to the mature flow:

```text
REQUESTED
ACCEPTED_FOR_DELIVERY
PROTOCOL_ACKNOWLEDGED
ACTUALLY_STARTED
REJECTED
EXPIRED
RECONCILIATION_REQUIRED
```

Meaning:

| State | Durable meaning |
| --- | --- |
| `REQUESTED` | CMS admission, immutable start intent, commercial snapshot, credential, and any required funding reservation are committed. HAL has not yet durably accepted the logical start command. |
| `ACCEPTED_FOR_DELIVERY` | HAL durably knows the logical start command. This does not mean OCPP/protocol acceptance and does not mean charging started. |
| `PROTOCOL_ACKNOWLEDGED` | The charger/protocol accepted the remote-start command. This still does not prove physical charging start. |
| `ACTUALLY_STARTED` | Authoritative charger-originated transaction-start evidence passed the complete identifier/correlation checks and materialized one CMS ChargingSession. |
| `REJECTED` | The start cannot proceed and no authoritative start evidence exists. |
| `EXPIRED` | The approved start window ended without authoritative physical-start evidence. |
| `RECONCILIATION_REQUIRED` | Delivery, identity, mapping, late evidence, or correlation is ambiguous and truth cannot safely be concluded. |

Allowed transition principles:

```text
REQUESTED -> ACCEPTED_FOR_DELIVERY | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
ACCEPTED_FOR_DELIVERY -> PROTOCOL_ACKNOWLEDGED | ACTUALLY_STARTED | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
PROTOCOL_ACKNOWLEDGED -> ACTUALLY_STARTED | EXPIRED | RECONCILIATION_REQUIRED
REJECTED -> RECONCILIATION_REQUIRED only on contrary late evidence
EXPIRED -> RECONCILIATION_REQUIRED only on contrary late evidence
RECONCILIATION_REQUIRED -> evidence-backed state only
```

A remote-start timeout after possible transmission is never `REJECTED` merely because CMS did not receive a response.

## 18.7 No CMS ChargingSession before physical-start evidence

There MUST be no normal materialized ChargingSession just because:

- the user/driver tapped Start;
- CMS created a start intent;
- CMS sent an HTTP request;
- HAL persisted the command;
- HAL returned `202`;
- the protocol returned RemoteStart accepted.

A CMS ChargingSession is materialized only from authoritative normalized transaction-start evidence with a valid identifier chain.

Initial CMS ChargingSession states:

```text
ACTIVE
STOP_PENDING
RECONCILIATION_REQUIRED
COMPLETED
FAILED             # only for evidence-backed non-commercial failure semantics
```

`ACTIVE` requires the real transaction-start fact. `STOP_PENDING` is a CMS projection indicating a durable stop request exists while physical completion remains absent. `RECONCILIATION_REQUIRED` preserves occupancy and blocks unsafe duplicate settlement/starts when physical truth is incomplete.

## 18.8 Materializing transaction-start evidence

For `transaction.started`, CMS MUST validate before session creation:

- immutable fact ID/digest integrity;
- known supported schema version;
- exact CMS charger mapping;
- exact CMS connector mapping;
- charger protocol identity;
- connector number;
- nonzero HAL command identity where contract requires it;
- exact CMS command identity;
- exact ChargingStartIntent identity;
- one-use credential/hash correlation;
- HAL transaction identity;
- protocol transaction identity where present;
- receipt/order/timestamp policy;
- current start intent has not already materialized a different transaction;
- no conflicting nonzero identity was previously accepted.

One accepted start fact materializes exactly one CMS session for that start intent.

A duplicate identical fact is a no-op success. A same fact ID with altered immutable content is an integrity violation. A different fact claiming a conflicting transaction identity moves the affected CMS truth to reconciliation rather than choosing whichever arrived last.

## 18.9 ChargingSession persistence

`charging_sessions` SHOULD include at least:

```text
id
service_job_id
assignment_id
duty_session_id
customer_id
charger_id
connector_id
start_intent_id UNIQUE
start_command_id
hal_command_id nullable
hal_transaction_id UNIQUE nullable
protocol_transaction_id nullable
state
started_at
completed_at nullable
meter_start_wh
latest_meter_wh nullable
meter_stop_wh nullable
consumed_wh nullable
latest_meter_sequence nullable
latest_meter_observed_at nullable
initial_soc_percent nullable
latest_soc_percent nullable
latest_soc_sequence nullable
latest_soc_observed_at nullable
final_soc_percent nullable
settlement_state
reconciliation_reason nullable
created_at
updated_at
```

The exact schema may split projection tables, but uniqueness and identity-chain semantics MUST remain enforceable at the database/service boundary.

## 18.10 Meter evidence

Energy across CMS/HAL uses integer Wh as the durable cross-service unit unless a future measurement explicitly requires a different exact representation.

HAL emits immutable `transaction.meter` facts only from accepted protocol evidence.

Each accepted meter fact carries enough information to prove:

```text
hal_transaction_id
protocol_transaction_id
cms_start_intent_id
cms_charger_id / mapped identity chain
cms_connector_id / connector number chain
meter_sequence
meter_value_wh
consumed_wh
meter_observed_at
```

Rules:

- Never interpolate a missing meter reading.
- Never estimate authoritative energy from charger rated power and elapsed time.
- CMS may compute UI projections from measured facts, but the displayed result must remain distinguishable from authoritative final settlement values.
- CMS advances the current meter projection only on a strictly newer accepted sequence.
- Delayed older facts remain receipts/evidence and MUST NOT regress the live projection.
- Consumption cannot silently become negative because a register rolled backward.
- Completion uses an evidence-backed nondecreasing final meter policy.
- The inherited one-Wh quantization exception MAY be retained for adapters/hardware where proven relevant: a raw final register exactly one Wh below the latest temporally eligible accepted sample may be preserved as raw evidence while the normalized billable cumulative meter remains nondecreasing and the normalization is explicitly tagged. Do not generalize this tolerance without evidence.

## 18.11 SoC evidence is independent from energy

State of Charge is a separate optional evidence stream.

Rules:

- Missing SoC means unknown, never zero.
- SoC MUST NOT be derived from delivered Wh and nominal battery capacity as if it were charger truth.
- SoC-only evidence does not invent an energy sample.
- Energy-only evidence does not copy a cached SoC into a new observation.
- SoC has its own sequence and observed timestamp.
- SoC freshness is calculated independently even if it uses the same configured stale duration initially.
- A completed session's `final_soc_percent` is the last accepted observation, not necessarily a stop-time measurement unless its timestamp proves that.

A future target-SOC stop rule is allowed only when the chosen charger/protocol evidence is trustworthy enough for that rule. Otherwise target SOC is advisory rather than a guaranteed physical cutoff.

## 18.12 Stop request and completion are different truths

Stop may be initiated by:

- assigned Driver;
- Customer if enabled by product policy;
- authorized Admin technical/operations capability;
- CMS automatic charging target logic;
- funding/commercial safety logic;
- HAL deadline/energy threshold derived from CMS instructions;
- charger/local hardware/operator without any CMS stop request.

A stop request creates/reuses a durable `ChargingStopRequest` and CMS command identity.

The HAL response to RemoteStop or equivalent is command evidence only.

The ChargingSession remains `ACTIVE` or `STOP_PENDING` until authoritative transaction-completion evidence is accepted.

A spontaneous charger-originated end MUST be processed even if there is no CMS stop command.

## 18.13 Stop provenance

Preserve business/request provenance separately from protocol completion reason.

The session/completion projection may include:

```text
requested_stop_initiator
requested_stop_reason
protocol_stop_reason
```

Examples:

```text
requested_stop_initiator = SYSTEM
requested_stop_reason    = ENERGY_LIMIT
protocol_stop_reason     = Remote
```

`Remote` is protocol evidence, not the business reason the platform decided to stop.

If the charger stopped locally, `requested_stop_*` may be NULL while `protocol_stop_reason` is present.

## 18.14 Completion and settlement

Only authoritative `transaction.completed` evidence, or an exact HAL transaction-reconciliation snapshot satisfying the same evidence requirements, can physically complete a CMS ChargingSession.

CMS validates:

- exact HAL transaction identity;
- exact protocol transaction identity where applicable;
- exact start-intent/charger/connector chain;
- final meter non-regression;
- completion time not earlier than accepted start;
- no conflicting terminal evidence;
- optional stop provenance fields as provenance only.

Then one CMS transaction performs the idempotent completion side effects that are enabled for the selected business model:

1. lock session and commercial/funding rows in canonical order;
2. persist final physical metrics;
3. finalize pricing from frozen commercial terms and accepted physical facts;
4. perform the allowed payment/capture/debit/release operation exactly once;
5. record commercial ledger/adjustment records;
6. mark settlement result;
7. finalize or enqueue invoice generation according to invoice design;
8. emit durable domain/operational events;
9. transition the ServiceJob toward `WRAP_UP` only when field-service invariants allow it.

Repeated fact delivery or reconciliation MUST NOT create a second payment, debit, capture, refund, invoice, or compensation source fact.

## 18.15 Start ambiguity recovery

A network error after RequestStart may mean any of:

- HAL never received the command;
- HAL persisted it but CMS lost the response;
- HAL transmitted to the charger and the response was lost;
- charging physically started and the fact is delayed.

Therefore:

```text
possible RequestStart delivery
-> RECONCILIATION_REQUIRED
-> exact GET by original cms_command_id
```

Exact command lookup outcomes:

```text
command exists
    -> project HAL command state
    -> retain admission/funding reservation
    -> do not create a new command

canonical 404 / confirmed absent
    -> only if no materialized session exists and identity locks prove absence
    -> mark command CONFIRMED_ABSENT
    -> release unspent funding reservation if any
    -> REJECTED, or EXPIRED if the start window has elapsed

401/403/409/422/5xx/timeout/malformed response
    -> retain RECONCILIATION_REQUIRED
    -> retain occupancy/funding safety
    -> bounded retry of the same exact lookup
```

For an accepted/unmaterialized start that remains unresolved beyond a configured threshold, CMS SHOULD also query the exact transaction by `cms_start_intent_id`. A valid returned HAL transaction is fed through the same locked materializer as a normal `transaction.started` fact.

A 404 transaction lookup is not enough by itself to prove the command never crossed the boundary. Reconcile the exact command too.

Late physical-start evidence after CMS believed the intent rejected/expired is never discarded. Preserve it and move the intent to reconciliation; do not silently create a normal session or automatically send a stop unless separately authorized by safety policy.

## 18.16 Completion recovery for missing/delayed fact delivery

For a materialized CMS session with known `hal_transaction_id` and no completion:

```text
GET exact HAL transaction by hal_transaction_id
```

Possible outcomes:

```text
matching terminal transaction with valid completion evidence
    -> reuse the exact same locked finalization path as transaction.completed fact ingress

active/nonterminal transaction
    -> keep session open; no synthetic completion

404 / timeout / HAL unavailable / 5xx
    -> keep occupancy and financial state unchanged; retry later

malformed/conflicting identity, meter, or time evidence
    -> mark session RECONCILIATION_REQUIRED
    -> do not settle or clear occupancy by guesswork
```

A bounded fair cursor SHOULD prevent one old failing session from monopolizing every recovery pass.

## 18.17 Multiple physical starts within one ServiceJob

Charger-on-Wheels retains the plan that one ServiceJob may have multiple physical charging attempts.

The safe initial rule is:

- one accepted physical transaction start creates one CMS ChargingSession;
- if that physical session completes/fails and a later recovery start occurs, create a new ChargingStartIntent and a new ChargingSession under the same ServiceJob;
- do not mutate the first session into a second physical transaction merely to make the UI look continuous;
- the final ServiceJob commercial and driver-compensation engines aggregate the explicitly eligible physical facts across those sessions.

If a future protocol supports one logical transaction surviving transport reconnection, HAL keeps one HAL transaction and the CMS session remains one session. Transport reconnect alone is not a reason to split a charging session.

## 18.18 Customer/Driver initiation policy

Who is allowed to request physical charging start is a product policy, but the backend contract is not duplicated per actor.

For the initial field-service flow:

- Driver start is expected after arrival and preparation.
- Customer MAY be allowed to confirm/readiness-authorize start if product UX requires it.
- Admin MAY request start only under an explicitly capability-gated operational intervention flow with reason/audit.

All actors converge on the same CMS `RequestChargingStart` domain method, which derives trusted IDs from current ServiceJob/assignment context rather than accepting arbitrary charger/driver/customer ownership IDs from the client.

---

# 19. Dedicated HAL Exact Blueprint - Preserved Reliability Model

## 19.1 Authority

HAL owns:

- charger transport and connection/reconnection;
- protocol negotiation and framing through protocol libraries/adapters;
- exact protocol charger identity;
- current protocol connector evidence;
- remote command persistence and delivery;
- exact physical transaction identity;
- meter/SoC/protocol evidence;
- normalized physical facts;
- command and transaction reconciliation;
- raw/sanitized technical trace evidence;
- durable fact/trace outboxes.

HAL does not own:

- Customer identity semantics;
- Driver/assignment/duty semantics;
- ServiceJob lifecycle;
- customer price/tax;
- payment/funding policy;
- invoice generation;
- compensation;
- customer-visible business conclusions.

CMS and HAL have separate PostgreSQL databases and credentials.

## 19.2 Protocol-neutral core, protocol-specific adapters

Preserve the new project's protocol-neutral goal while carrying forward the existing OCPP reliability semantics.

Core concepts:

```text
HAL Core
  ChargerRegistry
  ConnectionRuntime
  MappingRegistry
  CapabilityProjection
  CommandStore
  CommandDispatcher
  TransactionStore
  MeterNormalizer
  StopWorkflow
  FactOutbox
  TraceOutbox
  Reconciler

Adapters
  OCPP 1.6
  OCPP 2.0.1
  OCPP 2.1
  vendor/proprietary
  simulator
```

Protocol-specific names such as `RemoteStartTransaction`, `RequestStartTransaction`, or `SetChargingProfile` stay inside adapters. CMS speaks semantic operations.

For OCPP, use a maintained protocol library rather than hand-building WebSocket/OCPP framing. The existing HAL uses `github.com/lorenzodonini/ocpp-go`; the new repository may retain it for OCPP 1.6 if it remains the best supported choice, but adapter boundaries MUST permit replacement without changing CMS contracts.

## 19.3 Charger mapping contract

HAL persists the approved CMS mapping rather than accepting arbitrary command destinations.

Conceptual mapping:

```text
cms_charger_id
charger_protocol_identity
expected_serial nullable
enabled
connectors[]:
  cms_connector_id
  protocol_connector_number
  enabled
mapping_revision / updated_at
```

Mapping synchronization is authenticated and idempotent.

Expected serial is additional physical evidence, never a substitute for canonical protocol identity.

## 19.4 Start/stop HAL command lifecycle

Preserve these durable states for start/stop:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED        # or protocol-equivalent accepted
OCPP_REJECTED        # or protocol-equivalent rejected
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Semantics:

- `PERSISTED`: command exists durably and no network transmission has occurred.
- `PENDING_DELIVERY`: a worker exclusively owns a known pre-network delivery window. Startup recovery may return this state to `PERSISTED` because the network boundary was not crossed.
- `DELIVERY_ATTEMPTED`: HAL has crossed or may have crossed the transport boundary. It is no longer blindly replayable.
- `OCPP_ACCEPTED`: charger accepted the protocol command. It does not prove physical start/end.
- `OCPP_REJECTED`: explicit protocol rejection.
- `AMBIGUOUS`: timeout/lost response/uncertain result after possible delivery.
- `EXPIRED`: command was no longer eligible before a safe result.
- `SUPERSEDED`: later physical/command truth makes this retry ineligible.
- `MATERIALIZED`: resulting physical transaction identity has been correlated. It still does not mean CMS commercial completion.

Same `cms_command_id` plus identical immutable command returns the same HAL command. Same identity plus altered immutable command is an idempotency conflict.

## 19.5 HAL delivery fence

The database record MUST prove whether a command is still safely sendable.

Before network I/O:

1. select a `PERSISTED` command;
2. atomically claim it with a unique claim token/lease;
3. verify it is still eligible and mapped;
4. commit a delivery-attempt marker before the network call if the implementation cannot otherwise prove no transmission;
5. perform network I/O outside the database transaction;
6. persist the result with state/token fencing.

After the delivery-attempt marker is committed, a process crash cannot turn the row back into replayable `PERSISTED` state.

If final result persistence fails after the OCPP call, leave the durable row in attempted/ambiguous state and reconcile rather than resending.

## 19.6 Generic charger operations inherit the same no-replay safety

Administrative/technical operations such as:

```text
Reset
UnlockConnector
ChangeAvailability
SetChargingLimit
TriggerMessage / diagnostics request
future adapter-specific safe operations
```

use a durable operation model separate from ChargingStartIntent/ChargingStopRequest.

CMS-side states SHOULD preserve the mature operation-dispatch distinction:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

Important rules:

- CMS freezes destination and immutable request parameters at admission.
- Recovery never rebuilds destination from current mappings.
- CMS commits `DELIVERY_ATTEMPTED` before HAL I/O.
- No database transaction spans HAL network I/O.
- After possible delivery, CMS performs exact-ID HAL lookup only.
- `CONFIRMED_ABSENT` means HAL's durable exact lookup proves the operation was not accepted; it does not prove a physical effect and does not authorize automatic replay.
- A genuinely new operator instruction is a new operation with new authorization, reason, audit, and idempotency identity.

## 19.7 HAL recovery worker isolation

Preserve the currently hardened worker separation from `ocpp-hal-go-new`.

The dedicated generic charger-operation recovery worker MUST be separate from:

- charging deadline enforcement;
- automatic energy/time/funding stop workflows;
- pending charging-stop recovery;
- core connection handling.

A slow Reset/Unlock/diagnostic operation MUST NOT delay an automatic charging stop or transaction-lifecycle recovery.

Recommended worker behavior:

- sequential per process initially;
- bounded batch per pass;
- rotate fairly across active charger identities;
- avoid polling offline chargers for safely `PERSISTED` work;
- use the same atomic claim and typed dispatcher as immediate HTTP acceptance;
- no unbounded goroutines;
- request-detached final bookkeeping with a bounded deadline, still cancelled on HAL shutdown;
- startup converts any possibly sent `DELIVERY_ATTEMPTED` work to reconciliation rather than replay.

The exact interval/batch/timeout are configuration, not semantic constants.

## 19.8 Command payload contract

The Charger-on-Wheels internal start command SHOULD contain:

```json
{
  "cms_command_id": "<uuid>",
  "cms_start_intent_id": "<uuid>",
  "cms_charger_id": "<uuid>",
  "cms_connector_id": "<uuid>",
  "charger_protocol_identity": "<string>",
  "protocol_connector_number": 1,
  "id_tag": "cowv1_<opaque>",
  "credential_expires_at": "<rfc3339 utc>",
  "command_expires_at": "<rfc3339 utc>",
  "limit_type": "AUTO|ENERGY|TIME|MONEY",
  "energy_limit_wh": 0,
  "energy_limit_source": "NONE|CUSTOMER_ENERGY|CUSTOMER_MONEY|FUNDING_SAFETY",
  "max_duration_seconds": 0,
  "duration_limit_source": "NONE|CUSTOMER_TIME|CUSTOMER_MONEY|FUNDING_SAFETY"
}
```

The final field vocabulary MAY differ, but preserve these semantics:

- customer preference classification and enforcement thresholds are separate;
- energy and duration thresholds are independent;
- zero means no threshold, not zero entitlement;
- threshold provenance is explicit;
- HAL receives no tariff rates, GST, customer balance, payment credentials, or pricing formula;
- HAL reports why its stop workflow fired but CMS owns the business/commercial interpretation.

If Charger-on-Wheels later supports a trusted SoC stop threshold, add it compositionally as another capability/source. Do not overload `energy_limit_wh`.

## 19.9 Fact envelope and integrity

HAL facts are immutable protocol evidence.

Every authoritative fact includes at least:

```text
fact_id
fact_type
schema_version
occurred_at
producer
immutable_content_sha256
payload
```

The digest is calculated over the canonical immutable envelope with the digest field excluded. Use an explicit canonical JSON rule, such as RFC 8785 JCS, on both sides.

HAL sends:

```http
Authorization: Bearer <hal-to-cms-fact-token>
Idempotency-Key: <fact_id>
```

CMS behavior:

```text
new fact ID + valid digest -> durable receipt + projection transaction
same fact ID + same digest -> idempotent success/no-op
same fact ID + different digest -> integrity violation, no projection mutation
```

Do not use mutable payload reserialization as the dedupe identity.

## 19.10 Normalized facts

Initial required fact vocabulary:

```text
charger.connection.updated
connector.status.updated
command.updated
transaction.started
transaction.meter
transaction.soc          # optional when evidence exists
transaction.completed
fault.observed
capability.changed       # as needed
```

`command.updated` can advance command/recovery state but NEVER creates/completes a physical ChargingSession by itself.

## 19.11 Connection truth, restart behavior, and heartbeat

HAL is authoritative for current charger connection evidence.

Preserve these semantics:

- process-local connection generation fences stale callbacks only inside one process lifetime;
- durable `connection_sequence` orders projections across reconnects and process restarts;
- on HAL startup, prior connection state is first treated as `UNKNOWN` until new-process evidence establishes current truth;
- an accepted Heartbeat from the currently tracked connection is liveness evidence, advances the durable sequence/observed time, and preserves `ONLINE`;
- Heartbeat cannot create or resurrect a connection that the transport layer does not own;
- charger-supplied clocks are evidence, not authority for credential expiry or security deadlines;
- trusted HAL receipt time is used for expiry/deadline decisions subject to explicit bounded clock-skew validation.

CMS has a longer configurable connection stale horizon than HAL's requested heartbeat cadence.

## 19.12 Connector status projection

HAL accepts mapped `StatusNotification`/equivalent evidence and publishes a monotonic `connector_status_sequence`.

CMS stores historical status but derives live availability only when parent connection evidence is current.

Baseline mapping:

```text
no connector observation                         -> UNKNOWN
parent OFFLINE / UNKNOWN / stale                 -> STALE or UNAVAILABLE with stale reason
fresh ONLINE + protocol Available                -> AVAILABLE
fresh ONLINE + Preparing/Charging/Finishing      -> CHARGING/IN_USE category
fresh ONLINE + Faulted                           -> FAULTED
other fresh protocol status                      -> UNAVAILABLE
```

Inventory/admin state remains a separate overlay. A technically `Available` connector on an inactive/out-of-service charger is not dispatchable.

## 19.13 Fact acceptance classes

HAL input handling MUST distinguish evidence criticality:

- transaction start and transaction end are irreplaceable lifecycle truth and MUST commit with durable outbox evidence before protocol acknowledgement where protocol timing allows;
- accepted active-transaction MeterValues and mapped connector status SHOULD persist their normalized durable fact before acknowledgement where required for guaranteed evidence;
- Heartbeat is refreshable liveness evidence;
- socket connect/disconnect callbacks are transport evidence;
- stale/unsupported/unmapped/unrelatable observations do not advance authoritative projections.

Fail-safe boundary behavior beats guesswork.

## 19.14 Completion meter integrity

HAL accepts completion only for the exact active transaction and connector/protocol identity chain.

The effective cumulative final meter is nondecreasing.

A conflicting duplicate StopTransaction/completion is rejected and MUST NOT create a second terminal fact.

Concurrent stop lifecycle mutations lock durable rows in one documented canonical order, for example:

```text
transaction
-> stop workflow
-> remote command rows
-> outbox fact reservation
```

A local PostgreSQL deadlock/serialization failure may retry the uncommitted database transaction. It MUST NOT replay the OCPP network command.

## 19.15 Durable fact outbox

HAL facts are delivered with a durable outbox.

Delivery guarantees:

- same immutable fact ID/body retried until CMS durably acknowledges or a terminal receiver error requires operator reconciliation;
- delivery may be duplicate or out of order;
- one delivery lease belongs to one worker/token;
- expired lease may be reclaimed using a new token;
- stale worker result cannot overwrite a later claim;
- a retry never creates a replacement fact identity;
- per-call timeout stays inside lease budget;
- poison/terminal rows do not block unrelated facts.

The baseline implementation MAY serialize fact delivery initially to minimize ordering/concurrency complexity; scale only when measurement requires it.

## 19.16 Diagnostic trace plane is separate from fact truth

Preserve the mature split:

```text
Authoritative fact outbox -> CMS HAL fact ingress
Diagnostic trace outbox   -> CMS HAL trace ingress
```

Trace events:

- are sanitized immutable technical evidence;
- use a separate bearer/credential;
- have their own worker and retry budget;
- may contain CALL/CALLRESULT/CALLERROR and bounded follow-on evidence;
- NEVER establish charging lifecycle, connector availability, meter, settlement, or command truth;
- MUST NOT consume fact-delivery worker capacity or delay authoritative fact delivery.

A diagnostic "accepted but no follow-on observed" result remains a diagnostic conclusion, not proof that physical state did or did not change.

## 19.17 Raw evidence retention

HAL retains sufficient raw or sanitized protocol evidence to investigate:

- connection chronology;
- commands and responses;
- Start/Stop transaction evidence;
- MeterValues/SoC;
- connector status;
- adapter/vendor behavior;
- mapping/identity conflicts.

Requirements:

- no bearer tokens, credentials, passwords, or app charging credential in logs;
- access limited to technical/admin capability;
- retention configurable;
- immutable correlation links to normalized facts/commands where possible;
- ordinary User/Driver APIs never expose raw protocol payloads.

## 19.18 Simulator contract

The simulator is a protocol adapter/test system, not a toy.

It MUST support deterministic scripts for:

- initial connect and boot/registration;
- Heartbeat/liveness;
- mapped connector status;
- accepted/rejected start;
- command timeout before and after possible delivery;
- charger-originated transaction start;
- integer-Wh MeterValues;
- SoC-only and energy-only observations;
- local stop without CMS request;
- remote stop accepted but completion delayed;
- transaction completion;
- duplicate facts/messages;
- out-of-order meter/SoC sequence;
- reconnect during active transaction;
- HAL process restart and connection state reset to unknown;
- lost CMS fact receiver and outbox retry;
- conflicting duplicate evidence;
- generic administrative operation recovery;
- multiple charging sessions inside one ServiceJob.

CI scenarios MUST be reproducible from source-controlled fixtures.

---

# 20. CMS-HAL Cross-Repository Integration Contract

This section is intentionally self-contained. An implementer should not need the old EV-CMS or HAL repositories to understand the required Charger-on-Wheels integration behavior.

## 20.1 Source inheritance snapshot

This blueprint was hydrated on 2026-09-24 from the following current reference state:

```text
Reference CMS repo:
  Transmogriffy-Global-Private-Limited/ev-cms-backend-new
  observed main: dafcab3f11f403f4a70fd0d9f24064f3b873f3af

Reference HAL repo:
  Transmogriffy-Global-Private-Limited/ocpp-hal-go-new
  observed main: 1908c934c0e2570b81523e8ef3fe20be1e519da0
```

Important reference documents/code lines of behavior were:

```text
ev-cms-backend-new/docs/USERAPP_FE_HANDOFF.md
ev-cms-backend-new/docs/integrations/ocpp-hal-boundary.md
ev-cms-backend-new/docs/integrations/charger-operation-recovery.md
ev-cms-backend-new/docs/integrations/cpo-hal-operational-capability-manual.md

ocpp-hal-go-new/docs/ARCHITECTURE_BOUNDARY.md
ocpp-hal-go-new/docs/contracts/CMS_HAL_CHARGING_V1.md
ocpp-hal-go-new/docs/PROJECT_STATE.md
ocpp-hal-go-new current charger-operation recovery implementation
```

These repositories are provenance, not runtime dependencies. Charger-on-Wheels owns its own source and contract after implementation. Future upstream changes are reviewed deliberately rather than silently inherited.

### 20.1.1 Inheritance/adaptation matrix

The reference repositories are not copied wholesale. The following classification is normative for Charger on Wheels.

| Reference behavior | Charger-on-Wheels decision | Reason |
| --- | --- | --- |
| CMS and HAL have separate databases | **PRESERVE** | Keeps business truth and physical protocol truth independently recoverable. |
| Start intent exists before a charging session | **PRESERVE** | Command intent is not physical-start truth. |
| One-use short-lived app charging credential, distinct from customer identity | **PRESERVE** | Prevents identity leakage/replay and gives exact start correlation. |
| Exact CMS command -> HAL command -> HAL transaction -> OCPP transaction identity chain | **PRESERVE** | Recovery must never correlate by time/latest/guesswork. |
| Mapping synchronization plus pre-dispatch reconfirmation | **PRESERVE** | Closes inventory/mapping races before physical action. |
| Commit delivery fence before uncertain network I/O; exact-ID reconciliation after possible delivery | **PRESERVE** | Prevents duplicate physical commands after crash/timeout. |
| HAL durable fact outbox, immutable fact identity/digest, duplicate/out-of-order-safe CMS ingest | **PRESERVE** | Cross-service delivery is at-least-once in reality. |
| HAL raw evidence + normalized semantic facts | **PRESERVE** | Business code needs stable semantics while technical investigation retains protocol truth. |
| Independent connection, connector, meter, and SoC sequences/freshness | **PRESERVE** | Delayed evidence must not regress current projection. |
| User App talks only to CMS; CMS REST/snapshot is recovery authority | **PRESERVE** | Browser/mobile state cannot become a second business authority. |
| Rotating one-use refresh tokens and single-refresh client mutex | **PRESERVE** | Prevents refresh-token replay/races. |
| Realtime events are replayable hints/full snapshots, not sole truth | **PRESERVE** | App must recover after disconnect/background/token rotation. |
| Existing CPO tenancy and `X-CPO-App-ID` | **DO NOT INHERIT** | Charger on Wheels is one platform with User/Driver/Admin surfaces, not a CPO product. |
| CPO-vs-Platform support channels | **ADAPT** to `CUSTOMER_PLATFORM` and `DRIVER_PLATFORM` | Keeps actor separation without inventing CPO tenancy. |
| Stationary hub/charger discovery assumptions | **ADAPT/REPLACE** | This product dispatches a mobile ServiceVehicle + Charger through ServiceJob. |
| CPO subscription admission rule | **DO NOT INHERIT** | It is not part of this product model. Any future entitlement rule must be explicit. |
| Existing wallet requirement as the only start-funding model | **ADAPT** | Preserve commercial freeze/reservation ordering, but funding mechanism follows the selected customer payment strategy. |
| Generic administrative charger-operation recovery | **PRESERVE AS A SEPARATE PLANE** | Reset/unlock/diagnostics have different semantic completion than customer charging start/stop. |

When an inherited mechanism conflicts with the Charger-on-Wheels domain, preserve the safety/correctness property and adapt the domain vocabulary, not the old tenant/product assumption.

## 20.2 No shared database

CMS and HAL:

- have separate PostgreSQL databases;
- never read/write each other's tables;
- never share DB credentials;
- communicate only through authenticated versioned service contracts;
- reconcile using durable public service identities, never direct SQL.

## 20.3 Service authentication

Use separate opaque service credentials for at least:

```text
CMS -> HAL commands/mappings/reconciliation
HAL -> CMS authoritative facts
HAL -> CMS diagnostic traces
```

Do not reuse:

- customer access tokens;
- driver tokens;
- admin tokens;
- public API keys;
- one-use charging credentials.

Secrets are never included in OpenAPI examples, traces, logs, issue transcripts, or browser configuration.

Constant-time bearer comparison SHOULD be used where applicable.

## 20.4 Correlation and idempotency headers

Every mutating cross-service call uses:

```http
Idempotency-Key: <canonical durable mutation identity>
X-Correlation-ID: <canonical request/correlation uuid>
```

For command creation, `Idempotency-Key` equals the canonical `cms_command_id` carried in the body.

For fact/trace delivery, `Idempotency-Key` equals the immutable fact/event identity.

CMS-generated request/correlation identity is the service-to-service correlation authority. Clients may have their own request IDs for UI diagnostics but MUST NOT be able to choose cross-service business command identity.

## 20.5 Canonical internal API surface

The Charger-on-Wheels HAL v1 contract uses the following canonical service-only routes. These names are part of the blueprint and MUST change only through an explicit contract revision.

### CMS -> HAL

```text
PUT  /v1/mappings/chargers/{cms_charger_id}
POST /v1/remote-commands/start
POST /v1/remote-commands/stop
GET  /v1/remote-commands?cms_command_id={uuid}
GET  /v1/transactions?cms_start_intent_id={uuid}
GET  /v1/transactions/{hal_transaction_id}
```

Generic administrative charger operations use a separate service surface:

```text
POST /v1/charger-operations
GET  /v1/charger-operations?cms_operation_id={uuid}
```

Charging start/stop and generic administrative operations remain separate because their semantic completion truths differ.

### HAL -> CMS

```text
POST /internal/v1/hal-facts
POST /internal/v1/hal-trace-events
```

The HAL calls those paths on the private CMS service origin. They are not registered in the public User/Driver/Admin route groups.

A batch fact endpoint is optional only if it preserves per-fact immutable identity, response semantics, and retry isolation. Do not introduce batching merely for appearance.

## 20.6 Cross-service response semantics

`202` from HAL means the logical command is durably accepted/known by HAL according to the command contract. It never means:

- protocol command was accepted by the charger;
- transaction started;
- transaction completed;
- charging energy flowed;
- customer payment is final;
- ServiceJob is complete.

Stable error categories:

| HTTP | Meaning | Automatic behavior |
| --- | --- | --- |
| 400 | malformed envelope/header/identity/timestamp/integer | fix request; no blind retry |
| 401/403 | bad service identity or scope | repair auth/config first |
| 404 | exact durable resource absent | apply resource-specific reconciliation rule; never guess |
| 409 | idempotency/integrity/correlation/state conflict | stop automatic mutation and reconcile |
| 410 | command/credential/window expired | do not revive automatically |
| 422 | semantic mapping/connector/limit invalid | correct source state |
| 429/500/502/503/504 | transient service/capacity/transport | retry same immutable identity only where operation's replay rules permit; otherwise exact-ID reconcile |

## 20.7 Immutable CMS command record

CMS stores an immutable dispatch envelope before HAL I/O.

For start/stop it includes, as relevant:

```text
cms_command_id
kind
start_intent_id / charging_session_id
service_job_id
charger_id
connector_id
dispatch_charger_protocol_identity
dispatch_connector_number
request_digest
correlation_id
idempotency_key
command_expires_at
requested limits + provenance
created_at
```

A database guard or service-level invariant MUST prevent an attempted command's frozen destination/immutable input from being edited into a different physical action.

## 20.8 CMS start request exact sequence

The intended cross-repo sequence is:

```text
User/Driver action
-> CMS auth and ServiceJob authorization
-> validate current assignment/duty/assets/compatibility
-> ensure exact HAL mapping exists
-> CMS transaction:
     freeze charging commercial/admission terms
     create any required funding reservation
     create one-use credential
     create ChargingStartIntent REQUESTED
     create immutable CMS START command record
-> commit
-> reconfirm exact mapping revision/destination
-> RequestStart to HAL using same cms_command_id
-> project returned durable HAL command state
-> return start-progress object, not a ChargingSession unless already materialized concurrently

later:
HAL protocol RemoteStart accepted/rejected/ambiguous
-> command.updated fact / exact lookup can update command/start-progress

later:
charger-originated transaction start
-> HAL transaction.started immutable fact
-> CMS validates entire identity chain
-> create ChargingSession ACTIVE exactly once
-> start intent ACTUALLY_STARTED
-> ServiceJob CHARGING when field-service transition is valid
-> durable operational event
-> User/Driver/Admin projections refresh
```

## 20.9 CMS stop request exact sequence

```text
User/Driver/Admin/system stop request
-> authorize against existing materialized ChargingSession
-> create/reuse durable ChargingStopRequest and STOP command
-> RequestStop to HAL using exact cms_command_id
-> project durable HAL command state
-> session ACTIVE/STOP_PENDING
-> return accepted-stop-progress

later:
charger-originated transaction completion
-> HAL transaction.completed fact
-> CMS validates exact transaction identity/final meter/time
-> locked exactly-once session finalization + commercial settlement
-> ServiceJob wrap-up transition only when other operational invariants permit
```

An exact HAL lookup returning a missing STOP command does not prove the physical transaction stopped. A materialized session remains open/reconciling until transaction evidence says otherwise.

## 20.10 HAL fact ingress transaction

CMS fact ingestion ordering:

1. authenticate the HAL fact service bearer;
2. validate `Idempotency-Key == fact_id`;
3. validate schema version and envelope;
4. recompute immutable canonical digest;
5. begin DB transaction;
6. lock/read existing fact receipt by `fact_id`;
7. exact same digest -> idempotent success;
8. same ID/different digest -> integrity conflict, no projection change;
9. validate mapping and identity chain for the fact type;
10. insert immutable receipt;
11. apply monotonic projection/business transition;
12. insert durable operational/domain event when state actually changes;
13. commit;
14. only then return success to HAL.

A receiver crash before COMMIT results in HAL retrying the same fact. A receiver crash after COMMIT but before HTTP response results in a duplicate that becomes a no-op success.

## 20.11 Monotonic runtime projection

CMS maintains projections with explicit sequence and freshness:

```text
charger connection:
  state
  connection_sequence
  observed_at

connector status:
  status
  connector_status_sequence
  observed_at

session meter:
  meter_sequence
  meter_value_wh
  consumed_wh
  observed_at

session SoC:
  soc_sequence
  soc_percent
  observed_at
```

Only advancing sequence updates the current projection.

A delayed old fact remains evidence but cannot move the UI backward.

Freshness is derived at read time or through a rebuildable projection using configured stale horizons. A stale connection makes retained connector/meter/SoC evidence historical rather than fresh.

## 20.12 Runtime reads never synchronously depend on HAL

Ordinary User, Driver, and Admin list/detail/live reads query CMS durable projections.

They MUST NOT synchronously call HAL for:

- customer live job screen;
- charging history;
- driver current job screen;
- fleet list;
- charger list;
- meter display;
- connector availability list.

Exact HAL reads are reconciliation/technical operations, not ordinary presentation dependencies.

This keeps UI available during HAL outage and prevents N+1 provider calls.

## 20.13 Operational events and realtime

When an authoritative CMS transaction changes a projection, CMS writes notification-sized durable operational events in the same transaction.

Representative event types:

```text
service_job.changed
dispatch.changed
driver.location.changed
charger.live_state_changed
connector.live_state_changed
charging.command_changed
charging.session_changed
charging.meter_changed
charging.soc_changed
payment.changed
invoice.changed
support.changed
```

Events tell consumers that state changed. They are not the state authority.

## 20.14 Exact-ID reconciler ownership

A CMS reconciler owns unresolved cross-service truth.

It handles at least:

- start command ambiguity;
- accepted start with missing transaction-start fact;
- open materialized session with missing completion fact;
- generic charger operation ambiguity;
- mapping synchronization retry.

Requirements:

- bounded batch;
- stable cursor/fair ordering;
- persistent backoff/recovery-after time;
- no unbounded goroutine per row;
- no new logical command identity for recovery;
- poison row isolation;
- structured safe diagnostics;
- stop/shutdown joins worker before DB close.

## 20.15 Mapping reconciler

Mapping synchronization is its own durable concern.

States SHOULD include:

```text
PENDING
SYNCHRONIZED
RECONCILIATION_REQUIRED
DISABLED / RETIRED where appropriate
```

Inventory edits commit CMS first. Mapping delivery occurs post-commit and can fail independently.

A failed mapping never causes CMS to silently rewrite local inventory to match stale HAL state.

## 20.16 Restart and outage behavior

### CMS restart

- durable start/stop/operation/fact state survives;
- unresolved rows remain unresolved;
- reconcilers resume from durable cursor/backoff;
- no command is replayed simply because the process restarted;
- User/Driver/Admin recover current state through CMS REST/snapshot APIs.

### HAL restart

- durable command/transaction/fact/outbox state survives;
- possibly sent commands become reconciliation candidates, not replay candidates;
- prior connection projection becomes unknown until new connection evidence arrives;
- active transaction recovery uses protocol/device evidence where possible;
- fact delivery resumes with same immutable fact IDs.

### CMS unavailable while HAL continues

- HAL retains authoritative facts in its outbox;
- it retries with same identity;
- physical transaction handling/deadline safety continues according to HAL-owned workflow;
- no CMS availability assumption is allowed to corrupt OCPP lifecycle.

### HAL unavailable while CMS continues

- CMS read surfaces remain available from durable projections with stale/unknown truth shown honestly;
- new charging starts fail/queue according to explicit admission policy, never pretend success;
- active-session stop intent is retained/retried/reconciled without declaring physical completion;
- business settlement waits for authoritative completion evidence.

## 20.17 Cross-repository contract tests

The new project MUST have versioned consumer/provider fixtures so contract drift is found without relying only on deployed end-to-end tests.

At minimum:

```text
CMS request fixture -> HAL request parser
HAL response fixture -> CMS parser
HAL fact fixture -> CMS fact ingestor
CMS mapping fixture -> HAL mapping store
exact command lookup fixtures
exact transaction lookup fixtures
error/status fixtures
immutable digest fixtures
```

CI should run these in both repositories against the same versioned fixture package/artifact or duplicated generated fixture with digest/version verification.

## 20.18 Full virtual charger acceptance

Before calling charging integration complete, a disposable CMS PostgreSQL + HAL PostgreSQL + virtual charge point test proves:

```text
CMS inventory/mapping
-> HAL mapping synchronized
-> ServiceJob start-eligible
-> ChargingStartIntent committed
-> HAL start command durably accepted
-> protocol start accepted
-> charger-originated transaction start
-> CMS ChargingSession materialized
-> connection/status projection fresh
-> meter facts ordered
-> optional SoC independent
-> stop request
-> physical completion
-> exactly-once finalization
-> invoice/payment/commercial result consistent
-> User REST/history consistent
-> Driver live/history consistent
-> Admin projection consistent
-> restart/outage reconciliation converges
```

Also prove:

- lost start response;
- command exact-lookup absent/present;
- delayed start fact;
- late start after local expiry/rejection;
- missing completion fact recovered by exact transaction lookup;
- duplicate fact;
- altered same-ID fact conflict;
- out-of-order meter;
- HAL restart during active charge;
- CMS outage during meter/completion;
- generic charger operation does not starve automatic stop worker;
- realtime disconnect does not lose recoverability.

Physical charger acceptance is a separate later gate and MUST be reported separately from virtual integration success.

---

# 21. Pricing Engine Blueprint

## 21.0 Stable pricing contract required before B06.3

B06.3 MUST NOT create a disposable "quote shell" that Program 10 later replaces. The first quote implementation is a deliberately small capability set behind the final pricing semantic contract.

The stable engine boundary is conceptually:

```text
EvaluatePricing(
  mode,                 # QUOTE or FINAL
  policy_version,
  pricing_context,
  source_facts
) -> PricingEvaluation

PricingEvaluation
  policy_id
  policy_version
  currency
  timezone
  line_items[]
  subtotal_minor
  tax_minor
  total_minor
  assumptions[]
  source_fact_refs[]
```

The exact Go type names may differ, but these semantics MUST remain stable.

For B06.3, the implementation MAY initially activate only the components that can be calculated truthfully before charging integration, such as fixed visit/service components and explicitly available distance/zone inputs. Unknown future quantities remain assumptions/conditional components; they are never fabricated. The evaluator still returns typed line items using the same money, policy-version, condition, operator, source-reference, and snapshot vocabulary used by the full engine.

Program 10 extends supported rule/component evaluation and binds final authoritative facts. It MUST NOT require replacing quote identity, line-item meaning, policy versioning, snapshot semantics, or the public quote contract merely because more pricing capabilities become available.

If B06.3 cannot be implemented without inventing a business rate, it uses an Admin-configured seed policy or test fixture. Rates are data, not hard-coded architectural defaults.

## 21.1 Pricing ownership

CMS owns all customer-facing commercial truth.

Pricing is configured by Admin, evaluated by CMS, snapshotted at quote/job/finalization boundaries, and never delegated to Driver or HAL.

## 21.2 Policy model

Use versioned policies rather than one mutable global price table.

```text
pricing_policies
  id
  name
  status              # DRAFT, ACTIVE, RETIRED
  currency
  timezone
  effective_from
  effective_to nullable
  version
  created_by
  created_at
  activated_at nullable
  retired_at nullable
```

`pricing_rules`:

```text
id
pricing_policy_id
component_type
operator
priority
conditions jsonb
calculation jsonb
effective_from
effective_to nullable
is_enabled
rule_version
created_at
```

Policies/rules referenced by historical snapshots are never destructively rewritten.

## 21.3 Initial price components

The engine MUST be able to represent these components independently:

```text
VISIT_FEE
DISTANCE_FEE
TRAVEL_TIME_FEE
WAITING_TIME_FEE
ENERGY_FEE
CHARGING_TIME_FEE
FAST_CHARGE_PREMIUM
CONVENIENCE_FEE
PRIORITY_FEE
TIME_WINDOW_MODIFIER
DATE_WINDOW_MODIFIER
ZONE_FEE
DISCOUNT
PROMOTION
MANUAL_ADJUSTMENT
TAX
```

Not every deployment must activate every component.

## 21.4 Rule operators

Supported operators:

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM
MAXIMUM
CAP
```

Operator semantics MUST be deterministic.

Recommended evaluation order:

1. establish raw measurable quantities;
2. calculate base component rules;
3. apply component-specific overrides;
4. apply multipliers/modifiers in ascending priority;
5. apply minimum/maximum/caps;
6. apply discounts/promotions according to explicit stacking rules;
7. calculate tax on explicitly defined taxable bases;
8. apply manual post-finalization adjustments only as separate ledger entries, never by mutating original line items.

## 21.5 Applicability conditions

Rules may condition on bounded, explicit dimensions:

- service type;
- zone;
- customer segment if introduced;
- connector/charging mode;
- charger power band;
- day of week;
- local time window;
- date/date range;
- immediate vs scheduled request;
- priority/emergency flag;
- distance band;
- waiting duration band;
- energy band;
- promotion code.

Do not permit arbitrary executable expressions from Admin input.

## 21.6 Quote calculation

Quote uses known facts and documented assumptions.

Example:

```text
fixed visit fee                        known
estimated travel distance/time         estimated
energy fee                             estimated by requested target / known battery data
waiting                                usually unknown / shown as conditional
final tax                              estimated from quoted taxable components
```

Every estimated component SHOULD expose:

```text
component_type
quantity_estimate
unit
rate
amount_minor
is_estimate
assumption
```

## 21.7 Finalization

Final customer price uses authoritative actual facts where the rule requires them:

- route/eligible travel distance from trusted location/route facts;
- eligible travel duration from job timestamps;
- waiting duration from defined lifecycle boundaries;
- charging time from HAL transaction facts;
- energy from HAL meter facts;
- applicable local-time/date windows from timestamps plus policy timezone;
- accepted promotions from durable promotion records.

Pricing policy changes after the quote/job boundary MUST NOT silently change the already accepted policy snapshot unless product explicitly defines re-quote behavior before dispatch.

## 21.8 PricingSnapshot

`pricing_snapshots` MUST persist:

```text
id
service_job_id
source_quote_id
policy_id
policy_version
currency
timezone
rule_snapshot jsonb
input_snapshot jsonb
created_at
```

Final line items:

```text
customer_charge_line_items
  id
  service_job_id
  pricing_snapshot_id
  component_type
  quantity
  unit
  rate_minor nullable
  operator
  amount_minor
  taxability_code nullable
  source_fact_refs jsonb
  calculation_metadata jsonb
  created_at
```

Final amount is the sum of immutable finalized line items plus explicit later adjustment/refund semantics.

## 21.9 Cancellation/no-show pricing

Cancellation and no-show charges are policy rules, not hard-coded branches.

Conditions may include lifecycle state and timing:

- before assignment;
- after assignment;
- after driver en route;
- after arrival;
- customer no-show;
- driver/platform failure.

Platform-caused failures SHOULD default to no customer penalty unless an explicit business rule says otherwise.

The exact monetary rates remain Admin policy data, not source-code constants.

---

# 22. Payment Blueprint

## 22.1 Provider

Initial customer payment provider: Razorpay.

The provider integration MUST be replaceable behind a payment service contract so core ServiceJob semantics are not Razorpay-specific.

## 22.2 Payment model

`payments`:

```text
id
service_job_id
customer_id
provider
provider_order_id nullable
provider_payment_id nullable
currency
amount_minor
purpose
status
idempotency_key
created_at
updated_at
```

Canonical status:

```text
CREATED
PENDING
AUTHORIZED
CAPTURED
FAILED
CANCELLED
REFUND_PENDING
PARTIALLY_REFUNDED
REFUNDED
```

Do not infer CAPTURED from client callback alone.

## 22.3 Payment order creation

Payment order creation is idempotent.

The backend stores the provider order identity before returning it when possible.

A retry with the same idempotency key reuses the same logical payment order.

## 22.4 Verification

Provider success is established through authenticated server verification:

- signature verification for client-returned payment proof where applicable;
- provider API reconciliation where needed;
- webhook processing;
- idempotent status advancement.

A client telling the backend `payment_success=true` is never authoritative.

## 22.5 Webhooks

Webhook ingress MUST:

1. verify provider signature before parsing into trusted events;
2. persist provider event ID/hash;
3. reject or idempotently accept duplicates;
4. process within a transaction;
5. maintain monotonic payment semantics unless explicit provider correction is supported;
6. emit durable internal event after commit.

## 22.6 Payment timing

The exact customer commercial flow may use preauthorization/hold, deposit, or final payment depending on Razorpay capabilities and business choice.

The blueprint requirement is invariant:

- the platform must not allow a payment race to rewrite finalized job facts;
- final charge amount must be tied to finalized pricing line items;
- any delta between pre-collected amount and final amount has an explicit settlement/refund/additional-charge path;
- failure to collect final money is a commercial state, not a reason to falsify ServiceJob physical completion.

## 22.7 Payment vs job completion

`ServiceJob.COMPLETED` means the field service completed successfully.

Payment may still require reconciliation.

Admin and User views must expose both service status and payment status instead of encoding one into the other.

---

# 23. Refunds and Commercial Adjustments

## 23.1 Refund model

`refunds`:

```text
id
payment_id
service_job_id
amount_minor
currency
reason_code
reason_note nullable
status               # REQUESTED, SUBMITTED, SUCCEEDED, FAILED, CANCELLED
provider_ref nullable
idempotency_key
requested_by_actor_type
requested_by_actor_id
created_at
updated_at
```

## 23.2 Refund safety

Refund request MUST validate:

- captured refundable payment exists;
- requested amount does not exceed remaining refundable amount;
- same logical refund has not already succeeded/pended;
- actor has permission;
- reason is recorded.

Provider timeouts are reconciled by stable refund identity/provider status before retrying.

## 23.3 Manual commercial adjustments

Corrections after invoice/finalization are explicit adjustment records.

Never silently rewrite historical base pricing line items.

Adjustment types may include:

```text
CUSTOMER_CREDIT
CUSTOMER_DEBIT
GOODWILL_CREDIT
DISPUTE_CORRECTION
TAX_CORRECTION
ROUNDING_CORRECTION
```

Accounting/invoice handling for post-invoice tax corrections must comply with the chosen GST/accounting process and may require credit/debit-note features in a later scope.

---

# 24. GST and Invoice Blueprint

## 24.1 Tax snapshots

The system MUST snapshot tax-relevant configuration used for a finalized job/invoice.

`gst_snapshots` may include:

```text
supplier legal name
supplier GSTIN
supplier address
place of supply
customer tax identity if supplied
SAC/HSN classifications as applicable
rates
component taxability
CGST/SGST/IGST split
rounding rules
```

Do not recalculate old invoices from current tax configuration.

## 24.2 Invoice lifecycle

Canonical states:

```text
PENDING
GENERATING
READY
FAILED
VOIDED
```

A READY invoice artifact is immutable.

If a correction legally requires a new document, create a new version/corrective document rather than regenerating the same historical file in place.

## 24.3 Invoice artifact storage

Invoices are private artifacts.

Requirements:

- non-public storage;
- access only through authenticated authorization-checked API or signed short-lived delivery mechanism;
- checksum stored;
- renderer/version stored;
- no predictable public static URL;
- backup/retention policy.

## 24.4 Invoice creation flow

1. Service commercial finalization completes.
2. Payment state reaches the configured invoice eligibility boundary.
3. Durable invoice generation intent is created.
4. Worker loads frozen job/pricing/GST/customer/supplier facts.
5. Renderer produces deterministic PDF/artifact.
6. Artifact checksum and metadata are stored.
7. Invoice becomes READY atomically with artifact registration.
8. Notification/mail intent is enqueued after commit.

Rendering failure leaves recoverable FAILED/PENDING state and never marks READY without an artifact.

## 24.5 Download permissions

- User: own job invoice only.
- Admin Finance/Commercial: any invoice permitted by capability.
- Driver: no customer invoice by default.

---

# 25. Driver Compensation Engine Blueprint

## 25.1 Scope

Driver compensation is calculation, explanation, aggregation, and correction only.

It MUST NOT represent bank/payment execution.

The word `paid` must not appear as a compensation lifecycle status unless a future accounting/payout module explicitly introduces and owns that truth.

## 25.2 Policy model

`compensation_policies`:

```text
id
name
status              # DRAFT, ACTIVE, RETIRED
currency
timezone
effective_from
effective_to nullable
version
created_by
created_at
activated_at nullable
```

`compensation_rules`:

```text
id
policy_id
component_type
operator
priority
scope jsonb
conditions jsonb
calculation jsonb
time_basis nullable
rule_version
is_enabled
created_at
```

## 25.3 Initial component types

```text
COMPLETED_JOB_BASE
TRAVEL_DISTANCE
TRAVEL_TIME
WAITING_TIME
CHARGING_TIME
ENERGY_DELIVERED
REVENUE_COMMISSION
PER_CHARGE
TIME_WINDOW_MODIFIER
DATE_WINDOW_MODIFIER
ZONE_MODIFIER
DRIVER_OVERRIDE
DRIVER_GROUP_MODIFIER
BONUS
PENALTY
MINIMUM_GUARANTEE
CAP
MANUAL_ADJUSTMENT
```

## 25.4 Rule operators

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM_GUARANTEE
CAP
```

Evaluation order MUST be explicitly deterministic.

Recommended order:

1. calculate base additive components;
2. apply explicit scoped overrides to rates/quantities;
3. calculate modifiers/multipliers in priority order;
4. apply minimum guarantee;
5. apply caps;
6. append manual adjustments separately.

## 25.5 Source facts

Compensation uses authoritative system facts wherever possible:

```text
travel distance         <- trusted location/route evidence under defined basis
travel time             <- job lifecycle timestamps
waiting time            <- defined ARRIVED/preparation/charging boundaries
charging time           <- HAL transaction evidence
energy delivered        <- HAL meter evidence
completed job           <- terminal ServiceJob fact
revenue                 <- finalized customer commercial line items
zone                    <- service location / defined operating zone snapshot
```

Driver-entered freeform values are not authoritative financial inputs without explicit Admin approval workflow.

## 25.6 Time basis

Every time-sensitive rule MUST declare one of:

```text
JOB_START
JOB_END
EVENT_TIME
INTERVAL_PRORATED
```

For `INTERVAL_PRORATED`, the engine splits the relevant measurable interval across local-time rule boundaries.

Example: 21:45-22:35 job with night rule at 22:00.

The engine must calculate pre-22:00 and post-22:00 quantities separately when the component is interval-prorated.

## 25.7 CompensationSnapshot

When a ServiceJob reaches the compensation finalization boundary, freeze:

```text
compensation_snapshots
  id
  service_job_id
  driver_id
  assignment_id
  policy_id
  policy_version
  timezone
  source_fact_snapshot jsonb
  rule_snapshot jsonb
  calculated_at
```

## 25.8 Ledger line items

`compensation_line_items`:

```text
id
compensation_snapshot_id
service_job_id
driver_id
component_type
rule_id
rule_version
quantity
unit
rate_minor nullable
operator
amount_minor
source_fact_refs jsonb
calculation_metadata jsonb
created_at
```

The total is derived from line items, not stored as the only truth.

## 25.9 Adjustments

A correction creates a new `compensation_adjustments` record/line item with reason, actor, and target prior calculation.

Never edit old finalized line items to make the total look correct.

## 25.10 Reassignment allocation

If more than one driver serves one ServiceJob, compensation MUST be attributable by assignment/duty interval.

Default rule:

- each driver receives only components supported by facts from their own assignment interval;
- completed-job base goes to the driver who completes the job unless policy explicitly defines split/credit semantics;
- travel distance/time are assignment-specific;
- charging metrics belong to the driver assignment active during those facts unless an Admin correction reallocates them.

This prevents a reassigned driver from receiving or losing unrelated work silently.

## 25.11 Summaries

Daily/weekly/monthly/custom-range views are aggregates over immutable line items and adjustments.

They must not be separately maintained money totals that can drift.

---

# 26. Ratings and Reviews

## 26.1 Ownership

A customer may rate only a ServiceJob they own and that reached an eligible terminal state.

Initial eligible state: `COMPLETED`.

## 26.2 Rating model

`ratings_reviews`:

```text
id
service_job_id
customer_id
driver_id nullable
rating integer          # 1..5
review_text nullable
created_at
updated_at
version
```

Enforce one rating per customer + ServiceJob.

Customer may edit their own rating/review.

## 26.3 Privacy

User-facing aggregates MUST NOT expose identities of other customers.

Admin may see review text and associated operational context under `ratings.read`.

Driver may see their own aggregate and review text only according to product policy; customer contact/identity should not be exposed merely because a review exists.

## 26.4 Aggregates

Average/rating count SHOULD be computed from authoritative ratings or a rebuildable projection.

If a projection is used for scale, it is derived and must be repairable.

---

# 27. Support and Incident Blueprint

Support and incidents are separate concepts.

- Support: customer/driver asks for assistance or reports a service issue conversationally.
- Incident: operational/safety/technical event requiring structured investigation or resolution.

## 27.1 Support channels

Initial channels:

```text
CUSTOMER_PLATFORM
DRIVER_PLATFORM
```

A support ticket MUST have exactly one owner plane.

## 27.2 Ticket model

```text
support_tickets
  id
  channel
  customer_id nullable
  driver_id nullable
  service_job_id nullable
  subject
  status
  priority
  created_at
  updated_at
  closed_at nullable
```

Status:

```text
OPEN
IN_PROGRESS
RESOLVED
CLOSED
```

Customer/Driver replies to RESOLVED/CLOSED MAY reopen to OPEN under the same durable rules used in the mature EV-CMS support model.

## 27.3 Messages

`support_messages` is append-only.

App-side projections expose author class (`CUSTOMER`, `DRIVER`, `SUPPORT`) rather than unnecessary staff identity.

Private internal notes are separate records and MUST NOT leak to User/Driver clients or outbound mail.

## 27.4 Reply idempotency

Replies require idempotency key and durable uniqueness.

Duplicate retry must not create duplicate message, event, or notification intent.

## 27.5 Incident model

`incidents`:

```text
id
service_job_id nullable
duty_session_id nullable
driver_id nullable
vehicle_id nullable
charger_id nullable
type
severity
status              # OPEN, INVESTIGATING, MITIGATED, RESOLVED, CLOSED
reported_by_actor_type
reported_by_actor_id
reported_at
summary
resolution nullable
resolved_at nullable
```

Examples:

- vehicle breakdown;
- charger fault;
- asset mismatch;
- safety event;
- customer dispute;
- driver emergency;
- HAL unrecoverable fault.

High-severity incidents may block asset/driver eligibility through explicit operational holds rather than silently modifying unrelated master records.

---

# 28. Notification Blueprint

## 28.1 Durable notification intent

Important notifications are produced through a durable outbox after the authoritative transaction commits.

Channels may include:

- in-app;
- push;
- email;
- SMS if later integrated.

## 28.2 Notification content rule

Do not copy sensitive freeform support message bodies, raw KYC, auth data, or raw protocol payloads into external notification payloads.

Use bounded metadata and deep links.

## 28.3 Preference model

Customer/Driver notification preferences may disable optional categories, but mandatory security/safety/legal messages remain governed by platform policy.

Preferences are scoped by notification category and channel.

## 28.4 Delivery states

```text
PENDING
CLAIMED
SENT
FAILED_RETRYABLE
FAILED_TERMINAL
CANCELLED
```

`SENT` means accepted by the configured provider, not necessarily read by the human unless the provider supplies a separate delivery/read fact.

---

# 29. Realtime Blueprint

## 29.1 Purpose

Realtime improves responsiveness. It does not replace durable HTTP state.

## 29.2 Subscription scope

A client may subscribe only to resources it is authorized to read.

Suggested channels/topics:

```text
user:{customer_id}
job:{service_job_id}
driver:{driver_id}
duty:{duty_session_id}
admin:operations
admin:hal
```

Server authorization derives IDs from auth context and resource permissions. Clients cannot subscribe to arbitrary user/driver topics by guessing IDs.

## 29.3 Event envelope

```json
{
  "event_id": "...",
  "type": "service_job.updated",
  "resource_type": "service_job",
  "resource_id": "...",
  "occurred_at": "...",
  "version": 17,
  "request_id": "...",
  "data": { }
}
```

For important state, `data` may be only a compact projection. REST remains recovery authority.

## 29.4 Ordering

Per-resource version or sequence is recommended so clients can detect missed/out-of-order events.

Clients receiving version 15 after version 17 ignore stale data.

A gap can trigger REST refresh.

## 29.5 User realtime

User may receive:

- request/quote expiry;
- dispatch progress;
- assignment;
- driver/mobile unit public projection;
- ETA/location updates;
- arrival;
- charging readiness;
- physical charging start;
- live energy/power/SoC where available;
- projected cost;
- charging end;
- wrap-up/completion;
- payment/invoice changes;
- support updates.

## 29.6 Driver realtime

Driver may receive:

- schedule changes;
- offer created/withdrawn/expired;
- assignment changes;
- job/customer service-location projection;
- admin correction of pairing;
- HAL readiness/fault state;
- charging state;
- compensation calculation completion;
- support/incident updates.

## 29.7 Admin realtime

Admin may receive broad operational invalidations/projections by capability:

- online drivers;
- duty sessions;
- locations;
- dispatch queues;
- jobs;
- asset mismatch;
- charger/HAL connectivity;
- faults;
- payment exceptions;
- invoice failures;
- support/incident queues.

Do not push secrets or full sensitive records over a generic operations stream.


# 30. Unified Admin Product Blueprint

Admin is one product with capability-gated surfaces, not separate products pretending to be different authorities.

## 30.1 Admin home / operational dashboard

Must be able to answer quickly:

- How many drivers are currently on duty/available/busy/unavailable?
- Which ServiceJobs are dispatching, assigned, en route, at customer, charging, wrapping up, or exceptioned?
- Which vehicles/chargers are available, claimed, in use, under maintenance, offline, or faulted?
- Which chargers/HAL connections are stale/offline/faulted?
- Which payments/refunds/invoices require attention?
- Which asset mismatches/incidents/support tickets require attention?

Dashboard metrics are derived projections, not independent truth tables.

## 30.2 Driver recruitment

Admin can:

- list/search/filter applications;
- inspect current application and versioned documents;
- move through explicit review actions;
- request changes with structured reason;
- approve/reject;
- complete onboarding;
- inspect audit history;
- suspend/offboard an operational driver separately from application history.

## 30.3 Fleet

Admin can:

- CRUD/deactivate vehicles and chargers with optimistic concurrency;
- manage connectors/capabilities metadata;
- manage maintenance intervals;
- manage effective-dated pairings;
- inspect active claims and duty use;
- inspect HAL projection and last seen;
- search/filter/sort inventory;
- resolve observed mismatch reports without rewriting duty history.

## 30.4 Schedules and assignments

Admin can:

- create one-off/recurring schedules;
- materialize occurrences;
- assign/suggest assets;
- cancel future occurrences;
- inspect planned vs actual start/end;
- inspect deviations;
- not overwrite started/completed history.

## 30.5 Dispatch operations

Admin can:

- view candidate/offer/assignment state;
- retry dispatch;
- directly assign an eligible driver;
- override with explicit reason only when policy allows;
- reassign active work;
- see why candidates are ineligible when diagnostic evidence exists;
- never bypass physical compatibility silently.

## 30.6 Job operations

Admin may perform explicit actions such as:

- cancel job;
- mark no-show with evidence/reason;
- reassign;
- record operational correction;
- close exception after charging/field-service facts reconcile.

No generic unrestricted status editor is permitted.

## 30.7 Technical/HAL operations

Technical Admin may:

- view charger connection state;
- view normalized capabilities;
- inspect operation state and exact operation ID;
- inspect normalized facts;
- inspect protected raw trace/evidence;
- request supported technical commands with explicit reason;
- reconcile uncertain state.

Technical actions still respect ServiceJob/charging safety boundaries.

## 30.8 Finance/commercial

Finance Admin may:

- manage versioned pricing policies;
- inspect quotes/final charges;
- inspect payments;
- issue permitted refunds;
- inspect/generate/retry invoices;
- inspect tax snapshots;
- manage compensation policies separately;
- create compensation adjustments with reason.

## 30.9 Support/incident

Support/Admin can view and act according to channel/capability.

Incident actions are structured and audited.

---

# 31. Public API Surface - User App

The exact request/response schemas belong in OpenAPI. This section defines required semantic operations.

## 31.1 Authentication/profile

The User App preserves the mature verified email + password + OTP flow, adapted to the single Charger-on-Wheels platform account model.

```text
POST   /api/v1/app/auth/signup
POST   /api/v1/app/auth/signup/verify
POST   /api/v1/app/auth/signup/resend

POST   /api/v1/app/auth/login
POST   /api/v1/app/auth/login/verify
POST   /api/v1/app/auth/login/resend

POST   /api/v1/app/auth/refresh
POST   /api/v1/app/auth/logout
POST   /api/v1/app/auth/logout-all
GET    /api/v1/app/auth/sessions
DELETE /api/v1/app/auth/sessions/{session_id}

POST   /api/v1/app/auth/password/forgot
POST   /api/v1/app/auth/password/reset/resend
POST   /api/v1/app/auth/password/reset
POST   /api/v1/app/auth/password/change

GET    /api/v1/app/me
PATCH  /api/v1/app/profile
```

There is no `X-CPO-App-ID` or CPO-local account scope. The authenticated Customer account belongs to this platform. Email uniqueness and any future multi-brand partitioning are CMS domain rules, not client-supplied tenant selection.

## 31.2 Saved vehicles

```text
GET    /api/v1/app/vehicles
POST   /api/v1/app/vehicles
GET    /api/v1/app/vehicles/{vehicle_id}
PATCH  /api/v1/app/vehicles/{vehicle_id}
DELETE /api/v1/app/vehicles/{vehicle_id}      # deactivate/remove from saved list
```

Deletion does not alter historical snapshots.

## 31.3 Saved addresses

```text
GET    /api/v1/app/addresses
POST   /api/v1/app/addresses
GET    /api/v1/app/addresses/{address_id}
PATCH  /api/v1/app/addresses/{address_id}
DELETE /api/v1/app/addresses/{address_id}
POST   /api/v1/app/addresses/{address_id}/make-default
```

## 31.4 Service request and quote

```text
POST /api/v1/app/service-requests
GET  /api/v1/app/service-requests/{request_id}
POST /api/v1/app/service-requests/{request_id}/quote
POST /api/v1/app/quotes/{quote_id}/accept
```

Quote acceptance is idempotent.

## 31.5 Jobs

```text
GET  /api/v1/app/jobs
GET  /api/v1/app/jobs/{job_id}
POST /api/v1/app/jobs/{job_id}/cancel
GET  /api/v1/app/jobs/{job_id}/live
POST /api/v1/app/jobs/{job_id}/vehicle/promote
POST /api/v1/app/jobs/{job_id}/address/promote
```

User can only read/cancel their own jobs and only at allowed lifecycle points.

## 31.6 Charging

If product permits user-initiated stop:

```text
POST /api/v1/app/jobs/{job_id}/charging/stop
```

There is no user endpoint that claims physical start by setting status.

Live charging reads come through job/live projection endpoints.

## 31.7 Payments

```text
POST /api/v1/app/jobs/{job_id}/payments/orders
POST /api/v1/app/payments/{payment_id}/verify
GET  /api/v1/app/jobs/{job_id}/payments
```

Provider client secret/server credentials never go to User App.

## 31.8 Invoices

```text
GET /api/v1/app/jobs/{job_id}/invoice
GET /api/v1/app/invoices/{invoice_id}/download
```

## 31.9 Ratings

```text
GET /api/v1/app/ratings
GET /api/v1/app/jobs/{job_id}/rating
PUT /api/v1/app/jobs/{job_id}/rating
```

`PUT` gives natural idempotent replace semantics for the customer's own rating.

## 31.10 Support

```text
GET  /api/v1/app/support/tickets
POST /api/v1/app/support/tickets
GET  /api/v1/app/support/tickets/{ticket_id}
POST /api/v1/app/support/tickets/{ticket_id}/replies
```

---

## 31.11 Preserved User App architecture rules

The User App inherits the mature EV-CMS client/server rules where they remain semantically valid for Charger on Wheels.

The client architecture is:

```text
User App
  -> Charger-on-Wheels CMS public API
CMS
  -> payment provider when needed
  -> dedicated HAL through private service contracts
HAL
  -> physical charger
```

The User App NEVER:

- calls HAL directly;
- receives HAL service credentials;
- creates a physical charging session because a start command was accepted;
- invents meter, power, voltage, current, SoC, ETA, payment, or completion truth;
- supplies trusted customer/driver/admin ownership IDs to select server scope;
- derives final bill from live displayed metrics;
- treats a realtime event as more authoritative than the corresponding CMS durable snapshot.

The CMS API is the sole app-facing business boundary.

## 31.12 User authentication and session semantics

The initial User App authentication flow is defined, not left open.

### Signup

1. `POST /auth/signup` receives normalized email, password, full name, and optional phone.
2. Password length is 10-128 characters before any stronger password policy configured by security review.
3. Full name is trimmed, non-empty, maximum 255 characters.
4. Phone is optional and, when supplied, is a normalized international-compatible value with 7-15 digits and optional leading `+`.
5. CMS creates an expiring signup challenge and queues OTP delivery only after the challenge is durable.
6. Response is `202` with:

```json
{
  "challenge_id": "<opaque-or-uuid-id>",
  "expires_at": "<rfc3339-utc>",
  "resend_available_at": "<rfc3339-utc>"
}
```

7. `POST /auth/signup/verify` accepts that challenge ID + six-digit code and atomically creates the verified Customer account/profile. It returns `201`. Signup completion does not silently log the user in; the app enters the login flow.
8. `POST /auth/signup/resend` replaces the challenge/code. The previous challenge becomes unusable immediately. The client replaces all stored challenge/timing fields atomically.

### Login

1. `POST /auth/login` verifies email/password without creating app-authenticated state. Invalid account/password share one generic credential failure to avoid account enumeration.
2. Valid credentials create an expiring login OTP challenge and return `202 ChallengeResponse`.
3. `POST /auth/login/verify` accepts challenge ID + code. Only this operation creates the authenticated server session and returns the token bundle.
4. `POST /auth/login/resend` replaces the current login challenge and invalidates the old code.
5. After token receipt, the client calls `GET /me` and treats that response as the bootstrap business identity/profile state.

### Access/refresh/session rules

The token bundle uses:

- short-lived bearer access token;
- opaque refresh token;
- server session ID/expiry metadata;
- one-time rotating refresh semantics.

A successful `POST /auth/refresh` consumes the supplied refresh token and atomically returns a new access token and refresh token. The client replaces both before releasing queued requests. Reusing an already-consumed refresh token is treated as possible theft and revokes the affected session/session family according to the server auth policy.

Client rule:

```text
one refresh in flight per app process
```

If several API requests receive `401` concurrently, they wait for one refresh promise/mutex rather than consuming the same one-use refresh token multiple times. If refresh fails because the credential is invalid, consumed, expired, or revoked, clear authenticated local state and do not loop.

`GET /auth/sessions` lists only the current customer's sessions. `DELETE /auth/sessions/{session_id}` revokes one owned session. Revoking the current session immediately clears local authenticated state. `POST /auth/logout` revokes the current session; `POST /auth/logout-all` revokes all customer sessions.

### Password recovery/change

`POST /auth/password/forgot` is enumeration-safe: the HTTP response does not disclose whether the email exists. If eligible, the recovery message contains the recovery challenge identifier, OTP/code, and expiry needed by the client.

`POST /auth/password/reset/resend` replaces the recovery challenge/code and invalidates the prior pair.

`POST /auth/password/reset` accepts:

```json
{
  "challenge_id": "<recovery-id>",
  "code": "<six-digit-code>",
  "new_password": "<10-to-128-character-password>"
}
```

Successful forgotten-password reset revokes existing sessions and invalidates outstanding login/recovery challenges according to the auth transaction, then the app returns to login.

`POST /auth/password/change` requires the current password plus a different valid new password and revokes all active sessions after the password changes, including the current session.

### Profile

`GET /me` returns the authenticated Customer identity/profile and the minimum app bootstrap state. `PATCH /profile` updates only editable profile fields such as `full_name` and nullable phone. Email, auth state, roles/capabilities, payment state, jobs, and identifiers are not mutable through profile editing.

### Storage and secrecy

On mobile, refresh credentials SHOULD use OS-protected secure storage. Passwords, OTPs, access tokens, refresh tokens, recovery IDs, and challenge codes MUST NOT be placed in URLs, analytics, crash reports, screenshots, logs, or ordinary unencrypted preferences. Server challenge/OTP values are stored only as cryptographically appropriate hashes/encrypted secrets according to their verification purpose and are rate-limited for start, verify, and resend.

## 31.13 User API error envelope

All handled User App errors use a stable machine-readable envelope:

```json
{
  "error": {
    "code": "stable_machine_code",
    "message": "Human-readable message"
  }
}
```

Clients branch on `error.code`, not English wording.

Common semantic classes use the canonical uppercase registry from Appendix C:

```text
400 INVALID_REQUEST / VALIDATION_FAILED
401 UNAUTHENTICATED / INVALID_CREDENTIALS / INVALID_REFRESH_TOKEN
403 FORBIDDEN / BUSINESS_ADMISSION_DENIED
404 RESOURCE_NOT_FOUND
409 STATE_CONFLICT / IDEMPOTENCY_KEY_REUSED / RECONCILIATION_REQUIRED
410 RESOURCE_EXPIRED
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE / DEPENDENCY_UNAVAILABLE
```

A privacy-safe `404` SHOULD be used where revealing that another user's job/ticket/session exists would disclose cross-user existence.

Automatic client retries are limited to clearly safe reads and explicitly retryable transient failures. Mutation retries use the same idempotency identity; the app never creates a fresh logical charging/payment/support mutation simply because it missed a response.

## 31.14 User charging projection contract

A User App job detail/live response MUST expose start progress and physical session state as separate concepts.

Recommended projection shape:

```json
{
  "charging": {
    "start": {
      "start_intent_id": "<uuid>",
      "status": "REQUESTED|ACCEPTED_FOR_DELIVERY|PROTOCOL_ACKNOWLEDGED|ACTUALLY_STARTED|REJECTED|EXPIRED|RECONCILIATION_REQUIRED",
      "session_id": null
    },
    "session": null
  }
}
```

After physical start:

```json
{
  "charging": {
    "start": {
      "start_intent_id": "<uuid>",
      "status": "ACTUALLY_STARTED",
      "session_id": "<uuid>"
    },
    "session": {
      "id": "<uuid>",
      "state": "ACTIVE|STOP_PENDING|RECONCILIATION_REQUIRED|COMPLETED|FAILED",
      "started_at": "<rfc3339>",
      "completed_at": null,
      "meter": {
        "consumed_wh": 1234,
        "observed_at": "<rfc3339>",
        "freshness": "FRESH|STALE|UNKNOWN"
      },
      "soc": {
        "percent": "54.0",
        "observed_at": "<rfc3339>",
        "freshness": "FRESH|STALE|UNKNOWN"
      }
    }
  }
}
```

Fields may differ in final OpenAPI, but semantics are mandatory.

UI state rules:

- `REQUESTED`: show start request accepted by CMS, not charging.
- `ACCEPTED_FOR_DELIVERY`: HAL durably knows the request, not charging.
- `PROTOCOL_ACKNOWLEDGED`: charger accepted the protocol command, still not charging.
- `ACTUALLY_STARTED` plus `session_id`: transition to the active-charging screen.
- `RECONCILIATION_REQUIRED`: show "confirming charger state" or equivalent product copy and continue durable recovery. Never send another start.
- `REJECTED`/`EXPIRED`: terminal for that intent; a new user/driver action may create a fresh intent only after backend says the connector/job is start-eligible again.

The UI MUST NOT remain indefinitely in an optimistic local "starting" state after network loss. Refetch the CMS start/job projection.

## 31.15 User start and stop endpoints

The baseline public read surface SHOULD include an explicit charging projection:

```text
GET /api/v1/app/jobs/{job_id}/charging
```

It returns the current job-owned start progress and materialized session, if any.

If customer-controlled start is enabled:

```text
POST /api/v1/app/jobs/{job_id}/charging/start
```

If it is not enabled, that route is absent or returns a stable policy denial. The customer cannot emulate Driver start by posting charger IDs to a hidden endpoint.

If customer stop is enabled:

```text
POST /api/v1/app/jobs/{job_id}/charging/stop
```

A successful stop request returns `202 Accepted` with durable stop-progress state. It does NOT return or imply `COMPLETED` unless completion raced and the response explicitly embeds an already-completed authoritative snapshot.

The app then recovers through `GET /jobs/{job_id}/charging` or the live-job snapshot/stream.

## 31.16 User live meter and SoC rules

The app receives committed CMS projections only.

For energy:

- use integer Wh from backend as the base exact value;
- display kWh by presentation conversion only;
- never sum browser samples to create authoritative energy;
- never extrapolate between samples;
- stale/unknown evidence remains stale/unknown.

For SoC:

- nullable means unknown;
- never show missing SoC as 0%;
- never derive SoC from delivered Wh/battery capacity and label it charger SoC;
- show observation time/freshness when useful;
- final SoC is the last accepted observation, not guaranteed stop-time truth.

For power/current/voltage if later exposed:

- label them live observations;
- missing observation is unknown;
- do not use them to reconstruct billing energy in the client.

## 31.17 User charger/mobile-unit readiness projection

The User App may display the assigned mobile unit/charger readiness after assignment, but it receives the CMS-derived projection, not raw HAL state.

Preserve distinct reasons such as:

```text
ONLINE / OFFLINE / UNKNOWN / STALE
connector AVAILABLE / CHARGING / FAULTED / STALE / UNKNOWN
CMS inventory ineligible
asset mismatch unresolved
job occupies connector
```

Do not collapse every non-chargeable condition into `OFFLINE`.

The frontend can present a simplified message, but the API retains a stable machine reason so recovery/QA/analytics can distinguish the cause.

## 31.18 User history semantics

Charging attempt history under a ServiceJob contains only real materialized ChargingSessions.

Failed/rejected/expired start intents that never produced physical-start evidence are start-attempt history, not fake charging sessions.

For jobs with more than one physical charging attempt, the detail API can expose:

```text
job.charging_sessions[]
```

ordered by actual start time and stable ID.

A history card/detail MAY include:

- ServiceJob identity/number;
- driver/mobile-unit public context;
- service address snapshot;
- customer vehicle snapshot;
- charging session IDs;
- actual start/end times;
- committed energy;
- initial/latest/final observed SoC when present;
- requested stop provenance;
- protocol stop reason;
- final customer price only after commercial finalization;
- payment/settlement state;
- invoice state;
- rating state.

Do not render a stored zero as a final amount/energy when the value is actually not finalized.

History lists use bounded keyset pagination. A stable default/max limit and deterministic tie-breaker are required; offset pagination SHOULD NOT be used for frequently changing chronological history.

## 31.19 Stop provenance in the User App

The API keeps these concepts separate:

```text
requested_initiator
requested_reason
protocol_reason
```

The frontend SHOULD map them through product-owned presentation copy.

It must not show raw OCPP reason codes as if they explain the business decision. For example, protocol `Remote` may correspond to a customer target, driver action, Admin action, or funding safety stop.

## 31.20 User payment verification rules

Provider UI/redirect success is not final CMS payment truth.

The app:

1. requests order/payment intent from CMS;
2. performs only the provider client-side step allowed by the chosen payment integration;
3. returns provider result identifiers/signature to the documented CMS verification endpoint;
4. refetches CMS payment/job state;
5. trusts CMS durable state.

On response loss, recover the existing payment/order by CMS/provider identity. Do not create a replacement order unless backend explicitly says the previous operation is terminal/absent.

Exact money values are decimal strings or integer minor units according to the canonical contract; the frontend MUST NOT use binary floating point for authoritative totals.

## 31.21 User invoice rules

Invoice readiness is distinct from ServiceJob physical completion and payment attempt.

The User App MUST distinguish at least:

```text
NOT_ELIGIBLE
PENDING
READY
UNAVAILABLE / FAILED
```

A READY historical invoice is immutable. The client downloads it through an authenticated CMS route or approved short-lived delivery mechanism; it never guesses a filesystem/object-storage path.

A missing/pending invoice does not cause the frontend to locally generate a tax invoice.

## 31.22 User rating/review rules

Preserve one durable customer rating per eligible ServiceJob unless product explicitly chooses per-ChargingSession ratings.

Recommended surface:

```text
GET /api/v1/app/jobs/{job_id}/rating
PUT /api/v1/app/jobs/{job_id}/rating
GET /api/v1/app/ratings
```

`PUT` creates or replaces the owner's rating idempotently.

Eligibility:

- customer owns the job;
- job is completed under the rating policy;
- one logical rating per rating target;
- no other customer's identity is exposed through customer-facing aggregates/reviews.

If public review text is added later, define moderation/privacy separately. Do not leak another user's name merely because a review exists.

## 31.23 User support rules

For Charger-on-Wheels, the customer support channel is conceptually:

```text
CUSTOMER_PLATFORM
```

not the inherited EV-CMS `CUSTOMER_CPO` channel.

Preserve the durable support mechanics:

- server derives customer ownership from bearer context;
- customer can see only their own tickets;
- privacy-safe not-found for another customer's ticket;
- append-only replies;
- reply idempotency key;
- explicit status graph;
- customer reply to `RESOLVED` or `CLOSED` MAY reopen atomically to `OPEN`;
- same-state mutation has no duplicate side effect;
- mail/push is notification, never the support source of truth;
- freeform support message bodies are not copied into broad notification/event payloads;
- Admin internal identities/notes are not leaked to the User App.

Recommended status graph:

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> CLOSED | OPEN
CLOSED -> OPEN
```

## 31.24 User realtime and notification contract

The exact v1 client realtime and human-notification contract is normative Annex 10, `normative/10_REALTIME_SSE_AND_NOTIFICATION_CONTRACTS.md`. It replaces the inherited EV-CMS `/operations/realtime/*` route family.

User realtime uses exactly:

```text
POST /api/v1/app/realtime/tickets
GET  /api/v1/app/realtime/stream?ticket={opaque_ticket}
```

The ticket POST is authenticated with the normal User bearer session. The SSE URL receives only a short-lived single-use opaque stream ticket, never the access token. Resume, replay-to-live handoff, signed cursor, heartbeat, backpressure, coalescing, resync, audience filtering, control events, and connection bounds are owned by Annex 10 and its machine event registry.

The User App treats SSE as an at-least-once invalidation/projection channel. Durable REST resources remain recovery authority. On cursor expiry or `stream.resync_required`, the client refetches authoritative snapshots, discards stale replay position, obtains a new ticket, and reconnects.

Human notifications are a separate plane from realtime. Durable in-app notification resources, device registration, notification preferences, push/email delivery attempts, provider acceptance vs delivery, retry, dedupe, and deep-link safety are also owned by Annex 10 and Annex 26. Push/email failure cannot change domain truth.

HAL -> CMS facts and traces are **not** client realtime. They use the separately authenticated service contracts in Sections 19-20 and Annex 34.

## 31.25 User realtime reduction rules

The User App MUST:

- dedupe by `event_id`;
- apply monotonic `resource.version` rules;
- refetch on suspicious version gaps;
- never treat meter/location hints as stronger than the authorized REST/live projection;
- remain usable during SSE outage through snapshot/refetch behavior;
- reconnect after token/session changes using a newly authorized stream ticket;
- never infer domain success from receipt of a notification or realtime event alone.

Exact event names and audience-safe payload/recovery targets are `registries/realtime_events.csv`.

## 31.26 User frontend state and security checklist

The frontend implementation MUST:

- model signup verification, login verification, and password recovery as separate state machines if OTP/challenge flows are used;
- keep tokens/OTPs/recovery IDs out of logs and analytics;
- treat timestamps as UTC instants and localize only at presentation;
- disable duplicate submit while a mutation is in flight;
- preserve server idempotency key while retrying an uncertain mutation;
- escape review/support/free-text content;
- never render raw HTML from untrusted server/user text;
- clear state after logout/session revocation/password reset as defined by the API;
- invalidate/refetch job state after any mutation instead of manually forcing a final status;
- keep API origin in deployment configuration, not user-editable profile/deep-link input.

## 31.27 User acceptance matrix

A User App release is not complete until these journeys pass against the matching CMS contract:

| Journey | Pass condition | Failure/recovery requirement |
| --- | --- | --- |
| Auth/refresh | login reaches verified authenticated state; refresh rotates token pair exactly once | concurrent 401s share one refresh; invalid/reused refresh clears auth without loop |
| Saved vehicle/address | create/edit/remove affects reusable data while old ServiceJob snapshots stay unchanged | stale edits do not mutate history |
| Service request/quote | saved or temporary EV/address creates a quote and accepted job with immutable snapshots | expired/stale quote returns explicit re-quote/conflict flow |
| Dispatch tracking | assignment, driver public projection, ETA/location converge | realtime loss recovers from job snapshot |
| Charging start | start progress becomes `ACTUALLY_STARTED` only after physical fact | ambiguity remains inspectable and never duplicates start |
| Live charging | energy/SoC/freshness reflect CMS accepted evidence | stale/missing values remain unknown/stale, not fabricated |
| Stop | stop request is durable; completion occurs only from physical completion evidence | lost response recovers existing stop/session, never duplicate physical command |
| Payment | CMS state agrees with provider verification | provider UI alone cannot mark paid |
| Invoice | READY artifact downloads and matches finalized job | pending/unavailable states remain explicit |
| Rating | owner can create/read/replace own eligible rating | no other customer identity leakage |
| Support | owner can create/read/reply; closed/resolved reply reopens when policy says so | mail/push loss does not lose ticket state |
| Realtime | REST catch-up + stream converges after reconnect/token rotation | cursor expiry forces snapshot recovery rather than guessed delta merge |

---

# 32. Public API Surface - Driver App

## 32.1 Authentication/profile

```text
POST  /api/v1/driver/auth/login
POST  /api/v1/driver/auth/refresh
POST  /api/v1/driver/auth/logout
GET   /api/v1/driver/me
PATCH /api/v1/driver/me
```

Recruitment may use a pre-active account flow or a dedicated application token/session. The implementation must keep recruitment access distinct from operational authorization.

## 32.2 Recruitment

```text
GET  /api/v1/driver/application
PUT  /api/v1/driver/application
POST /api/v1/driver/application/documents
POST /api/v1/driver/application/submit
GET  /api/v1/driver/application/reviews
```

A rejected/offboarded driver cannot access operational endpoints merely because login still succeeds.

## 32.3 Schedule

```text
GET /api/v1/driver/schedules
GET /api/v1/driver/schedules/{occurrence_id}
```

## 32.4 Duty and assets

```text
GET  /api/v1/driver/duty/current
POST /api/v1/driver/duty/start
POST /api/v1/driver/duty/current/breaks
POST /api/v1/driver/duty/current/breaks/{break_id}/end
POST /api/v1/driver/duty/current/end
GET  /api/v1/driver/duty/current/eligible-assets
POST /api/v1/driver/duty/current/asset-mismatch
```

Duty start is idempotent and concurrency-safe.

## 32.5 Location

```text
POST /api/v1/driver/location
POST /api/v1/driver/location/batch
```

Batch is recommended for mobile connectivity recovery. Samples are bounded, validated, and associated only with the authenticated driver/current duty session.

## 32.6 Offers and jobs

```text
GET  /api/v1/driver/offers
GET  /api/v1/driver/offers/{offer_id}
POST /api/v1/driver/offers/{offer_id}/accept
POST /api/v1/driver/offers/{offer_id}/reject
GET  /api/v1/driver/jobs/current
GET  /api/v1/driver/jobs
GET  /api/v1/driver/jobs/{job_id}
POST /api/v1/driver/jobs/{job_id}/en-route
POST /api/v1/driver/jobs/{job_id}/arrive
POST /api/v1/driver/jobs/{job_id}/prepare
POST /api/v1/driver/jobs/{job_id}/report-problem
```

## 32.7 Charging controls

```text
POST /api/v1/driver/jobs/{job_id}/charging/start
POST /api/v1/driver/jobs/{job_id}/charging/stop
GET  /api/v1/driver/jobs/{job_id}/charging
```

Start/stop endpoints create intents. Their synchronous response MUST describe intent/command state truthfully, not fabricate physical start/end.

## 32.8 Wrap-up

```text
POST /api/v1/driver/jobs/{job_id}/wrap-up
POST /api/v1/driver/jobs/{job_id}/complete
```

`complete` is permitted only after all completion invariants pass.

## 32.9 Earnings

```text
GET /api/v1/driver/earnings/summary
GET /api/v1/driver/earnings/jobs
GET /api/v1/driver/earnings/jobs/{job_id}
GET /api/v1/driver/earnings/daily
```

Filters cover custom date ranges with bounded limits.

## 32.10 Driver support

```text
GET  /api/v1/driver/support/tickets
POST /api/v1/driver/support/tickets
GET  /api/v1/driver/support/tickets/{ticket_id}
POST /api/v1/driver/support/tickets/{ticket_id}/replies
```

---

# 33. Public API Surface - Admin

## 33.1 Admin auth and self

```text
POST /api/v1/admin/auth/login
POST /api/v1/admin/auth/refresh
POST /api/v1/admin/auth/logout
GET  /api/v1/admin/me
GET  /api/v1/admin/me/capabilities
```

## 33.2 Customers

```text
GET /api/v1/admin/customers
GET /api/v1/admin/customers/{customer_id}
GET /api/v1/admin/customers/{customer_id}/jobs
```

Sensitive account/security data remains in dedicated authorized endpoints if ever needed.

## 33.3 Driver applications and drivers

```text
GET  /api/v1/admin/driver-applications
GET  /api/v1/admin/driver-applications/{application_id}
POST /api/v1/admin/driver-applications/{application_id}/start-review
POST /api/v1/admin/driver-applications/{application_id}/request-action
POST /api/v1/admin/driver-applications/{application_id}/approve
POST /api/v1/admin/driver-applications/{application_id}/reject
POST /api/v1/admin/driver-applications/{application_id}/complete-onboarding
GET  /api/v1/admin/drivers
GET  /api/v1/admin/drivers/{driver_id}
POST /api/v1/admin/drivers/{driver_id}/suspend
POST /api/v1/admin/drivers/{driver_id}/reinstate
POST /api/v1/admin/drivers/{driver_id}/offboard
```

## 33.4 Vehicles

```text
GET   /api/v1/admin/vehicles
POST  /api/v1/admin/vehicles
GET   /api/v1/admin/vehicles/{vehicle_id}
PATCH /api/v1/admin/vehicles/{vehicle_id}
POST  /api/v1/admin/vehicles/{vehicle_id}/deactivate
POST  /api/v1/admin/vehicles/{vehicle_id}/reactivate
GET   /api/v1/admin/vehicles/{vehicle_id}/history
GET   /api/v1/admin/vehicles/{vehicle_id}/availability
```

## 33.5 Chargers/connectors

```text
GET   /api/v1/admin/chargers
POST  /api/v1/admin/chargers
GET   /api/v1/admin/chargers/{charger_id}
PATCH /api/v1/admin/chargers/{charger_id}
POST  /api/v1/admin/chargers/{charger_id}/deactivate
POST  /api/v1/admin/chargers/{charger_id}/reactivate
GET   /api/v1/admin/chargers/{charger_id}/history
GET   /api/v1/admin/chargers/{charger_id}/runtime
GET   /api/v1/admin/chargers/{charger_id}/capabilities
GET   /api/v1/admin/chargers/{charger_id}/connectors
POST  /api/v1/admin/chargers/{charger_id}/connectors
PATCH /api/v1/admin/chargers/{charger_id}/connectors/{connector_id}
```

## 33.6 Pairings/maintenance

```text
GET  /api/v1/admin/pairings
POST /api/v1/admin/pairings
POST /api/v1/admin/pairings/{pairing_id}/end
GET  /api/v1/admin/asset-mismatches
GET  /api/v1/admin/asset-mismatches/{mismatch_id}
POST /api/v1/admin/asset-mismatches/{mismatch_id}/resolve
POST /api/v1/admin/vehicles/{vehicle_id}/maintenance
POST /api/v1/admin/chargers/{charger_id}/maintenance
```

## 33.7 Schedules/duty

```text
GET   /api/v1/admin/schedules
POST  /api/v1/admin/schedules
GET   /api/v1/admin/schedules/{schedule_id}
PATCH /api/v1/admin/schedules/{schedule_id}
POST  /api/v1/admin/schedules/{schedule_id}/cancel
GET   /api/v1/admin/duty-sessions
GET   /api/v1/admin/duty-sessions/{duty_session_id}
POST  /api/v1/admin/duty-sessions/{duty_session_id}/hold
POST  /api/v1/admin/duty-sessions/{duty_session_id}/release-hold
```

Started historical occurrences are not destructively edited.

## 33.8 Dispatch/jobs

```text
GET  /api/v1/admin/jobs
GET  /api/v1/admin/jobs/{job_id}
GET  /api/v1/admin/jobs/{job_id}/timeline
GET  /api/v1/admin/jobs/{job_id}/dispatch
POST /api/v1/admin/jobs/{job_id}/dispatch/retry
POST /api/v1/admin/jobs/{job_id}/assign
POST /api/v1/admin/jobs/{job_id}/reassign
POST /api/v1/admin/jobs/{job_id}/cancel
POST /api/v1/admin/jobs/{job_id}/mark-no-show
POST /api/v1/admin/jobs/{job_id}/record-correction
```

## 33.9 Charging/HAL

```text
GET  /api/v1/admin/jobs/{job_id}/charging
GET  /api/v1/admin/charging-sessions
GET  /api/v1/admin/charging-sessions/{session_id}
GET  /api/v1/admin/hal/operations
GET  /api/v1/admin/hal/operations/{cms_operation_id}
GET  /api/v1/admin/hal/facts
GET  /api/v1/admin/hal/traces
POST /api/v1/admin/chargers/{charger_id}/commands/reset
POST /api/v1/admin/chargers/{charger_id}/commands/unlock
POST /api/v1/admin/chargers/{charger_id}/commands/change-availability
POST /api/v1/admin/hal/operations/{cms_operation_id}/reconcile
```

Admin command endpoints require technical capability, reason, and safety validation.

## 33.10 Pricing/payments/invoices

```text
GET   /api/v1/admin/pricing/policies
POST  /api/v1/admin/pricing/policies
GET   /api/v1/admin/pricing/policies/{policy_id}
PATCH /api/v1/admin/pricing/policies/{policy_id}
POST  /api/v1/admin/pricing/policies/{policy_id}/activate
POST  /api/v1/admin/pricing/policies/{policy_id}/retire

GET  /api/v1/admin/payments
GET  /api/v1/admin/payments/{payment_id}
GET  /api/v1/admin/refunds
POST /api/v1/admin/payments/{payment_id}/refunds

GET  /api/v1/admin/invoices
GET  /api/v1/admin/invoices/{invoice_id}
POST /api/v1/admin/invoices/{invoice_id}/retry-generation
GET  /api/v1/admin/invoices/{invoice_id}/download
```

## 33.11 Compensation

```text
GET   /api/v1/admin/compensation/policies
POST  /api/v1/admin/compensation/policies
GET   /api/v1/admin/compensation/policies/{policy_id}
PATCH /api/v1/admin/compensation/policies/{policy_id}
POST  /api/v1/admin/compensation/policies/{policy_id}/activate
POST  /api/v1/admin/compensation/policies/{policy_id}/retire
GET   /api/v1/admin/compensation/jobs
GET   /api/v1/admin/compensation/jobs/{job_id}
POST  /api/v1/admin/compensation/jobs/{job_id}/adjustments
GET   /api/v1/admin/compensation/drivers/{driver_id}/summary
```

## 33.12 Ratings/support/incidents/audit

```text
GET  /api/v1/admin/ratings
GET  /api/v1/admin/support/tickets
GET  /api/v1/admin/support/tickets/{ticket_id}
POST /api/v1/admin/support/tickets/{ticket_id}/replies
PATCH /api/v1/admin/support/tickets/{ticket_id}/status
GET  /api/v1/admin/incidents
GET  /api/v1/admin/incidents/{incident_id}
POST /api/v1/admin/incidents/{incident_id}/actions
GET  /api/v1/admin/audit
```

---

# 34. API Consumer Contracts and Projection Rules

## 34.1 User projection

User job projection may expose:

- job number/status;
- service location snapshot;
- own vehicle snapshot;
- public driver identity subset after assignment;
- public service vehicle identity subset;
- ETA/location only while operationally relevant;
- charging metrics;
- pricing/payment/invoice state;
- own support/rating.

It MUST NOT expose:

- driver KYC;
- driver phone/email unless explicitly required by product policy;
- Admin identities;
- internal dispatch scores;
- raw HAL traces;
- internal incident notes;
- internal compensation.

## 34.2 Driver projection

Driver may see only data necessary for current/own work:

- assigned customer display/contact information required for service;
- exact service location/instructions;
- customer vehicle snapshot;
- charging preference;
- job/payment information only to the extent operationally required;
- own compensation.

Driver MUST NOT see full customer account/security history.

## 34.3 Admin projection

Admin receives data by capability and need, not one giant universal object.

High-sensitivity KYC, payment, raw trace, and audit data should have separately authorized endpoints/fields.

---

# 35. Idempotency Matrix

At minimum, these operations require durable idempotency or stable operation identity:

| Operation | Mechanism |
| --- | --- |
| Quote acceptance / ServiceJob creation | `Idempotency-Key` |
| Driver duty start | `Idempotency-Key` + unique active-duty constraint |
| Driver offer accept | offer identity + transactional winner |
| Driver job transition actions | action idempotency / current-state same-result semantics |
| Charging start | `Idempotency-Key` -> `ChargingStartIntent` -> immutable `cms_command_id` -> one HAL start command |
| Charging stop | `Idempotency-Key` -> `ChargingStopRequest` -> immutable `cms_command_id` -> one HAL stop command; completion still requires physical completion evidence |
| Payment order creation | `Idempotency-Key` + provider order identity |
| Payment verification/webhook | provider event/payment identity |
| Refund | `Idempotency-Key` + provider refund identity |
| Invoice generation intent | unique invoice/job/version key |
| Support reply | `Idempotency-Key` |
| Notification/outbox delivery | outbox row/event identity |
| HAL fact ingest | immutable `fact_id` |
| HAL start/stop command | immutable `cms_command_id` plus durable `hal_command_id`; retry/reconcile same identity |
| Generic administrative HAL operation | immutable `cms_operation_id` plus durable HAL operation identity; no automatic replay after possible delivery |
| Promotion of temp vehicle/address | `Idempotency-Key` / unique promotion record |
| Compensation finalization | unique job/assignment calculation version |
| Compensation adjustment | `Idempotency-Key` |

Idempotency records MUST have a retention policy long enough to cover realistic mobile retry behavior and external provider retries.

---

# 36. Concurrency and Transaction Boundaries

## 36.1 Database as concurrency authority

Use PostgreSQL constraints/locking for invariants that must survive multiple API instances.

Do not rely on process mutexes for cross-instance business invariants.

## 36.2 Required protected races

Must explicitly handle:

- two duty starts for same driver;
- two drivers claiming same vehicle;
- two drivers claiming same charger;
- two offer acceptances;
- driver accepts offer while Admin reassigns/cancels;
- customer cancels while driver accepts;
- charging start retried during unknown HAL delivery;
- duplicate HAL transaction/fact;
- simultaneous payment callback + webhook;
- simultaneous rating PUT;
- simultaneous policy activation;
- invoice worker duplicate claim;
- compensation worker duplicate finalization.

## 36.3 Row locking

Use `SELECT ... FOR UPDATE` or equivalent narrowly around mutable aggregate roots where transition serialization is required.

Avoid holding DB transactions open across slow external network calls.

Correct pattern:

1. transactionally create durable intent/claim;
2. commit;
3. perform external I/O;
4. transactionally record outcome;
5. reconcile uncertainty asynchronously if needed.

## 36.4 Outbox atomicity

Any external side effect that must correspond to a committed business mutation is enqueued in the same DB transaction as that mutation.

No pattern of "commit DB, then maybe remember to send notification" is allowed for critical side effects.

---

# 37. Durable Domain Events and Outbox

## 37.1 Event purpose

Domain events support:

- realtime invalidation;
- notifications;
- projections;
- asynchronous commercial workflows;
- audit correlation;
- integration with HAL/provider workers.

They do not replace normalized domain tables.

## 37.2 Event envelope

```text
id
aggregate_type
aggregate_id
event_type
occurred_at
actor_type
actor_id nullable
request_id
payload_version
payload jsonb
```

## 37.3 Important CMS events

Examples:

```text
DriverApplicationSubmitted
DriverApproved
DriverSuspended
DriverDutyStarted
DriverDutyEnded
AssetMismatchReported

ServiceRequestCreated
QuoteCreated
QuoteAccepted
ServiceJobCreated
DispatchStarted
DispatchOfferCreated
JobAssigned
JobReassigned
DriverEnRoute
DriverArrived
ServicePreparationStarted
ServiceJobChargingStarted
ServiceJobChargingEnded
ServiceJobCompleted
ServiceJobCancelled
ServiceJobFailed

ChargingStartIntentCreated
ChargingStartCommandStateChanged
ChargingSessionMaterialized
ChargingStopRequested
ChargingCommandStateChanged
ChargingMeterObserved
ChargingSoCObserved
ChargingSessionCompleted
ChargingReconciliationRequired

PriceFinalized
PaymentCaptured
PaymentFailed
RefundSucceeded
InvoiceReady

CompensationCalculated
CompensationAdjusted

SupportTicketCreated
SupportReplyAdded
IncidentOpened
IncidentResolved
```

## 37.4 Event payload discipline

Events contain only what downstream consumers need plus stable identifiers.

Avoid duplicating complete mutable entities or sensitive data into every event.

Payloads are versioned.

---

# 38. Background Workers

Initial CMS worker set SHOULD be explicit and independently observable:

1. **Outbox dispatcher**: claims domain/notification work.
2. **Realtime publisher**: publishes authorized projections/invalidations from committed events.
3. **Notification delivery worker**: push/email/SMS providers.
4. **Dispatch scheduler/retry worker**: scheduled-job dispatch windows and retry when no candidates.
5. **Payment reconciliation worker**: provider status for uncertain/pending payment operations.
6. **Invoice generation worker**.
7. **Compensation finalization/reconciliation worker**.
8. **Projection reconciliation worker**: repair/rebuild derived current state if needed.
9. **Retention/cleanup worker**: expires temporary/idempotency/raw location data according to policy.

HAL worker set:

1. connection supervisor;
2. charging command dispatcher;
3. charging deadline/automatic-stop worker;
4. pending charging-stop recovery worker;
5. dedicated sequential generic charger-operation recovery worker;
6. reconnect/transaction reconciliation worker;
7. authoritative fact outbox delivery worker;
8. independent diagnostic trace outbox/retention worker;
9. health/liveness ticker.

The generic charger-operation recovery worker MUST NOT share a sequential execution loop with charging deadline enforcement, automatic stops, or pending charging-stop recovery. Slow Reset/Unlock/diagnostic work cannot delay safety/commercial charging lifecycle work.

Every worker must have:

- bounded batch size;
- claim/lease or transactional ownership;
- retry classification;
- backoff;
- max-attempt/dead-letter visibility where appropriate;
- metrics for pending/oldest age/failures;
- graceful shutdown behavior.

---

# 39. Failure Classification and Recovery

Failures MUST be classified so retries do not make reality worse.

## 39.1 Classes

```text
VALIDATION
AUTHORIZATION
CONFLICT
TRANSIENT_INTERNAL
TRANSIENT_EXTERNAL
TERMINAL_EXTERNAL
OUTCOME_UNKNOWN
INTEGRITY_VIOLATION
```

## 39.2 Retry policy

- Validation/auth/conflict: caller must change state/input; no blind server retry.
- Transient internal: bounded automatic retry if operation is safe/idempotent.
- Transient external before known delivery: bounded retry.
- Outcome unknown after possible physical/payment side effect: reconcile by stable identity before retry.
- Integrity violation: stop, alert, preserve evidence.

## 39.3 Stop conditions

Workers MUST stop automatic retries and surface operational attention when:

- semantic conflict appears;
- same identity maps to conflicting payload;
- repeated failures exceed policy;
- physical command outcome remains unknown beyond reconciliation horizon;
- provider/charger reports impossible transition;
- database constraint indicates an unexpected invariant breach.

---

# 40. Security and Privacy Blueprint

## 40.1 Authentication secrets

Passwords, OTPs, refresh tokens, service credentials, Razorpay secrets, webhook secrets, and private keys MUST never be logged.

Store password hashes with a modern password hashing algorithm if passwords are used.

OTP codes are short-lived, rate-limited, and stored only in protected/hashed form where possible.

## 40.2 PII

Sensitive fields include:

- phone/email;
- addresses/location history;
- KYC documents/numbers;
- driving licence;
- bank information if stored;
- exact driver/customer traces;
- support free text;
- invoice/customer tax info.

APIs return the minimum projection required for that actor.

## 40.3 KYC document storage

- private object/file storage;
- random opaque object identifiers;
- MIME/type and size validation;
- malware scanning if infrastructure supports it;
- authorization on every fetch;
- short-lived signed URLs if used;
- audit reads for highly sensitive documents where practical.

## 40.4 Input safety

All user-generated free text is untrusted.

Frontend must escape reviews/support/notes.

Backend must use parameterized SQL and never interpolate user strings into queries.

## 40.5 Rate limiting

At minimum rate-limit:

- login/OTP/recovery;
- registration;
- quote creation abuse;
- support spam;
- location ingestion by device;
- provider callback endpoints according to provider expectations;
- HAL internal ingress by authenticated service/size limits.

## 40.6 Authorization test requirement

Every protected route family requires tests for:

- unauthenticated rejection;
- wrong principal type;
- wrong owner/resource;
- missing capability;
- positive allowed path.

---

# 41. Audit Blueprint

Audit is separate from ordinary application logs.

Audit records are durable and queryable for security/administrative actions.

Minimum fields:

```text
id
actor_type
actor_id nullable
action
target_type
target_id nullable
occurred_at
request_id
reason nullable
before_summary jsonb nullable
after_summary jsonb nullable
metadata jsonb
```

Audit at minimum:

- driver KYC review decision;
- driver suspension/reinstatement/offboarding;
- schedule/admin assignment edits;
- vehicle/charger changes;
- pairings/mismatch resolution;
- maintenance state changes;
- pricing policy activation/retirement;
- compensation policy activation/retirement;
- manual compensation adjustment;
- admin job cancel/reassign/override;
- technical charger commands;
- refund issuance;
- invoice manual retry/void if supported;
- incident resolution;
- permission/role changes;
- system setting changes.

Audit entries must not contain secret values.

---

# 42. Observability Blueprint

## 42.1 Structured logs

All services log structured fields such as:

```text
timestamp
level
service
environment
request_id
trace_id where available
actor_type safe
actor_id safe when appropriate
cms_command_id/cms_operation_id/hal_command_id/hal_transaction_id/fact_id/job_id where relevant
event
error_code
```

No raw request/response bodies by default.

## 42.2 Metrics

CMS metrics should include:

- HTTP rate/latency/error by route template;
- DB pool saturation/latency;
- active duties by status;
- jobs by status and oldest age;
- dispatch attempt success/time-to-assignment;
- offer accept/reject/expire rate;
- stale driver locations;
- payments pending/failed/reconciliation age;
- invoice queue depth/failure;
- notification queue depth/failure;
- compensation backlog/failure;
- support/incident queue age;
- realtime connections/publish failures.

HAL metrics should include:

- connected chargers;
- connection churn;
- stale chargers;
- operations by state;
- oldest queued operation;
- unknown outcomes;
- fact outbox backlog/oldest age;
- reconnect reconciliations;
- protocol errors;
- meter sample rate/drop/invalid counts.

## 42.3 Health and readiness

Each service exposes:

```text
/health/live
/health/ready
```

Liveness means process is alive.

Readiness checks dependencies required to safely accept traffic, without making fragile third-party APIs mandatory if requests can queue/reconcile safely.

## 42.4 Alerts

Alert on actionable conditions, including:

- service down/restart loop;
- DB unavailable;
- worker oldest age exceeds threshold;
- dispatch backlog/assignment time breach;
- payment reconciliation backlog;
- HAL fact backlog;
- charger unknown command outcomes;
- unusually high charger disconnect rate;
- invoice generation repeated failure;
- storage nearing capacity;
- migration/runtime mismatch.

---

# 43. Data Retention, Privacy, and Archival

Retention MUST be explicit per data class rather than "keep everything forever" by accident.

Suggested categories:

- legal/financial invoices/payments/refunds: long-term according to accounting/legal obligations;
- ServiceJob commercial history: long-term;
- compensation ledger: long-term business record;
- audit: long-term security/business record;
- raw driver GPS samples: bounded operational retention, with aggregates/history kept as needed;
- raw HAL protocol traces: bounded technical retention, longer around incidents;
- idempotency keys: bounded but long enough for retries;
- notification delivery attempts: bounded after terminal state;
- expired sessions/tokens: security retention as needed;
- KYC: lifecycle/legal retention policy with deletion/anonymization process.

A future privacy deletion/anonymization workflow must preserve legal/financial integrity while removing or pseudonymizing data that is no longer required.

---

# 44. Database Schema Grouping and Migration Plan

The exact SQL is created as work is implemented, but migration dependencies SHOULD follow this order so later features do not force semantic rewrites.

## 44.1 Migration groups

```text
000001 platform extensions / UUID support / base conventions
000002 accounts and sessions
000003 admin roles/capabilities
000004 audit foundation
000005 durable outbox/idempotency

000010 customer profiles
000011 customer vehicles
000012 customer addresses

000020 driver applications
000021 driver documents/reviews
000022 driver profiles/eligibility

000030 service vehicles
000031 chargers/connectors
000032 vehicle-charger pairings/history
000033 maintenance/lifecycle
000034 driver asset assignments
000035 mobile energy stores/capabilities (conditional when REQUIRED)

000040 schedules/occurrences
000041 duty sessions
000042 asset claims
000043 availability intervals
000044 location samples/projection
000045 asset mismatch reports
000046 energy observations/reservations (conditional when REQUIRED)

000050 service requests
000051 quotes
000052 service jobs/events
000053 dispatch attempts/candidates/offers
000054 job assignments

000060 charging start intents, one-use credential hashes, CMS command records
000061 charging sessions, stop requests, HAL transaction links
000062 HAL mapping registry, immutable fact receipts, connection/connector projections
000063 meter/SoC observations and charging operational events
000064 generic charger-operation dispatch/recovery fencing
000065 HAL reconciliation cursors/state

000070 pricing policies/rules/snapshots/line items
000071 payments/provider events
000072 refunds/adjustments
000073 GST snapshots/invoices

000080 compensation policies/rules
000081 compensation snapshots/line items/adjustments

000090 ratings/reviews
000091 support tickets/messages
000092 incidents
000093 notifications/preferences

000100 realtime/projection support where persistence is actually needed
```

Numbers are a proposed bootstrap sequence, not a requirement to create empty placeholder migrations.

## 44.2 Migration rules

- Applied migrations are immutable.
- Every migration has deterministic up behavior.
- Down migration exists only where semantically safe; destructive history rollback may deliberately refuse.
- Large/data-transforming migrations include preflight and verification query plan.
- Production migration is preceded by verified backup/rollback strategy appropriate to blast radius.
- New binary/schema compatibility is analyzed before deployment order is chosen.

---

# 45. Configuration Blueprint

Configuration is environment-driven with an example key contract.

Categories:

```text
APP_ENV
HTTP_LISTEN_ADDR
PUBLIC_BASE_URL
DATABASE_URL
LOG_LEVEL

AUTH_*
SESSION_*
RATE_LIMIT_*

RAZORPAY_*
PAYMENT_*

HAL_V1_BASE_URL
HAL_V1_CMS_BEARER_TOKEN
HAL_V1_CMS_FACT_BEARER_TOKEN
HAL_V1_TRACE_BEARER_TOKEN
HAL_V1_REQUEST_TIMEOUT
HAL_V1_START_RECONCILE_AFTER
HAL_V1_CONNECTION_STALE_AFTER
HAL_V1_METER_STALE_AFTER
HAL_V1_RECONCILE_INTERVAL

INVOICE_STORAGE_ROOT or object-storage configuration
MAIL_*
PUSH_*

DISPATCH_*
LOCATION_*
SERVICE_AREA_*

MOBILE_ENERGY_MODEL
MOBILE_ENERGY_OBSERVATION_MAX_AGE_SECONDS   # required when model=REQUIRED

OUTBOX_*
WORKER_*

REALTIME_*
```

The HAL repository has its own independent configuration contract. At minimum:

```text
DATABASE_URL
HTTP_LISTEN_ADDR
OCPP_LISTEN_ADDR
CMS_V1_FACTS_URL
CMS_V1_FACT_BEARER_TOKEN
CMS_V1_TRACE_EVENTS_URL
CMS_V1_TRACE_BEARER_TOKEN
FACT_OUTBOX_*
TRACE_OUTBOX_*
COMMAND_WORKER_*
CHARGER_OPERATION_RECOVERY_*
CONNECTION_*
OCPP_*
```

`HAL_V1_CMS_BEARER_TOKEN`, `HAL_V1_CMS_FACT_BEARER_TOKEN`, and `HAL_V1_TRACE_BEARER_TOKEN` are three distinct secret purposes. The CMS-to-HAL command credential MUST NOT be reused for HAL-to-CMS fact or trace delivery.

Rules:

- `.env` never committed;
- `.env.example` contains names and safe descriptions/defaults, never secrets;
- startup validates required configuration;
- no secret values printed in logs;
- pre-deploy key-name parity check detects missing/extra/blank keys safely.

Business pricing/compensation rules belong in versioned database policies, not environment variables.

---

# 46. OpenAPI and Human Contract Discipline

OpenAPI is a first-class deliverable, not generated as an afterthought from undocumented handlers.

Every route change updates together:

1. handler;
2. service/domain logic;
3. persistence/migration;
4. authorization;
5. OpenAPI;
6. human integration guidance where needed;
7. tests;
8. project state/changelog/work item.

Runtime route registration MUST be tested against the canonical OpenAPI contract.

Verification and documentation MUST distinguish:

- **path count**: number of distinct OpenAPI path keys;
- **operation count**: number of concrete HTTP method operations across those paths.

One path may contain multiple operations. Never propagate a bare API count without naming the metric, and compare source/runtime using the same metric.

User, Driver, and Admin integrator documents should be standalone and generated/maintained by domain, not one unstructured mega-document.

---

# 47. End-to-End User Flow

## 47.1 Immediate service, normal path

```text
User authenticates
-> chooses saved or temporary EV
-> chooses saved or temporary location
-> chooses charging preference
-> creates ServiceRequest
-> backend validates serviceability
-> backend creates Quote from active PricingPolicy
-> user accepts Quote
-> ServiceJob created with immutable snapshots
-> dispatch attempt starts
-> eligible drivers determined
-> ranked candidate offered
-> driver accepts
-> assignment frozen/current
-> user sees assigned driver/mobile unit
-> driver begins EN_ROUTE
-> driver location updates User/Admin projection
-> driver arrives
-> backend records arrival validation
-> driver enters SERVICE_PREPARING
-> actual charger/connector compatibility revalidated
-> authorized User/Driver policy requests charging start
-> CMS validates job/duty/asset/readiness and commercial admission
-> CMS durably creates ChargingStartIntent + frozen commercial inputs + one-use credential hash + immutable cms_command_id
-> CMS confirms the committed charger/connector mapping and submits that exact start command to HAL
-> start progresses through REQUESTED / ACCEPTED_FOR_DELIVERY / PROTOCOL_ACKNOWLEDGED or RECONCILIATION_REQUIRED; none means charging started
-> authoritative HAL `transaction.started` fact with the exact identity chain arrives
-> CMS materializes exactly one ACTIVE ChargingSession and marks the start intent ACTUALLY_STARTED
-> ServiceJob enters CHARGING from materialized physical-start evidence
-> monotonic meter/SoC/connection/connector facts update durable CMS projections
-> user/driver/admin see CMS projection; realtime is recoverable from REST/snapshot
-> stop request creates one durable ChargingStopRequest/command, or the charger may stop spontaneously
-> RemoteStop acknowledgement leaves the session open
-> authoritative HAL `transaction.completed` fact, or exact completed-transaction reconciliation, finalizes the session exactly once
-> ServiceJob enters WRAP_UP
-> final physical/source facts collected
-> PricingEngine finalizes customer line items
-> payment settlement/reconciliation reaches required boundary
-> invoice generated from frozen facts
-> CompensationEngine calculates driver line items
-> driver completes closeout
-> ServiceJob becomes COMPLETED when completion invariants pass
-> User history/payment/invoice/rating surfaces agree
-> Driver history/earnings agree
-> Admin sees same durable truth through broader projection
```

## 47.2 Scheduled service

Scheduled request adds:

- `requested_for` window;
- dispatch worker begins within configured lead window;
- quote validity/repricing policy explicitly determines whether original quote remains valid until service;
- scheduled dispatch respects driver schedules and asset availability at the target time;
- customer is notified on material assignment/availability changes.

No fake assignment is created hours early merely to reserve appearance of certainty unless an explicit reservation mechanism owns that truth.

---

# 48. End-to-End Driver Flow

```text
Driver applies
-> submits required KYC/documents
-> Admin reviews
-> action required or approved
-> onboarding
-> DriverProfile ACTIVE
-> driver logs in
-> sees schedule/eligibility
-> starts duty
-> backend validates eligibility + actual assets + exclusive claims
-> duty becomes AVAILABLE
-> driver sends location
-> dispatch offer received
-> driver accepts
-> duty/job becomes ASSIGNED
-> en route
-> arrival
-> service preparation
-> start charging intent
-> observe physical charging status
-> handle stop/fault/recovery
-> wrap-up
-> complete job
-> duty returns AVAILABLE if still valid
-> compensation calculated from authoritative facts
-> driver sees explainable line items and aggregates
-> driver ends duty after no active blocking job
```

Driver UI must make uncertain technical states explicit. After tapping Start, show start-progress state until the CMS reports `ACTUALLY_STARTED` with a materialized `session_id`. `ACCEPTED_FOR_DELIVERY` or `PROTOCOL_ACKNOWLEDGED` is still "waiting for charger"; `RECONCILIATION_REQUIRED` is "confirming charger state" and MUST NOT trigger another start.

---

# 49. End-to-End Admin Flow

Admin product combines multiple operational personas without losing capability boundaries.

Example live operations flow:

```text
Admin opens operations dashboard
-> sees dispatching job with no eligible candidate
-> inspects diagnostics
-> sees closest driver excluded because charger lacks connector
-> sees second driver location stale
-> third driver eligible but on break
-> Admin may contact/resolve actual operation
-> can release hold/end break only with proper authority/real-world confirmation
-> retry dispatch
-> assignment occurs
-> later charger faults
-> technical Admin sees HAL fact/trace
-> operations Admin reassigns if recovery cannot continue
-> original assignment preserved
-> customer job remains one ServiceJob
-> finance later sees final charge and refund/adjustment if needed
-> compensation reflects each driver's actual eligible work
```

This is why all actor views must compose the same durable domain truth rather than maintain separate contradictory copies.


# 50. Completion Invariants

A ServiceJob may transition to `COMPLETED` only when all applicable invariants are true.

Minimum invariants:

1. Job is in `WRAP_UP`.
2. No active physical charging transaction remains for the job.
3. No `ChargingStartIntent`, `ChargingStopRequest`, or physical-delivery command remains unresolved without an explicit reconciliation disposition. A start in `RECONCILIATION_REQUIRED` blocks replacement start on the same job/asset until exact evidence resolves it; an unresolved stop never allows CMS to claim physical completion. Generic administrative charger-operation ambiguity is tracked separately and blocks job completion only when that specific operation is defined as a safety prerequisite.
4. Final charging metrics have been frozen or explicitly marked unavailable with reason.
5. Final pricing has been calculated or a deliberate zero/exception commercial disposition exists.
6. The current assignment has a closeout disposition.
7. Required driver closeout fields are present.
8. Any mandatory incident/blocking exception is resolved or explicitly transferred to post-service handling.
9. Job history/event write succeeds in the same transaction.

Payment capture and invoice readiness SHOULD NOT be required to mark physical field service complete unless the business explicitly chooses a pre-completion collection rule. Their state remains visible independently.

Driver compensation MAY be calculated asynchronously after completion but must be derived from frozen source facts and eventually converge.

---

# 51. Cancellation, No-Show, and Failure Matrix

Cancellation semantics depend on actor and lifecycle state.

## 51.1 Customer cancellation

Customer MAY cancel when policy permits.

At minimum, cancellation should be possible before physical charging begins. After physical charging begins, use stop + wrap-up/commercial finalization rather than pretending the service never happened.

Recommended state handling:

```text
DISPATCHING -> CANCELLED
ASSIGNED -> CANCELLED
ACCEPTED -> CANCELLED
EN_ROUTE -> CANCELLED
ARRIVED -> CANCELLED or NO_SHOW depending facts
SERVICE_PREPARING -> CANCELLED if no physical charge started
CHARGING -> not direct CANCELLED; stop charging, finalize delivered service, then terminal disposition
```

Cancellation fee is pricing-policy driven.

## 51.2 Driver cancellation/unavailability

Driver cannot simply mark the customer job cancelled.

A driver unable to continue reports an operational reason. Backend/Admin decides:

- reassign job;
- fail job;
- cancel due platform/driver cause;
- create incident.

The assignment ends with reason; the ServiceJob remains independent.

## 51.3 Customer no-show

A no-show requires arrival/attempt evidence and policy-defined waiting threshold or Admin override.

Do not let Driver immediately mark NO_SHOW without server-side timing/location checks where available.

## 51.4 Driver no-show

If an assigned driver fails to progress/arrive:

- system/admin may mark assignment failed;
- job enters `REASSIGNING`;
- incident/driver performance evidence may be recorded;
- customer is not blamed commercially.

## 51.5 Failure taxonomy

`FAILED` job requires a reason code such as:

```text
NO_COMPATIBLE_DRIVER
VEHICLE_BREAKDOWN
CHARGER_FAULT
HAL_UNAVAILABLE
UNSAFE_SERVICE_CONDITIONS
CUSTOMER_VEHICLE_INCOMPATIBLE
LOCATION_INACCESSIBLE
PAYMENT_POLICY_BLOCK
PLATFORM_TECHNICAL_FAILURE
OTHER_ADMIN_RESOLVED_FAILURE
```

A human-readable note may supplement but never replace structured reason.

---

# 52. Asset Mismatch and Reconciliation Flow

## 52.1 Report

When actual assets differ from intended records:

1. Driver selects expected asset context.
2. Driver reports observed vehicle/charger.
3. Backend records mismatch with timestamps and evidence.
4. Backend decides whether safe temporary operation is permitted.
5. DutySession stores actual operational snapshot.
6. Admin queue receives mismatch.

## 52.2 Temporary operation decision

Temporary operation can continue only if all mandatory safety/technical identity facts are available.

For a charger, this means at minimum:

- stable physical/HAL identity known;
- required connector/capability known;
- current HAL state acceptable;
- no conflicting claim/use;
- policy allows observed mismatch operation.

Unknown/unmanaged charger identity blocks charging dispatch.

## 52.3 Admin resolution

Resolution actions:

```text
CONFIRM_MASTER_DATA_CORRECTION
RESTORE_EXPECTED_CONFIGURATION
CREATE_NEW_ASSET_AND_PAIR
REASSIGN_ASSET
REJECT_REPORT
CLOSE_NO_CHANGE
```

Resolution updates master data only through normal audited operations.

It never rewrites the old DutySession snapshot.

---

# 53. Mobile Unit Energy/Capacity Model and Activation Gate

A mobile charging unit may itself carry a finite onboard energy store. This is not an optional afterthought once the chosen hardware actually has such a constraint.

## 53.1 Activation decision

Before B04.7/B05.8 are skipped and before B07.1 dispatch eligibility is declared complete, the hardware decision in Section 69.2 MUST be resolved.

Exactly one project state is recorded:

```text
MOBILE_ENERGY_MODEL = NOT_APPLICABLE
MOBILE_ENERGY_MODEL = REQUIRED
MOBILE_ENERGY_MODEL = TEMPORARILY_UNAVAILABLE
```

- `NOT_APPLICABLE`: the operational hardware does not have a dispatch-relevant finite energy store.
- `REQUIRED`: hardware has finite deliverable energy and the platform can obtain sufficiently trustworthy capacity/SoC/availability evidence. Energy modeling becomes a core dispatch dependency.
- `TEMPORARILY_UNAVAILABLE`: hardware has finite energy but trustworthy telemetry/manual evidence is not yet integrated. The system MUST expose this limitation to Admin and MUST NOT claim energy-aware dispatch. Production dispatch under this mode requires an explicit documented operational safety policy and acceptance by the business/operations owner.

## 53.2 Required persistence when active

When `REQUIRED`, implement:

```text
mobile_energy_stores
energy_store_observations
energy_store_reservations
energy_store_capability_snapshots
```

The energy store is separate from `ServiceVehicle` and `Charger` identity even if permanently installed initially. Historical DutySession/ServiceJob records snapshot the relevant capability/reserve context.

## 53.3 Dispatch and reservation semantics

Dispatch eligibility requires sufficient **deliverable** reserve for the requested job plus configured safety reserve, accounting for existing active reservations/claims. Two simultaneously evaluated jobs MUST NOT both consume the same unreserved capacity as if it were fully available.

Reservation must be concurrency-safe and have:

- stable reservation identity;
- job/duty/energy-store ownership;
- reserved energy estimate;
- safety reserve applied;
- creation/expiry/release semantics;
- conversion/reconciliation against actual delivered energy where meaningful;
- recovery for abandoned jobs/assignments.

The authoritative input may come from vehicle telemetry, BMS integration, HAL/vendor telemetry, or validated manual state depending on hardware. Every observation records provenance and freshness.

## 53.4 No fabricated certainty

When energy evidence is unavailable or stale, the system MUST NOT fabricate a numeric reserve. Candidate eligibility either blocks under configured safety policy or reports the explicit non-modeled/unknown reason. Admin diagnostics MUST distinguish `INSUFFICIENT`, `STALE`, `UNKNOWN`, and `NOT_APPLICABLE`.

Driver/User UI MUST NOT present a guaranteed deliverable energy amount unless the backend has a defined evidence basis for that guarantee.

---

# 54. Derived Projections and Rebuildability

Derived projections improve read performance but cannot become hidden sources of truth.

Candidate projections:

- current driver location;
- driver current duty summary;
- current job live projection;
- charger runtime projection;
- admin operations dashboard counters;
- driver earnings summaries;
- customer rating aggregates.

For each projection, document:

- source tables/events;
- update trigger/worker;
- staleness semantics;
- rebuild/reconciliation method;
- what happens if projection update fails.

A failed projection update must not roll back already committed physical/commercial truth unless the projection itself is part of the transaction intentionally.

---

# 55. Search, Filtering, and Operational Query Rules

Operational list APIs MUST be useful to real admins, not only technically paginated.

## 55.1 Drivers

Filter/sort by:

- recruitment status;
- operational status;
- eligibility;
- on-duty/off-duty;
- schedule window;
- active job;
- base zone;
- document expiry/block reason;
- name/phone/email search with privacy controls.

## 55.2 Fleet

Filter/sort by:

- active/retired;
- maintenance;
- availability derived state;
- vehicle/charger pairing;
- current driver/duty;
- connector type;
- power;
- protocol;
- HAL online/staleness;
- last activity.

## 55.3 Jobs

Filter/sort by:

- status;
- created/requested time;
- scheduled/immediate;
- customer;
- driver;
- vehicle;
- charger;
- payment state;
- invoice state;
- incident/support association;
- exception state;
- zone;
- age in current state.

## 55.4 Finance/compensation

Filter by date ranges using explicit timezone semantics and bounded exports.

Large exports should be asynchronous durable export jobs, not unbounded API responses.

---

# 56. Operational Exports

Admin may require CSV/structured exports for finance, driver compensation, jobs, and assets.

Exports SHOULD be modeled as asynchronous jobs for nontrivial ranges:

```text
export_jobs
  id
  type
  requested_by
  filters jsonb
  status
  storage_ref nullable
  checksum nullable
  created_at
  completed_at nullable
  expires_at
```

Export artifacts are private and time-bounded.

Export data must use the same authoritative queries/definitions as UI summaries to prevent inconsistent numbers.

---

# 57. Testing Strategy

Testing is layered by the kind of claim being made.

## 57.1 Unit tests

Mandatory areas:

- every state transition table;
- customer pricing rule evaluation;
- compensation rule evaluation;
- time-window/interval prorating;
- dispatch eligibility;
- dispatch ranking deterministic tie-break;
- geofence intersection;
- snapshot construction;
- authorization decisions;
- cancellation/no-show rules;
- HAL adapter normalization;
- payment/refund state transitions;
- invoice calculation inputs;
- privacy projection shaping.

## 57.2 PostgreSQL integration tests

Run against explicit disposable PostgreSQL.

Must test:

- migrations from empty DB;
- up/down where down is safe;
- uniqueness/exclusion constraints;
- active DutySession uniqueness;
- asset claim race;
- offer acceptance race;
- idempotency duplicate/conflict;
- outbox atomicity;
- duplicate HAL fact ingest;
- transaction rollback;
- version/optimistic concurrency;
- historical FK behavior;
- policy version immutability.

## 57.3 Service integration

CMS-HAL:

- mapping create/update and post-commit reconfirmation;
- start command durable acceptance without session materialization;
- protocol acknowledgement without session materialization;
- authoritative `transaction.started` materializes exactly one session;
- command explicit rejection;
- HTTP timeout before HAL durable acceptance;
- HTTP timeout after HAL persisted/possibly delivered command;
- exact `cms_command_id` reconciliation and confirmed absence;
- exact `cms_start_intent_id` transaction reconciliation;
- late start fact after rejected/expired intent;
- duplicate identical fact is success/no-op;
- same fact ID with changed digest is integrity conflict;
- out-of-order connection/connector/meter/SoC sequence cannot regress projection;
- stop acknowledgement does not complete session;
- spontaneous charger-originated completion is accepted when identity chain validates;
- missing completion fact recovered by exact `hal_transaction_id` and same finalizer;
- reconnect/restart during active transaction;
- CMS outage while HAL fact outbox accumulates;
- HAL outage while CMS preserves durable intent/session truth;
- generic admin charger operation uses pre-I/O delivery fence and no-replay exact-ID recovery;
- slow generic operation recovery cannot delay charging deadline/automatic-stop worker;
- multiple physical sessions under one ServiceJob.

Payments:

- order retry;
- callback success + webhook duplicate;
- webhook before client verify;
- provider timeout;
- captured payment with lost API response;
- refund timeout/reconciliation.

## 57.4 End-to-end simulator tests

At minimum script these flows:

### E2E-01 happy path saved data

Saved EV + saved address -> quote -> dispatch -> charge -> payment -> invoice -> compensation -> rating.

### E2E-02 temporary customer data

Temporary EV/address -> completed job -> history retains snapshots -> promote both -> old history unchanged.

### E2E-03 scheduled driver

Admin schedule + assigned assets -> driver starts occurrence -> job -> planned vs actual times preserved.

### E2E-04 unscheduled driver

Driver self-starts duty under permitted policy -> selects eligible assets -> receives job.

### E2E-05 pairing mismatch

Admin expects C1, driver observes C2 -> report -> allowed temporary operation -> job uses C2 snapshot -> Admin reconciles later -> old duty remains C2.

### E2E-06 no compatible charger

Nearby drivers exist but connector/capability incompatible -> no invalid offer -> Admin diagnostic explains exclusion.

### E2E-07 start response lost after possible physical success

CMS creates one ChargingStartIntent/command -> HAL durably persists and sends start -> response is lost -> CMS enters `RECONCILIATION_REQUIRED` without a replacement command -> exact command/transaction lookup or immutable `transaction.started` fact proves the same attempt -> exactly one ChargingSession materializes.

### E2E-08 charger fault and restart

Transaction S1 ends unexpectedly -> same ServiceJob remains active -> recovery -> S2 starts -> final billing aggregates eligible facts.

### E2E-09 driver reassignment

D1 en route then breaks down -> assignment closes -> D2 assigned -> one ServiceJob -> compensation split by authoritative intervals.

### E2E-10 customer cancel after dispatch

Cancellation policy line item applied, assignment closed, no charging started, no fake energy/invoice facts.

### E2E-11 customer no-show

Arrival evidence + waiting threshold -> no-show -> policy charge -> compensation rule as configured.

### E2E-12 policy changes mid-job

Pricing and compensation policy edited/activated after job started -> job uses frozen versions defined by snapshot boundary.

### E2E-13 time boundary compensation

Driver work crosses night-rate boundary -> interval-prorated line items match exact minutes/distance basis.

### E2E-14 payment duplicate/recovery

Captured payment, lost response, duplicate webhook -> one captured logical payment.

### E2E-15 realtime disconnect

User/Driver/Admin lose realtime -> reconnect -> REST current state is correct -> subsequent versioned events converge.

## 57.5 Physical hardware acceptance

Before production readiness for a charger model/protocol:

- connect/disconnect;
- remote start/stop;
- transaction IDs;
- meter values;
- SoC if claimed;
- faults;
- reconnect during transaction;
- network loss;
- charger reboot;
- uncertain command outcome;
- connector mapping;
- max power/capability reporting;
- repeated sessions;
- time synchronization behavior;
- vendor deviations.

Simulator acceptance is not physical hardware acceptance.

---

# 58. Verification Gates for Every Work Item

Every meaningful burner/work item has four separate gates.

## Gate A: semantic/design

- scope and non-goals explicit;
- domain owner clear;
- state transition defined;
- persistence/constraints defined;
- authorization defined;
- idempotency defined;
- failure/recovery defined;
- history/realtime/audit impact defined.

## Gate B: source

- formatting/lint;
- focused tests;
- broad unit/integration tests;
- OpenAPI/runtime parity;
- documentation verifier;
- migration checks;
- `git diff --check`;
- no unrelated changes.

## Gate C: integration/runtime

- migrations applied to target environment intentionally;
- service healthy/readiness;
- changed routes behave under auth boundaries;
- workers healthy;
- logs clean of new panics/fatals;
- external integration tested or explicitly marked unverified.

## Gate D: physical/external acceptance where relevant

- real Razorpay provider behavior;
- real email/push provider acceptance;
- real HAL-to-charger behavior;
- real hardware acceptance.

A feature can be source-complete but not physically accepted. The completion statement must say which gate was reached.

---

# 59. CI Pipeline Blueprint

Every repository pull/merge validation SHOULD include, as applicable:

CMS:

```text
format check
go test focused critical packages
go test ./...
go vet ./...
go build ./...
go mod verify
migration parse/check
OpenAPI schema validation
runtime-route vs OpenAPI parity test
documentation verifier
git diff --check
disposable PostgreSQL integration suite
```

HAL:

```text
format check
go test ./...
go vet ./...
go build ./...
go mod verify
migration checks
adapter contract tests
scripted simulator scenarios
CMS-HAL schema compatibility tests
```

Never run DB integration suites against shared development/production databases.

---

# 60. Deployment Blueprint

## 60.1 Deployment order principle

Choose deployment order based on schema/contract compatibility, not habit.

Prefer backwards-compatible additive releases:

1. additive DB migration;
2. deploy code that understands old+new where transition requires;
3. switch behavior/config;
4. remove old support only in later release when safe.

## 60.2 CMS deployment preflight

Before activation:

- verify intended Git SHA;
- clean/understood worktree;
- verify migrations pending/current;
- validate configuration key parity without printing secrets;
- verify disk/storage;
- verify service unit and listener;
- verify reverse proxy routing;
- verify DB backup/recovery plan if schema mutation is consequential;
- build candidate;
- run source verification;
- identify old binary/rollback asset;
- inspect currently active jobs/operations if maintenance may disrupt them.

## 60.3 HAL deployment preflight

Additionally:

- inspect active charger connections;
- inspect active transactions;
- inspect queued/unknown operations;
- confirm restart recovery can reconcile active physical sessions;
- avoid deployment when a known non-recoverable hardware operation is in a dangerous boundary unless necessary.

## 60.4 Activation

Use managed service deployment/rehost procedure.

Do not improvise kill/start commands when a controlled framework exists.

## 60.5 Post-deploy verification

CMS:

- service active/restart count;
- local/public health/readiness;
- OpenAPI/Swagger;
- migration ledger;
- worker health/backlogs;
- auth rejection on protected routes;
- changed feature smoke path;
- payment/notification/invoice external boundary if included;
- logs.

HAL:

- service active/restart count;
- internal health/readiness;
- charger reconnection;
- active transaction reconciliation;
- operation queue;
- fact outbox;
- simulator smoke;
- real charger smoke where deployment claims physical acceptance.

## 60.6 Rollback

Rollback decision considers:

- whether schema down is safe;
- whether new historical rows make destructive down unsafe;
- whether a forward fix is safer;
- active physical transactions;
- payment/invoice facts created by new release.

Binary rollback must never be described as complete if database/state semantics are incompatible with the older binary.

---

# 61. Backup, Recovery, and Disaster Principles

## 61.1 CMS database

- automated backups;
- tested restore procedure;
- pre-migration backup for high-risk schema/data changes;
- retention appropriate to business/legal importance;
- periodic restore drill.

## 61.2 HAL database

HAL persistent operations/facts are operational evidence and need backups as appropriate.

However, recovery design must also tolerate losing rebuildable connection projections while preserving operation/fact integrity.

## 61.3 Artifact storage

Invoice/KYC/export storage requires backup/retention consistent with database references.

Database restore without corresponding artifacts must be detectable, not silently produce broken downloads.

Store checksums and perform integrity checks.

---

# 62. Project Documentation Set

The repository should maintain at minimum:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/DEVELOPMENT_PLAN.md
docs/AI_CHANGELOG.md

docs/architecture/SYSTEM_ARCHITECTURE.md
docs/architecture/DOMAIN_MODEL.md
docs/architecture/STATE_MACHINES.md
docs/architecture/CMS_HAL_BOUNDARY.md
docs/architecture/CHARGING_TRUTH_MODEL.md

docs/contracts/openapi/openapi.yaml
docs/contracts/api/user-app.md
docs/contracts/api/driver-app.md
docs/contracts/api/admin.md
docs/contracts/api/internal-hal.md
docs/contracts/hal/CMS_HAL_CHARGING_V1.md
docs/contracts/realtime/events.md
docs/contracts/configuration.md

docs/handoffs/USER_APP_FE_HANDOFF.md
docs/handoffs/DRIVER_APP_FE_HANDOFF.md
docs/handoffs/ADMIN_FE_HANDOFF.md

docs/guides/operations/dev-hosting.md
docs/guides/operations/deployment.md
docs/guides/operations/rollback-recovery.md
docs/guides/operations/charger-onboarding.md
docs/guides/operations/incident-response.md

docs/work/active/
docs/work/archive/
```

HAL repository has its own equivalent architecture, adapter, operation-state, simulator, and hosting docs.

---

# 63. Work Item Discipline

Every burner is narrow and complete.

A work item states:

- objective;
- claimed surfaces;
- dependencies;
- invariants;
- schema changes;
- API changes;
- realtime/worker changes;
- non-goals;
- tests;
- operational impact;
- verification target;
- current unverified boundary.

One burner is finished and verified before opening a semantically dependent burner unless parallelism is genuinely independent.

---

# 64. Exact Implementation Program

The implementation sequence below converts architecture into buildable burners. It intentionally front-loads contracts and stable primitives that later domains depend on.

## Program 0 - Repository and engineering authority

### B00.1 CMS repository bootstrap

Deliver:

- Go module/repo structure;
- config loader;
- structured logging;
- graceful shutdown;
- health/readiness;
- PostgreSQL connection;
- migration command;
- request IDs;
- base error contract;
- OpenAPI serving/Swagger;
- CI baseline;
- AGENTS/project docs.

Exit gate: clean empty service deploys to dev, migration 1 applies, OpenAPI/runtime route test passes.

### B00.2 HAL repository bootstrap

Deliver same platform foundations separately, plus protocol adapter interfaces and simulator skeleton.

Exit gate: HAL dev service runs independently, simulator adapter can connect logically, CMS-HAL auth contract stub works.

### B00.3 Disposable integration DB harness

Deliver isolated PostgreSQL test database orchestration for CMS and HAL.

Exit gate: concurrency/migration tests can run without touching shared dev DB.

---

## Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

### B01.1 Account/session authentication

Customer/Driver/Admin principal separation, session revocation/refresh, security tests.

### B01.2 Admin capability engine

Capability catalog, role bundles, effective authorization, explicit endpoint middleware.

### B01.3 Audit foundation

Append-only audit API/service and Admin query.

### B01.4 Durable idempotency primitive

Reusable idempotency storage/response binding for HTTP mutations.

### B01.5 Durable outbox and worker framework

Claim/lease/retry/backoff/metrics with one harmless test event.

Exit gate: later domains use these primitives instead of inventing local variants.

---

## Program 2 - Customer master data

### B02.1 Customer profile
### B02.2 Saved vehicles
### B02.3 Saved addresses/default handling
### B02.4 Snapshot schemas/builders
### B02.5 Temporary object and promotion behavior

Exit gate: API can create saved/temporary data, snapshot it, edit master data, and prove historical snapshot immutability.

---

## Program 3 - Driver recruitment and workforce

### B03.1 Driver application lifecycle
### B03.2 Secure document storage + versioned KYC review
### B03.3 Driver profile creation/onboarding
### B03.4 Eligibility engine + blocking reasons
### B03.5 Suspension/reinstatement/offboarding

Exit gate: an applicant can progress end-to-end and only an ACTIVE eligible driver reaches operational APIs.

---

## Program 4 - Fleet and inventory

### B04.1 Vehicle inventory/history
### B04.2 Charger inventory/connectors
### B04.3 Pairing history
### B04.4 Maintenance/lifecycle intervals
### B04.5 Admin asset assignment
### B04.6 Derived availability projection

### B04.7 Mobile energy-store registry/capability foundation (conditional)

Required only when Section 53 resolves `MOBILE_ENERGY_MODEL = REQUIRED`. Deliver stable energy-store identity, vehicle relationship/history, capability snapshot, and Admin inventory visibility. If `NOT_APPLICABLE`, record the decision and skip. If `TEMPORARILY_UNAVAILABLE`, the project may proceed only under the explicit limitations in Section 53.

Exit gate: Admin can answer current and historical vehicle/charger/assignment questions without overwriting history, and the Section 53 mobile-energy decision is recorded rather than silently deferred.

---

## Program 5 - Scheduling, duty, location

### B05.1 Schedules and materialized occurrences
### B05.2 DutySession lifecycle
### B05.3 Exclusive asset claim constraints/concurrency tests
### B05.4 Driver asset mismatch reporting
### B05.5 Break/availability intervals
### B05.6 Location ingestion/current projection/freshness
### B05.7 Driver geofence and effective area

### B05.8 Mobile energy observation/reservation foundation (conditional)

Required only when Section 53 resolves `MOBILE_ENERGY_MODEL = REQUIRED`. Deliver observation provenance/freshness, available-vs-reserved capacity projection, concurrency-safe reservation/release primitives, and recovery for abandoned reservations.

Exit gate: scheduled and unscheduled eligible drivers can start duty safely, become dispatchable, move, pause, and end duty with exact asset history. If mobile energy is required, duty/dispatch readiness also has truthful energy evidence and reservation primitives.

---

## Program 6 - Service request, pricing foundation, ServiceJob core

### B06.1 ServiceRequest
### B06.2 Serviceability validation
### B06.3 First production slice of the final pricing interface

Implement the Section 21.0 stable evaluator/line-item/snapshot contract with only the truthfully available initial components. This is production architecture, not a throwaway shell. Program 10 expands rule coverage without replacing this contract.

### B06.4 Quote acceptance -> ServiceJob snapshots
### B06.5 ServiceJob state machine/event history
### B06.6 Cancellation/no-show reason framework

Exit gate: customer can create a job independent of dispatch and history is correct.

---

## Program 7 - Dispatch

### B07.1 Eligibility engine
### B07.2 Ranking engine
### B07.3 DispatchAttempt/Candidate persistence
### B07.4 Sequential offer workflow
### B07.5 Atomic offer acceptance
### B07.6 Assignment and Driver current-job contract
### B07.7 Reassignment
### B07.8 No-candidate retry/scheduled dispatch worker
### B07.9 Admin diagnostics/direct assignment

Exit gate: simulator drivers/duties can be dispatched under race, rejection, expiry, reassignment, and no-candidate tests.

---

## Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

This program begins only after CMS charger/connector identity and the internal contract version are frozen enough that both repositories can implement against the same fixtures. It may run in parallel with late dispatch work, but not before the identifier crosswalk and mapping semantics in Sections 18-20 are settled.

### B08.1 HAL repository/bootstrap contract

- independent Go module/service/database;
- configuration loader with fail-safe production PostgreSQL requirement;
- health/readiness split;
- migration runner/explicit migration command;
- structured logging with secret/body exclusions;
- worker lifecycle and graceful shutdown framework.

Exit: empty HAL starts against disposable PostgreSQL, migrations apply, readiness reflects DB/worker health, shutdown joins workers.

### B08.2 CMS-HAL service authentication

- distinct CMS->HAL command bearer;
- distinct HAL->CMS fact bearer;
- distinct HAL->CMS trace bearer;
- constant-time credential validation where applicable;
- no human/customer token reuse;
- configuration parity/docs/tests.

Exit: each credential can call only its intended plane; cross-use fails.

### B08.3 Charger/connector mapping registry

- `PUT /v1/mappings/chargers/{cms_charger_id}` or final equivalent;
- exact CMS charger/connector UUIDs;
- protocol identity and connector-number mapping;
- enabled state and optional expected serial;
- idempotent same-content replay;
- conflicting immutable identity change semantics;
- CMS durable mapping state + post-commit reconciler.

Exit: mapping create/replay/conflict/recovery pass across both services.

### B08.4 Connection runtime and restart fencing

- tracked transport connection identity;
- process-scoped generation guard for stale callbacks;
- durable connection sequence;
- startup projection to UNKNOWN until new evidence;
- Heartbeat/liveness renewal;
- connection fact outbox;
- CMS monotonic projection/freshness.

Exit: connect, stale disconnect callback, heartbeat, HAL restart, reconnect, delayed old fact all converge correctly.

### B08.5 Connector status runtime

- mapped protocol status ingestion;
- monotonic connector status sequence;
- parent connection freshness overlay;
- CMS historical-vs-live distinction;
- inventory eligibility overlay.

Exit: Available/Preparing/Charging/Finishing/Faulted/offline/stale scenarios produce truthful CMS projection.

### B08.6 Durable HAL command store and start/stop lifecycle

Implement exact states from Section 19.4:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED
OCPP_REJECTED
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Include immutable request digest, exact CMS command identity, destination, expiry, attempts, result/error category, optional resulting transaction IDs, and database guards.

Exit: crash at every boundary cannot cause an unsafe replay.

### B08.7 One-use charging credential and OCPP authorization bridge

- CMS generation/hash persistence;
- HAL durable start-command value handling/redaction;
- OCPP 1.6 idTag translation;
- Authorize/StartTransaction correlation;
- expiry using trusted HAL receipt time and bounded charger clock-skew handling;
- replay prevention.

Exit: valid credential starts once; expired/replayed/wrong-mapping credential fails without identity leakage.

### B08.8 OCPP 1.6 transaction materialization

- charger-originated StartTransaction only;
- Central System exact transaction ID allocation;
- durable HAL transaction row;
- exact command/start-intent/credential/mapping chain;
- one immutable `transaction.started` fact reservation in the same durable operation.

Exit: RemoteStart accepted without StartTransaction never materializes transaction; duplicate StartTransaction cannot create a second logical transaction.

### B08.9 MeterValues normalization

- cumulative integer Wh selection;
- accepted-measurand rules;
- exact HAL transaction binding;
- monotonic meter sequence;
- consumed Wh relative to accepted start meter;
- invalid/decreasing/out-of-order evidence handling;
- immutable `transaction.meter` facts;
- optional instantaneous measurements kept non-authoritative.

Exit: valid, duplicate, delayed, decreasing, malformed, and unrelated meter samples are covered.

### B08.10 Independent SoC normalization

- OCPP SoC extraction when present;
- canonical decimal percent 0..100;
- independent SoC sequence/time;
- SoC-only fact allowed;
- no energy invention/cached SoC replay.

Exit: missing SoC remains unknown and energy/SoC streams cannot regress one another.

### B08.11 Stop workflow and automatic limit sources

- remote stop request persistence;
- spontaneous/local stop support;
- energy limit;
- duration limit;
- funding/commercial safety threshold only as an opaque CMS-derived bound;
- explicit threshold provenance;
- shared controlled idempotent stop workflow;
- no pricing/GST/payment interpretation in HAL.

Exit: customer/driver/admin/system/local/threshold stops preserve requested-vs-protocol provenance.

### B08.12 Transaction completion truth

- exact active transaction identity check;
- StopTransaction ordering;
- nondecreasing final meter;
- documented one-Wh quantization normalization only if retained/tested;
- duplicate/conflicting terminal evidence handling;
- canonical row-lock order;
- exactly one terminal fact aggregate.

Exit: retransmitted StopTransaction cannot produce duplicate completion fact; conflicting evidence enters reconciliation.

### B08.13 Durable fact outbox

- immutable fact envelope + canonical digest;
- per-fact idempotency identity;
- lease/claim token;
- retry/backoff;
- same identity on retry;
- stale worker fencing;
- terminal receiver error classification;
- poison isolation;
- worker health/readiness.

Exit: CMS outage/restart and HAL worker crash preserve exactly the same logical facts.

### B08.14 CMS fact ingress and projection transaction

- separate fact bearer;
- `Idempotency-Key == fact_id` validation;
- canonical digest recomputation;
- durable receipt/dedupe;
- same-ID altered-content conflict;
- type-specific mapping/identity checks;
- monotonic connection/connector/meter/SoC projection;
- session materialization/completion integration seam;
- operational event emitted in same CMS transaction.

Exit: crash-before/after commit, exact replay, altered replay, delayed sequence, unsupported fact all behave deterministically.

### B08.15 Exact command and transaction reconciliation APIs

- exact command GET by `cms_command_id`;
- exact transaction GET by `cms_start_intent_id`;
- exact transaction GET by `hal_transaction_id`;
- strict response shape/identity validation;
- canonical 404 semantics;
- no "latest" lookup.

Exit: CMS can recover start ambiguity and missing completion without direct HAL DB access or a new command.

### B08.16 Generic administrative charger operation boundary

Implement separate Reset/Unlock/Availability/diagnostic operation surface with frozen immutable destination and exact operation identity.

CMS states:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

HAL preserves pre-network replayability and post-attempt ambiguity rules.

Exit: generic operation uncertainty never mutates charging/commercial truth and never blindly replays.

### B08.17 Isolated charger-operation recovery worker

- independent from deadline/automatic-stop/pending-stop workers;
- bounded fair rotation across connected chargers;
- same atomic claim/dispatcher as immediate operation;
- request-detached bounded result persistence;
- shutdown cancellation/join;
- restart classification of attempted work to reconciliation.

Exit: intentionally slow admin OCPP command cannot delay charging stop deadline processing.

### B08.18 Diagnostic trace plane

- separate trace envelope/outbox/worker/bearer;
- sanitized CALL/CALLRESULT/CALLERROR evidence;
- bounded follow-on diagnostic windows if retained;
- CMS trace store/read capability;
- hard guarantee trace failure cannot block fact worker or mutate lifecycle state.

Exit: trace receiver outage has zero authoritative charging effect.

### B08.19 Scriptable simulator

Source-controlled scenarios cover every Section 19.18 case and expose deterministic timing/failure knobs.

Exit: CI can reproduce all command/fact/reconnect/ambiguity scenarios without physical hardware.

### B08.20 Cross-repository contract fixtures

- request/response/fact/error fixtures;
- canonical digest fixtures;
- schema version fixtures;
- CMS parser tests against HAL provider fixtures;
- HAL parser tests against CMS consumer fixtures;
- fixture version/digest guard.

Exit: incompatible drift fails CI before deployment.

Program 8 exit gate: disposable CMS + HAL PostgreSQL and virtual charger prove mapping, start command durability, real transaction start, meter/SoC, stop/completion, fact idempotency, restart/outage recovery, generic-operation worker isolation, and exact-ID reconciliation. This gate is not physical charger acceptance.

---

## Program 9 - CMS charging integration and app projections

### B09.1 Charging admission model

- ServiceJob/assignment/duty/asset authorization;
- compatibility revalidation;
- mapping prerequisite;
- frozen pricing/tax/admission context;
- selected funding-safety strategy integration without hard-coded wallet assumption;
- one-use credential generation;
- database constraints.

### B09.2 ChargingStartIntent state machine

Implement exact states/transitions from Section 18.6 plus DB/service guards and history/audit.

### B09.3 Immutable CMS START command record

Freeze command ID, start intent, HAL destination, connector number, request digest, correlation, expiry, limits/provenance before HAL I/O.

### B09.4 Start orchestration and post-commit mapping reconfirmation

Implement the exact sequence in Section 20.8, including safe cleanup when the post-commit mapping prerequisite fails before RequestStart.

### B09.5 Start ambiguity reconciler

- exact command lookup;
- confirmed-absence cleanup;
- exact transaction-by-start-intent lookup after threshold;
- late evidence handling;
- durable cursor/backoff/fairness;
- no blind new start.

### B09.6 `transaction.started` -> ChargingSession materialization

- full identity chain validation;
- exactly one session per start intent;
- exact HAL/protocol transaction IDs;
- ServiceJob transition to CHARGING only when legal;
- operational event/realtime invalidation.

### B09.7 Meter/SoC CMS projection

- independent sequences/freshness;
- accepted fact receipts;
- historical observation retention;
- user/driver/admin safe projections;
- stale parent connection semantics.

### B09.8 Charging stop request

- actor policy for Driver/User/Admin/system;
- durable stop request/command;
- optional bounded reason;
- `STOP_PENDING` projection;
- no completion from HAL/OCPP command acknowledgement.

### B09.9 `transaction.completed` finalization

- full identity/meter/time validation;
- requested-vs-protocol stop provenance;
- exactly-once session completion;
- final pricing source binding;
- payment/funding settlement seam;
- invoice intent seam;
- ServiceJob WRAP_UP gate;
- durable events.

### B09.10 Missing-completion recovery

- exact HAL transaction lookup by `hal_transaction_id`;
- same locked finalization path as normal fact;
- active/404/unavailable/malformed/conflict behaviors from Section 18.16;
- fair durable cursor.

### B09.11 Multiple ChargingSessions per ServiceJob

- separate start intent/session for later physical restart after prior session ended;
- aggregation for final pricing and compensation;
- UI/history representation;
- no transport-reconnect-induced false split.

### B09.12 Runtime availability and chargeability

- CMS inventory status;
- HAL connection freshness;
- connector protocol status/freshness;
- unresolved occupancy/start/session state;
- compatibility;
- asset mismatch;
- stable machine reason codes.

### B09.13 User charging read/progress contract

Implement Section 31.14-31.19: start progress distinct from session, exact unknown/stale behavior, materialized-session-only history, stop provenance, bounded pagination.

### B09.14 Driver charging contract

Driver Start/Stop/prepare UI consumes the same CMS domain methods and receives explicit requested/accepted/physical/reconciling states. Driver cannot force physical state by status mutation.

### B09.15 Admin technical charging views

Expose safe command/fact/runtime/trace projections with capability boundaries. Diagnostic trace is visibly labeled non-authoritative.

### B09.16 User live-job snapshot/SSE integration

- durable REST snapshot;
- full-replacement live jobs/session stream;
- generic event replay cursor;
- reconnect/token rotation/cursor expiry recovery;
- realtime outage fallback.

### B09.17 End-to-end charging acceptance

Run Section 20.18 matrix plus User/Driver/Admin projection agreement tests.

Program 9 exit gate: a virtual charger can drive a full ServiceJob charging lifecycle while every application sees the same CMS durable truth, all ambiguity is recoverable by exact identity, and no command acknowledgement is mistaken for physical charging state.

---

## Program 10 - Full pricing engine

### B10.1 Versioned pricing policy/rule persistence
### B10.2 Deterministic rule evaluator
### B10.3 Quote estimation line items
### B10.4 Final source-fact binding
### B10.5 Final pricing line items/snapshot
### B10.6 Cancellation/no-show components
### B10.7 Time/date/zone modifiers
### B10.8 Admin policy editor contract

Exit gate: fixed test fixtures prove same inputs + versions produce same result and historical jobs survive policy changes.

---

## Program 11 - Payments, refunds, tax, invoices

### B11.1 Razorpay order/payment integration
### B11.2 webhook/idempotent reconciliation
### B11.3 refund workflow
### B11.4 GST snapshot calculation
### B11.5 invoice renderer/storage/version/checksum
### B11.6 invoice worker/retry/download
### B11.7 mail/notification intent for invoice

Exit gate: provider sandbox/test environment and local artifact flow accepted end-to-end, with external acceptance boundary documented.

---

## Program 12 - Driver compensation

### B12.1 Versioned policy/rules
### B12.2 deterministic evaluator
### B12.3 time-boundary/interval prorating
### B12.4 source-fact binding
### B12.5 line-item ledger
### B12.6 reassignment allocation
### B12.7 adjustments
### B12.8 Driver summary/history
### B12.9 Admin views/exports

Exit gate: fixtures cover base, distance, time, night modifier, date bonus, driver override, minimum, cap, reassignment, and correction.

---

## Program 13 - Product completeness

### B13.1 User ratings/reviews
### B13.2 Customer support
### B13.3 Driver support
### B13.4 Incident management
### B13.5 Notification preferences/delivery
### B13.6 Admin operational dashboard
### B13.7 Async exports
### B13.8 retention/cleanup jobs

---

## Program 14 - Realtime hardening

Realtime basics may exist earlier, but this program makes it complete:

### B14.1 authenticated subscriptions
### B14.2 per-resource versioning
### B14.3 reconnect/catch-up guidance
### B14.4 user projections
### B14.5 driver projections
### B14.6 admin projections
### B14.7 backpressure/disconnect behavior
### B14.8 realtime-vs-REST consistency E2E tests

---

## Program 15 - Production hardening

### B15.1 security review
### B15.2 DB backup/restore drill
### B15.3 worker/backlog alerting
### B15.4 load tests for location/realtime/dispatch
### B15.5 Razorpay production-readiness checks
### B15.6 mail/push production acceptance
### B15.7 physical charger certification matrix
### B15.8 operational runbooks/on-call drills
### B15.9 staging full-day/long-session soak
### B15.10 release/rollback drill

---

## Program 16 - Protocol expansion

Only after core semantics are stable:

### B16.1 OCPP 2.0.1 adapter
### B16.2 adapter parity matrix
### B16.3 OCPP 2.1 if hardware/business requires
### B16.4 vendor-specific extensions behind adapter capability interfaces

Protocol expansion MUST NOT change CMS business semantics unless a genuinely new business capability is introduced deliberately.

---

# 65. Dependency Graph

High-level dependency order:

```text
Repository foundations
  -> auth/capability/audit/idempotency/outbox
     -> customer master data
     -> driver recruitment
        -> fleet
           -> schedule/duty/location
              -> service request/job
                 -> dispatch
                    -> charging integration

HAL foundations
  -> protocol-neutral core
     -> OCPP16/simulator
        -> CMS charging integration

ServiceJob + charging source facts
  -> final pricing
     -> payment/tax/invoice
  -> compensation

Core lifecycle
  -> ratings/support/incidents
  -> realtime completeness
  -> production hardening
```

The first production slice of the final pricing contract may begin before charging, but final pricing requires authoritative source facts.

HAL work can proceed in parallel after charger identity and CMS-HAL semantic contracts are frozen.

If Section 53 resolves `MOBILE_ENERGY_MODEL = REQUIRED`, B04.7 and B05.8 are hard dependencies of B07.1 eligibility and therefore of the dispatch exit gate. They cannot be postponed to a post-dispatch enhancement.

---

# 66. Phase Entrance and Exit Criteria

A later program may start only when its upstream semantic contracts are stable enough that proceeding will not force known rework.

Examples:

- Dispatch does not begin before DutySession + asset claim semantics exist.
- If mobile energy is `REQUIRED`, dispatch eligibility does not begin before energy-store identity, trustworthy observation/freshness semantics, and concurrency-safe reservation exist.
- Charging integration does not begin before stable ServiceJob/assignment IDs and charger-HAL identity mapping exist.
- Compensation finalization does not begin before source facts/time boundaries are defined.
- Invoice generation does not begin before pricing/tax snapshots are frozen.
- Protocol 2.x adapters do not begin by duplicating OCPP 1.6 code before protocol-neutral core contracts are proven.

Parallel development is allowed when dependencies are interfaces already fixed and independently testable.

---

# 67. Definition of Done - Project Level

The project is not production-ready merely because all endpoints exist.

Production readiness requires:

1. User flow accepted end-to-end.
2. Driver recruitment + operational flow accepted end-to-end.
3. Admin can operate and recover abnormal flows.
4. Dispatch handles eligibility/races/reassignment.
5. Dedicated HAL survives reconnect/restart/uncertain operation tests.
6. At least one target physical charger model is hardware-accepted.
7. Pricing fixtures and real job calculations agree.
8. Razorpay production integration is verified at the intended flow boundary.
9. Refund flow verified.
10. Invoice artifact + download + delivery path verified.
11. Compensation ledger is explainable and stable across policy changes.
12. Realtime reconnects recover from REST.
13. Authorization/privacy tests cover all three human planes.
14. Backups and restore are tested.
15. Deployment/rollback runbook is exercised.
16. Monitoring alerts on critical backlogs/failures.
17. Documentation and OpenAPI match runtime.
18. No known unresolved integrity issue is hidden behind UI workarounds.
19. Known external/unverified boundaries are documented explicitly.

---

# 68. Decisions Intentionally Left as Business Configuration

The following are not architecture gaps. They are explicit policy data/knobs that the business can change without code redesign:

- customer price/rates;
- driver compensation rates;
- cancellation/no-show monetary rules;
- dispatch ranking weights;
- sequential vs batched offer strategy;
- offer expiry duration;
- scheduled-dispatch lead time;
- driver voluntary geofence limits;
- required location freshness threshold;
- arrival radius/manual override policy;
- whether customer may directly request charging stop;
- whether charger online state is mandatory at duty start or only at dispatch;
- which KYC documents are mandatory;
- exact retention periods;
- optional notification channels;
- whether driver review text is shown directly to Driver;
- mobile-energy safety reserve, freshness, reservation expiry, and blocking thresholds once the Section 53 model is active.

Each knob needs a safe default, validation, auditability if Admin-editable, and documentation.

---

# 69. Decisions That Must Be Resolved Before Their Burner

These are genuine external/business/hardware inputs that cannot be truthfully invented in architecture:

1. Exact Charger-on-Wheels physical hardware models and connector configurations.
2. Whether the mobile unit has onboard energy storage and how its SoC/capacity is obtained. This MUST be resolved to one of the Section 53 activation states before B04.7/B05.8 are skipped and before dispatch eligibility is declared complete.
3. Exact customer payment capture strategy supported/desired with Razorpay: upfront, deposit, authorization-like pattern, or post-service collection.
4. Legal/business invoice and GST classification details for mobility/service vs energy components.
5. Required KYC document set and storage/compliance retention requirements.
6. Client platform decisions that affect push provider/device token implementation.
7. Exact navigation/maps provider if server-side ETA/routing is required.
8. Production infrastructure/hostnames/secrets/storage provider.

The implementation program does not wait on these globally. It defers only the burner whose exact behavior depends on them, using explicit interfaces in the meantime.

These are the complete known architecture-blocking external inputs as of this package. Account identity architecture, service authentication, pricing-engine interface shape, truth ownership, persistence semantics, state machines, idempotency, concurrency, recovery philosophy, and client/HAL boundaries are already resolved here and MUST NOT be re-opened as "implementation choices" without an explicit blueprint change.

---

# 70. Traceability Back to the Supplied Sources

## 70.1 Consolidated Charger-on-Wheels planning baseline

This blueprint preserves and concretizes the planning baseline's major commitments:

| Planning concept | Blueprint realization |
| --- | --- |
| User / Driver / unified Admin | Sections 1, 30-33 |
| intended vs actual vs historical vs physical/commercial truth | Sections 3, 12-20, 52 |
| reusable vs temporary customer data | Sections 10, 31, 57 |
| driver recruitment as lifecycle | Sections 11, 32-33 |
| asset inventory/pairing/mismatch | Sections 12-13, 52 |
| schedules vs actual duty | Section 13 |
| optional driver geofence | Section 14 |
| two-stage dispatch eligibility/ranking | Section 15 |
| ServiceJob central object | Sections 16-18 |
| separate charging lifecycle | Sections 18-20 |
| composable pricing | Section 21 |
| compensation calculation not payout | Section 25 |
| realtime not durable truth | Section 29 |
| dedicated protocol-neutral HAL | Sections 19-20 |
| raw evidence + normalized facts | Section 19 |
| audit and historical snapshot principles | Sections 3, 41 |
| implementation sequence | Section 64 |
| real verification / physical acceptance boundaries | Sections 57-60 |

---

## 70.2 EV-CMS Go New continuity handoff

The supplied EV-CMS continuity handoff is retained unchanged in this package as `08_SOURCE_EVCMS_FULL_CONTINUITY_HANDOFF.md`. Charger-on-Wheels does not inherit the old product's tenancy or runtime topology, but the mature engineering lessons below are promoted into this canonical blueprint:

| EV-CMS continuity lesson | Charger-on-Wheels canonical realization |
| --- | --- |
| PostgreSQL is durable truth; migrations immutable after application | Sections 9, 44, 57-61; Appendix B |
| CMS/HAL separate ownership and no shared DB | Sections 3, 5-6, 18-20 |
| physical command acceptance is not charger execution | Sections 3, 18-20; Appendices A/E/F |
| uncertain delivery reconciles rather than blind replay | Sections 18-20, 35, 38-39 |
| capability authorization and explicit DENY | Section 7 and Admin contracts |
| customer/admin identity planes must not be conflated | Sections 7, 10-11, 34, 40 |
| durable idempotency and outbox patterns | Sections 35, 37-39 |
| customer support ownership/privacy and reply idempotency | Section 27 |
| ratings/reviews own-history and aggregate semantics | Section 26 |
| invoice artifacts become immutable once finalized/READY | Section 24 |
| provider delivery acceptance is separate from outbox intent | Sections 28, 57-60; Appendix F |
| environment key parity and secret non-disclosure | Sections 40, 45, 60 |
| source/test/DB/runtime/physical verification must be distinguished | Sections 0.5, 57-60; Appendix F |
| deployment requires rollback assets and post-activation verification | Sections 60-61; Appendix E |
| OpenAPI path count and operation count are different metrics | Section 46 |
| do not recreate completed proven patterns without a concrete semantic reason | Sections 3-6 and this traceability map |

Runtime-specific facts from EV-CMS such as old hostnames, service names, database names, current SHAs, CPO tenancy, migration numbers, and deployment paths are provenance only and MUST NOT be copied into Charger-on-Wheels runtime configuration.

## 70.3 Previous blueprint package

The previous blueprint package supplied the majority of this canonical implementation design. This sole-source edition preserves that design, corrects the remaining ambiguity identified during review, embeds both supplied source documents, and adds mechanical package verification. No requirement is intentionally removed unless the canonical text explicitly supersedes it.

# 71. Final Build Principle

Charger on Wheels must make the normal path easy without forcing abnormal real-world conditions into false data.

The implementation therefore preserves, separately and explicitly:

```text
what Admin intended
what Driver actually used
what the charger physically did
what the customer commercially owes
what the driver compensation engine calculated
what happened historically
what realtime currently projects
```

Then it composes those truths into User, Driver, and Admin experiences through explicit contracts.

The stable center is the ServiceJob. The operational driver context is the DriverDutySession. The physical charging authority is the dedicated HAL. PostgreSQL-backed durable state is the recovery authority. Realtime is an accelerator. Policies are versioned. History is not rewritten for convenience. Physical side effects are never inferred from optimistic UI actions.

That is the implementation blueprint.

---

# Appendix A. Normative State Machine Registry

This appendix is normative. Implementations must not add ad hoc transitions outside these graphs without updating the domain contract, tests, OpenAPI behavior, and this blueprint.

## A.1 DriverApplication

```text
DRAFT
  -> SUBMITTED
  -> WITHDRAWN

SUBMITTED
  -> UNDER_REVIEW
  -> WITHDRAWN

UNDER_REVIEW
  -> ACTION_REQUIRED
  -> APPROVED
  -> REJECTED

ACTION_REQUIRED
  -> SUBMITTED
  -> WITHDRAWN

APPROVED
  -> ONBOARDING

ONBOARDING
  -> ACTIVE

ACTIVE      terminal recruitment success state
REJECTED    terminal recruitment decision
WITHDRAWN   terminal applicant decision
```

Operational suspension/offboarding is not a recruitment-state transition.

## A.2 DriverDutySession

```text
STARTING
  -> AVAILABLE
  -> ABORTED

AVAILABLE
  -> OFFERED
  -> BREAK
  -> UNAVAILABLE
  -> ENDING

OFFERED
  -> ASSIGNED       accepted offer
  -> AVAILABLE      rejected/expired/withdrawn offer

ASSIGNED
  -> EN_ROUTE
  -> AVAILABLE      assignment ended before departure/reassigned/cancelled

EN_ROUTE
  -> AT_CUSTOMER
  -> AVAILABLE      job cancelled/reassigned/failed and assignment ended

AT_CUSTOMER
  -> SERVICING
  -> AVAILABLE      job terminal before service starts

SERVICING
  -> AVAILABLE      job terminal/completed and assignment ended

BREAK
  -> AVAILABLE
  -> ENDING

UNAVAILABLE
  -> AVAILABLE
  -> ENDING

ENDING
  -> ENDED

ABORTED             terminal emergency/failed start state
ENDED               terminal normal state
```

Rules:

- `ENDING` requires no active blocking assignment.
- `ABORTED` from an already operational state is an Admin/system emergency path only and requires active jobs/assets to be reconciled explicitly.
- Offer withdrawal occurs before entering BREAK/UNAVAILABLE if the driver is currently OFFERED.

## A.3 DispatchAttempt

```text
RUNNING
  -> OFFERING
  -> EXHAUSTED
  -> CANCELLED

OFFERING
  -> ASSIGNED
  -> RUNNING         recompute/continue after candidate result
  -> EXHAUSTED
  -> CANCELLED

ASSIGNED             terminal success
EXHAUSTED            terminal no-candidate result for this attempt
CANCELLED            terminal because job no longer needs this attempt
```

## A.4 DispatchOffer

```text
PENDING
  -> ACCEPTED
  -> REJECTED
  -> EXPIRED
  -> WITHDRAWN
```

All terminal. Exactly one ACCEPTED offer can become the current assignment for a given assignment cycle.

## A.5 ServiceJob

```text
DISPATCHING
  -> ASSIGNED         one sequential offer is live
  -> CANCELLED
  -> EXPIRED
  -> FAILED

ASSIGNED
  -> ACCEPTED         selected driver accepts; JobAssignment is created
  -> DISPATCHING      offer rejected/expired/withdrawn before acceptance
  -> REASSIGNING      provisional selection invalidated by operational change
  -> CANCELLED
  -> FAILED

ACCEPTED
  -> EN_ROUTE
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

EN_ROUTE
  -> ARRIVED
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

ARRIVED
  -> SERVICE_PREPARING
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

SERVICE_PREPARING
  -> CHARGING
  -> WRAP_UP          explicit zero-charge/aborted-service closeout only
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

CHARGING
  -> WRAP_UP
  -> FAILED

WRAP_UP
  -> COMPLETED
  -> FAILED

REASSIGNING
  -> DISPATCHING
  -> ASSIGNED
  -> CANCELLED
  -> FAILED

COMPLETED            terminal
CANCELLED            terminal
FAILED               terminal
NO_SHOW              terminal
EXPIRED              terminal
```

No reopening a terminal ServiceJob. Corrections are separate records/workflows.

## A.6 ChargingStartIntent

```text
REQUESTED
  -> ACCEPTED_FOR_DELIVERY
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

ACCEPTED_FOR_DELIVERY
  -> PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

REJECTED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

EXPIRED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

RECONCILIATION_REQUIRED
  -> ACTUALLY_STARTED           exact authoritative transaction evidence
  -> REJECTED                   exact command absence/rejection proves safe terminal result
  -> EXPIRED                    exact absence plus elapsed start window

ACTUALLY_STARTED               terminal for the start-intent state machine
```

No normal ChargingSession exists before `ACTUALLY_STARTED`. RemoteStart/protocol acknowledgement never creates one.

## A.7 ChargingSession and ChargingStopRequest

ChargingSession:

```text
ABSENT
  -> ACTIVE                    only from authoritative `transaction.started` evidence

ACTIVE
  -> STOP_PENDING              durable stop requested; physical transaction still open
  -> RECONCILIATION_REQUIRED  contradictory/missing predecessor/final evidence
  -> COMPLETED                 spontaneous authoritative physical completion is valid
  -> FAILED                    only under explicitly defined non-settleable failure semantics

STOP_PENDING
  -> ACTIVE                    stop command definitively rejected while physical session remains active
  -> RECONCILIATION_REQUIRED
  -> COMPLETED                 authoritative physical completion

RECONCILIATION_REQUIRED
  -> ACTIVE                    exact evidence proves still active
  -> STOP_PENDING              exact evidence proves stop still pending
  -> COMPLETED                 exact completed transaction passes full identity/meter/time validation

COMPLETED                     terminal immutable physical/commercial completion
FAILED                        terminal only when policy explicitly permits; raw evidence remains retained
```

ChargingStopRequest is a separate durable command/request record. A RemoteStop acknowledgement can advance stop-command progress but cannot set the ChargingSession to `COMPLETED`.

## A.8 HAL Start/Stop Command and Generic Charger Operation

HAL charging command:

```text
PERSISTED
  -> PENDING_DELIVERY
  -> EXPIRED

PENDING_DELIVERY
  -> PERSISTED                 startup recovery only while transmission is proven not attempted
  -> DELIVERY_ATTEMPTED

DELIVERY_ATTEMPTED
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> AMBIGUOUS
  -> MATERIALIZED              authoritative start correlation may race command-result bookkeeping

OCPP_ACCEPTED
  -> MATERIALIZED
  -> AMBIGUOUS                 only when later command-result bookkeeping becomes uncertain

OCPP_REJECTED
  -> MATERIALIZED              contradictory later physical start is reconciliation evidence, never silently discarded

AMBIGUOUS
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> MATERIALIZED
  -> EXPIRED                   only when exact evidence proves no physical materialization and contract permits terminalization

SUPERSEDED / EXPIRED / MATERIALIZED are non-dispatchable.
```

Generic administrative charger operations use the separate CMS dispatch states:

```text
PERSISTED
-> DISPATCH_CLAIMED
-> DELIVERY_ATTEMPTED
-> HAL_ACCEPTED | OCPP_CONFIRMED | RECONCILIATION_REQUIRED | CONFIRMED_ABSENT
```

A deadline or process restart MUST NOT make `DELIVERY_ATTEMPTED`, `HAL_ACCEPTED`, `AMBIGUOUS`, or `RECONCILIATION_REQUIRED` replayable. Exact-ID evidence resolves uncertainty.

## A.9 Payment

```text
CREATED
  -> PENDING
  -> FAILED
  -> CANCELLED

PENDING
  -> AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

CAPTURED
  -> REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED

REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED
  -> CAPTURED          refund attempt failed; captured payment remains

PARTIALLY_REFUNDED
  -> REFUND_PENDING
  -> REFUNDED

FAILED                terminal payment attempt
CANCELLED             terminal payment attempt
REFUNDED              terminal fully refunded state
```

Provider events may arrive out of order. Transition logic uses provider identity and reconciled facts, not arrival order alone.

## A.10 Refund

```text
REQUESTED
  -> SUBMITTED
  -> CANCELLED

SUBMITTED
  -> SUCCEEDED
  -> FAILED

SUCCEEDED             terminal
FAILED                terminal for this refund operation; a new reconciled retry uses controlled identity semantics
CANCELLED             terminal
```

## A.11 Invoice

```text
PENDING
  -> GENERATING
  -> VOIDED

GENERATING
  -> READY
  -> FAILED

FAILED
  -> GENERATING       explicit retry
  -> VOIDED

READY
  -> VOIDED           only if business/legal process permits; artifact remains historical

VOIDED                terminal
```

READY artifact bytes are immutable.

## A.12 PricingPolicy and CompensationPolicy

```text
DRAFT -> ACTIVE -> RETIRED
```

A RETIRED policy is not reactivated. Create/activate a new version instead.

## A.13 SupportTicket

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> OPEN | CLOSED
CLOSED -> OPEN
```

Same-state mutation is side-effect-free.

## A.14 Incident

```text
OPEN
  -> INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

MITIGATED
  -> INVESTIGATING
  -> RESOLVED
  -> CLOSED

RESOLVED
  -> CLOSED
  -> INVESTIGATING    explicit reopen with reason

CLOSED
  -> INVESTIGATING    explicit reopen with reason
```

Reopen events are auditable.

## A.15 AssetMismatchReport

```text
MISMATCH_REPORTED
  -> ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

CONFIRMED_CORRECTION -> RESOLVED
EXPECTED_RESTORED    -> RESOLVED
REASSIGNED           -> RESOLVED
REJECTED_REPORT      -> RESOLVED
RESOLVED             terminal
```

---

## A.16 EnergyStoreReservation (conditional when MOBILE_ENERGY_MODEL=REQUIRED)

Canonical states:

```text
ACTIVE
CONSUMED
RELEASED
EXPIRED
CANCELLED
```

Creation enters `ACTIVE` only inside the serialized allocation transaction described in Section 53.6.

Legal transitions:

```text
ACTIVE -> CONSUMED | RELEASED | EXPIRED | CANCELLED
```

Terminal states do not transition back to ACTIVE. Reassignment/retry creates a new reservation identity after terminalizing the old one. The reserved amount and owning energy-store/job identity are immutable after ACTIVE creation; corrections are release + new reservation, preserving history.

Duplicate release/expiry commands are idempotent and return the existing terminal result. `CONSUMED` means the reservation has been reconciled into the completed/accepted delivery accounting boundary defined by the implementation; it does not by itself prove a customer ChargingSession completed. HAL charging evidence remains authoritative for physical delivery.

# Appendix B. Mandatory Database Constraints and Indexes

Application validation improves errors. PostgreSQL constraints preserve truth under concurrency.

## B.1 Identity/session

- unique normalized login identifier according to chosen auth strategy;
- session token identifiers unique;
- revoked/expired session indexes for cleanup;
- admin role/capability foreign keys;
- no capability name duplicates.

## B.2 Customer

- `customer_profiles.account_id` unique;
- active saved vehicle belongs to exactly one customer;
- active saved address belongs to exactly one customer;
- partial unique index: at most one active default address per customer;
- registration number uniqueness is not globally assumed for incomplete/temporary customer metadata unless business verification requires it.

## B.3 Driver

- `driver_profiles.account_id` unique;
- one driver profile per source application unless explicit migration path says otherwise;
- only one nonterminal application per account if repeat applications are not supported;
- licence/document identifiers may have uniqueness checks where legally/business appropriate, with careful privacy handling.

## B.4 Fleet

- service vehicle registration number unique among non-retired canonical inventory;
- charger asset tag unique;
- charger serial number unique where manufacturer serial is trusted/required;
- HAL identity unique among active charger mappings;
- `(charger_id, connector_number)` unique;
- no overlapping active exclusive charger-to-vehicle pairing periods when physical exclusivity applies.

## B.5 Duty/claims

- partial unique: one nonterminal DutySession per driver;
- partial unique: one unreleased exclusive vehicle claim per vehicle;
- partial unique: one unreleased exclusive charger claim per charger;
- claim foreign key to active DutySession;
- one open break/unavailability interval of the same incompatible class if semantics require.

## B.6 Dispatch

- `dispatch_attempts(service_job_id, attempt_number)` unique;
- one candidate row per attempt + duty session;
- one offer identity unique;
- one live provisional offer per ServiceJob in the initial sequential strategy;
- one current accepted/active assignment enforced through serialized job update + partial unique current-assignment constraint;
- offer acceptance cannot reference a different driver/duty than the offer row.

## B.7 ServiceJob

- `job_number` unique;
- immutable ownership customer ID after creation unless a dedicated migration/correction framework explicitly exists;
- current assignment FK nullable but must point to same ServiceJob, enforced using composite unique/FK pattern where practical;
- event IDs unique;
- event transition data check constraints for required fields where practical.

## B.8 Charging

- ChargingStartIntent idempotency unique in actor/job/start-attempt scope;
- at most one unresolved start intent for the same ServiceJob + effective charger/connector when policy forbids parallel starts;
- one immutable `cms_command_id` per logical start or stop command;
- one durable `hal_command_id` maps to only its originating CMS command identity;
- one-use charging credential hash is unique and cannot be rebound to another start intent;
- HAL `fact_id` unique; same fact ID with different immutable digest/content is an integrity violation, never overwrite;
- accepted fact receipt and its CMS projection/event commit atomically;
- connection, connector, meter, and SoC projections advance only on their own monotonic sequences;
- one `hal_transaction_id` and one exact OCPP transaction ID chain cannot materialize multiple CMS ChargingSessions;
- one ChargingSession belongs to exactly one ServiceJob, while one ServiceJob may own multiple sequential ChargingSessions;
- meter observation dedupe uses immutable fact/sample identity and sequence, not timestamp alone;
- completed session final meter cannot regress below accepted start/latest eligible cumulative meter except the explicitly documented one-Wh quantization normalization rule if that rule is implemented;
- generic administrative charger-operation dispatch destination/parameters become immutable before possible delivery.

## B.9 Pricing

- policy version unique per policy lineage/name as modeled;
- no mutation of ACTIVE/RETIRED rule version through normal update API;
- no overlapping ACTIVE policy effective windows for the same global scope unless the engine explicitly supports scoped multiple policies;
- finalized line items immutable.

## B.10 Payments/refunds

- provider order ID unique when non-null;
- provider payment ID unique when non-null;
- provider webhook event ID unique;
- idempotency key unique in actor/operation scope;
- refund provider reference unique when non-null;
- database or transactional check prevents cumulative successful/pending refundable amount from exceeding captured amount.

## B.11 Invoice

- one active canonical invoice per ServiceJob/document type unless version/corrective-document semantics explicitly allow more;
- READY invoice has non-null storage ref, checksum, renderer version, issued timestamp;
- artifact metadata immutable after READY except delivery metadata.

## B.12 Compensation

- one finalized compensation snapshot per ServiceJob + assignment + calculation version;
- line item belongs to snapshot driver/job;
- finalized line items immutable;
- adjustments append only.

## B.13 Rating

- unique `(service_job_id, customer_id)`;
- rating check `1 <= rating <= 5`.

## B.14 Support

- channel/owner checks ensure CUSTOMER_PLATFORM requires customer owner and no driver owner;
- DRIVER_PLATFORM requires driver owner and no customer owner;
- message actor ownership is tied to ticket owner where applicable;
- reply idempotency key unique within ticket/actor scope.

## B.15 Mobile energy (conditional when REQUIRED)

- stable energy-store identity; active asset tags/serial identities unique where used;
- observation belongs to one energy store and uses immutable observation identity;
- accepted observation ordering cannot be regressed by an older received sample;
- at most one ACTIVE reservation per logical job + energy store allocation attempt unless explicit split-reservation semantics are introduced;
- ACTIVE reservation has positive reserved energy and cannot reference terminal/nonexistent job ownership;
- reservation state transition is explicit; terminal rows are not reactivated in place;
- allocation transaction serializes on the energy-store authority and proves available deliverable energy minus other active reservations minus safety reserve before commit;
- release/expiry is idempotent; historical reservation rows are retained;
- capability snapshot referenced by historical duty/job is immutable.

## B.16 Query indexes

Create indexes from actual query plans, but baseline indexes must support:

- jobs by status + updated/created time;
- jobs by customer/driver/current assignment;
- duty sessions by driver/status;
- active claims by asset;
- location projection by geospatial search strategy;
- schedules/occurrences by driver/time;
- offers by driver/status/expiry;
- payments by job/status/provider IDs;
- invoices by job/status;
- compensation by driver/date/job;
- support by owner/status/updated time;
- incidents by status/severity/job/asset;
- HAL facts by charger/time/transaction;
- HAL operations by charger/state/created time;
- when mobile energy is REQUIRED: observations by energy store/observed time and reservations by energy store/status/expiry/job.

Use PostGIS only if geospatial complexity/query scale justifies it. If adopted, make it an explicit project dependency and use proper geography indexes rather than handwritten distance SQL everywhere.

---

# Appendix C. Canonical Error Code Registry

HTTP status and machine error code are both part of the contract.

## C.1 Common

```text
400 INVALID_REQUEST
400 VALIDATION_FAILED
401 UNAUTHENTICATED
403 FORBIDDEN
404 RESOURCE_NOT_FOUND
409 VERSION_CONFLICT
409 IDEMPOTENCY_KEY_REUSED
409 STATE_CONFLICT
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE
```

Privacy-sensitive ownership failures SHOULD use `404 RESOURCE_NOT_FOUND` instead of revealing that another user's resource exists.

## C.2 Driver/duty

```text
409 DRIVER_NOT_ELIGIBLE
409 DRIVER_ALREADY_ON_DUTY
409 DUTY_NOT_ACTIVE
409 DUTY_HAS_ACTIVE_JOB
409 VEHICLE_ALREADY_CLAIMED
409 CHARGER_ALREADY_CLAIMED
409 ASSET_NOT_OPERATIONAL
409 ASSET_PAIRING_MISMATCH_BLOCKED
409 CHARGER_HAL_IDENTITY_UNKNOWN
409 DRIVER_LOCATION_STALE
```

## C.3 Dispatch/job

```text
409 OFFER_EXPIRED
409 OFFER_NO_LONGER_AVAILABLE
409 JOB_NOT_ASSIGNABLE
409 JOB_INVALID_TRANSITION
409 JOB_ALREADY_TERMINAL
409 JOB_HAS_ACTIVE_CHARGING
422 NO_ELIGIBLE_DRIVER
422 CUSTOMER_LOCATION_UNSERVICEABLE
422 CUSTOMER_VEHICLE_INCOMPATIBLE
```

`NO_ELIGIBLE_DRIVER` may be represented as job/dispatch state rather than direct request failure depending on operation.

## C.4 Charging/HAL

```text
409 CHARGING_ALREADY_ACTIVE
409 CHARGING_NOT_ACTIVE
409 CHARGING_START_IN_PROGRESS
409 RECONCILIATION_REQUIRED
409 HAL_COMMAND_IDEMPOTENCY_CONFLICT
409 HAL_FACT_INTEGRITY_VIOLATION
409 HAL_START_EVIDENCE_CONFLICT
409 CHARGING_STOP_IN_PROGRESS
410 CHARGING_START_EXPIRED
422 CHARGER_CAPABILITY_UNSUPPORTED
422 CONNECTOR_INCOMPATIBLE
503 HAL_UNAVAILABLE
503 CHARGER_MAPPING_UNAVAILABLE
```

## C.5 Payments/invoices

```text
409 PAYMENT_ALREADY_CAPTURED
409 PAYMENT_AMOUNT_MISMATCH
409 REFUND_EXCEEDS_REFUNDABLE_AMOUNT
409 REFUND_ALREADY_IN_PROGRESS
422 PAYMENT_VERIFICATION_FAILED
503 PAYMENT_PROVIDER_UNAVAILABLE
409 INVOICE_NOT_READY
409 INVOICE_ALREADY_READY
```

## C.6 Policies

```text
409 POLICY_VERSION_CONFLICT
409 POLICY_EFFECTIVE_RANGE_CONFLICT
409 ACTIVE_POLICY_IMMUTABLE
422 RULE_CONFIGURATION_INVALID
```

## C.7 Mobile energy (conditional)

```text
409 ENERGY_RESERVATION_CONFLICT
409 ENERGY_RESERVATION_ALREADY_TERMINAL
422 MOBILE_ENERGY_INSUFFICIENT
422 MOBILE_ENERGY_UNKNOWN
422 MOBILE_ENERGY_OBSERVATION_STALE
422 MOBILE_ENERGY_OBSERVATION_INVALID
503 MOBILE_ENERGY_TELEMETRY_UNAVAILABLE
```

`UNKNOWN`/`STALE` are not silently converted into `INSUFFICIENT`; operations needs to know whether capacity is truly low or merely unproven.

---

# Appendix D. Initial Operational Defaults and Knobs

These values are implementation defaults, not eternal business rules. They live in validated configuration or Admin policy and can be changed without changing semantics.

## D.1 API

```text
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100
DEFAULT_TIMEZONE=Asia/Kolkata
```

## D.2 Dispatch

Initial normal strategy:

```text
SEQUENTIAL
```

`DIRECT_ASSIGNMENT` is an explicit Admin action. `BATCHED` is not implemented initially.

No hard-coded offer timeout or scheduled dispatch lead time is mandated by architecture because those materially affect field operations. They MUST be explicit configuration before shared staging is enabled. Startup should reject an environment that enables dispatch without required timing values.

Required knobs:

```text
DISPATCH_OFFER_TTL_SECONDS
DISPATCH_RETRY_MIN_SECONDS
DISPATCH_RETRY_MAX_SECONDS
SCHEDULED_DISPATCH_LEAD_MINUTES
DISPATCH_MAX_LOCATION_AGE_SECONDS
ARRIVAL_VALIDATION_RADIUS_METERS
```

## D.3 Location

Client reporting cadence is a mobile-product/battery tradeoff, so the server defines freshness/maximum ingest rate, while Driver App chooses cadence within contract.

Server MUST reject abusive/implausible rates and accept batch recovery for offline periods.

## D.4 Mobile energy (conditional)

When `MOBILE_ENERGY_MODEL=REQUIRED`, shared staging/startup MUST have explicit validated values/policy for observation freshness and safety reserve. Architecture does not invent universal numbers because they depend on the actual hardware and operating policy. Missing required values fail readiness/config validation rather than silently disabling energy safety.

The reserve policy MAY be per energy-store capability/policy rather than one global value, but its effective value and provenance must be inspectable by Admin.

## D.5 Workers

Every worker has configurable:

```text
BATCH_SIZE
POLL_INTERVAL
LEASE_DURATION
MAX_ATTEMPTS or terminal policy
BACKOFF_MIN
BACKOFF_MAX
```

No worker may use an unbounded immediate retry loop.

## D.6 Realtime

Required knobs:

```text
MAX_CONNECTIONS_PER_ACCOUNT
HEARTBEAT_INTERVAL
CLIENT_IDLE_TIMEOUT
MAX_OUTBOUND_QUEUE_PER_CONNECTION
```

Backpressure disconnects a slow client rather than consuming unbounded memory. Client recovers with REST.

---

# Appendix E. Operational Recovery Playbooks

These are behavioral playbooks. Exact shell commands belong in environment-specific operations docs.

## E.1 Driver app loses connectivity while en route

1. Server keeps assignment/job authoritative.
2. Location becomes stale after configured threshold.
3. Admin sees stale-location warning.
4. Driver app reconnects and fetches current duty/job via REST.
5. Buffered valid location samples may upload in batch.
6. No assignment is automatically cancelled solely because one realtime socket dropped.
7. Escalation/reassignment follows dispatch operations policy if staleness exceeds business threshold.

## E.2 Driver app loses connectivity during charging

1. HAL continues owning physical charger truth independently of Driver App.
2. CMS continues ingesting HAL facts.
3. User/Admin can still see charging projection if CMS/HAL links remain healthy.
4. Reconnected Driver App fetches job/charging state.
5. Never infer stop/start from Driver App reconnect state.

## E.3 CMS temporarily unavailable during active charging

1. HAL persists operation/transaction/facts locally.
2. Charger session continues according to physical/protocol reality.
3. HAL fact outbox retries delivery.
4. CMS restart recovers database state.
5. HAL delivers missed facts idempotently.
6. CMS reconciles transaction links/projections.
7. No new physical command is replayed unless operation identity proves it safe.

## E.4 HAL restarts during active charging

1. HAL reconnect supervisor restores charger connection.
2. Protocol adapter reconciles active transaction state.
3. Existing stable HAL transaction is recovered or a reconciliation record explains identity change where protocol makes exact restoration impossible.
4. CMS receives no duplicate semantic start if same transaction is proven.
5. Raw evidence links restart/reconnect chain.

## E.5 Start command times out

1. CMS marks the existing ChargingStartIntent/command `RECONCILIATION_REQUIRED` when RequestStart may have crossed the boundary.
2. Keep the original `cms_command_id`, hold/reservation, start intent, one-use credential binding, and immutable destination evidence. Do not create a replacement start automatically.
3. Reconcile `GET /v1/remote-commands?cms_command_id={uuid}` by the exact original command identity.
4. If HAL returns the exact command, project that command state and continue waiting/reconciling for authoritative transaction evidence.
5. If HAL returns canonical `404` for that exact durable command and CMS proves no materialized session exists, atomically release only the still-reserved commercial hold/reservation and terminalize the intent `REJECTED` or `EXPIRED` according to its window.
6. For an accepted/unmaterialized start past the reconcile threshold, query `GET /v1/transactions?cms_start_intent_id={uuid}`. A matching transaction uses the same locked materializer as a normal `transaction.started` fact.
7. Any non-404 lookup failure or conflicting/malformed evidence keeps reconciliation state; it never becomes absence by timeout.
8. Late physical-start evidence after `REJECTED`/`EXPIRED` is retained and moves the attempt into reconciliation rather than silently fabricating a normal session.
9. If unresolved beyond the operational horizon, alert Technical Admin while continuing safe exact-ID recovery according to retention policy.

## E.6 Payment API response lost after capture

1. Keep logical payment identity/provider order.
2. Do not create a second charge automatically.
3. Reconcile provider state by provider identity/webhook/API.
4. Mark CAPTURED idempotently if proven.
5. User client retry returns same logical payment result.

## E.7 Invoice generation fails

1. Payment/job truth remains untouched.
2. Invoice stays FAILED/PENDING with error classification.
3. Worker retries retryable renderer/storage errors.
4. Admin sees failure and may explicitly retry.
5. READY is never set without verified artifact metadata/checksum.

## E.8 No drivers available

1. DispatchAttempt becomes EXHAUSTED.
2. Job remains truthfully unassigned/dispatching subject to policy.
3. User receives availability/delay state.
4. Retry worker reevaluates fresh candidates, not stale ranking.
5. Admin sees reason/age.
6. Job expires only under explicit policy/deadline.

## E.9 Assigned driver breaks down

1. Driver reports problem/incident.
2. Current assignment ends with reason.
3. Duty becomes UNAVAILABLE or ends depending reality.
4. Job enters REASSIGNING.
5. New dispatch attempt selects another eligible duty.
6. Historical assignment remains.
7. Compensation uses facts attributable to each assignment.

## E.10 Customer location changes after assignment

1. User cannot silently overwrite ServiceJob service-address snapshot.
2. Submit relocation/change request.
3. Backend assesses serviceability, price impact, and current assignment feasibility.
4. If accepted, create an explicit address-change event/new operational snapshot version while preserving original request snapshot.
5. Requote/reassign if required.
6. If not supported initially, customer must cancel and create a new request; API says so explicitly.

The initial implementation SHOULD choose one of these semantics before enabling mid-job relocation. Do not silently mutate coordinates.

## E.11 Mobile energy becomes stale/unknown after assignment (conditional)

1. Preserve the accepted assignment/reservation history; do not rewrite the earlier eligibility decision.
2. Mark the current energy evidence stale/unknown with provenance and age.
3. Before charging begins, re-evaluate the configured safety policy using any newer trustworthy observation.
4. If safe deliverability cannot be proven under policy, block charging start or require the explicitly authorized operational override path; do not fabricate capacity.
5. If the unit is already physically charging, HAL physical truth continues to be processed. Do not issue a blind emergency stop solely because CMS telemetry became stale unless the hardware/safety policy explicitly requires it.
6. Alert Driver/Admin according to severity, preserve incident/audit evidence, and reconcile reservation against eventual actual delivery.
7. Reassignment/recovery creates/releases reservations transactionally so capacity is not double-booked.

---

# Appendix F. Acceptance Evidence Matrix

A claim of completion should name evidence level.

| Claim | Minimum evidence |
| --- | --- |
| Domain implemented | source + unit tests |
| DB invariant enforced | disposable PostgreSQL integration test |
| API contract implemented | OpenAPI/runtime parity + auth tests |
| Worker reliable | retry/lease/integration tests + runtime backlog metrics |
| CMS-HAL command flow works | service integration test |
| OCPP adapter works logically | scripted simulator acceptance |
| Mobile-energy reservation invariant works (when REQUIRED) | disposable PostgreSQL concurrency tests + normalized observation fixtures |
| Mobile-energy telemetry works with target hardware (when REQUIRED) | source-adapter/service acceptance at claimed boundary; physical telemetry acceptance before production energy-aware dispatch |
| Charger model works physically | real hardware acceptance |
| Payment flow works | provider test/live acceptance at claimed boundary |
| Refund works | provider acceptance |
| Invoice generation works | generated artifact checksum + authorized download |
| Email/push works | provider accepted delivery request; do not claim recipient read |
| Deployment works | target runtime health + changed-feature smoke + logs |
| Rollback works | exercised compatible rollback/recovery path |
| Production ready | project-level Definition of Done plus all critical external boundaries accepted |

---

# Appendix G. Blueprint Change Control

Once implementation starts, this blueprint itself follows change discipline.

A semantic change must identify:

1. reason/new evidence;
2. affected actors;
3. affected state machines;
4. persistence/migration impact;
5. API/OpenAPI impact;
6. worker/realtime impact;
7. security/privacy impact;
8. historical compatibility;
9. rollout/rollback plan;
10. affected tests/docs;
11. whether existing mobile/frontends remain compatible.

Do not update only this document while leaving runtime semantics unchanged, and do not change runtime semantics without updating the authoritative contract set.

---

# Appendix H. Exact Burner Execution Claim Map

This appendix removes ambiguity from the short burner titles in Section 64. It is normative because it is part of the canonical blueprint. Every burner still requires a repository work item using Section 63 before code changes begin.

For every burner, the work item MUST explicitly list: objective; claimed surfaces; dependencies; canonical sections; schema/migration impact; API/contract impact; authorization; idempotency/concurrency; worker/realtime impact; failure/recovery; audit/observability; tests; documentation; operational impact; evidence target; non-goals; rollback/forward-fix considerations; and current unverified boundary.

A burner is not allowed to invent a competing semantic model because its title is short. The sections named below, the state-machine registry, DB constraints, error registry, operational defaults, recovery playbooks, and acceptance matrix are the source of detail.

## H.00 Program 0 - Repository and engineering authority

Program dependency baseline: none beyond the package and chosen development infrastructure. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B00.1 CMS repository bootstrap

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B00.2 HAL repository bootstrap

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B00.3 Disposable integration DB harness

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.01 Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

Program dependency baseline: Program 0 CMS foundation. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B01.1 Account/session authentication

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.2 Admin capability engine

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.3 Audit foundation

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.4 Durable idempotency primitive

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.5 Durable outbox and worker framework

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.02 Program 2 - Customer master data

Program dependency baseline: Program 1 account/auth/idempotency/audit primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B02.1 Customer profile

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.2 Saved vehicles

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.3 Saved addresses/default handling

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.4 Snapshot schemas/builders

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.5 Temporary object and promotion behavior

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.03 Program 3 - Driver recruitment and workforce

Program dependency baseline: Program 1 account/auth/audit primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B03.1 Driver application lifecycle

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.2 Secure document storage + versioned KYC review

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Do not choose a production KYC retention/storage policy before Section 69.5 is resolved; keep storage interface and encryption/access contract explicit.

### H.B03.3 Driver profile creation/onboarding

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.4 Eligibility engine + blocking reasons

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.5 Suspension/reinstatement/offboarding

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.04 Program 4 - Fleet and inventory

Program dependency baseline: Program 1 authorization/audit primitives; charger identity created here is later shared with HAL. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B04.1 Vehicle inventory/history

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.2 Charger inventory/connectors

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.3 Pairing history

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.4 Maintenance/lifecycle intervals

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.5 Admin asset assignment

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.6 Derived availability projection

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.7 Mobile energy-store registry/capability foundation (conditional)

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Conditional gate: follow Section 53 exactly; skipping requires a recorded NOT_APPLICABLE decision.

## H.05 Program 5 - Scheduling, duty, location

Program dependency baseline: Programs 3-4 workforce/fleet truth plus Program 1 primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B05.1 Schedules and materialized occurrences

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.2 DutySession lifecycle

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.3 Exclusive asset claim constraints/concurrency tests

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.4 Driver asset mismatch reporting

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.5 Break/availability intervals

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.6 Location ingestion/current projection/freshness

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.7 Driver geofence and effective area

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.8 Mobile energy observation/reservation foundation (conditional)

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Conditional gate: follow Section 53 exactly; skipping requires a recorded NOT_APPLICABLE decision.

## H.06 Program 6 - Service request, pricing foundation, ServiceJob core

Program dependency baseline: Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B06.1 ServiceRequest

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.2 Serviceability validation

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.3 First production slice of the final pricing interface

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B06.4 Quote acceptance -> ServiceJob snapshots

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B06.5 ServiceJob state machine/event history

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.6 Cancellation/no-show reason framework

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.07 Program 7 - Dispatch

Program dependency baseline: Programs 5-6. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B07.1 Eligibility engine

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.2 Ranking engine

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.3 DispatchAttempt/Candidate persistence

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.4 Sequential offer workflow

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.5 Atomic offer acceptance

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.6 Assignment and Driver current-job contract

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.7 Reassignment

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.8 No-candidate retry/scheduled dispatch worker

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.9 Admin diagnostics/direct assignment

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.08 Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

Program dependency baseline: HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B08.1 HAL repository/bootstrap contract

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.2 CMS-HAL service authentication

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.3 Charger/connector mapping registry

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.4 Connection runtime and restart fencing

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.5 Connector status runtime

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.6 Durable HAL command store and start/stop lifecycle

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.7 One-use charging credential and OCPP authorization bridge

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.8 OCPP 1.6 transaction materialization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.9 MeterValues normalization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.10 Independent SoC normalization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.11 Stop workflow and automatic limit sources

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.12 Transaction completion truth

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.13 Durable fact outbox

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.14 CMS fact ingress and projection transaction

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.15 Exact command and transaction reconciliation APIs

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.16 Generic administrative charger operation boundary

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.17 Isolated charger-operation recovery worker

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.18 Diagnostic trace plane

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.19 Scriptable simulator

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.20 Cross-repository contract fixtures

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

## H.09 Program 9 - CMS charging integration and app projections

Program dependency baseline: Programs 6-8 and assignment/job identity from Program 7. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B09.1 Charging admission model

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.2 ChargingStartIntent state machine

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.3 Immutable CMS START command record

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.4 Start orchestration and post-commit mapping reconfirmation

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.5 Start ambiguity reconciler

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.6 `transaction.started` -> ChargingSession materialization

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.7 Meter/SoC CMS projection

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.8 Charging stop request

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.9 `transaction.completed` finalization

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.10 Missing-completion recovery

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.11 Multiple ChargingSessions per ServiceJob

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.12 Runtime availability and chargeability

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.13 User charging read/progress contract

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.14 Driver charging contract

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.15 Admin technical charging views

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.16 User live-job snapshot/SSE integration

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.17 End-to-end charging acceptance

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

## H.10 Program 10 - Full pricing engine

Program dependency baseline: B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B10.1 Versioned pricing policy/rule persistence

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.2 Deterministic rule evaluator

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.3 Quote estimation line items

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.4 Final source-fact binding

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.5 Final pricing line items/snapshot

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.6 Cancellation/no-show components

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.7 Time/date/zone modifiers

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.8 Admin policy editor contract

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.11 Program 11 - Payments, refunds, tax, invoices

Program dependency baseline: Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B11.1 Razorpay order/payment integration

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.2 webhook/idempotent reconciliation

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.3 refund workflow

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.4 GST snapshot calculation

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.5 invoice renderer/storage/version/checksum

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.6 invoice worker/retry/download

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.7 mail/notification intent for invoice

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

## H.12 Program 12 - Driver compensation

Program dependency baseline: Programs 5, 7, 9 and the relevant finalized source facts. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B12.1 Versioned policy/rules

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.2 deterministic evaluator

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.3 time-boundary/interval prorating

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.4 source-fact binding

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.5 line-item ledger

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.6 reassignment allocation

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.7 adjustments

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.8 Driver summary/history

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.9 Admin views/exports

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.13 Program 13 - Product completeness

Program dependency baseline: the domain feature being completed plus Program 1 primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B13.1 User ratings/reviews

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.2 Customer support

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.3 Driver support

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.4 Incident management

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.5 Notification preferences/delivery

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.6 Admin operational dashboard

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.7 Async exports

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.8 retention/cleanup jobs

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.14 Program 14 - Realtime hardening

Program dependency baseline: durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B14.1 authenticated subscriptions

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.2 per-resource versioning

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.3 reconnect/catch-up guidance

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.4 user projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.5 driver projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.6 admin projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.7 backpressure/disconnect behavior

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.8 realtime-vs-REST consistency E2E tests

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

## H.15 Program 15 - Production hardening

Program dependency baseline: all production-targeted programs relevant to the acceptance claim. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B15.1 security review

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.2 DB backup/restore drill

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.3 worker/backlog alerting

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.4 load tests for location/realtime/dispatch

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.5 Razorpay production-readiness checks

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.6 mail/push production acceptance

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.7 physical charger certification matrix

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.8 operational runbooks/on-call drills

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.9 staging full-day/long-session soak

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.10 release/rollback drill

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

## H.16 Program 16 - Protocol expansion

Program dependency baseline: Program 8 normalized HAL core and stable contract fixtures. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B16.1 OCPP 2.0.1 adapter

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.2 adapter parity matrix

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.3 OCPP 2.1 if hardware/business requires

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.4 vendor-specific extensions behind adapter capability interfaces

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.


# Appendix I. Normative Package Annex Registry

The following files are incorporated into the pre-implementation normative package set. Each owns only its declared scope; cross-domain ownership and fundamental invariants remain governed by this core blueprint.

```text
10 Realtime SSE and notifications
11 HTTP API/auth/payload standard
12 Persistence schema/data dictionary
13 State authorization/transition registry
14 Workers/schedulers/idempotency/recovery
15 Security/privacy/rate-limit/abuse model
16 Observability/SLO/alerting/runbook contract
17 Configuration/secrets/environment catalog
18 Test/fixture/simulator/acceptance specification
19 Deployment/backup/restore/release runbook
20 Frontend projection/integration contracts
21 Provider adapter/external dependency contracts
22 Repository bootstrap/coding/migration standard
23 Domain glossary/naming/enum registry
24 API endpoint/payload catalog
25 Durable event/outbox registry
26 Notification template/trigger registry
27 Business decision gates/policy register
28 Reference sequences/failure scenarios
29 Project execution playbook
30 Operations/Admin/support playbook
31 Data retention/export/privacy lifecycle
32 Physical hardware certification/protocol matrix
33 Package change-control/traceability
34 CMS-HAL wire contract/reconciliation
35 Dispatch/location/geofence/ETA contract
36 Pricing/tax/payment/refund/invoice contract
37 Driver compensation engine contract
38 Ratings/support/incident contract
39 Driver workforce/fleet/duty contract
40 Customer/service-request/ServiceJob contract
41 Audit/provenance/correction/manual-action contract
42 Transaction locking/concurrency/isolation contract
43 Time/timezone/calendar/precision/identifier contract
44 Admin capability/role/authorization catalog
45 Query/filter/sort/search/export contract
46 Sole-source coverage/traceability matrix
```

Machine restatements live under `registries/` and `schemas/`. `tools/verify_package.py` is the mandatory pre-handoff integrity/consistency gate.
