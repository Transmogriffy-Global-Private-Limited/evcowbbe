> PACKAGE STATUS: NON-NORMATIVE FOCUSED VIEW. `01_CANONICAL_FULL_BLUEPRINT.md` is the only design authority in this ZIP. This file exists for lower-context reading and provenance; it MUST NOT introduce a requirement that is absent from the canonical blueprint. If wording differs, canonical wins.

# Charger on Wheels - Data, Reliability, Verification, Deployment, and Exact Implementation Program

This is the execution/operations slice of the canonical blueprint. It defines cross-cutting idempotency, concurrency, durable events/outboxes, workers, failure classification, security, audit, observability, retention, schema/migration discipline, configuration, OpenAPI discipline, tests, verification gates, CI, deployment, backup/recovery, documentation/work-item discipline, and the exact burner-by-burner implementation program.

Use this file when sequencing or verifying implementation. It is not a replacement for the domain contracts in the other files; the canonical full blueprint composes all of them.

---

# 0. How to Use This Document

This is not a pitch, product brochure, architecture sketch, or backlog dump. It is the intended engineering authority for taking Charger on Wheels from an agreed plan to an implementable system.

A team should be able to use this document to answer, before writing code:

- What each actor is allowed to do.
- Which service owns each truth.
- Which records are mutable master data and which records are immutable history.
- Which state machines exist and what transitions are legal.
- Which database records must exist.
- Which invariants must be enforced by PostgreSQL rather than only by application code.
- Which API surfaces must exist for User, Driver, Admin, and HAL integration.
- Which mutations require idempotency.
- What happens when networks, workers, payments, chargers, drivers, or APIs fail halfway through an operation.
- Which side effects are durable and replayable.
- What clients may infer from realtime events and what they must recover through REST.
- How pricing and compensation are calculated and frozen.
- How a ServiceJob relates to dispatch, charging transactions, payment, invoice, compensation, rating, support, and incidents.
- How to deploy, verify, roll back, recover, and prove a change is complete.
- In what order the project should actually be built.

## 0.1 Authority order

When implementation evidence conflicts, use this authority order:

1. Current repository source and migrations for already-implemented behavior.
2. Current machine-readable contract, especially OpenAPI and CMS-HAL schemas.
3. Current runtime/database evidence.
4. This blueprint.
5. Older planning documents and chat history.

Before implementation begins, this blueprint is the primary semantic authority. After implementation exists, changes to semantics must update source, database constraints, OpenAPI, human contracts, tests, and this blueprint together.

## 0.2 Language convention

Normative terms:

- **MUST / MUST NOT**: correctness or product invariant.
- **SHOULD / SHOULD NOT**: strong engineering default; deviation requires a documented reason.
- **MAY**: supported optional behavior or policy knob.
- **Derived**: computed from other authoritative state and not itself the durable authority.
- **Snapshot**: immutable historical representation captured at a boundary in time.
- **Fact**: observed or accepted durable evidence, not UI intent.

## 0.3 Core completion rule

A feature is complete only when the domain semantics, persistence, constraints, API contract, authorization, idempotency, failure behavior, recovery, observability, tests, documentation, consumer guidance, and runtime evidence agree.

Compilation is not completion. A 200 response is not physical charger proof. Outbox insertion is not mail delivery. Payment intent creation is not payment settlement. Command acceptance is not charging start.

---

# 2. Explicit Non-Goals

The current system MUST NOT implement the following unless scope is explicitly changed:

- CPO tenancy.
- SuperAdmin/CPO product separation.
- Customer charging-network roaming.
- Selling this backend as a generic multi-tenant CPO CMS.
- Driver payout execution through Razorpay Route or equivalent.
- Driver linked-account onboarding for payouts.
- Automated external wage/payout transfer retries.
- Treating calculated driver compensation as paid money.
- Route/seat/stop semantics from the corporate shuttle product where they do not apply.
- Protocol-specific OCPP request names in CMS business APIs.
- A shared database between CMS and HAL.

The absence of payout execution does not prevent compensation calculation, ledgers, adjustments, summaries, exports, or later accounting integration.

---

# 3. Architectural Laws and Invariants

These rules are global and must hold across every module.

## 3.1 Separate different kinds of truth

The system MUST preserve these as distinct concepts:

- Administrative/intended state.
- Observed real-world operational state.
- Physical charger/protocol truth.
- Historical snapshot state.
- Customer commercial truth.
- Driver compensation truth.
- Derived/realtime projections.

No convenience field may silently collapse them.

Examples:

- Admin pairing says Vehicle V1 carries Charger C1.
- Driver reports Vehicle V1 actually carries Charger C2.
- Current duty may proceed with observed C2 if policy permits.
- Admin sees a mismatch requiring reconciliation.
- Master pairing remains unchanged until deliberately corrected.
- Historical duty remains permanently tied to the actual observed combination used.

## 3.2 History does not mutate because master data changes

Every historical ServiceJob MUST preserve its own vehicle, service-address, pricing, tax, assignment, and relevant identity snapshots.

Every DriverDutySession MUST preserve its actual vehicle/charger context.

Every finalized compensation result MUST preserve the policy/rule versions and source facts used.

Every invoice MUST preserve the commercial facts used to create it.

Editing a CustomerVehicle, CustomerAddress, ServiceVehicle, Charger, pricing policy, compensation policy, driver profile, or admin assignment later MUST NOT rewrite historical records.

## 3.3 Physical charging truth comes from HAL facts

UI intent, CMS command dispatch, socket write success, or charger command acceptance MUST NOT be represented as a physical charging start.

Physical charging start requires normalized HAL transaction evidence.

Energy delivered requires normalized meter evidence.

Physical charging end requires normalized HAL transaction-end evidence or an explicit reconciled equivalent.

## 3.4 Service lifecycle and charging lifecycle are independent

A ServiceJob may be ARRIVED or SERVICE_PREPARING before physical charging starts.

A physical transaction may end while the ServiceJob remains in WRAP_UP.

A charger fault may end one ChargingSession while the same ServiceJob later starts another ChargingSession.

## 3.5 Customer price and driver compensation are separate engines

They may consume overlapping facts, but they MUST have independent policies, snapshots, ledgers, correction semantics, and administrative permissions.

Customer price changes MUST NOT implicitly change driver compensation.

Driver compensation changes MUST NOT change customer invoices.

## 3.6 External mutations are idempotent or reconcilable

Any mutation that can be retried across network boundaries MUST have one of:

- durable idempotency key semantics;
- a stable operation identity plus exact reconciliation;
- a provider-native idempotency mapping stored durably.

In-memory dedupe is never sufficient for externally retried business mutations.

## 3.7 Realtime is advisory, durable state is recoverable

Realtime messages tell clients that state changed and MAY carry a safe projection.

The client MUST be able to recover authoritative current state using HTTP APIs after disconnect/reconnect.

No critical state transition exists only in WebSocket memory.

## 3.8 Feature completeness remains invariant under extension

Adding a new adapter, vehicle type, charger protocol, pricing component, compensation component, user role, or realtime consumer MUST NOT degrade already-supported correctness properties.

Existing paths retain authorization, idempotency, auditability, verification, and documentation guarantees after extension.

## 3.9 Every actor is a real user

Customer, driver, dispatcher, recruiter, finance operator, support operator, technical/HAL operator, read-only observer, automated worker, CMS, HAL, and external payment provider are all first-class actors with explicit contracts and failure modes.

---

# 4. Chosen Technical Shape

## 4.1 CMS/backend

The initial Charger-on-Wheels CMS SHOULD be a modular monolith because the domains are strongly transactional and still one product boundary.

Chosen baseline:

- Go 1.25.
- Gin HTTP stack.
- PostgreSQL as durable truth.
- Versioned SQL migrations.
- OpenAPI 3.x as machine contract.
- Structured JSON logging.
- Durable database outbox workers for externally visible side effects.
- WebSocket or SSE realtime fanout built from durable/authoritative state changes, not as a source of truth.

The implementation MUST keep package boundaries strong enough that later extraction remains possible without changing domain semantics.

## 4.2 HAL

HAL is a separate Go service/repository/process with its own persistence and deployment lifecycle.

It MUST be protocol-neutral in the core and adapter-driven at the edges.

The first physical-protocol adapter is OCPP 1.6 unless hardware requirements force another initial protocol.

OCPP 2.0.1, OCPP 2.1, vendor adapters, and simulator adapters are additive extensions of the same normalized core.

## 4.3 Databases

CMS and HAL MUST use separate PostgreSQL databases and MUST NOT share tables or database credentials.

Cross-service communication uses authenticated HTTP and/or durable callback/fact delivery contracts.

## 4.4 Recommended repositories

Logical repository identities:

- `charger-on-wheels-backend`
- `charger-on-wheels-hal`

The exact Git organization/remote may be chosen during bootstrap. Once created, repository identity becomes part of the deployment contract and must be documented.

---

# 5. System Context and Deployment Topology

## 5.1 Logical topology

```text
User App -----------\
Driver App ----------> Charger-on-Wheels CMS/API -----> PostgreSQL (CMS)
Admin App -----------/          |   |   |
                               |   |   +--> Mail/notification providers
                               |   +------> Razorpay customer payments
                               +----------> Dedicated HAL API
                                              |
                                              +--> PostgreSQL (HAL)
                                              +--> charger WebSocket/OCPP/proprietary links
```

## 5.2 Trust boundaries

- User/Driver/Admin clients are untrusted network clients.
- CMS auth context is authoritative for human identity.
- CMS MUST NOT trust arbitrary client-supplied actor IDs, driver IDs, or admin capability claims.
- HAL is a trusted service only after service-to-service authentication succeeds.
- Charger-provided data is physical evidence but still untrusted input and must be validated/normalized.
- Razorpay/webhook payloads are trusted only after signature verification and replay/idempotency handling.

## 5.3 Environment tiers

At minimum:

- local development;
- shared development/integration;
- staging/pre-production;
- production.

Development and staging MUST use separate databases and separate HAL identities from production.

No production database may be used as an automated test database.

---

# 6. Repository and Module Ownership

Recommended CMS package layout:

```text
cmd/
  api/
  migrate/
  worker/                 # optional split entrypoint later

internal/
  platform/
    config/
    db/
    httpx/
    authn/
    authz/
    idempotency/
    outbox/
    audit/
    observability/
    realtime/

  users/
  customerprofiles/
  customervehicles/
  customeraddresses/

  driverrecruitment/
  drivers/
  schedules/
  duty/
  availability/

  fleet/
  vehicles/
  chargers/
  connectors/
  pairings/
  assignments/
  maintenance/

  dispatch/
  servicejobs/
  locations/

  charging/
  halclient/
  halfacts/

  pricing/
  payments/
  refunds/
  invoices/
  tax/

  compensation/

  ratings/
  support/
  incidents/
  notifications/

  admin/
```

The package names can be refined during bootstrap, but ownership MUST remain domain-oriented rather than one giant handlers/services/models structure.

Recommended HAL layout:

```text
cmd/
  hal/
  simulator/
  migrate/

internal/
  core/
    charger/
    connection/
    capability/
    transaction/
    command/
    metering/
    state/
    faults/
    operations/
    recovery/
    reconciliation/
    facts/
    trace/

  protocols/
    ocpp16/
    ocpp201/
    ocpp21/

  vendors/
  simulator/
  cmsclient/
  platform/
```

---

# 8. Universal HTTP/API Contract

## 8.1 Versioning

Initial public API prefix:

```text
/api/v1
```

Internal CMS-only service API prefix:

```text
/internal/v1
```

The separately hosted HAL is its own service and deliberately uses its own service-major root:

```text
/v1
```

Therefore `HAL_ORIGIN + /v1/...` is not a public CMS route and does not conflict with CMS `/internal/v1/...`. Browser/mobile clients never receive the HAL origin or service credentials.

Breaking contract changes require a new version or a backwards-compatible migration strategy.

## 8.2 Envelope

Success responses SHOULD use the resource directly unless pagination/metadata requires an envelope.

Errors use one canonical shape:

```json
{
  "error": {
    "code": "JOB_INVALID_TRANSITION",
    "message": "The job cannot move from ARRIVED to COMPLETED.",
    "request_id": "...",
    "details": {}
  }
}
```

`message` is safe for the client. Internal stack traces, SQL text, secrets, and provider payloads MUST NOT be returned.

## 8.3 Pagination

Use keyset pagination for growing operational/history collections.

Default page size: 20. Maximum: 100 unless an endpoint explicitly documents otherwise.

Ordering must be deterministic, typically:

```text
created_at DESC, id DESC
```

Cursor fields must encode every sort key required to avoid duplicates/skips.

## 8.4 Filtering and sorting

Filtering happens in SQL before LIMIT.

Every list endpoint documents:

- allowed filters;
- allowed sort keys;
- default sort;
- null ordering where relevant;
- full-text/search fields if `q` is accepted.

## 8.5 Idempotency header

Business-create and side-effecting retryable endpoints use:

```text
Idempotency-Key: <client-generated opaque key>
```

Scope is at least authenticated principal + HTTP operation + idempotency key.

Same key + semantically same request returns the same committed result.

Same key + conflicting request returns `409 IDEMPOTENCY_KEY_REUSED`.

## 8.6 Optimistic concurrency

Admin edits of mutable configuration SHOULD use either:

- `version` integer checked in the mutation; or
- strong ETag/If-Match.

Conflicts return 409 rather than silently overwriting a newer edit.

---

# 9. Global Persistence Conventions

## 9.1 IDs

Use UUID primary keys generated server-side, preferably UUIDv7 where implementation support is stable.

Provider IDs, charger protocol IDs, registration numbers, and human-readable job numbers are alternate identifiers, not primary keys.

## 9.2 Time

- Store all event timestamps as timezone-aware PostgreSQL `timestamptz` in UTC.
- Store an explicit IANA timezone on policies where local time affects behavior.
- Default business timezone for India deployment: `Asia/Kolkata`.
- Never compute compensation/time-window rules using server-local implicit timezone.

## 9.3 Money

Store monetary minor units as integers plus ISO currency code.

For INR:

```text
amount_minor = paise
currency = INR
```

Do not use binary floating point for money.

## 9.4 Energy and measurements

Choose canonical internal units and document them:

- energy: Wh integer where possible;
- power: W integer where possible;
- distance: meters integer;
- duration: milliseconds or seconds integer;
- latitude/longitude: decimal numeric precision sufficient for location;
- percentage/SoC: numeric/decimal with explicit range.

API may expose convenient derived units, but durable facts remain canonical.

## 9.5 Soft deletion

Use soft deactivation for identities/assets/configuration that must remain referentially visible to history.

Do not physically delete a driver, vehicle, charger, pricing policy, compensation policy, or saved customer object while history references it unless an explicit anonymization/retention process exists.

## 9.6 Audit columns

Mutable administrative/master tables SHOULD include:

```text
created_at
created_by
updated_at
updated_by
version
```

Historical event tables normally append new rows instead of updating semantic history.

---

# 34. API Consumer Contracts and Projection Rules

## 34.1 User projection

User job projection may expose:

- job number/status;
- service location snapshot;
- own vehicle snapshot;
- public driver identity subset after assignment;
- public service vehicle identity subset;
- ETA/location only while operationally relevant;
- charging metrics;
- pricing/payment/invoice state;
- own support/rating.

It MUST NOT expose:

- driver KYC;
- driver phone/email unless explicitly required by product policy;
- Admin identities;
- internal dispatch scores;
- raw HAL traces;
- internal incident notes;
- internal compensation.

## 34.2 Driver projection

Driver may see only data necessary for current/own work:

- assigned customer display/contact information required for service;
- exact service location/instructions;
- customer vehicle snapshot;
- charging preference;
- job/payment information only to the extent operationally required;
- own compensation.

Driver MUST NOT see full customer account/security history.

## 34.3 Admin projection

Admin receives data by capability and need, not one giant universal object.

High-sensitivity KYC, payment, raw trace, and audit data should have separately authorized endpoints/fields.

---

# 35. Idempotency Matrix

At minimum, these operations require durable idempotency or stable operation identity:

| Operation | Mechanism |
| --- | --- |
| Quote acceptance / ServiceJob creation | `Idempotency-Key` |
| Driver duty start | `Idempotency-Key` + unique active-duty constraint |
| Driver offer accept | offer identity + transactional winner |
| Driver job transition actions | action idempotency / current-state same-result semantics |
| Charging start | `Idempotency-Key` -> `ChargingStartIntent` -> immutable `cms_command_id` -> one HAL start command |
| Charging stop | `Idempotency-Key` -> `ChargingStopRequest` -> immutable `cms_command_id` -> one HAL stop command; completion still requires physical completion evidence |
| Payment order creation | `Idempotency-Key` + provider order identity |
| Payment verification/webhook | provider event/payment identity |
| Refund | `Idempotency-Key` + provider refund identity |
| Invoice generation intent | unique invoice/job/version key |
| Support reply | `Idempotency-Key` |
| Notification/outbox delivery | outbox row/event identity |
| HAL fact ingest | immutable `fact_id` |
| HAL start/stop command | immutable `cms_command_id` plus durable `hal_command_id`; retry/reconcile same identity |
| Generic administrative HAL operation | immutable `cms_operation_id` plus durable HAL operation identity; no automatic replay after possible delivery |
| Promotion of temp vehicle/address | `Idempotency-Key` / unique promotion record |
| Compensation finalization | unique job/assignment calculation version |
| Compensation adjustment | `Idempotency-Key` |

Idempotency records MUST have a retention policy long enough to cover realistic mobile retry behavior and external provider retries.

---

# 36. Concurrency and Transaction Boundaries

## 36.1 Database as concurrency authority

Use PostgreSQL constraints/locking for invariants that must survive multiple API instances.

Do not rely on process mutexes for cross-instance business invariants.

## 36.2 Required protected races

Must explicitly handle:

- two duty starts for same driver;
- two drivers claiming same vehicle;
- two drivers claiming same charger;
- two offer acceptances;
- driver accepts offer while Admin reassigns/cancels;
- customer cancels while driver accepts;
- charging start retried during unknown HAL delivery;
- duplicate HAL transaction/fact;
- simultaneous payment callback + webhook;
- simultaneous rating PUT;
- simultaneous policy activation;
- invoice worker duplicate claim;
- compensation worker duplicate finalization.

## 36.3 Row locking

Use `SELECT ... FOR UPDATE` or equivalent narrowly around mutable aggregate roots where transition serialization is required.

Avoid holding DB transactions open across slow external network calls.

Correct pattern:

1. transactionally create durable intent/claim;
2. commit;
3. perform external I/O;
4. transactionally record outcome;
5. reconcile uncertainty asynchronously if needed.

## 36.4 Outbox atomicity

Any external side effect that must correspond to a committed business mutation is enqueued in the same DB transaction as that mutation.

No pattern of "commit DB, then maybe remember to send notification" is allowed for critical side effects.

---

# 37. Durable Domain Events and Outbox

## 37.1 Event purpose

Domain events support:

- realtime invalidation;
- notifications;
- projections;
- asynchronous commercial workflows;
- audit correlation;
- integration with HAL/provider workers.

They do not replace normalized domain tables.

## 37.2 Event envelope

```text
id
aggregate_type
aggregate_id
event_type
occurred_at
actor_type
actor_id nullable
request_id
payload_version
payload jsonb
```

## 37.3 Important CMS events

Examples:

```text
DriverApplicationSubmitted
DriverApproved
DriverSuspended
DriverDutyStarted
DriverDutyEnded
AssetMismatchReported

ServiceRequestCreated
QuoteCreated
QuoteAccepted
ServiceJobCreated
DispatchStarted
DispatchOfferCreated
JobAssigned
JobReassigned
DriverEnRoute
DriverArrived
ServicePreparationStarted
ServiceJobChargingStarted
ServiceJobChargingEnded
ServiceJobCompleted
ServiceJobCancelled
ServiceJobFailed

ChargingStartIntentCreated
ChargingStartCommandStateChanged
ChargingSessionMaterialized
ChargingStopRequested
ChargingCommandStateChanged
ChargingMeterObserved
ChargingSoCObserved
ChargingSessionCompleted
ChargingReconciliationRequired

PriceFinalized
PaymentCaptured
PaymentFailed
RefundSucceeded
InvoiceReady

CompensationCalculated
CompensationAdjusted

SupportTicketCreated
SupportReplyAdded
IncidentOpened
IncidentResolved
```

## 37.4 Event payload discipline

Events contain only what downstream consumers need plus stable identifiers.

Avoid duplicating complete mutable entities or sensitive data into every event.

Payloads are versioned.

---

# 38. Background Workers

Initial CMS worker set SHOULD be explicit and independently observable:

1. **Outbox dispatcher**: claims domain/notification work.
2. **Realtime publisher**: publishes authorized projections/invalidations from committed events.
3. **Notification delivery worker**: push/email/SMS providers.
4. **Dispatch scheduler/retry worker**: scheduled-job dispatch windows and retry when no candidates.
5. **Payment reconciliation worker**: provider status for uncertain/pending payment operations.
6. **Invoice generation worker**.
7. **Compensation finalization/reconciliation worker**.
8. **Projection reconciliation worker**: repair/rebuild derived current state if needed.
9. **Retention/cleanup worker**: expires temporary/idempotency/raw location data according to policy.

HAL worker set:

1. connection supervisor;
2. charging command dispatcher;
3. charging deadline/automatic-stop worker;
4. pending charging-stop recovery worker;
5. dedicated sequential generic charger-operation recovery worker;
6. reconnect/transaction reconciliation worker;
7. authoritative fact outbox delivery worker;
8. independent diagnostic trace outbox/retention worker;
9. health/liveness ticker.

The generic charger-operation recovery worker MUST NOT share a sequential execution loop with charging deadline enforcement, automatic stops, or pending charging-stop recovery. Slow Reset/Unlock/diagnostic work cannot delay safety/commercial charging lifecycle work.

Every worker must have:

- bounded batch size;
- claim/lease or transactional ownership;
- retry classification;
- backoff;
- max-attempt/dead-letter visibility where appropriate;
- metrics for pending/oldest age/failures;
- graceful shutdown behavior.

---

# 39. Failure Classification and Recovery

Failures MUST be classified so retries do not make reality worse.

## 39.1 Classes

```text
VALIDATION
AUTHORIZATION
CONFLICT
TRANSIENT_INTERNAL
TRANSIENT_EXTERNAL
TERMINAL_EXTERNAL
OUTCOME_UNKNOWN
INTEGRITY_VIOLATION
```

## 39.2 Retry policy

- Validation/auth/conflict: caller must change state/input; no blind server retry.
- Transient internal: bounded automatic retry if operation is safe/idempotent.
- Transient external before known delivery: bounded retry.
- Outcome unknown after possible physical/payment side effect: reconcile by stable identity before retry.
- Integrity violation: stop, alert, preserve evidence.

## 39.3 Stop conditions

Workers MUST stop automatic retries and surface operational attention when:

- semantic conflict appears;
- same identity maps to conflicting payload;
- repeated failures exceed policy;
- physical command outcome remains unknown beyond reconciliation horizon;
- provider/charger reports impossible transition;
- database constraint indicates an unexpected invariant breach.

---

# 40. Security and Privacy Blueprint

## 40.1 Authentication secrets

Passwords, OTPs, refresh tokens, service credentials, Razorpay secrets, webhook secrets, and private keys MUST never be logged.

Store password hashes with a modern password hashing algorithm if passwords are used.

OTP codes are short-lived, rate-limited, and stored only in protected/hashed form where possible.

## 40.2 PII

Sensitive fields include:

- phone/email;
- addresses/location history;
- KYC documents/numbers;
- driving licence;
- bank information if stored;
- exact driver/customer traces;
- support free text;
- invoice/customer tax info.

APIs return the minimum projection required for that actor.

## 40.3 KYC document storage

- private object/file storage;
- random opaque object identifiers;
- MIME/type and size validation;
- malware scanning if infrastructure supports it;
- authorization on every fetch;
- short-lived signed URLs if used;
- audit reads for highly sensitive documents where practical.

## 40.4 Input safety

All user-generated free text is untrusted.

Frontend must escape reviews/support/notes.

Backend must use parameterized SQL and never interpolate user strings into queries.

## 40.5 Rate limiting

At minimum rate-limit:

- login/OTP/recovery;
- registration;
- quote creation abuse;
- support spam;
- location ingestion by device;
- provider callback endpoints according to provider expectations;
- HAL internal ingress by authenticated service/size limits.

## 40.6 Authorization test requirement

Every protected route family requires tests for:

- unauthenticated rejection;
- wrong principal type;
- wrong owner/resource;
- missing capability;
- positive allowed path.

---

# 41. Audit Blueprint

Audit is separate from ordinary application logs.

Audit records are durable and queryable for security/administrative actions.

Minimum fields:

```text
id
actor_type
actor_id nullable
action
target_type
target_id nullable
occurred_at
request_id
reason nullable
before_summary jsonb nullable
after_summary jsonb nullable
metadata jsonb
```

Audit at minimum:

- driver KYC review decision;
- driver suspension/reinstatement/offboarding;
- schedule/admin assignment edits;
- vehicle/charger changes;
- pairings/mismatch resolution;
- maintenance state changes;
- pricing policy activation/retirement;
- compensation policy activation/retirement;
- manual compensation adjustment;
- admin job cancel/reassign/override;
- technical charger commands;
- refund issuance;
- invoice manual retry/void if supported;
- incident resolution;
- permission/role changes;
- system setting changes.

Audit entries must not contain secret values.

---

# 42. Observability Blueprint

## 42.1 Structured logs

All services log structured fields such as:

```text
timestamp
level
service
environment
request_id
trace_id where available
actor_type safe
actor_id safe when appropriate
cms_command_id/cms_operation_id/hal_command_id/hal_transaction_id/fact_id/job_id where relevant
event
error_code
```

No raw request/response bodies by default.

## 42.2 Metrics

CMS metrics should include:

- HTTP rate/latency/error by route template;
- DB pool saturation/latency;
- active duties by status;
- jobs by status and oldest age;
- dispatch attempt success/time-to-assignment;
- offer accept/reject/expire rate;
- stale driver locations;
- payments pending/failed/reconciliation age;
- invoice queue depth/failure;
- notification queue depth/failure;
- compensation backlog/failure;
- support/incident queue age;
- realtime connections/publish failures.

HAL metrics should include:

- connected chargers;
- connection churn;
- stale chargers;
- operations by state;
- oldest queued operation;
- unknown outcomes;
- fact outbox backlog/oldest age;
- reconnect reconciliations;
- protocol errors;
- meter sample rate/drop/invalid counts.

## 42.3 Health and readiness

Each service exposes:

```text
/health/live
/health/ready
```

Liveness means process is alive.

Readiness checks dependencies required to safely accept traffic, without making fragile third-party APIs mandatory if requests can queue/reconcile safely.

## 42.4 Alerts

Alert on actionable conditions, including:

- service down/restart loop;
- DB unavailable;
- worker oldest age exceeds threshold;
- dispatch backlog/assignment time breach;
- payment reconciliation backlog;
- HAL fact backlog;
- charger unknown command outcomes;
- unusually high charger disconnect rate;
- invoice generation repeated failure;
- storage nearing capacity;
- migration/runtime mismatch.

---

# 43. Data Retention, Privacy, and Archival

Retention MUST be explicit per data class rather than "keep everything forever" by accident.

Suggested categories:

- legal/financial invoices/payments/refunds: long-term according to accounting/legal obligations;
- ServiceJob commercial history: long-term;
- compensation ledger: long-term business record;
- audit: long-term security/business record;
- raw driver GPS samples: bounded operational retention, with aggregates/history kept as needed;
- raw HAL protocol traces: bounded technical retention, longer around incidents;
- idempotency keys: bounded but long enough for retries;
- notification delivery attempts: bounded after terminal state;
- expired sessions/tokens: security retention as needed;
- KYC: lifecycle/legal retention policy with deletion/anonymization process.

A future privacy deletion/anonymization workflow must preserve legal/financial integrity while removing or pseudonymizing data that is no longer required.

---

# 44. Database Schema Grouping and Migration Plan

The exact SQL is created as work is implemented, but migration dependencies SHOULD follow this order so later features do not force semantic rewrites.

## 44.1 Migration groups

```text
000001 platform extensions / UUID support / base conventions
000002 accounts and sessions
000003 admin roles/capabilities
000004 audit foundation
000005 durable outbox/idempotency

000010 customer profiles
000011 customer vehicles
000012 customer addresses

000020 driver applications
000021 driver documents/reviews
000022 driver profiles/eligibility

000030 service vehicles
000031 chargers/connectors
000032 vehicle-charger pairings/history
000033 maintenance/lifecycle
000034 driver asset assignments

000040 schedules/occurrences
000041 duty sessions
000042 asset claims
000043 availability intervals
000044 location samples/projection
000045 asset mismatch reports

000050 service requests
000051 quotes
000052 service jobs/events
000053 dispatch attempts/candidates/offers
000054 job assignments

000060 charging start intents, one-use credential hashes, CMS command records
000061 charging sessions, stop requests, HAL transaction links
000062 HAL mapping registry, immutable fact receipts, connection/connector projections
000063 meter/SoC observations and charging operational events
000064 generic charger-operation dispatch/recovery fencing
000065 HAL reconciliation cursors/state

000070 pricing policies/rules/snapshots/line items
000071 payments/provider events
000072 refunds/adjustments
000073 GST snapshots/invoices

000080 compensation policies/rules
000081 compensation snapshots/line items/adjustments

000090 ratings/reviews
000091 support tickets/messages
000092 incidents
000093 notifications/preferences

000100 realtime/projection support where persistence is actually needed
```

Numbers are a proposed bootstrap sequence, not a requirement to create empty placeholder migrations.

## 44.2 Migration rules

- Applied migrations are immutable.
- Every migration has deterministic up behavior.
- Down migration exists only where semantically safe; destructive history rollback may deliberately refuse.
- Large/data-transforming migrations include preflight and verification query plan.
- Production migration is preceded by verified backup/rollback strategy appropriate to blast radius.
- New binary/schema compatibility is analyzed before deployment order is chosen.

---

# 45. Configuration Blueprint

Configuration is environment-driven with an example key contract.

Categories:

```text
APP_ENV
HTTP_LISTEN_ADDR
PUBLIC_BASE_URL
DATABASE_URL
LOG_LEVEL

AUTH_*
SESSION_*
RATE_LIMIT_*

RAZORPAY_*
PAYMENT_*

HAL_V1_BASE_URL
HAL_V1_CMS_BEARER_TOKEN
HAL_V1_CMS_FACT_BEARER_TOKEN
HAL_V1_TRACE_BEARER_TOKEN
HAL_V1_REQUEST_TIMEOUT
HAL_V1_START_RECONCILE_AFTER
HAL_V1_CONNECTION_STALE_AFTER
HAL_V1_METER_STALE_AFTER
HAL_V1_RECONCILE_INTERVAL

INVOICE_STORAGE_ROOT or object-storage configuration
MAIL_*
PUSH_*

DISPATCH_*
LOCATION_*
SERVICE_AREA_*

OUTBOX_*
WORKER_*

REALTIME_*
```

The HAL repository has its own independent configuration contract. At minimum:

```text
DATABASE_URL
HTTP_LISTEN_ADDR
OCPP_LISTEN_ADDR
CMS_V1_FACTS_URL
CMS_V1_FACT_BEARER_TOKEN
CMS_V1_TRACE_EVENTS_URL
CMS_V1_TRACE_BEARER_TOKEN
FACT_OUTBOX_*
TRACE_OUTBOX_*
COMMAND_WORKER_*
CHARGER_OPERATION_RECOVERY_*
CONNECTION_*
OCPP_*
```

`HAL_V1_CMS_BEARER_TOKEN`, `HAL_V1_CMS_FACT_BEARER_TOKEN`, and `HAL_V1_TRACE_BEARER_TOKEN` are three distinct secret purposes. The CMS-to-HAL command credential MUST NOT be reused for HAL-to-CMS fact or trace delivery.

Rules:

- `.env` never committed;
- `.env.example` contains names and safe descriptions/defaults, never secrets;
- startup validates required configuration;
- no secret values printed in logs;
- pre-deploy key-name parity check detects missing/extra/blank keys safely.

Business pricing/compensation rules belong in versioned database policies, not environment variables.

---

# 46. OpenAPI and Human Contract Discipline

OpenAPI is a first-class deliverable, not generated as an afterthought from undocumented handlers.

Every route change updates together:

1. handler;
2. service/domain logic;
3. persistence/migration;
4. authorization;
5. OpenAPI;
6. human integration guidance where needed;
7. tests;
8. project state/changelog/work item.

Runtime route registration MUST be tested against the canonical OpenAPI contract.

User, Driver, and Admin integrator documents should be standalone and generated/maintained by domain, not one unstructured mega-document.

---

# 50. Completion Invariants

A ServiceJob may transition to `COMPLETED` only when all applicable invariants are true.

Minimum invariants:

1. Job is in `WRAP_UP`.
2. No active physical charging transaction remains for the job.
3. No `ChargingStartIntent`, `ChargingStopRequest`, or physical-delivery command remains unresolved without an explicit reconciliation disposition. A start in `RECONCILIATION_REQUIRED` blocks replacement start on the same job/asset until exact evidence resolves it; an unresolved stop never allows CMS to claim physical completion. Generic administrative charger-operation ambiguity is tracked separately and blocks job completion only when that specific operation is defined as a safety prerequisite.
4. Final charging metrics have been frozen or explicitly marked unavailable with reason.
5. Final pricing has been calculated or a deliberate zero/exception commercial disposition exists.
6. The current assignment has a closeout disposition.
7. Required driver closeout fields are present.
8. Any mandatory incident/blocking exception is resolved or explicitly transferred to post-service handling.
9. Job history/event write succeeds in the same transaction.

Payment capture and invoice readiness SHOULD NOT be required to mark physical field service complete unless the business explicitly chooses a pre-completion collection rule. Their state remains visible independently.

Driver compensation MAY be calculated asynchronously after completion but must be derived from frozen source facts and eventually converge.

---

# 53. Mobile Unit Energy/Capacity Model (see canonical activation gate)

The planning baseline recognizes that a mobile charging unit may itself have an energy/capacity constraint.

This is a first-class extension point rather than an ignored TODO.

If Charger-on-Wheels hardware uses onboard battery/energy storage, add:

```text
mobile_energy_stores
energy_store_observations
energy_store_reservations
energy_store_capability_snapshots
```

Dispatch eligibility then requires sufficient deliverable reserve for the requested job plus configured safety reserve.

The authoritative input may come from vehicle telemetry, BMS integration, HAL/vendor telemetry, or validated manual state depending hardware.

Until such hardware facts are integrated, the system MUST NOT fabricate energy reserve. The dispatch policy can mark this criterion `NOT_MODELED` and rely on operational policy, but the limitation must be explicit in Admin.

---

# 54. Derived Projections and Rebuildability

Derived projections improve read performance but cannot become hidden sources of truth.

Candidate projections:

- current driver location;
- driver current duty summary;
- current job live projection;
- charger runtime projection;
- admin operations dashboard counters;
- driver earnings summaries;
- customer rating aggregates.

For each projection, document:

- source tables/events;
- update trigger/worker;
- staleness semantics;
- rebuild/reconciliation method;
- what happens if projection update fails.

A failed projection update must not roll back already committed physical/commercial truth unless the projection itself is part of the transaction intentionally.

---

# 55. Search, Filtering, and Operational Query Rules

Operational list APIs MUST be useful to real admins, not only technically paginated.

## 55.1 Drivers

Filter/sort by:

- recruitment status;
- operational status;
- eligibility;
- on-duty/off-duty;
- schedule window;
- active job;
- base zone;
- document expiry/block reason;
- name/phone/email search with privacy controls.

## 55.2 Fleet

Filter/sort by:

- active/retired;
- maintenance;
- availability derived state;
- vehicle/charger pairing;
- current driver/duty;
- connector type;
- power;
- protocol;
- HAL online/staleness;
- last activity.

## 55.3 Jobs

Filter/sort by:

- status;
- created/requested time;
- scheduled/immediate;
- customer;
- driver;
- vehicle;
- charger;
- payment state;
- invoice state;
- incident/support association;
- exception state;
- zone;
- age in current state.

## 55.4 Finance/compensation

Filter by date ranges using explicit timezone semantics and bounded exports.

Large exports should be asynchronous durable export jobs, not unbounded API responses.

---

# 56. Operational Exports

Admin may require CSV/structured exports for finance, driver compensation, jobs, and assets.

Exports SHOULD be modeled as asynchronous jobs for nontrivial ranges:

```text
export_jobs
  id
  type
  requested_by
  filters jsonb
  status
  storage_ref nullable
  checksum nullable
  created_at
  completed_at nullable
  expires_at
```

Export artifacts are private and time-bounded.

Export data must use the same authoritative queries/definitions as UI summaries to prevent inconsistent numbers.

---

# 57. Testing Strategy

Testing is layered by the kind of claim being made.

## 57.1 Unit tests

Mandatory areas:

- every state transition table;
- customer pricing rule evaluation;
- compensation rule evaluation;
- time-window/interval prorating;
- dispatch eligibility;
- dispatch ranking deterministic tie-break;
- geofence intersection;
- snapshot construction;
- authorization decisions;
- cancellation/no-show rules;
- HAL adapter normalization;
- payment/refund state transitions;
- invoice calculation inputs;
- privacy projection shaping.

## 57.2 PostgreSQL integration tests

Run against explicit disposable PostgreSQL.

Must test:

- migrations from empty DB;
- up/down where down is safe;
- uniqueness/exclusion constraints;
- active DutySession uniqueness;
- asset claim race;
- offer acceptance race;
- idempotency duplicate/conflict;
- outbox atomicity;
- duplicate HAL fact ingest;
- transaction rollback;
- version/optimistic concurrency;
- historical FK behavior;
- policy version immutability.

## 57.3 Service integration

CMS-HAL:

- mapping create/update and post-commit reconfirmation;
- start command durable acceptance without session materialization;
- protocol acknowledgement without session materialization;
- authoritative `transaction.started` materializes exactly one session;
- command explicit rejection;
- HTTP timeout before HAL durable acceptance;
- HTTP timeout after HAL persisted/possibly delivered command;
- exact `cms_command_id` reconciliation and confirmed absence;
- exact `cms_start_intent_id` transaction reconciliation;
- late start fact after rejected/expired intent;
- duplicate identical fact is success/no-op;
- same fact ID with changed digest is integrity conflict;
- out-of-order connection/connector/meter/SoC sequence cannot regress projection;
- stop acknowledgement does not complete session;
- spontaneous charger-originated completion is accepted when identity chain validates;
- missing completion fact recovered by exact `hal_transaction_id` and same finalizer;
- reconnect/restart during active transaction;
- CMS outage while HAL fact outbox accumulates;
- HAL outage while CMS preserves durable intent/session truth;
- generic admin charger operation uses pre-I/O delivery fence and no-replay exact-ID recovery;
- slow generic operation recovery cannot delay charging deadline/automatic-stop worker;
- multiple physical sessions under one ServiceJob.

Payments:

- order retry;
- callback success + webhook duplicate;
- webhook before client verify;
- provider timeout;
- captured payment with lost API response;
- refund timeout/reconciliation.

## 57.4 End-to-end simulator tests

At minimum script these flows:

### E2E-01 happy path saved data

Saved EV + saved address -> quote -> dispatch -> charge -> payment -> invoice -> compensation -> rating.

### E2E-02 temporary customer data

Temporary EV/address -> completed job -> history retains snapshots -> promote both -> old history unchanged.

### E2E-03 scheduled driver

Admin schedule + assigned assets -> driver starts occurrence -> job -> planned vs actual times preserved.

### E2E-04 unscheduled driver

Driver self-starts duty under permitted policy -> selects eligible assets -> receives job.

### E2E-05 pairing mismatch

Admin expects C1, driver observes C2 -> report -> allowed temporary operation -> job uses C2 snapshot -> Admin reconciles later -> old duty remains C2.

### E2E-06 no compatible charger

Nearby drivers exist but connector/capability incompatible -> no invalid offer -> Admin diagnostic explains exclusion.

### E2E-07 start response lost after possible physical success

CMS creates one ChargingStartIntent/command -> HAL durably persists and sends start -> response is lost -> CMS enters `RECONCILIATION_REQUIRED` without a replacement command -> exact command/transaction lookup or immutable `transaction.started` fact proves the same attempt -> exactly one ChargingSession materializes.

### E2E-08 charger fault and restart

Transaction S1 ends unexpectedly -> same ServiceJob remains active -> recovery -> S2 starts -> final billing aggregates eligible facts.

### E2E-09 driver reassignment

D1 en route then breaks down -> assignment closes -> D2 assigned -> one ServiceJob -> compensation split by authoritative intervals.

### E2E-10 customer cancel after dispatch

Cancellation policy line item applied, assignment closed, no charging started, no fake energy/invoice facts.

### E2E-11 customer no-show

Arrival evidence + waiting threshold -> no-show -> policy charge -> compensation rule as configured.

### E2E-12 policy changes mid-job

Pricing and compensation policy edited/activated after job started -> job uses frozen versions defined by snapshot boundary.

### E2E-13 time boundary compensation

Driver work crosses night-rate boundary -> interval-prorated line items match exact minutes/distance basis.

### E2E-14 payment duplicate/recovery

Captured payment, lost response, duplicate webhook -> one captured logical payment.

### E2E-15 realtime disconnect

User/Driver/Admin lose realtime -> reconnect -> REST current state is correct -> subsequent versioned events converge.

## 57.5 Physical hardware acceptance

Before production readiness for a charger model/protocol:

- connect/disconnect;
- remote start/stop;
- transaction IDs;
- meter values;
- SoC if claimed;
- faults;
- reconnect during transaction;
- network loss;
- charger reboot;
- uncertain command outcome;
- connector mapping;
- max power/capability reporting;
- repeated sessions;
- time synchronization behavior;
- vendor deviations.

Simulator acceptance is not physical hardware acceptance.

---

# 58. Verification Gates for Every Work Item

Every meaningful burner/work item has four separate gates.

## Gate A: semantic/design

- scope and non-goals explicit;
- domain owner clear;
- state transition defined;
- persistence/constraints defined;
- authorization defined;
- idempotency defined;
- failure/recovery defined;
- history/realtime/audit impact defined.

## Gate B: source

- formatting/lint;
- focused tests;
- broad unit/integration tests;
- OpenAPI/runtime parity;
- documentation verifier;
- migration checks;
- `git diff --check`;
- no unrelated changes.

## Gate C: integration/runtime

- migrations applied to target environment intentionally;
- service healthy/readiness;
- changed routes behave under auth boundaries;
- workers healthy;
- logs clean of new panics/fatals;
- external integration tested or explicitly marked unverified.

## Gate D: physical/external acceptance where relevant

- real Razorpay provider behavior;
- real email/push provider acceptance;
- real HAL-to-charger behavior;
- real hardware acceptance.

A feature can be source-complete but not physically accepted. The completion statement must say which gate was reached.

---

# 59. CI Pipeline Blueprint

Every repository pull/merge validation SHOULD include, as applicable:

CMS:

```text
format check
go test focused critical packages
go test ./...
go vet ./...
go build ./...
go mod verify
migration parse/check
OpenAPI schema validation
runtime-route vs OpenAPI parity test
documentation verifier
git diff --check
disposable PostgreSQL integration suite
```

HAL:

```text
format check
go test ./...
go vet ./...
go build ./...
go mod verify
migration checks
adapter contract tests
scripted simulator scenarios
CMS-HAL schema compatibility tests
```

Never run DB integration suites against shared development/production databases.

---

# 60. Deployment Blueprint

## 60.1 Deployment order principle

Choose deployment order based on schema/contract compatibility, not habit.

Prefer backwards-compatible additive releases:

1. additive DB migration;
2. deploy code that understands old+new where transition requires;
3. switch behavior/config;
4. remove old support only in later release when safe.

## 60.2 CMS deployment preflight

Before activation:

- verify intended Git SHA;
- clean/understood worktree;
- verify migrations pending/current;
- validate configuration key parity without printing secrets;
- verify disk/storage;
- verify service unit and listener;
- verify reverse proxy routing;
- verify DB backup/recovery plan if schema mutation is consequential;
- build candidate;
- run source verification;
- identify old binary/rollback asset;
- inspect currently active jobs/operations if maintenance may disrupt them.

## 60.3 HAL deployment preflight

Additionally:

- inspect active charger connections;
- inspect active transactions;
- inspect queued/unknown operations;
- confirm restart recovery can reconcile active physical sessions;
- avoid deployment when a known non-recoverable hardware operation is in a dangerous boundary unless necessary.

## 60.4 Activation

Use managed service deployment/rehost procedure.

Do not improvise kill/start commands when a controlled framework exists.

## 60.5 Post-deploy verification

CMS:

- service active/restart count;
- local/public health/readiness;
- OpenAPI/Swagger;
- migration ledger;
- worker health/backlogs;
- auth rejection on protected routes;
- changed feature smoke path;
- payment/notification/invoice external boundary if included;
- logs.

HAL:

- service active/restart count;
- internal health/readiness;
- charger reconnection;
- active transaction reconciliation;
- operation queue;
- fact outbox;
- simulator smoke;
- real charger smoke where deployment claims physical acceptance.

## 60.6 Rollback

Rollback decision considers:

- whether schema down is safe;
- whether new historical rows make destructive down unsafe;
- whether a forward fix is safer;
- active physical transactions;
- payment/invoice facts created by new release.

Binary rollback must never be described as complete if database/state semantics are incompatible with the older binary.

---

# 61. Backup, Recovery, and Disaster Principles

## 61.1 CMS database

- automated backups;
- tested restore procedure;
- pre-migration backup for high-risk schema/data changes;
- retention appropriate to business/legal importance;
- periodic restore drill.

## 61.2 HAL database

HAL persistent operations/facts are operational evidence and need backups as appropriate.

However, recovery design must also tolerate losing rebuildable connection projections while preserving operation/fact integrity.

## 61.3 Artifact storage

Invoice/KYC/export storage requires backup/retention consistent with database references.

Database restore without corresponding artifacts must be detectable, not silently produce broken downloads.

Store checksums and perform integrity checks.

---

# 62. Project Documentation Set

The repository should maintain at minimum:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/DEVELOPMENT_PLAN.md
docs/AI_CHANGELOG.md

docs/architecture/SYSTEM_ARCHITECTURE.md
docs/architecture/DOMAIN_MODEL.md
docs/architecture/STATE_MACHINES.md
docs/architecture/CMS_HAL_BOUNDARY.md
docs/architecture/CHARGING_TRUTH_MODEL.md

docs/contracts/openapi/openapi.yaml
docs/contracts/api/user-app.md
docs/contracts/api/driver-app.md
docs/contracts/api/admin.md
docs/contracts/api/internal-hal.md
docs/contracts/hal/CMS_HAL_CHARGING_V1.md
docs/contracts/realtime/events.md
docs/contracts/configuration.md

docs/handoffs/USER_APP_FE_HANDOFF.md
docs/handoffs/DRIVER_APP_FE_HANDOFF.md
docs/handoffs/ADMIN_FE_HANDOFF.md

docs/guides/operations/dev-hosting.md
docs/guides/operations/deployment.md
docs/guides/operations/rollback-recovery.md
docs/guides/operations/charger-onboarding.md
docs/guides/operations/incident-response.md

docs/work/active/
docs/work/archive/
```

HAL repository has its own equivalent architecture, adapter, operation-state, simulator, and hosting docs.

---

# 63. Work Item Discipline

Every burner is narrow and complete.

A work item states:

- objective;
- claimed surfaces;
- dependencies;
- invariants;
- schema changes;
- API changes;
- realtime/worker changes;
- non-goals;
- tests;
- operational impact;
- verification target;
- current unverified boundary.

One burner is finished and verified before opening a semantically dependent burner unless parallelism is genuinely independent.

---

# 64. Exact Implementation Program

The implementation sequence below converts architecture into buildable burners. It intentionally front-loads contracts and stable primitives that later domains depend on.

## Program 0 - Repository and engineering authority

### B00.1 CMS repository bootstrap

Deliver:

- Go module/repo structure;
- config loader;
- structured logging;
- graceful shutdown;
- health/readiness;
- PostgreSQL connection;
- migration command;
- request IDs;
- base error contract;
- OpenAPI serving/Swagger;
- CI baseline;
- AGENTS/project docs.

Exit gate: clean empty service deploys to dev, migration 1 applies, OpenAPI/runtime route test passes.

### B00.2 HAL repository bootstrap

Deliver same platform foundations separately, plus protocol adapter interfaces and simulator skeleton.

Exit gate: HAL dev service runs independently, simulator adapter can connect logically, CMS-HAL auth contract stub works.

### B00.3 Disposable integration DB harness

Deliver isolated PostgreSQL test database orchestration for CMS and HAL.

Exit gate: concurrency/migration tests can run without touching shared dev DB.

---

## Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

### B01.1 Account/session authentication

Customer/Driver/Admin principal separation, session revocation/refresh, security tests.

### B01.2 Admin capability engine

Capability catalog, role bundles, effective authorization, explicit endpoint middleware.

### B01.3 Audit foundation

Append-only audit API/service and Admin query.

### B01.4 Durable idempotency primitive

Reusable idempotency storage/response binding for HTTP mutations.

### B01.5 Durable outbox and worker framework

Claim/lease/retry/backoff/metrics with one harmless test event.

Exit gate: later domains use these primitives instead of inventing local variants.

---

## Program 2 - Customer master data

### B02.1 Customer profile
### B02.2 Saved vehicles
### B02.3 Saved addresses/default handling
### B02.4 Snapshot schemas/builders
### B02.5 Temporary object and promotion behavior

Exit gate: API can create saved/temporary data, snapshot it, edit master data, and prove historical snapshot immutability.

---

## Program 3 - Driver recruitment and workforce

### B03.1 Driver application lifecycle
### B03.2 Secure document storage + versioned KYC review
### B03.3 Driver profile creation/onboarding
### B03.4 Eligibility engine + blocking reasons
### B03.5 Suspension/reinstatement/offboarding

Exit gate: an applicant can progress end-to-end and only an ACTIVE eligible driver reaches operational APIs.

---

## Program 4 - Fleet and inventory

### B04.1 Vehicle inventory/history
### B04.2 Charger inventory/connectors
### B04.3 Pairing history
### B04.4 Maintenance/lifecycle intervals
### B04.5 Admin asset assignment
### B04.6 Derived availability projection

Exit gate: Admin can answer current and historical vehicle/charger/assignment questions without overwriting history.

---

## Program 5 - Scheduling, duty, location

### B05.1 Schedules and materialized occurrences
### B05.2 DutySession lifecycle
### B05.3 Exclusive asset claim constraints/concurrency tests
### B05.4 Driver asset mismatch reporting
### B05.5 Break/availability intervals
### B05.6 Location ingestion/current projection/freshness
### B05.7 Driver geofence and effective area

Exit gate: scheduled and unscheduled eligible drivers can start duty safely, become dispatchable, move, pause, and end duty with exact asset history.

---

## Program 6 - Service request, pricing foundation, ServiceJob core

### B06.1 ServiceRequest
### B06.2 Serviceability validation
### B06.3 First production slice of the final pricing interface
### B06.4 Quote acceptance -> ServiceJob snapshots
### B06.5 ServiceJob state machine/event history
### B06.6 Cancellation/no-show reason framework

Exit gate: customer can create a job independent of dispatch and history is correct.

---

## Program 7 - Dispatch

### B07.1 Eligibility engine
### B07.2 Ranking engine
### B07.3 DispatchAttempt/Candidate persistence
### B07.4 Sequential offer workflow
### B07.5 Atomic offer acceptance
### B07.6 Assignment and Driver current-job contract
### B07.7 Reassignment
### B07.8 No-candidate retry/scheduled dispatch worker
### B07.9 Admin diagnostics/direct assignment

Exit gate: simulator drivers/duties can be dispatched under race, rejection, expiry, reassignment, and no-candidate tests.

---

## Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

This program begins only after CMS charger/connector identity and the internal contract version are frozen enough that both repositories can implement against the same fixtures. It may run in parallel with late dispatch work, but not before the identifier crosswalk and mapping semantics in Sections 18-20 are settled.

### B08.1 HAL repository/bootstrap contract

- independent Go module/service/database;
- configuration loader with fail-safe production PostgreSQL requirement;
- health/readiness split;
- migration runner/explicit migration command;
- structured logging with secret/body exclusions;
- worker lifecycle and graceful shutdown framework.

Exit: empty HAL starts against disposable PostgreSQL, migrations apply, readiness reflects DB/worker health, shutdown joins workers.

### B08.2 CMS-HAL service authentication

- distinct CMS->HAL command bearer;
- distinct HAL->CMS fact bearer;
- distinct HAL->CMS trace bearer;
- constant-time credential validation where applicable;
- no human/customer token reuse;
- configuration parity/docs/tests.

Exit: each credential can call only its intended plane; cross-use fails.

### B08.3 Charger/connector mapping registry

- `PUT /v1/mappings/chargers/{cms_charger_id}` or final equivalent;
- exact CMS charger/connector UUIDs;
- protocol identity and connector-number mapping;
- enabled state and optional expected serial;
- idempotent same-content replay;
- conflicting immutable identity change semantics;
- CMS durable mapping state + post-commit reconciler.

Exit: mapping create/replay/conflict/recovery pass across both services.

### B08.4 Connection runtime and restart fencing

- tracked transport connection identity;
- process-scoped generation guard for stale callbacks;
- durable connection sequence;
- startup projection to UNKNOWN until new evidence;
- Heartbeat/liveness renewal;
- connection fact outbox;
- CMS monotonic projection/freshness.

Exit: connect, stale disconnect callback, heartbeat, HAL restart, reconnect, delayed old fact all converge correctly.

### B08.5 Connector status runtime

- mapped protocol status ingestion;
- monotonic connector status sequence;
- parent connection freshness overlay;
- CMS historical-vs-live distinction;
- inventory eligibility overlay.

Exit: Available/Preparing/Charging/Finishing/Faulted/offline/stale scenarios produce truthful CMS projection.

### B08.6 Durable HAL command store and start/stop lifecycle

Implement exact states from Section 19.4:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED
OCPP_REJECTED
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Include immutable request digest, exact CMS command identity, destination, expiry, attempts, result/error category, optional resulting transaction IDs, and database guards.

Exit: crash at every boundary cannot cause an unsafe replay.

### B08.7 One-use charging credential and OCPP authorization bridge

- CMS generation/hash persistence;
- HAL durable start-command value handling/redaction;
- OCPP 1.6 idTag translation;
- Authorize/StartTransaction correlation;
- expiry using trusted HAL receipt time and bounded charger clock-skew handling;
- replay prevention.

Exit: valid credential starts once; expired/replayed/wrong-mapping credential fails without identity leakage.

### B08.8 OCPP 1.6 transaction materialization

- charger-originated StartTransaction only;
- Central System exact transaction ID allocation;
- durable HAL transaction row;
- exact command/start-intent/credential/mapping chain;
- one immutable `transaction.started` fact reservation in the same durable operation.

Exit: RemoteStart accepted without StartTransaction never materializes transaction; duplicate StartTransaction cannot create a second logical transaction.

### B08.9 MeterValues normalization

- cumulative integer Wh selection;
- accepted-measurand rules;
- exact HAL transaction binding;
- monotonic meter sequence;
- consumed Wh relative to accepted start meter;
- invalid/decreasing/out-of-order evidence handling;
- immutable `transaction.meter` facts;
- optional instantaneous measurements kept non-authoritative.

Exit: valid, duplicate, delayed, decreasing, malformed, and unrelated meter samples are covered.

### B08.10 Independent SoC normalization

- OCPP SoC extraction when present;
- canonical decimal percent 0..100;
- independent SoC sequence/time;
- SoC-only fact allowed;
- no energy invention/cached SoC replay.

Exit: missing SoC remains unknown and energy/SoC streams cannot regress one another.

### B08.11 Stop workflow and automatic limit sources

- remote stop request persistence;
- spontaneous/local stop support;
- energy limit;
- duration limit;
- funding/commercial safety threshold only as an opaque CMS-derived bound;
- explicit threshold provenance;
- shared controlled idempotent stop workflow;
- no pricing/GST/payment interpretation in HAL.

Exit: customer/driver/admin/system/local/threshold stops preserve requested-vs-protocol provenance.

### B08.12 Transaction completion truth

- exact active transaction identity check;
- StopTransaction ordering;
- nondecreasing final meter;
- documented one-Wh quantization normalization only if retained/tested;
- duplicate/conflicting terminal evidence handling;
- canonical row-lock order;
- exactly one terminal fact aggregate.

Exit: retransmitted StopTransaction cannot produce duplicate completion fact; conflicting evidence enters reconciliation.

### B08.13 Durable fact outbox

- immutable fact envelope + canonical digest;
- per-fact idempotency identity;
- lease/claim token;
- retry/backoff;
- same identity on retry;
- stale worker fencing;
- terminal receiver error classification;
- poison isolation;
- worker health/readiness.

Exit: CMS outage/restart and HAL worker crash preserve exactly the same logical facts.

### B08.14 CMS fact ingress and projection transaction

- separate fact bearer;
- `Idempotency-Key == fact_id` validation;
- canonical digest recomputation;
- durable receipt/dedupe;
- same-ID altered-content conflict;
- type-specific mapping/identity checks;
- monotonic connection/connector/meter/SoC projection;
- session materialization/completion integration seam;
- operational event emitted in same CMS transaction.

Exit: crash-before/after commit, exact replay, altered replay, delayed sequence, unsupported fact all behave deterministically.

### B08.15 Exact command and transaction reconciliation APIs

- exact command GET by `cms_command_id`;
- exact transaction GET by `cms_start_intent_id`;
- exact transaction GET by `hal_transaction_id`;
- strict response shape/identity validation;
- canonical 404 semantics;
- no "latest" lookup.

Exit: CMS can recover start ambiguity and missing completion without direct HAL DB access or a new command.

### B08.16 Generic administrative charger operation boundary

Implement separate Reset/Unlock/Availability/diagnostic operation surface with frozen immutable destination and exact operation identity.

CMS states:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

HAL preserves pre-network replayability and post-attempt ambiguity rules.

Exit: generic operation uncertainty never mutates charging/commercial truth and never blindly replays.

### B08.17 Isolated charger-operation recovery worker

- independent from deadline/automatic-stop/pending-stop workers;
- bounded fair rotation across connected chargers;
- same atomic claim/dispatcher as immediate operation;
- request-detached bounded result persistence;
- shutdown cancellation/join;
- restart classification of attempted work to reconciliation.

Exit: intentionally slow admin OCPP command cannot delay charging stop deadline processing.

### B08.18 Diagnostic trace plane

- separate trace envelope/outbox/worker/bearer;
- sanitized CALL/CALLRESULT/CALLERROR evidence;
- bounded follow-on diagnostic windows if retained;
- CMS trace store/read capability;
- hard guarantee trace failure cannot block fact worker or mutate lifecycle state.

Exit: trace receiver outage has zero authoritative charging effect.

### B08.19 Scriptable simulator

Source-controlled scenarios cover every Section 19.18 case and expose deterministic timing/failure knobs.

Exit: CI can reproduce all command/fact/reconnect/ambiguity scenarios without physical hardware.

### B08.20 Cross-repository contract fixtures

- request/response/fact/error fixtures;
- canonical digest fixtures;
- schema version fixtures;
- CMS parser tests against HAL provider fixtures;
- HAL parser tests against CMS consumer fixtures;
- fixture version/digest guard.

Exit: incompatible drift fails CI before deployment.

Program 8 exit gate: disposable CMS + HAL PostgreSQL and virtual charger prove mapping, start command durability, real transaction start, meter/SoC, stop/completion, fact idempotency, restart/outage recovery, generic-operation worker isolation, and exact-ID reconciliation. This gate is not physical charger acceptance.

---

## Program 9 - CMS charging integration and app projections

### B09.1 Charging admission model

- ServiceJob/assignment/duty/asset authorization;
- compatibility revalidation;
- mapping prerequisite;
- frozen pricing/tax/admission context;
- selected funding-safety strategy integration without hard-coded wallet assumption;
- one-use credential generation;
- database constraints.

### B09.2 ChargingStartIntent state machine

Implement exact states/transitions from Section 18.6 plus DB/service guards and history/audit.

### B09.3 Immutable CMS START command record

Freeze command ID, start intent, HAL destination, connector number, request digest, correlation, expiry, limits/provenance before HAL I/O.

### B09.4 Start orchestration and post-commit mapping reconfirmation

Implement the exact sequence in Section 20.8, including safe cleanup when the post-commit mapping prerequisite fails before RequestStart.

### B09.5 Start ambiguity reconciler

- exact command lookup;
- confirmed-absence cleanup;
- exact transaction-by-start-intent lookup after threshold;
- late evidence handling;
- durable cursor/backoff/fairness;
- no blind new start.

### B09.6 `transaction.started` -> ChargingSession materialization

- full identity chain validation;
- exactly one session per start intent;
- exact HAL/protocol transaction IDs;
- ServiceJob transition to CHARGING only when legal;
- operational event/realtime invalidation.

### B09.7 Meter/SoC CMS projection

- independent sequences/freshness;
- accepted fact receipts;
- historical observation retention;
- user/driver/admin safe projections;
- stale parent connection semantics.

### B09.8 Charging stop request

- actor policy for Driver/User/Admin/system;
- durable stop request/command;
- optional bounded reason;
- `STOP_PENDING` projection;
- no completion from HAL/OCPP command acknowledgement.

### B09.9 `transaction.completed` finalization

- full identity/meter/time validation;
- requested-vs-protocol stop provenance;
- exactly-once session completion;
- final pricing source binding;
- payment/funding settlement seam;
- invoice intent seam;
- ServiceJob WRAP_UP gate;
- durable events.

### B09.10 Missing-completion recovery

- exact HAL transaction lookup by `hal_transaction_id`;
- same locked finalization path as normal fact;
- active/404/unavailable/malformed/conflict behaviors from Section 18.16;
- fair durable cursor.

### B09.11 Multiple ChargingSessions per ServiceJob

- separate start intent/session for later physical restart after prior session ended;
- aggregation for final pricing and compensation;
- UI/history representation;
- no transport-reconnect-induced false split.

### B09.12 Runtime availability and chargeability

- CMS inventory status;
- HAL connection freshness;
- connector protocol status/freshness;
- unresolved occupancy/start/session state;
- compatibility;
- asset mismatch;
- stable machine reason codes.

### B09.13 User charging read/progress contract

Implement Section 31.14-31.19: start progress distinct from session, exact unknown/stale behavior, materialized-session-only history, stop provenance, bounded pagination.

### B09.14 Driver charging contract

Driver Start/Stop/prepare UI consumes the same CMS domain methods and receives explicit requested/accepted/physical/reconciling states. Driver cannot force physical state by status mutation.

### B09.15 Admin technical charging views

Expose safe command/fact/runtime/trace projections with capability boundaries. Diagnostic trace is visibly labeled non-authoritative.

### B09.16 User live-job snapshot/SSE integration

- durable REST snapshot;
- full-replacement live jobs/session stream;
- generic event replay cursor;
- reconnect/token rotation/cursor expiry recovery;
- realtime outage fallback.

### B09.17 End-to-end charging acceptance

Run Section 20.18 matrix plus User/Driver/Admin projection agreement tests.

Program 9 exit gate: a virtual charger can drive a full ServiceJob charging lifecycle while every application sees the same CMS durable truth, all ambiguity is recoverable by exact identity, and no command acknowledgement is mistaken for physical charging state.

---

## Program 10 - Full pricing engine

### B10.1 Versioned pricing policy/rule persistence
### B10.2 Deterministic rule evaluator
### B10.3 Quote estimation line items
### B10.4 Final source-fact binding
### B10.5 Final pricing line items/snapshot
### B10.6 Cancellation/no-show components
### B10.7 Time/date/zone modifiers
### B10.8 Admin policy editor contract

Exit gate: fixed test fixtures prove same inputs + versions produce same result and historical jobs survive policy changes.

---

## Program 11 - Payments, refunds, tax, invoices

### B11.1 Razorpay order/payment integration
### B11.2 webhook/idempotent reconciliation
### B11.3 refund workflow
### B11.4 GST snapshot calculation
### B11.5 invoice renderer/storage/version/checksum
### B11.6 invoice worker/retry/download
### B11.7 mail/notification intent for invoice

Exit gate: provider sandbox/test environment and local artifact flow accepted end-to-end, with external acceptance boundary documented.

---

## Program 12 - Driver compensation

### B12.1 Versioned policy/rules
### B12.2 deterministic evaluator
### B12.3 time-boundary/interval prorating
### B12.4 source-fact binding
### B12.5 line-item ledger
### B12.6 reassignment allocation
### B12.7 adjustments
### B12.8 Driver summary/history
### B12.9 Admin views/exports

Exit gate: fixtures cover base, distance, time, night modifier, date bonus, driver override, minimum, cap, reassignment, and correction.

---

## Program 13 - Product completeness

### B13.1 User ratings/reviews
### B13.2 Customer support
### B13.3 Driver support
### B13.4 Incident management
### B13.5 Notification preferences/delivery
### B13.6 Admin operational dashboard
### B13.7 Async exports
### B13.8 retention/cleanup jobs

---

## Program 14 - Realtime hardening

Realtime basics may exist earlier, but this program makes it complete:

### B14.1 authenticated subscriptions
### B14.2 per-resource versioning
### B14.3 reconnect/catch-up guidance
### B14.4 user projections
### B14.5 driver projections
### B14.6 admin projections
### B14.7 backpressure/disconnect behavior
### B14.8 realtime-vs-REST consistency E2E tests

---

## Program 15 - Production hardening

### B15.1 security review
### B15.2 DB backup/restore drill
### B15.3 worker/backlog alerting
### B15.4 load tests for location/realtime/dispatch
### B15.5 Razorpay production-readiness checks
### B15.6 mail/push production acceptance
### B15.7 physical charger certification matrix
### B15.8 operational runbooks/on-call drills
### B15.9 staging full-day/long-session soak
### B15.10 release/rollback drill

---

## Program 16 - Protocol expansion

Only after core semantics are stable:

### B16.1 OCPP 2.0.1 adapter
### B16.2 adapter parity matrix
### B16.3 OCPP 2.1 if hardware/business requires
### B16.4 vendor-specific extensions behind adapter capability interfaces

Protocol expansion MUST NOT change CMS business semantics unless a genuinely new business capability is introduced deliberately.

---

# 65. Dependency Graph

High-level dependency order:

```text
Repository foundations
  -> auth/capability/audit/idempotency/outbox
     -> customer master data
     -> driver recruitment
        -> fleet
           -> schedule/duty/location
              -> service request/job
                 -> dispatch
                    -> charging integration

HAL foundations
  -> protocol-neutral core
     -> OCPP16/simulator
        -> CMS charging integration

ServiceJob + charging source facts
  -> final pricing
     -> payment/tax/invoice
  -> compensation

Core lifecycle
  -> ratings/support/incidents
  -> realtime completeness
  -> production hardening
```

The first production slice of the final pricing contract may begin before charging, but final pricing requires authoritative source facts.

HAL work can proceed in parallel after charger identity and CMS-HAL semantic contracts are frozen.

---

# 66. Phase Entrance and Exit Criteria

A later program may start only when its upstream semantic contracts are stable enough that proceeding will not force known rework.

Examples:

- Dispatch does not begin before DutySession + asset claim semantics exist.
- Charging integration does not begin before stable ServiceJob/assignment IDs and charger-HAL identity mapping exist.
- Compensation finalization does not begin before source facts/time boundaries are defined.
- Invoice generation does not begin before pricing/tax snapshots are frozen.
- Protocol 2.x adapters do not begin by duplicating OCPP 1.6 code before protocol-neutral core contracts are proven.

Parallel development is allowed when dependencies are interfaces already fixed and independently testable.

---

# 67. Definition of Done - Project Level

The project is not production-ready merely because all endpoints exist.

Production readiness requires:

1. User flow accepted end-to-end.
2. Driver recruitment + operational flow accepted end-to-end.
3. Admin can operate and recover abnormal flows.
4. Dispatch handles eligibility/races/reassignment.
5. Dedicated HAL survives reconnect/restart/uncertain operation tests.
6. At least one target physical charger model is hardware-accepted.
7. Pricing fixtures and real job calculations agree.
8. Razorpay production integration is verified at the intended flow boundary.
9. Refund flow verified.
10. Invoice artifact + download + delivery path verified.
11. Compensation ledger is explainable and stable across policy changes.
12. Realtime reconnects recover from REST.
13. Authorization/privacy tests cover all three human planes.
14. Backups and restore are tested.
15. Deployment/rollback runbook is exercised.
16. Monitoring alerts on critical backlogs/failures.
17. Documentation and OpenAPI match runtime.
18. No known unresolved integrity issue is hidden behind UI workarounds.
19. Known external/unverified boundaries are documented explicitly.

---

# 68. Decisions Intentionally Left as Business Configuration

The following are not architecture gaps. They are explicit policy data/knobs that the business can change without code redesign:

- customer price/rates;
- driver compensation rates;
- cancellation/no-show monetary rules;
- dispatch ranking weights;
- sequential vs batched offer strategy;
- offer expiry duration;
- scheduled-dispatch lead time;
- driver voluntary geofence limits;
- required location freshness threshold;
- arrival radius/manual override policy;
- whether customer may directly request charging stop;
- whether charger online state is mandatory at duty start or only at dispatch;
- which KYC documents are mandatory;
- exact retention periods;
- optional notification channels;
- whether driver review text is shown directly to Driver;
- whether mobile energy reserve is enforced once hardware telemetry exists.

Each knob needs a safe default, validation, auditability if Admin-editable, and documentation.

---

# 69. Decisions That Must Be Resolved Before Their Burner

These are genuine external/business/hardware inputs that cannot be truthfully invented in architecture:

1. Exact Charger-on-Wheels physical hardware models and connector configurations.
2. Whether the mobile unit has onboard energy storage and how its SoC/capacity is obtained.
3. Exact customer payment capture strategy supported/desired with Razorpay: upfront, deposit, authorization-like pattern, or post-service collection.
4. Legal/business invoice and GST classification details for mobility/service vs energy components.
5. Required KYC document set and storage/compliance retention requirements.
6. Client platform decisions that affect push provider/device token implementation.
7. Exact navigation/maps provider if server-side ETA/routing is required.
8. Production infrastructure/hostnames/secrets/storage provider.

The implementation program does not wait on these globally. It defers only the burner whose exact behavior depends on them, using explicit interfaces in the meantime.

---

# 70. Traceability Back to the Planning Baseline

This blueprint preserves and concretizes the planning baseline's major commitments:

| Planning concept | Blueprint realization |
| --- | --- |
| User / Driver / unified Admin | Sections 1, 30-33 |
| intended vs actual vs historical vs physical/commercial truth | Sections 3, 12-20, 52 |
| reusable vs temporary customer data | Sections 10, 31, 57 |
| driver recruitment as lifecycle | Sections 11, 32-33 |
| asset inventory/pairing/mismatch | Sections 12-13, 52 |
| schedules vs actual duty | Section 13 |
| optional driver geofence | Section 14 |
| two-stage dispatch eligibility/ranking | Section 15 |
| ServiceJob central object | Sections 16-18 |
| separate charging lifecycle | Sections 18-20 |
| composable pricing | Section 21 |
| compensation calculation not payout | Section 25 |
| realtime not durable truth | Section 29 |
| dedicated protocol-neutral HAL | Sections 19-20 |
| raw evidence + normalized facts | Section 19 |
| audit and historical snapshot principles | Sections 3, 41 |
| implementation sequence | Section 64 |
| real verification / physical acceptance boundaries | Sections 57-60 |

---

# 71. Final Build Principle

Charger on Wheels must make the normal path easy without forcing abnormal real-world conditions into false data.

The implementation therefore preserves, separately and explicitly:

```text
what Admin intended
what Driver actually used
what the charger physically did
what the customer commercially owes
what the driver compensation engine calculated
what happened historically
what realtime currently projects
```

Then it composes those truths into User, Driver, and Admin experiences through explicit contracts.

The stable center is the ServiceJob. The operational driver context is the DriverDutySession. The physical charging authority is the dedicated HAL. PostgreSQL-backed durable state is the recovery authority. Realtime is an accelerator. Policies are versioned. History is not rewritten for convenience. Physical side effects are never inferred from optimistic UI actions.

That is the implementation blueprint.

---

# Appendix A. Normative State Machine Registry

This appendix is normative. Implementations must not add ad hoc transitions outside these graphs without updating the domain contract, tests, OpenAPI behavior, and this blueprint.

## A.1 DriverApplication

```text
DRAFT
  -> SUBMITTED
  -> WITHDRAWN

SUBMITTED
  -> UNDER_REVIEW
  -> WITHDRAWN

UNDER_REVIEW
  -> ACTION_REQUIRED
  -> APPROVED
  -> REJECTED

ACTION_REQUIRED
  -> SUBMITTED
  -> WITHDRAWN

APPROVED
  -> ONBOARDING

ONBOARDING
  -> ACTIVE

ACTIVE      terminal recruitment success state
REJECTED    terminal recruitment decision
WITHDRAWN   terminal applicant decision
```

Operational suspension/offboarding is not a recruitment-state transition.

## A.2 DriverDutySession

```text
STARTING
  -> AVAILABLE
  -> ABORTED

AVAILABLE
  -> OFFERED
  -> BREAK
  -> UNAVAILABLE
  -> ENDING

OFFERED
  -> ASSIGNED       accepted offer
  -> AVAILABLE      rejected/expired/withdrawn offer

ASSIGNED
  -> EN_ROUTE
  -> AVAILABLE      assignment ended before departure/reassigned/cancelled

EN_ROUTE
  -> AT_CUSTOMER
  -> AVAILABLE      job cancelled/reassigned/failed and assignment ended

AT_CUSTOMER
  -> SERVICING
  -> AVAILABLE      job terminal before service starts

SERVICING
  -> AVAILABLE      job terminal/completed and assignment ended

BREAK
  -> AVAILABLE
  -> ENDING

UNAVAILABLE
  -> AVAILABLE
  -> ENDING

ENDING
  -> ENDED

ABORTED             terminal emergency/failed start state
ENDED               terminal normal state
```

Rules:

- `ENDING` requires no active blocking assignment.
- `ABORTED` from an already operational state is an Admin/system emergency path only and requires active jobs/assets to be reconciled explicitly.
- Offer withdrawal occurs before entering BREAK/UNAVAILABLE if the driver is currently OFFERED.

## A.3 DispatchAttempt

```text
RUNNING
  -> OFFERING
  -> EXHAUSTED
  -> CANCELLED

OFFERING
  -> ASSIGNED
  -> RUNNING         recompute/continue after candidate result
  -> EXHAUSTED
  -> CANCELLED

ASSIGNED             terminal success
EXHAUSTED            terminal no-candidate result for this attempt
CANCELLED            terminal because job no longer needs this attempt
```

## A.4 DispatchOffer

```text
PENDING
  -> ACCEPTED
  -> REJECTED
  -> EXPIRED
  -> WITHDRAWN
```

All terminal. Exactly one ACCEPTED offer can become the current assignment for a given assignment cycle.

## A.5 ServiceJob

```text
DISPATCHING
  -> ASSIGNED         one sequential offer is live
  -> CANCELLED
  -> EXPIRED
  -> FAILED

ASSIGNED
  -> ACCEPTED         selected driver accepts; JobAssignment is created
  -> DISPATCHING      offer rejected/expired/withdrawn before acceptance
  -> REASSIGNING      provisional selection invalidated by operational change
  -> CANCELLED
  -> FAILED

ACCEPTED
  -> EN_ROUTE
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

EN_ROUTE
  -> ARRIVED
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

ARRIVED
  -> SERVICE_PREPARING
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

SERVICE_PREPARING
  -> CHARGING
  -> WRAP_UP          explicit zero-charge/aborted-service closeout only
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

CHARGING
  -> WRAP_UP
  -> FAILED

WRAP_UP
  -> COMPLETED
  -> FAILED

REASSIGNING
  -> DISPATCHING
  -> ASSIGNED
  -> CANCELLED
  -> FAILED

COMPLETED            terminal
CANCELLED            terminal
FAILED               terminal
NO_SHOW              terminal
EXPIRED              terminal
```

No reopening a terminal ServiceJob. Corrections are separate records/workflows.

## A.6 ChargingStartIntent

```text
REQUESTED
  -> ACCEPTED_FOR_DELIVERY
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

ACCEPTED_FOR_DELIVERY
  -> PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

REJECTED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

EXPIRED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

RECONCILIATION_REQUIRED
  -> ACTUALLY_STARTED           exact authoritative transaction evidence
  -> REJECTED                   exact command absence/rejection proves safe terminal result
  -> EXPIRED                    exact absence plus elapsed start window

ACTUALLY_STARTED               terminal for the start-intent state machine
```

No normal ChargingSession exists before `ACTUALLY_STARTED`. RemoteStart/protocol acknowledgement never creates one.

## A.7 ChargingSession and ChargingStopRequest

ChargingSession:

```text
ABSENT
  -> ACTIVE                    only from authoritative `transaction.started` evidence

ACTIVE
  -> STOP_PENDING              durable stop requested; physical transaction still open
  -> RECONCILIATION_REQUIRED  contradictory/missing predecessor/final evidence
  -> COMPLETED                 spontaneous authoritative physical completion is valid
  -> FAILED                    only under explicitly defined non-settleable failure semantics

STOP_PENDING
  -> ACTIVE                    stop command definitively rejected while physical session remains active
  -> RECONCILIATION_REQUIRED
  -> COMPLETED                 authoritative physical completion

RECONCILIATION_REQUIRED
  -> ACTIVE                    exact evidence proves still active
  -> STOP_PENDING              exact evidence proves stop still pending
  -> COMPLETED                 exact completed transaction passes full identity/meter/time validation

COMPLETED                     terminal immutable physical/commercial completion
FAILED                        terminal only when policy explicitly permits; raw evidence remains retained
```

ChargingStopRequest is a separate durable command/request record. A RemoteStop acknowledgement can advance stop-command progress but cannot set the ChargingSession to `COMPLETED`.

## A.8 HAL Start/Stop Command and Generic Charger Operation

HAL charging command:

```text
PERSISTED
  -> PENDING_DELIVERY
  -> EXPIRED

PENDING_DELIVERY
  -> PERSISTED                 startup recovery only while transmission is proven not attempted
  -> DELIVERY_ATTEMPTED

DELIVERY_ATTEMPTED
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> AMBIGUOUS
  -> MATERIALIZED              authoritative start correlation may race command-result bookkeeping

OCPP_ACCEPTED
  -> MATERIALIZED
  -> AMBIGUOUS                 only when later command-result bookkeeping becomes uncertain

OCPP_REJECTED
  -> MATERIALIZED              contradictory later physical start is reconciliation evidence, never silently discarded

AMBIGUOUS
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> MATERIALIZED
  -> EXPIRED                   only when exact evidence proves no physical materialization and contract permits terminalization

SUPERSEDED / EXPIRED / MATERIALIZED are non-dispatchable.
```

Generic administrative charger operations use the separate CMS dispatch states:

```text
PERSISTED
-> DISPATCH_CLAIMED
-> DELIVERY_ATTEMPTED
-> HAL_ACCEPTED | OCPP_CONFIRMED | RECONCILIATION_REQUIRED | CONFIRMED_ABSENT
```

A deadline or process restart MUST NOT make `DELIVERY_ATTEMPTED`, `HAL_ACCEPTED`, `AMBIGUOUS`, or `RECONCILIATION_REQUIRED` replayable. Exact-ID evidence resolves uncertainty.

## A.9 Payment

```text
CREATED
  -> PENDING
  -> FAILED
  -> CANCELLED

PENDING
  -> AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

CAPTURED
  -> REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED

REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED
  -> CAPTURED          refund attempt failed; captured payment remains

PARTIALLY_REFUNDED
  -> REFUND_PENDING
  -> REFUNDED

FAILED                terminal payment attempt
CANCELLED             terminal payment attempt
REFUNDED              terminal fully refunded state
```

Provider events may arrive out of order. Transition logic uses provider identity and reconciled facts, not arrival order alone.

## A.10 Refund

```text
REQUESTED
  -> SUBMITTED
  -> CANCELLED

SUBMITTED
  -> SUCCEEDED
  -> FAILED

SUCCEEDED             terminal
FAILED                terminal for this refund operation; a new reconciled retry uses controlled identity semantics
CANCELLED             terminal
```

## A.11 Invoice

```text
PENDING
  -> GENERATING
  -> VOIDED

GENERATING
  -> READY
  -> FAILED

FAILED
  -> GENERATING       explicit retry
  -> VOIDED

READY
  -> VOIDED           only if business/legal process permits; artifact remains historical

VOIDED                terminal
```

READY artifact bytes are immutable.

## A.12 PricingPolicy and CompensationPolicy

```text
DRAFT -> ACTIVE -> RETIRED
```

A RETIRED policy is not reactivated. Create/activate a new version instead.

## A.13 SupportTicket

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> OPEN | CLOSED
CLOSED -> OPEN
```

Same-state mutation is side-effect-free.

## A.14 Incident

```text
OPEN
  -> INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

MITIGATED
  -> INVESTIGATING
  -> RESOLVED
  -> CLOSED

RESOLVED
  -> CLOSED
  -> INVESTIGATING    explicit reopen with reason

CLOSED
  -> INVESTIGATING    explicit reopen with reason
```

Reopen events are auditable.

## A.15 AssetMismatchReport

```text
MISMATCH_REPORTED
  -> ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

CONFIRMED_CORRECTION -> RESOLVED
EXPECTED_RESTORED    -> RESOLVED
REASSIGNED           -> RESOLVED
REJECTED_REPORT      -> RESOLVED
RESOLVED             terminal
```

---

# Appendix B. Mandatory Database Constraints and Indexes

Application validation improves errors. PostgreSQL constraints preserve truth under concurrency.

## B.1 Identity/session

- unique normalized login identifier according to chosen auth strategy;
- session token identifiers unique;
- revoked/expired session indexes for cleanup;
- admin role/capability foreign keys;
- no capability name duplicates.

## B.2 Customer

- `customer_profiles.account_id` unique;
- active saved vehicle belongs to exactly one customer;
- active saved address belongs to exactly one customer;
- partial unique index: at most one active default address per customer;
- registration number uniqueness is not globally assumed for incomplete/temporary customer metadata unless business verification requires it.

## B.3 Driver

- `driver_profiles.account_id` unique;
- one driver profile per source application unless explicit migration path says otherwise;
- only one nonterminal application per account if repeat applications are not supported;
- licence/document identifiers may have uniqueness checks where legally/business appropriate, with careful privacy handling.

## B.4 Fleet

- service vehicle registration number unique among non-retired canonical inventory;
- charger asset tag unique;
- charger serial number unique where manufacturer serial is trusted/required;
- HAL identity unique among active charger mappings;
- `(charger_id, connector_number)` unique;
- no overlapping active exclusive charger-to-vehicle pairing periods when physical exclusivity applies.

## B.5 Duty/claims

- partial unique: one nonterminal DutySession per driver;
- partial unique: one unreleased exclusive vehicle claim per vehicle;
- partial unique: one unreleased exclusive charger claim per charger;
- claim foreign key to active DutySession;
- one open break/unavailability interval of the same incompatible class if semantics require.

## B.6 Dispatch

- `dispatch_attempts(service_job_id, attempt_number)` unique;
- one candidate row per attempt + duty session;
- one offer identity unique;
- one live provisional offer per ServiceJob in the initial sequential strategy;
- one current accepted/active assignment enforced through serialized job update + partial unique current-assignment constraint;
- offer acceptance cannot reference a different driver/duty than the offer row.

## B.7 ServiceJob

- `job_number` unique;
- immutable ownership customer ID after creation unless a dedicated migration/correction framework explicitly exists;
- current assignment FK nullable but must point to same ServiceJob, enforced using composite unique/FK pattern where practical;
- event IDs unique;
- event transition data check constraints for required fields where practical.

## B.8 Charging

- ChargingStartIntent idempotency unique in actor/job/start-attempt scope;
- at most one unresolved start intent for the same ServiceJob + effective charger/connector when policy forbids parallel starts;
- one immutable `cms_command_id` per logical start or stop command;
- one durable `hal_command_id` maps to only its originating CMS command identity;
- one-use charging credential hash is unique and cannot be rebound to another start intent;
- HAL `fact_id` unique; same fact ID with different immutable digest/content is an integrity violation, never overwrite;
- accepted fact receipt and its CMS projection/event commit atomically;
- connection, connector, meter, and SoC projections advance only on their own monotonic sequences;
- one `hal_transaction_id` and one exact OCPP transaction ID chain cannot materialize multiple CMS ChargingSessions;
- one ChargingSession belongs to exactly one ServiceJob, while one ServiceJob may own multiple sequential ChargingSessions;
- meter observation dedupe uses immutable fact/sample identity and sequence, not timestamp alone;
- completed session final meter cannot regress below accepted start/latest eligible cumulative meter except the explicitly documented one-Wh quantization normalization rule if that rule is implemented;
- generic administrative charger-operation dispatch destination/parameters become immutable before possible delivery.

## B.9 Pricing

- policy version unique per policy lineage/name as modeled;
- no mutation of ACTIVE/RETIRED rule version through normal update API;
- no overlapping ACTIVE policy effective windows for the same global scope unless the engine explicitly supports scoped multiple policies;
- finalized line items immutable.

## B.10 Payments/refunds

- provider order ID unique when non-null;
- provider payment ID unique when non-null;
- provider webhook event ID unique;
- idempotency key unique in actor/operation scope;
- refund provider reference unique when non-null;
- database or transactional check prevents cumulative successful/pending refundable amount from exceeding captured amount.

## B.11 Invoice

- one active canonical invoice per ServiceJob/document type unless version/corrective-document semantics explicitly allow more;
- READY invoice has non-null storage ref, checksum, renderer version, issued timestamp;
- artifact metadata immutable after READY except delivery metadata.

## B.12 Compensation

- one finalized compensation snapshot per ServiceJob + assignment + calculation version;
- line item belongs to snapshot driver/job;
- finalized line items immutable;
- adjustments append only.

## B.13 Rating

- unique `(service_job_id, customer_id)`;
- rating check `1 <= rating <= 5`.

## B.14 Support

- channel/owner checks ensure CUSTOMER_PLATFORM requires customer owner and no driver owner;
- DRIVER_PLATFORM requires driver owner and no customer owner;
- message actor ownership is tied to ticket owner where applicable;
- reply idempotency key unique within ticket/actor scope.

## B.15 Query indexes

Create indexes from actual query plans, but baseline indexes must support:

- jobs by status + updated/created time;
- jobs by customer/driver/current assignment;
- duty sessions by driver/status;
- active claims by asset;
- location projection by geospatial search strategy;
- schedules/occurrences by driver/time;
- offers by driver/status/expiry;
- payments by job/status/provider IDs;
- invoices by job/status;
- compensation by driver/date/job;
- support by owner/status/updated time;
- incidents by status/severity/job/asset;
- HAL facts by charger/time/transaction;
- HAL operations by charger/state/created time.

Use PostGIS only if geospatial complexity/query scale justifies it. If adopted, make it an explicit project dependency and use proper geography indexes rather than handwritten distance SQL everywhere.

---

# Appendix C. Canonical Error Code Registry

HTTP status and machine error code are both part of the contract.

## C.1 Common

```text
400 INVALID_REQUEST
400 VALIDATION_FAILED
401 UNAUTHENTICATED
403 FORBIDDEN
404 RESOURCE_NOT_FOUND
409 VERSION_CONFLICT
409 IDEMPOTENCY_KEY_REUSED
409 STATE_CONFLICT
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE
```

Privacy-sensitive ownership failures SHOULD use `404 RESOURCE_NOT_FOUND` instead of revealing that another user's resource exists.

## C.2 Driver/duty

```text
409 DRIVER_NOT_ELIGIBLE
409 DRIVER_ALREADY_ON_DUTY
409 DUTY_NOT_ACTIVE
409 DUTY_HAS_ACTIVE_JOB
409 VEHICLE_ALREADY_CLAIMED
409 CHARGER_ALREADY_CLAIMED
409 ASSET_NOT_OPERATIONAL
409 ASSET_PAIRING_MISMATCH_BLOCKED
409 CHARGER_HAL_IDENTITY_UNKNOWN
409 DRIVER_LOCATION_STALE
```

## C.3 Dispatch/job

```text
409 OFFER_EXPIRED
409 OFFER_NO_LONGER_AVAILABLE
409 JOB_NOT_ASSIGNABLE
409 JOB_INVALID_TRANSITION
409 JOB_ALREADY_TERMINAL
409 JOB_HAS_ACTIVE_CHARGING
422 NO_ELIGIBLE_DRIVER
422 CUSTOMER_LOCATION_UNSERVICEABLE
422 CUSTOMER_VEHICLE_INCOMPATIBLE
```

`NO_ELIGIBLE_DRIVER` may be represented as job/dispatch state rather than direct request failure depending on operation.

## C.4 Charging/HAL

```text
409 CHARGING_ALREADY_ACTIVE
409 CHARGING_NOT_ACTIVE
409 CHARGING_START_IN_PROGRESS
409 RECONCILIATION_REQUIRED
409 HAL_COMMAND_IDEMPOTENCY_CONFLICT
409 HAL_FACT_INTEGRITY_VIOLATION
409 HAL_START_EVIDENCE_CONFLICT
409 CHARGING_STOP_IN_PROGRESS
410 CHARGING_START_EXPIRED
422 CHARGER_CAPABILITY_UNSUPPORTED
422 CONNECTOR_INCOMPATIBLE
503 HAL_UNAVAILABLE
503 CHARGER_MAPPING_UNAVAILABLE
```

## C.5 Payments/invoices

```text
409 PAYMENT_ALREADY_CAPTURED
409 PAYMENT_AMOUNT_MISMATCH
409 REFUND_EXCEEDS_REFUNDABLE_AMOUNT
409 REFUND_ALREADY_IN_PROGRESS
422 PAYMENT_VERIFICATION_FAILED
503 PAYMENT_PROVIDER_UNAVAILABLE
409 INVOICE_NOT_READY
409 INVOICE_ALREADY_READY
```

## C.6 Policies

```text
409 POLICY_VERSION_CONFLICT
409 POLICY_EFFECTIVE_RANGE_CONFLICT
409 ACTIVE_POLICY_IMMUTABLE
422 RULE_CONFIGURATION_INVALID
```

---

# Appendix D. Initial Operational Defaults and Knobs

These values are implementation defaults, not eternal business rules. They live in validated configuration or Admin policy and can be changed without changing semantics.

## D.1 API

```text
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100
DEFAULT_TIMEZONE=Asia/Kolkata
```

## D.2 Dispatch

Initial normal strategy:

```text
SEQUENTIAL
```

`DIRECT_ASSIGNMENT` is an explicit Admin action. `BATCHED` is not implemented initially.

No hard-coded offer timeout or scheduled dispatch lead time is mandated by architecture because those materially affect field operations. They MUST be explicit configuration before shared staging is enabled. Startup should reject an environment that enables dispatch without required timing values.

Required knobs:

```text
DISPATCH_OFFER_TTL_SECONDS
DISPATCH_RETRY_MIN_SECONDS
DISPATCH_RETRY_MAX_SECONDS
SCHEDULED_DISPATCH_LEAD_MINUTES
DISPATCH_MAX_LOCATION_AGE_SECONDS
ARRIVAL_VALIDATION_RADIUS_METERS
```

## D.3 Location

Client reporting cadence is a mobile-product/battery tradeoff, so the server defines freshness/maximum ingest rate, while Driver App chooses cadence within contract.

Server MUST reject abusive/implausible rates and accept batch recovery for offline periods.

## D.4 Workers

Every worker has configurable:

```text
BATCH_SIZE
POLL_INTERVAL
LEASE_DURATION
MAX_ATTEMPTS or terminal policy
BACKOFF_MIN
BACKOFF_MAX
```

No worker may use an unbounded immediate retry loop.

## D.5 Realtime

Required knobs:

```text
MAX_CONNECTIONS_PER_ACCOUNT
HEARTBEAT_INTERVAL
CLIENT_IDLE_TIMEOUT
MAX_OUTBOUND_QUEUE_PER_CONNECTION
```

Backpressure disconnects a slow client rather than consuming unbounded memory. Client recovers with REST.

---

# Appendix E. Operational Recovery Playbooks

These are behavioral playbooks. Exact shell commands belong in environment-specific operations docs.

## E.1 Driver app loses connectivity while en route

1. Server keeps assignment/job authoritative.
2. Location becomes stale after configured threshold.
3. Admin sees stale-location warning.
4. Driver app reconnects and fetches current duty/job via REST.
5. Buffered valid location samples may upload in batch.
6. No assignment is automatically cancelled solely because one realtime socket dropped.
7. Escalation/reassignment follows dispatch operations policy if staleness exceeds business threshold.

## E.2 Driver app loses connectivity during charging

1. HAL continues owning physical charger truth independently of Driver App.
2. CMS continues ingesting HAL facts.
3. User/Admin can still see charging projection if CMS/HAL links remain healthy.
4. Reconnected Driver App fetches job/charging state.
5. Never infer stop/start from Driver App reconnect state.

## E.3 CMS temporarily unavailable during active charging

1. HAL persists operation/transaction/facts locally.
2. Charger session continues according to physical/protocol reality.
3. HAL fact outbox retries delivery.
4. CMS restart recovers database state.
5. HAL delivers missed facts idempotently.
6. CMS reconciles transaction links/projections.
7. No new physical command is replayed unless operation identity proves it safe.

## E.4 HAL restarts during active charging

1. HAL reconnect supervisor restores charger connection.
2. Protocol adapter reconciles active transaction state.
3. Existing stable HAL transaction is recovered or a reconciliation record explains identity change where protocol makes exact restoration impossible.
4. CMS receives no duplicate semantic start if same transaction is proven.
5. Raw evidence links restart/reconnect chain.

## E.5 Start command times out

1. CMS marks the existing ChargingStartIntent/command `RECONCILIATION_REQUIRED` when RequestStart may have crossed the boundary.
2. Keep the original `cms_command_id`, hold/reservation, start intent, one-use credential binding, and immutable destination evidence. Do not create a replacement start automatically.
3. Reconcile `GET /v1/remote-commands?cms_command_id={uuid}` by the exact original command identity.
4. If HAL returns the exact command, project that command state and continue waiting/reconciling for authoritative transaction evidence.
5. If HAL returns canonical `404` for that exact durable command and CMS proves no materialized session exists, atomically release only the still-reserved commercial hold/reservation and terminalize the intent `REJECTED` or `EXPIRED` according to its window.
6. For an accepted/unmaterialized start past the reconcile threshold, query `GET /v1/transactions?cms_start_intent_id={uuid}`. A matching transaction uses the same locked materializer as a normal `transaction.started` fact.
7. Any non-404 lookup failure or conflicting/malformed evidence keeps reconciliation state; it never becomes absence by timeout.
8. Late physical-start evidence after `REJECTED`/`EXPIRED` is retained and moves the attempt into reconciliation rather than silently fabricating a normal session.
9. If unresolved beyond the operational horizon, alert Technical Admin while continuing safe exact-ID recovery according to retention policy.

## E.6 Payment API response lost after capture

1. Keep logical payment identity/provider order.
2. Do not create a second charge automatically.
3. Reconcile provider state by provider identity/webhook/API.
4. Mark CAPTURED idempotently if proven.
5. User client retry returns same logical payment result.

## E.7 Invoice generation fails

1. Payment/job truth remains untouched.
2. Invoice stays FAILED/PENDING with error classification.
3. Worker retries retryable renderer/storage errors.
4. Admin sees failure and may explicitly retry.
5. READY is never set without verified artifact metadata/checksum.

## E.8 No drivers available

1. DispatchAttempt becomes EXHAUSTED.
2. Job remains truthfully unassigned/dispatching subject to policy.
3. User receives availability/delay state.
4. Retry worker reevaluates fresh candidates, not stale ranking.
5. Admin sees reason/age.
6. Job expires only under explicit policy/deadline.

## E.9 Assigned driver breaks down

1. Driver reports problem/incident.
2. Current assignment ends with reason.
3. Duty becomes UNAVAILABLE or ends depending reality.
4. Job enters REASSIGNING.
5. New dispatch attempt selects another eligible duty.
6. Historical assignment remains.
7. Compensation uses facts attributable to each assignment.

## E.10 Customer location changes after assignment

1. User cannot silently overwrite ServiceJob service-address snapshot.
2. Submit relocation/change request.
3. Backend assesses serviceability, price impact, and current assignment feasibility.
4. If accepted, create an explicit address-change event/new operational snapshot version while preserving original request snapshot.
5. Requote/reassign if required.
6. If not supported initially, customer must cancel and create a new request; API says so explicitly.

The initial implementation SHOULD choose one of these semantics before enabling mid-job relocation. Do not silently mutate coordinates.

---

# Appendix F. Acceptance Evidence Matrix

A claim of completion should name evidence level.

| Claim | Minimum evidence |
| --- | --- |
| Domain implemented | source + unit tests |
| DB invariant enforced | disposable PostgreSQL integration test |
| API contract implemented | OpenAPI/runtime parity + auth tests |
| Worker reliable | retry/lease/integration tests + runtime backlog metrics |
| CMS-HAL command flow works | service integration test |
| OCPP adapter works logically | scripted simulator acceptance |
| Charger model works physically | real hardware acceptance |
| Payment flow works | provider test/live acceptance at claimed boundary |
| Refund works | provider acceptance |
| Invoice generation works | generated artifact checksum + authorized download |
| Email/push works | provider accepted delivery request; do not claim recipient read |
| Deployment works | target runtime health + changed-feature smoke + logs |
| Rollback works | exercised compatible rollback/recovery path |
| Production ready | project-level Definition of Done plus all critical external boundaries accepted |

---

# Appendix G. Blueprint Change Control

Once implementation starts, this blueprint itself follows change discipline.

A semantic change must identify:

1. reason/new evidence;
2. affected actors;
3. affected state machines;
4. persistence/migration impact;
5. API/OpenAPI impact;
6. worker/realtime impact;
7. security/privacy impact;
8. historical compatibility;
9. rollout/rollback plan;
10. affected tests/docs;
11. whether existing mobile/frontends remain compatible.

Do not update only this document while leaving runtime semantics unchanged, and do not change runtime semantics without updating the authoritative contract set.

