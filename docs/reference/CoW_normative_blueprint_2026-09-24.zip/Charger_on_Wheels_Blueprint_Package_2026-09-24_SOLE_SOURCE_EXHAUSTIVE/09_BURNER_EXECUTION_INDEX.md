> GENERATED NON-NORMATIVE VIEW. The content below is copied from Appendix H of `01_CANONICAL_FULL_BLUEPRINT.md`; the verifier requires exact equality.

# Appendix H. Exact Burner Execution Claim Map

This appendix removes ambiguity from the short burner titles in Section 64. It is normative because it is part of the canonical blueprint. Every burner still requires a repository work item using Section 63 before code changes begin.

For every burner, the work item MUST explicitly list: objective; claimed surfaces; dependencies; canonical sections; schema/migration impact; API/contract impact; authorization; idempotency/concurrency; worker/realtime impact; failure/recovery; audit/observability; tests; documentation; operational impact; evidence target; non-goals; rollback/forward-fix considerations; and current unverified boundary.

A burner is not allowed to invent a competing semantic model because its title is short. The sections named below, the state-machine registry, DB constraints, error registry, operational defaults, recovery playbooks, and acceptance matrix are the source of detail.

## H.00 Program 0 - Repository and engineering authority

Program dependency baseline: none beyond the package and chosen development infrastructure. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B00.1 CMS repository bootstrap

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B00.2 HAL repository bootstrap

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B00.3 Disposable integration DB harness

- **Canonical claim:** Sections 4-6, 45-46, 57-63; Appendices C-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** none beyond the package and chosen development infrastructure; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.01 Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

Program dependency baseline: Program 0 CMS foundation. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B01.1 Account/session authentication

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.2 Admin capability engine

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.3 Audit foundation

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.4 Durable idempotency primitive

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B01.5 Durable outbox and worker framework

- **Canonical claim:** Sections 7-9, 35-42, 45-46, 57-63; Appendices B-D, F-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 0 CMS foundation; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.02 Program 2 - Customer master data

Program dependency baseline: Program 1 account/auth/idempotency/audit primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B02.1 Customer profile

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.2 Saved vehicles

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.3 Saved addresses/default handling

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.4 Snapshot schemas/builders

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B02.5 Temporary object and promotion behavior

- **Canonical claim:** Sections 10, 31, 34-36, 40-41, 50, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/idempotency/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.03 Program 3 - Driver recruitment and workforce

Program dependency baseline: Program 1 account/auth/audit primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B03.1 Driver application lifecycle

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.2 Secure document storage + versioned KYC review

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Do not choose a production KYC retention/storage policy before Section 69.5 is resolved; keep storage interface and encryption/access contract explicit.

### H.B03.3 Driver profile creation/onboarding

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.4 Eligibility engine + blocking reasons

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B03.5 Suspension/reinstatement/offboarding

- **Canonical claim:** Sections 11, 32-34, 36, 40-41, 50, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 account/auth/audit primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.04 Program 4 - Fleet and inventory

Program dependency baseline: Program 1 authorization/audit primitives; charger identity created here is later shared with HAL. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B04.1 Vehicle inventory/history

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.2 Charger inventory/connectors

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.3 Pairing history

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.4 Maintenance/lifecycle intervals

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.5 Admin asset assignment

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.6 Derived availability projection

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B04.7 Mobile energy-store registry/capability foundation (conditional)

- **Canonical claim:** Sections 12, 33-36, 41, 50, 52-55, 57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 1 authorization/audit primitives; charger identity created here is later shared with HAL; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Conditional gate: follow Section 53 exactly; skipping requires a recorded NOT_APPLICABLE decision.

## H.05 Program 5 - Scheduling, duty, location

Program dependency baseline: Programs 3-4 workforce/fleet truth plus Program 1 primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B05.1 Schedules and materialized occurrences

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.2 DutySession lifecycle

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.3 Exclusive asset claim constraints/concurrency tests

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.4 Driver asset mismatch reporting

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.5 Break/availability intervals

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.6 Location ingestion/current projection/freshness

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.7 Driver geofence and effective area

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B05.8 Mobile energy observation/reservation foundation (conditional)

- **Canonical claim:** Sections 13-14, 32-38, 41-42, 50, 53-55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 3-4 workforce/fleet truth plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Conditional gate: follow Section 53 exactly; skipping requires a recorded NOT_APPLICABLE decision.

## H.06 Program 6 - Service request, pricing foundation, ServiceJob core

Program dependency baseline: Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B06.1 ServiceRequest

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.2 Serviceability validation

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.3 First production slice of the final pricing interface

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B06.4 Quote acceptance -> ServiceJob snapshots

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B06.5 ServiceJob state machine/event history

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B06.6 Cancellation/no-show reason framework

- **Canonical claim:** Sections 16, 21, 31, 34-36, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 2 customer master data plus Program 1 primitives; B06.3 uses Section 21.0; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.07 Program 7 - Dispatch

Program dependency baseline: Programs 5-6. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B07.1 Eligibility engine

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.2 Ranking engine

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.3 DispatchAttempt/Candidate persistence

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.4 Sequential offer workflow

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.5 Atomic offer acceptance

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.6 Assignment and Driver current-job contract

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.7 Reassignment

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.8 No-candidate retry/scheduled dispatch worker

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B07.9 Admin diagnostics/direct assignment

- **Canonical claim:** Sections 15, 17, 32-39, 49-52, 55, 57; Appendices A-B, C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5-6; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.08 Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

Program dependency baseline: HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B08.1 HAL repository/bootstrap contract

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.2 CMS-HAL service authentication

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.3 Charger/connector mapping registry

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.4 Connection runtime and restart fencing

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.5 Connector status runtime

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.6 Durable HAL command store and start/stop lifecycle

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.7 One-use charging credential and OCPP authorization bridge

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.8 OCPP 1.6 transaction materialization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.9 MeterValues normalization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.10 Independent SoC normalization

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.11 Stop workflow and automatic limit sources

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.12 Transaction completion truth

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.13 Durable fact outbox

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.14 CMS fact ingress and projection transaction

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.15 Exact command and transaction reconciliation APIs

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.16 Generic administrative charger operation boundary

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.17 Isolated charger-operation recovery worker

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.18 Diagnostic trace plane

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.19 Scriptable simulator

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

### H.B08.20 Cross-repository contract fixtures

- **Canonical claim:** Sections 18-20, 34-46, 50, 54, 57-61; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** HAL bootstrap plus stable CMS charger/connector identity from Program 4 and the frozen Sections 18-20 contract; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Keep protocol-specific/OCPP details inside HAL/adapters; CMS sees normalized semantic commands/facts only.

## H.09 Program 9 - CMS charging integration and app projections

Program dependency baseline: Programs 6-8 and assignment/job identity from Program 7. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B09.1 Charging admission model

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.2 ChargingStartIntent state machine

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.3 Immutable CMS START command record

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.4 Start orchestration and post-commit mapping reconfirmation

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.5 Start ambiguity reconciler

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.6 `transaction.started` -> ChargingSession materialization

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.7 Meter/SoC CMS projection

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.8 Charging stop request

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.9 `transaction.completed` finalization

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.10 Missing-completion recovery

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.11 Multiple ChargingSessions per ServiceJob

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.12 Runtime availability and chargeability

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.13 User charging read/progress contract

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.14 Driver charging contract

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.15 Admin technical charging views

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.16 User live-job snapshot/SSE integration

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

### H.B09.17 End-to-end charging acceptance

- **Canonical claim:** Sections 18-20, 31-39, 47-50, 54, 57; Appendices A-B, C-E, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 6-8 and assignment/job identity from Program 7; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Never infer physical start/stop from command acknowledgement; exact HAL facts/reconciliation are authoritative.

## H.10 Program 10 - Full pricing engine

Program dependency baseline: B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B10.1 Versioned pricing policy/rule persistence

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.2 Deterministic rule evaluator

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.3 Quote estimation line items

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.4 Final source-fact binding

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.5 Final pricing line items/snapshot

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Use the stable Section 21.0 evaluator/line-item/snapshot semantics; do not create a parallel or throwaway pricing model.

### H.B10.6 Cancellation/no-show components

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.7 Time/date/zone modifiers

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B10.8 Admin policy editor contract

- **Canonical claim:** Sections 21, 31, 33-39, 47, 50-51, 57; Appendices A-B, C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** B06.3 stable pricing contract; finalization additionally depends on authoritative facts from Program 9; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.11 Program 11 - Payments, refunds, tax, invoices

Program dependency baseline: Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B11.1 Razorpay order/payment integration

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.2 webhook/idempotent reconciliation

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.3 refund workflow

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.4 GST snapshot calculation

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.5 invoice renderer/storage/version/checksum

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.6 invoice worker/retry/download

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

### H.B11.7 mail/notification intent for invoice

- **Canonical claim:** Sections 22-24, 31, 33-42, 47, 50, 57-61; Appendices A-B, C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 9-10 plus the Section 69 payment/GST decisions required by the specific burner; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** Provider/UI success is not settlement; reconcile by durable provider identity and preserve idempotency.

## H.12 Program 12 - Driver compensation

Program dependency baseline: Programs 5, 7, 9 and the relevant finalized source facts. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B12.1 Versioned policy/rules

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.2 deterministic evaluator

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.3 time-boundary/interval prorating

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.4 source-fact binding

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.5 line-item ledger

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.6 reassignment allocation

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.7 adjustments

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.8 Driver summary/history

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B12.9 Admin views/exports

- **Canonical claim:** Sections 25, 32-39, 41-42, 50, 56-57; Appendices B-C, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Programs 5, 7, 9 and the relevant finalized source facts; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.13 Program 13 - Product completeness

Program dependency baseline: the domain feature being completed plus Program 1 primitives. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B13.1 User ratings/reviews

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.2 Customer support

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.3 Driver support

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.4 Incident management

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.5 Notification preferences/delivery

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.6 Admin operational dashboard

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.7 Async exports

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B13.8 retention/cleanup jobs

- **Canonical claim:** Sections 26-28, 31-43, 50, 54-57; Appendices B-C, E-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** the domain feature being completed plus Program 1 primitives; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

## H.14 Program 14 - Realtime hardening

Program dependency baseline: durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B14.1 authenticated subscriptions

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.2 per-resource versioning

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.3 reconnect/catch-up guidance

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.4 user projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.5 driver projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.6 admin projections

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.7 backpressure/disconnect behavior

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

### H.B14.8 realtime-vs-REST consistency E2E tests

- **Canonical claim:** Sections 29, 31-34, 37-39, 42, 47-50, 54, 57; Appendices C-D, F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** durable REST/domain projections from the implemented programs; realtime never substitutes for missing durable truth; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** REST/durable projection remains reconnect/catch-up authority; realtime is never the only truth.

## H.15 Program 15 - Production hardening

Program dependency baseline: all production-targeted programs relevant to the acceptance claim. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B15.1 security review

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.2 DB backup/restore drill

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.3 worker/backlog alerting

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.4 load tests for location/realtime/dispatch

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.5 Razorpay production-readiness checks

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.6 mail/push production acceptance

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.7 physical charger certification matrix

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.8 operational runbooks/on-call drills

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.9 staging full-day/long-session soak

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

### H.B15.10 release/rollback drill

- **Canonical claim:** Sections 40-46, 57-61, 67; Appendices B-G. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** all production-targeted programs relevant to the acceptance claim; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.
- **Special rule:** State the acceptance evidence class from Section 0.5; do not promote simulator/runtime evidence to physical/provider acceptance.

## H.16 Program 16 - Protocol expansion

Program dependency baseline: Program 8 normalized HAL core and stable contract fixtures. Section 65 remains authoritative for cross-program ordering and any more specific dependency.

### H.B16.1 OCPP 2.0.1 adapter

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.2 adapter parity matrix

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.3 OCPP 2.1 if hardware/business requires

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.

### H.B16.4 vendor-specific extensions behind adapter capability interfaces

- **Canonical claim:** Sections 19-20, 57, 65-66; Appendices A, C-F. The burner implements only the subset required by its title and any explicit Section 64 deliverables.
- **Dependencies:** Program 8 normalized HAL core and stable contract fixtures; plus any earlier burner whose durable identity/state this burner consumes. Do not duplicate a prerequisite locally to avoid the dependency.
- **Persistence/contracts:** add or change only the tables/constraints/indexes, API operations, event/outbox schemas, config keys, and projections required by the claimed behavior. Applied migrations are immutable; later corrections are forward migrations.
- **Correctness:** enforce authoritative ownership, authorization/privacy, idempotency, transaction/concurrency boundaries, historical immutability, and recovery semantics from the cited canonical sections and Appendices A-E.
- **Verification:** focused unit/state-machine tests plus disposable PostgreSQL integration/concurrency tests whenever persistence is involved; route/OpenAPI parity for HTTP changes; simulator/service/provider/runtime/physical acceptance only when the burner claims that boundary. Record the evidence class from Section 0.5.
- **Completion:** repository-native docs/work item/OpenAPI/handoffs and project-state evidence agree; no unrelated burner is smuggled in; remaining external boundary is named rather than guessed.


# Appendix I. Normative Package Annex Registry

The following files are incorporated into the pre-implementation normative package set. Each owns only its declared scope; cross-domain ownership and fundamental invariants remain governed by this core blueprint.

```text
10 Realtime SSE and notifications
11 HTTP API/auth/payload standard
12 Persistence schema/data dictionary
13 State authorization/transition registry
14 Workers/schedulers/idempotency/recovery
15 Security/privacy/rate-limit/abuse model
16 Observability/SLO/alerting/runbook contract
17 Configuration/secrets/environment catalog
18 Test/fixture/simulator/acceptance specification
19 Deployment/backup/restore/release runbook
20 Frontend projection/integration contracts
21 Provider adapter/external dependency contracts
22 Repository bootstrap/coding/migration standard
23 Domain glossary/naming/enum registry
24 API endpoint/payload catalog
25 Durable event/outbox registry
26 Notification template/trigger registry
27 Business decision gates/policy register
28 Reference sequences/failure scenarios
29 Project execution playbook
30 Operations/Admin/support playbook
31 Data retention/export/privacy lifecycle
32 Physical hardware certification/protocol matrix
33 Package change-control/traceability
34 CMS-HAL wire contract/reconciliation
35 Dispatch/location/geofence/ETA contract
36 Pricing/tax/payment/refund/invoice contract
37 Driver compensation engine contract
38 Ratings/support/incident contract
39 Driver workforce/fleet/duty contract
40 Customer/service-request/ServiceJob contract
41 Audit/provenance/correction/manual-action contract
42 Transaction locking/concurrency/isolation contract
43 Time/timezone/calendar/precision/identifier contract
44 Admin capability/role/authorization catalog
45 Query/filter/sort/search/export contract
46 Sole-source coverage/traceability matrix
```

Machine restatements live under `registries/` and `schemas/`. `tools/verify_package.py` is the mandatory pre-handoff integrity/consistency gate.
