# EVCMS Go New - Full Continuity Handoff

**Prepared:** 2026-09-24  
**Purpose:** Drop-in continuity document for another AI or engineer. The goal is to let a new working session continue the EV-CMS Go project with minimal loss of project understanding, operational context, architectural intent, user preferences, and current backend state.

---

# 0. Read This First

This file is a continuity handoff, not executable authority.

When anything here conflicts with the repository, runtime, database, systemd, Caddy, or current Git history, **current source/runtime evidence wins**.

Before making any meaningful change:

1. Read repository `AGENTS.md`.
2. Read:
   - `README.md`
   - `docs/README.md`
   - `docs/DEVELOPMENT_PLAN.md`
   - `docs/PROJECT_STATE.md`
   - `docs/AI_CHANGELOG.md`
   - relevant active work items under `docs/work/active/`
3. For CPO backend work, read `docs/CPO_BACKEND_AGENT_HANDOFF.md`.
4. For User App work, read `docs/USERAPP_FE_HANDOFF.md` when frontend contract implications matter.
5. For SuperAdmin work, read `docs/SUPERADMIN_FRONTEND_HANDOFF.md`.
6. For runtime work, read `docs/guides/operations/dev-hosting.md`.
7. Inspect current Git HEAD, worktree, migration ledger, environment-key parity, service unit, listener, Caddy, and rollback path before operational changes.

Do not treat old chat claims or this file as stronger than current observed evidence.

---

# 1. User / Working Style Context

The user is informally "Akash"; use **Anubhab Dey** for official reports/signatures.

The user is the senior backend/infra/DevOps/IT person at a small startup and often works as the final technical owner. Responses should therefore optimize for actual operational correctness, not tutorial theater.

The user's core working principles are:

1. **Recursive full coverage** is the highest-order principle.
   - Expand every meaningful task into assumptions, dependencies, constraints, failure cases, side effects, rollback, recovery, verification, downstream consumers, documentation, and completion criteria.
   - Apply this recursively to the assistant's own work.

2. **Consistency** is immediately below recursive coverage.
   - Preserve terminology, semantics, assumptions, constraints, naming, contracts, state models, docs, and conclusions across turns and artifacts.
   - If reality changes, update all affected downstream layers consistently.

3. **Reality-first honesty and verification.**
   - Never claim something is deployed, working, migrated, emailed, sent, verified, or complete without actual evidence.
   - Clearly distinguish:
     - source-verified
     - test-verified
     - database-verified
     - runtime-verified
     - physical-hardware verified
     - inferred / unverified

4. **Front-load before consequential action.**
   - Before execution or design, inspect relevant assumptions, dependencies, blast radius, failure modes, rollback path, observability, and stop conditions.

5. **Anti-deferral.**
   - If a necessary safe action can be completed now, do it in the same turn instead of postponing it.

6. **Small coherent changes.**
   - Stable semantic core.
   - Explicit contracts.
   - Composition/config-driven capabilities.
   - Replaceable implementations.
   - Additive low-blast-radius evolution.
   - No hidden side effects.
   - Compromise only after good non-compromising designs are exhausted.

7. **Humans and computers are both first-class users.**
   - Logs, docs, APIs, CLIs, configuration, and workflows should be both human-legible and machine-precise.

8. **"Complete document" standard.**
   - A complete document must be sole-source, zero-assumption, exhaustive, end-to-end, operationally usable, and independent of chat history.
   - It should include prerequisites, contracts, exact procedures, verification, failure/recovery, maintenance, troubleshooting, limits, and definition of done.

9. **One burner / one prompt at a time** is preferred.
   - Finish and verify one coherent work item before beginning the next.

10. **No em dashes in user-facing prose.**
    - ASCII-first communication is preferred unless the task requires otherwise.

---

# 2. Project Identity

Repository:

`Transmogriffy-Global-Private-Limited/ev-cms-backend-new`

Language/runtime:

- Go 1.25
- Gin HTTP stack
- PostgreSQL is durable truth

The EV-CMS owns the commercial and administrative management plane for an EV charging network.

A separate OCPP HAL owns:

- charger connections
- OCPP protocol state
- exact OCPP transaction IDs
- raw meter communication
- charger-facing OCPP behavior

**CMS and HAL do not share a database.**

They communicate through explicit authenticated/idempotent service contracts.

Do not move OCPP protocol responsibility into CMS and do not make HAL own CMS commercial/admin truth.

---

# 3. Current Git / Deployment State

As of this handoff:

## Repository `main`

Current latest known `main` HEAD:

`dafcab3f11f403f4a70fd0d9f24064f3b873f3af`

Message:

`docs: record customer support rehost`

This is a documentation/rehost-record commit.

## Deployed application source

The currently deployed CMS binary was built from:

`ea0f8fe5d5a3c99370be3e86963408b475ee15f7`

That source includes:

- customer-to-CPO support
- migration 72
- migration 73
- migration 74
- publication-date correction for migration-74 docs

The later `dafcab3...` commit records deployment evidence and updates documentation. The running binary is therefore expected to report source revision `ea0f8fe...`, not `dafcab3...`.

## Branch relation

At handoff time:

- `main` is at `dafcab3...`
- `anubhab-work` is at `ea0f8fe...`
- therefore `anubhab-work` is one docs commit behind `main`

Verify this before relying on it.

---

# 4. Development VPS Shape

Current documented development deployment:

```text
HTTPS client
  -> Caddy :80/:443
  -> EV CMS 127.0.0.1:18080
  -> PostgreSQL devevcmsnewdb 127.0.0.1:5432
```

Public CMS development host:

`https://dev-evcmsnew.transev.site`

Systemd service:

`evcmsnew-dev.service`

The application listener is intentionally loopback-only.

The service runs the repository-local:

`builds/evcmsnew`

Environment comes from ignored `.env` / service environment.

Never expose `.env` values in chat, docs, logs, or commits.

---

# 5. Current Runtime Evidence

The customer-to-CPO support release was rehosted on 2026-09-23 from source `ea0f8fe...`.

Current recorded active binary SHA-256:

`28b6de6c028c4ccc44ad83d352e2904dba1173d7e7d8f381b3d0b7fe5bd215cc`

Recorded service state after deployment:

- service active
- zero restarts
- process/install hashes matched
- local health 200
- public HTTPS health 200
- readiness 200
- Swagger 200
- OpenAPI 200
- Caddy validates
- seven required/current workers healthy
- billing-maintenance worker separately disabled, not failed
- new support routes reject unauthenticated requests with 401
- migration 74 current
- `.env` mode 0600
- `.env` key names match `.env.example`
- no missing/extra/blank environment keys
- customer-support URL-template keys present

Current migration ledger high-water mark:

`000074_harden_customer_support_owner_immutability`

Migrations 72, 73, and 74 are applied to the development database.

---

# 6. Current Rollback Assets

For the customer-to-CPO support deployment:

Previous binary:

`/root/evcmsnew-backups/pre-customer-cpo-support-ea0f8fe-20260923T112639Z/evcmsnew.before`

Previous binary SHA-256:

`1a2819c96224d1016e3d2655b591993f405954cbe153faa71cfd6735e4e8d4b0`

Pre-migration PostgreSQL custom-format dump:

`/root/evcmsnew-backups/pre-customer-cpo-support-ea0f8fe-20260923T112639Z/devevcmsnewdb.dump`

Dump mode:

`0600`

Dump SHA-256:

`cf5e3ae8f82e2092ac2b68239a5be8d68e9edf47051c5aa2d9b2418c1ab4b4cd`

Do not improvise rollback. Inspect the hosting guide, migration down semantics, current database state, and whether a forward fix is safer.

---

# 7. Rehost Framework

An existing rehost framework already exists. Do not invent an ad hoc restart/deploy procedure without inspecting it.

Recent successful CMS rehost used:

```bash
rehost-evcmsnew -t 0 --no-tail
```

A generic helper also exists in the environment:

`/usr/local/bin/rehost-service`

Before deployment, inspect:

- `.bash_aliases` / shell aliases
- actual helper behavior
- systemd unit
- environment file
- listener
- Caddy route
- binary install path
- rollback behavior
- migration requirements
- logs

Important user rule:

**Never run `set -Eeuo pipefail` directly in an interactive SSH shell.**

If strict shell behavior is needed:

1. write a child script
2. run `bash -n`
3. execute the child script

Do not accidentally terminate the user's live interactive shell.

---

# 8. Canonical Architecture / Package Ownership

The repository operating contract assigns responsibilities approximately as follows:

- `main.go`
  - composes config, PostgreSQL, migrations, bootstrap, security, services, workers, router, graceful shutdown

- `src/routes/`
  - HTTP assembly
  - health/readiness
  - middleware order
  - OpenAPI/Swagger registration

- `src/auth/`
  - Platform and CPO administrative identities
  - administrative sessions
  - OTP / credential lifecycle

- `src/customerauth/`
  - CPO-local App Customer identity
  - customer sessions/auth
  - discovery
  - wallet
  - favorites
  - customer app functionality

- `src/cpo/`
  - CPO organization
  - memberships
  - capabilities / permissions
  - network
  - GST
  - tariffs
  - CPO-side administrative behavior

- `src/superadmin/`
  - SuperAdmin plane

- `src/platformops/`
  - Platform operational behavior

- `src/subscriptions/`
  - Platform/CPO subscription lifecycle

- `src/integrations/`
  - encrypted CPO integration credentials

- `src/mail/`
  - durable mail outbox + worker

- `src/security/`
  - crypto/security primitives

- `src/models/`
  - persistence mappings

- `db/migrations/`
  - immutable versioned PostgreSQL migrations

- `cmd/migrate/`
  - explicit migration command

Migrations already committed/applied are immutable. Add a forward migration.

---

# 9. Authentication and Tenant Model

There are intentionally separate identity planes.

## Administrative identities

Platform/CPO staff use the administrative `users` / membership model.

CPO administrative authority is capability-based.

A CPO is a tenant organization, not a global role.

Rules:

- derive tenant/CPO identity from trusted server-side/authenticated context
- do not trust arbitrary client-provided CPO IDs
- CPO roles are default permission bundles
- effective permission evaluation is authoritative
- explicit `DENY` overrides role defaults

## App Customer identities

Customers are **not** administrative `users`.

They are CPO-local customer identities.

Customer principal carries:

- CustomerID
- CPOID
- customer session identity

A compatibility `UserID` alias in customer principal refers to the Customer ID and must never be treated as a global `users.id`.

This distinction is especially important in support, ratings, wallet, charging, and audit actor persistence.

## CPO login behavior

Initial CPO administrative login uses:

`X-CPO-App-ID`

to select the active CPO context.

Do not reintroduce "enter CPO UUID every login" behavior.

---

# 10. Authorization Model

CPO capabilities are source-controlled.

Roles provide defaults.

Membership-level overrides can ALLOW/DENY.

**DENY wins.**

Do not authorize by role name when an endpoint has a documented capability.

For any new CPO operation:

1. identify semantic capability
2. add it to catalog only if necessary
3. define role defaults deliberately
4. use effective permission evaluation
5. test explicit DENY
6. document frontend behavior
7. never trust FE hiding as security

---

# 11. Current Customer-to-CPO Support Feature

This was the most recent major backend burner and is deployed.

The key design decision is:

**reuse one durable support core while separating channels semantically.**

Two support channels exist:

```text
CPO_PLATFORM
CPO staff <-> Platform SuperAdmin

CUSTOMER_CPO
App Customer <-> that customer's own CPO
```

These channels must never bleed into one another.

## Existing CPO-to-Platform routes

```text
GET  /api/v1/cpo/support
POST /api/v1/cpo/support
GET  /api/v1/cpo/support/{ticket_id}
POST /api/v1/cpo/support/{ticket_id}/replies

GET   /api/v1/platform/support/tickets
GET   /api/v1/platform/support/tickets/{ticket_id}
POST  /api/v1/platform/support/tickets/{ticket_id}/replies
PATCH /api/v1/platform/support/tickets/{ticket_id}/status
```

All legacy CPO/Platform paths explicitly filter `CPO_PLATFORM`.

## New User App routes

```text
GET  /api/v1/app/support/tickets
POST /api/v1/app/support/tickets
GET  /api/v1/app/support/tickets/{ticket_id}
POST /api/v1/app/support/tickets/{ticket_id}/replies
```

Customer identity/CPO identity are server-derived.

Customer can access only their own tickets.

Another customer, even in the same CPO, must receive a privacy-safe not-found result.

## New CPO customer-support routes

```text
GET   /api/v1/cpo/customer-support/tickets
GET   /api/v1/cpo/customer-support/tickets/{ticket_id}
POST  /api/v1/cpo/customer-support/tickets/{ticket_id}/replies
PATCH /api/v1/cpo/customer-support/tickets/{ticket_id}/status
```

No CPO "create ticket on behalf of customer" operation is part of this slice.

## New CPO permissions

```text
customer_support.read
customer_support.reply
customer_support.manage
```

Expected defaults:

- OWNER: all
- ADMIN: all
- OPERATOR: read/reply/manage
- VIEWER: read only

Explicit DENY remains authoritative.

## Customer-side privacy

User App sees author distinction only:

```text
CUSTOMER
CPO
```

The App Customer must not receive:

- CPO staff identity
- CPO staff email
- internal permissions
- staff audit identity
- platform-support internals

## CPO-side customer projection

CPO support views intentionally expose only minimal customer support identity:

```text
id
full_name
email
```

Do not add phone/security/auth internals without a concrete need.

CPO staff internal actor IDs may remain available on the CPO side for audit.

## Lifecycle

Status graph is reused:

```text
OPEN
IN_PROGRESS
RESOLVED
CLOSED
```

Transitions:

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> CLOSED | OPEN
CLOSED -> OPEN
```

Same-state status mutation is side-effect-free.

Customer reply behavior:

- reply to OPEN -> stays OPEN
- reply to IN_PROGRESS -> stays IN_PROGRESS
- reply to RESOLVED -> atomically reopens OPEN
- reply to CLOSED -> atomically reopens OPEN
- reopen clears `closed_at`
- reopen writes truthful immutable history

CPO reply does not silently change status.

## Reply idempotency

Replies require `idempotency_key`.

The durable design uses:

- ticket-row locking
- DB uniqueness/idempotency
- one message/event/mail intent for duplicate same-key retries

Do not replace this with in-memory dedupe.

## Queue semantics

CPO customer-support queue:

- default limit 20
- max 100
- deterministic order:
  `updated_at DESC, id DESC`
- keyset cursor:
  `before + before_id`
- filters:
  - status
  - customer_id
  - q

CPO `q` can match:

- ticket ID
- subject
- customer name
- customer email

Filters are applied in SQL **before LIMIT**.

Queue summaries do not include message bodies.

---

# 12. Support Migrations 72, 73, 74

## Migration 72

`000072_customer_cpo_support`

Introduced:

- support channel
- customer ownership
- customer actor columns
- channel actor checks
- composite ticket -> customer ownership
- customer-support mail-template catalog additions

Existing historical tickets classify as `CPO_PLATFORM`.

Rollback refuses while customer-support history exists instead of deleting history.

## Migration 73

`000073_harden_customer_cpo_support_actor_ownership`

Closed a database-level gap.

It binds customer actor identity directly to ticket ownership:

```text
(ticket_id, author_customer_id)
  -> support_tickets(id, customer_id)

(ticket_id, actor_customer_id)
  -> support_tickets(id, customer_id)
```

This means a CUSTOMER message/event cannot claim another customer, including another customer in the same CPO.

## Migration 74

`000074_harden_customer_support_owner_immutability`

Migration 73 initially used `ON UPDATE CASCADE`.

That would have allowed a direct ticket owner mutation to rewrite historical actor identity.

Migration 74 corrects this.

Current composite customer-actor FKs are:

```text
ON UPDATE RESTRICT
ON DELETE CASCADE
```

So changing a CUSTOMER_CPO ticket owner after customer-authored history exists fails rather than rewriting who historically authored that history.

This is deliberate immutable-history semantics.

---

# 13. Customer Support Notifications / Mail

Customer-to-CPO support uses durable outbox intents.

Templates include:

```text
CUSTOMER_CPO_SUPPORT_TICKET_CREATED
CUSTOMER_CPO_SUPPORT_TICKET_REPLY
CUSTOMER_CPO_SUPPORT_TICKET_STATUS_CHANGED
```

Message bodies are not copied into mail payloads.

Mail contains bounded metadata such as:

- recipient name
- CPO name
- support subject
- support status
- occurred-at timestamp
- action URL

Customer create/reply -> notification to appropriate active CPO support recipients.

CPO reply/status -> notification to ticket-owning customer's current email.

CUSTOMER_CPO activity does **not** emit Platform support events.

Two runtime frontend-link configuration keys were added:

```text
CPO_CUSTOMER_SUPPORT_TICKET_URL_TEMPLATE
CUSTOMER_SUPPORT_TICKET_URL_TEMPLATE
```

Current development environment has both keys present.

Do not expose values unless operationally necessary.

SMTP delivery was **not** accepted end-to-end as part of the latest release.

Durable outbox intent correctness is stronger evidence than SMTP transport acceptance.

---

# 14. Ratings / Reviews

The ratings/reviews burner is considered completed and deployed.

Key behavior:

- App Customer can rate their own completed charging session.
- Customer can read their own rating.
- Customer can replace/edit their own rating.
- One rating per customer/session/CPO is enforced.
- CPO can read customer ratings/reviews through CPO endpoints.
- Customer App does not expose other customers' identities.
- CPO rating reads may include customer email and review text; treat both as sensitive/untrusted UI content.
- Charger projections expose:
  - `rating_count`
  - nullable `average_rating`
- aggregate is read-time from session-owned ratings, not a separate mutable counter table.
- filtering/sorting by rating was added where applicable.
- customer rating history/discovery exists.
- migration 71 is the rating persistence migration.

Relevant recent commits before support:

```text
9752729 feat: add customer session ratings
9e2940c feat: add customer charger rating aggregate
a1f8717 feat: extend customer and CPO rating discovery
fbcfc39 docs: complete User App and CPO frontend handoffs
b924cae fix: validate rating pagination cursors
1c2a1fb docs: record rating discovery release
```

Do not reopen this burner without a concrete regression or new requirement.

---

# 15. Charger Operation Dispatch / Recovery

CMS durable charger-operation dispatch was hardened around migration 70.

Important principles:

- CMS freezes dispatch destination.
- pre-delivery claims are fenced with lease/token semantics.
- `DELIVERY_ATTEMPTED` is committed before HAL I/O.
- uncertain delivery is reconciled by exact CMS operation ID.
- uncertain operations are not blindly replayed.
- shared dispatcher is used by HTTP path and worker.
- HAL queue acceptance maps to CMS `HAL_ACCEPTED`.
- possible-delivery states do not pretend charger execution completed.
- legacy ambiguous rows were moved to reconciliation, not reconstructed.

Do not equate:

```text
HAL_ACCEPTED
```

with:

```text
physical charger action definitely occurred
```

Physical effect needs separate evidence.

Migration 70 down behavior may refuse while operation history exists. Forward-fix may be safer than binary rollback.

---

# 16. HAL Project Context

Separate repository:

`Transmogriffy-Global-Private-Limited/ocpp-hal-go-new`

Last known source revision:

`1908c934c0e2570b81523e8ef3fe20be1e519da0`

Message:

`fix: isolate charger operation recovery worker`

Known deployment:

- repo: `/opt/ocpp-hal-go-new`
- service: `ocpphalnew.service`
- binary: `/opt/ocpp-hal-go-new/bin/ocpphal`
- env: `/etc/ocpp-hal-new.env`
- AppRole: `ocpphalnew`
- generic rehost helper: `/usr/local/bin/rehost-service`

Important HAL worker split:

- deadline ticker
- sequential charger-operation worker at approximately 2-second cadence
- reconnect recovery remains separate
- atomic claim behavior exists

Do not modify HAL for CMS-only work unless the contract actually requires a HAL change.

---

# 17. CP Console / Charger Simulator

Known development cpconsole command for charger ID `bd9099`:

```bash
cd /opt/ocpp-hal-go-new && go run ./cmd/cpconsole \
  -url wss://dev-ocpphal-new.transev.site \
  -id bd9099 \
  -connectors 1 \
  -heartbeat-interval 60 \
  -auto-meter-interval 10 \
  -auto-power-kw 7.4
```

This is the current known public WSS simulation command for `bd9099`.

Do not confuse it with the older CMS `CHARGER_CONNECTION_URL` documentation referencing `dev-ocpphal.transev.site`.

Verify the actual active HAL host/Caddy route before changing connection URLs.

---

# 18. Invoices

Invoice support is already substantial and deployed.

Private invoice storage root on the VPS:

`/var/lib/evcmsnew/invoices`

Permissions:

- directories 0750
- files 0600

Environment:

`INVOICE_STORAGE_ROOT=/var/lib/evcmsnew/invoices`

Systemd drop-in grants write access to the invoice path while preserving sandboxing.

Important invoice principles:

- invoice artifacts become immutable once READY
- historical READY PDFs are not silently regenerated
- tariff/GST/session data used in invoice should come from frozen settlement truth
- issuer/CPO commercial identity comes from tenant-owned organization details
- logo import/storage is controlled
- customer/CPO download APIs exist
- invoice mail delivery uses durable delivery/outbox state
- SMTP attachment acceptance has historically remained an external verification boundary

Current renderer family includes V3 behavior, while older stamped renderer versions remain readable/dispatchable for historical artifacts.

Do not "fix" historical invoices by regenerating immutable artifacts.

---

# 19. Charging / Commercial Model

Known architectural expectations:

- Razorpay is the active payment provider.
- Per-session charging flow behaves like a bounded/held-money workflow rather than casual direct charge mutation.
- PostgreSQL durable session, tariff, tax, payment, wallet, and settlement state is authoritative.
- do not recalculate historical sessions from mutable current tariffs/GST.
- customer session limits and billing dimensions are distinct concerns.
- subscription expiry blocks only:
  - new customer charging starts
  - new customer wallet-recharge orders
- expiry must not break:
  - stop
  - settlement
  - reconciliation
  - reads
  - already-permitted payment verification

---

# 20. CPO / Customer / Platform Support Separation Summary

Never collapse these into a generic "support" concept.

```text
CPO_PLATFORM
  actor plane: administrative user
  customer_id: null
  CPO staff talks to Platform
  Platform endpoints can see this
  User App cannot

CUSTOMER_CPO
  customer owner required
  App Customer talks to own CPO
  customer actor is a real customer FK
  Platform support endpoints cannot see this
```

Use channel predicates explicitly in all reads/mutations.

---

# 21. API Contract Authority

Canonical machine contract:

`docs/contracts/openapi/openapi.yaml`

Canonical human administrative contract:

`docs/contracts/api/administrative-http-api.md`

Swagger/OpenAPI served when enabled:

```text
/docs/
/openapi.yaml
```

Any route/payload change should update together:

- handler
- service
- DB/migration if needed
- OpenAPI
- human API contract
- tests
- frontend handoff/consumer guidance
- project state/changelog/work item where appropriate

No generated client is currently a guaranteed source of truth.

---

# 22. Important Path-vs-Operation Count Note

There is a terminology/history trap.

During customer-support source implementation, verification used a **HTTP operation count** of 258 after adding eight operations to a prior 250-operation baseline.

The September 23 deployment record states source/live OpenAPI each expose **210 paths**.

These numbers are not inherently contradictory:

- one OpenAPI path can contain multiple methods/operations
- path count and operation count are different metrics

Some current documentation text may use "operations" where the observed deployment check was actually a 210-path comparison.

If a future task depends on the exact number:

1. parse current canonical OpenAPI
2. count distinct `paths` separately
3. count actual HTTP method operations separately
4. compare runtime and source using the same metric

Do not blindly propagate either 210 or 258 without naming the metric.

---

# 23. Frontend / Integration Surfaces

Known frontend host/context:

- SuperAdmin FE directory historically:
  `/var/www/superadmin-evcmsnew`
- SuperAdmin DNS:
  `superadmin-evcmsnew.transev.site`
- Customer app development host historically:
  `dev-evcustomerappnew.transev.site`

Frontend handoff docs are intended to be standalone.

For rating/review integration, dedicated User App and CPO FE handoffs were created.

For support integration, the main handoffs were updated to include:

- exact routes
- auth headers
- TypeScript shapes
- keyset pagination
- lifecycle semantics
- idempotency/retry rules
- privacy boundaries
- recovery behavior
- permission behavior

Use those docs before inventing frontend assumptions.

---

# 24. Known Earlier Burners / Features

The following work has been addressed historically and should not be casually recreated:

- mark-as-read / CPO admin access issue
- live charging session snapshot/charger projection problems
- offline "unknown" handling
- customer vehicle data
- auto invoice generation
- invoice email
- invoice storage
- invoice download APIs
- CPO-side download APIs
- customer rating/review lifecycle
- average charger rating
- rating sorting/filtering
- CPO rating visibility
- CPO administrative login via App ID
- durable charger operation/recovery
- customer-to-CPO support

If a regression is reported, inspect current source and historical work items instead of building a parallel solution.

---

# 25. Tracing / Realtime Context

The project has CMS/HAL trace/realtime work.

General intended direction:

- HAL can send trace points to CMS
- CMS can durably/appropriately store and expose them for viewing
- avoid making the frontend reconstruct transient HAL internals
- realtime is not durable truth
- REST/durable state remains the recovery/catch-up authority

Relevant router context includes HAL fact/trace ingress under internal `/v1` surfaces.

Inspect current contracts before extending this.

---

# 26. Configuration Rules

Configuration loads from:

1. ignored `.env`
2. process environment overrides

Never commit `.env`.

Never print secrets.

`.env.example` is the key-set reference.

Before rehost:

- compare key names
- detect missing keys
- detect extra keys
- detect blanks
- avoid printing values

Current development environment had exact example-key parity after the support release.

Relevant support keys:

```text
CPO_CUSTOMER_SUPPORT_TICKET_URL_TEMPLATE
CUSTOMER_SUPPORT_TICKET_URL_TEMPLATE
```

Relevant invoice key:

```text
INVOICE_STORAGE_ROOT
```

Relevant charger connection key:

```text
CHARGER_CONNECTION_URL
```

---

# 27. Database Rules

PostgreSQL is durable truth.

Migrations are immutable after publication/application.

Before DB change:

1. inspect current migration ledger
2. inspect affected rows/invariants
3. inspect target database
4. inspect rollback / down behavior
5. determine whether down is safe
6. create backup before live/dev schema mutation when consequential
7. stop conflicting writers when required
8. migrate
9. verify constraints/indexes/ledger
10. rehost if binary depends on new schema
11. verify runtime

Never use a development/live DB as `TEST_DATABASE_URL`.

DB-gated tests must use an explicitly selected disposable PostgreSQL database.

---

# 28. Verification Standard

Repository baseline verification:

```bash
gofmt -w <changed-go-files>
./scripts/verify-docs.ps1
go test ./src/routes -run TestOpenAPIContractMatchesRuntimeRoutesAndServesUI -count=1
go test ./...
go vet ./...
git diff --check
git status --short
```

In practice, serial form has often been used on constrained hosts:

```bash
go test -p 1 ./...
go vet -p 1 ./...
go build -p 1 ./...
go mod verify
```

PowerShell docs verifier may be unavailable on Ubuntu if `pwsh` is not installed. Report the skip truthfully.

For DB features, add PostgreSQL-gated lifecycle/isolation/concurrency tests with:

`TEST_DATABASE_URL`

only when explicitly pointing to a disposable database.

---

# 29. Current Unverified Boundaries

Even though the backend is broadly "done", do not silently erase these boundaries.

As of the latest support rehost:

- disposable PostgreSQL integration suite was skipped because `TEST_DATABASE_URL` was unset
- `pwsh` unavailable, so PowerShell docs verifier was not run on the VPS
- real SMTP delivery acceptance for the latest support flows was not performed
- HAL end-to-end acceptance was not part of the support release
- physical charger acceptance was not part of the support release

Runtime health is not proof of all external integrations.

---

# 30. Logging / Security

Do not log or document:

- secrets
- passwords
- OTPs
- tokens
- raw auth headers
- app IDs
- request/response bodies
- sensitive query strings
- customer PII beyond what is explicitly required
- panic internals

`LOG_LEVEL=DEBUG` does not relax security exclusions.

Request IDs and structured safe logs are preferred.

---

# 31. Operational Deployment Checklist

For a future CMS deployment, do not blindly copy commands. Use this as a decision checklist.

## Before

- verify user authorization to deploy/restart/migrate
- inspect `git status --short`
- verify intended source SHA
- inspect `AGENTS.md`
- inspect active work item
- inspect latest migration ledger
- inspect `.env` key parity without printing values
- inspect systemd unit
- inspect alias/rehost helper
- inspect Caddy
- inspect listener
- inspect disk space
- inspect service health/current workers
- identify rollback assets
- if migrations: create validated pre-migration DB dump
- build candidate
- run focused + broad source verification
- ensure no unrelated changes

## Activate

- stop service first if migration sequencing requires it
- apply migrations deliberately
- verify migration ledger
- preserve old binary
- activate candidate through existing rehost framework
- do not use ad hoc kill/start unless framework requires it

## Verify

- `systemctl is-active`
- restart count
- process hash
- installed binary hash
- health local/public
- readiness local/public
- Swagger
- OpenAPI
- route auth boundaries
- worker freshness
- Caddy validation
- post-start journal errors/panics/fatals
- environment key parity
- migration constraints
- changed feature behavior
- side-effect counters where relevant

Only then call it deployed.

---

# 32. Service / Runtime Commands to Know

Typical non-destructive checks:

```bash
systemctl is-active evcmsnew-dev.service
systemctl status evcmsnew-dev.service --no-pager
journalctl -u evcmsnew-dev.service --no-pager -n 200
```

Health shape:

```bash
curl -fsS http://127.0.0.1:18080/health/live
curl -fsS http://127.0.0.1:18080/health/ready
curl -fsS https://dev-evcmsnew.transev.site/health/live
curl -fsS https://dev-evcmsnew.transev.site/health/ready
```

Caddy:

```bash
caddy validate --config /etc/caddy/Caddyfile
```

Do not reload Caddy unless actually required.

Do not assume unrelated hostings are safe to rewrite. Caddy is shared.

---

# 33. Repository Change Discipline

Before editing:

```bash
git status --short
git log --oneline -n 20
```

Do not overwrite unrelated user changes.

Do not broad-stage by default.

Do not commit/push unless explicitly authorized.

When committing is authorized:

- stage explicit intended files
- inspect staged diff
- commit
- verify HEAD
- push
- verify remote SHA

When runtime deployment is also authorized, source publication and deployment evidence should be documented separately.

---

# 34. Work Item Discipline

Meaningful changes should have a narrowly scoped work item under:

`docs/work/active/`

It should name:

- objective
- claimed surfaces
- invariants
- scope / non-goals
- verification target
- runtime boundary

When complete and verified, move to:

`docs/work/archive/`

Current recent archived support work:

```text
docs/work/archive/WI-20260922-customer-cpo-support.md
docs/work/archive/WI-20260922-customer-cpo-support-actor-ownership.md
docs/work/archive/WI-20260923-customer-cpo-support-owner-immutability.md
docs/work/archive/WI-20260923-customer-cpo-support-rehost.md
```

---

# 35. Project Documentation That Matters Most

Always prefer repository documents over this handoff.

High-value files:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/DEVELOPMENT_PLAN.md
docs/AI_CHANGELOG.md
docs/SCHEMA.md
docs/AUTHENTICATION.md
docs/CPO_ADMINISTRATION.md
docs/CPO_BACKEND_AGENT_HANDOFF.md
docs/USERAPP_FE_HANDOFF.md
docs/SUPERADMIN_FRONTEND_HANDOFF.md
docs/contracts/openapi/openapi.yaml
docs/contracts/api/administrative-http-api.md
docs/contracts/configuration.md
docs/contracts/realtime/platform-events.md
docs/guides/operations/dev-hosting.md
```

For HAL/CMS operational integration, inspect relevant `docs/integrations/` files rather than inferring.

---

# 36. Current "Backend Is Kinda Done" Interpretation

The backend has reached a mature state across:

- administrative auth
- CPO tenancy/memberships/capabilities
- customer auth
- charger/network management
- GST/tariffs
- wallet/payment flows
- charging lifecycle
- durable charger-operation dispatch
- charging history/live projection
- invoice generation/storage/delivery workflow
- ratings/reviews
- CPO customer-rating discovery
- CPO-to-Platform support
- Customer-to-own-CPO support
- durable mail/outbox
- OpenAPI/human contracts
- deployment/recovery framework

This does **not** mean "never touch backend again."

It means future work should be:

- driven by concrete frontend/integration requirements
- bug/regression driven
- operational hardening driven
- new business requirements driven

Do not create speculative replacement architecture because the system already has strong durable contracts.

---

# 37. Important Domain Philosophy

When choosing between apparently convenient designs:

Prefer:

- durable truth over temporary UI state
- DB-enforced invariant over best-effort service check
- idempotent mutation over "probably once"
- explicit status/event history over inferred history
- bounded pagination over unbounded reads
- explicit tenant scoping over implicit context
- privacy-safe not-found over cross-tenant existence leaks
- additive forward migration over editing history
- deterministic recovery over blind retry
- source/runtime verification over plausible reasoning
- one canonical contract over duplicated manual schemas

---

# 38. Known User Expectations for AI Assistants

When the user says "check the commits":

- actually inspect GitHub
- compare current main with prior known SHA
- read the diff
- inspect migrations/tests/docs
- do not just restate commit messages
- find semantic gaps
- distinguish code correctness from verification evidence

When the user asks for "the next prompt":

- produce one strong Codex prompt
- preserve project rules
- avoid asking Codex to restart/redesign working implementation
- explicitly list verification and scope boundaries
- prevent deployment/commit unless authorized

When the user asks for deployment commands:

- first inspect current runtime/rehost framework
- never assume migration or environment state
- preserve unrelated hostings
- verify rollback path
- include post-deploy verification

---

# 39. Immediate State When Starting a New Session

A new AI should begin by assuming:

1. CMS backend is broadly implemented and deployed.
2. Latest known repo `main` is `dafcab3...`.
3. Running binary was built from `ea0f8fe...`.
4. Migration 74 is applied/current in development.
5. Customer-to-CPO support is live on the development CMS.
6. Ratings/reviews are already complete and deployed.
7. Do not reopen completed burners without evidence.
8. Next work should be based on the user's new request.
9. Before modifying code, refresh source/runtime state because this handoff will age.

---

# 40. Fast Context Refresh Commands / Queries

For Git:

```bash
git status --short
git log --oneline --decorate -n 25
git rev-parse HEAD
git rev-parse origin/main
```

For service:

```bash
systemctl is-active evcmsnew-dev.service
systemctl show evcmsnew-dev.service -p MainPID -p NRestarts
```

For current migration:

Use the repository migration tooling or inspect the migration ledger deliberately. Do not guess the ledger table name if it has changed.

For runtime API:

```bash
curl -fsS https://dev-evcmsnew.transev.site/health/live
curl -fsS https://dev-evcmsnew.transev.site/health/ready
curl -fsS https://dev-evcmsnew.transev.site/openapi.yaml
```

For protected route sanity:

Unauthenticated requests to newly protected customer/CPO routes should reject with 401, not expose data.

---

# 41. Things Not To Do

Do not:

- edit an applied migration
- trust client tenant IDs
- merge customer IDs into admin user IDs
- authorize by role name where capability exists
- let CUSTOMER_CPO support leak into Platform support
- expose CPO staff identity to User App support
- expose customer auth/security internals to CPO
- copy support message bodies into mail
- blindly retry uncertain charger operations
- equate HAL acceptance with physical charger execution
- regenerate immutable READY invoices casually
- infer live deployment from source commit
- infer SMTP success from outbox enqueue
- infer DB integration success from skipped tests
- kill/restart services outside the established rehost framework without cause
- touch shared Caddy configuration as if this were the only hosted app
- print `.env`
- claim "done" before code, schema, contracts, tests, docs, work item, runtime evidence, and boundaries agree

---

# 42. Final Continuity Snapshot

**CMS repo:** `Transmogriffy-Global-Private-Limited/ev-cms-backend-new`  
**Latest known main:** `dafcab3f11f403f4a70fd0d9f24064f3b873f3af`  
**Deployed source:** `ea0f8fe5d5a3c99370be3e86963408b475ee15f7`  
**Service:** `evcmsnew-dev.service`  
**Public dev host:** `dev-evcmsnew.transev.site`  
**Loopback listener:** `127.0.0.1:18080`  
**Database:** `devevcmsnewdb`  
**Current migration:** 74  
**Current active binary SHA-256:** `28b6de6c028c4ccc44ad83d352e2904dba1173d7e7d8f381b3d0b7fe5bd215cc`  
**Support channels:** `CPO_PLATFORM`, `CUSTOMER_CPO`  
**Latest major completed burner:** Customer App -> own CPO support  
**Ratings/reviews:** complete/deployed  
**HAL repo:** `Transmogriffy-Global-Private-Limited/ocpp-hal-go-new`  
**Last known HAL source:** `1908c934c0e2570b81523e8ef3fe20be1e519da0`  
**HAL service:** `ocpphalnew.service`  
**Known cpconsole charger:** `bd9099`  
**Main remaining verification boundaries:** disposable PostgreSQL integration gate, real SMTP acceptance, HAL/physical charger acceptance where relevant.

---

# 43. Handoff Principle

A new AI should not try to memorize this document and start coding immediately.

The correct seamless continuation workflow is:

1. absorb this continuity
2. inspect current Git/runtime truth
3. read the relevant repository contracts
4. identify exactly what changed since this handoff
5. preserve all established invariants unless new evidence requires revision
6. execute the user's next burner end-to-end
7. verify before claiming completion

That is the intended continuity model.
