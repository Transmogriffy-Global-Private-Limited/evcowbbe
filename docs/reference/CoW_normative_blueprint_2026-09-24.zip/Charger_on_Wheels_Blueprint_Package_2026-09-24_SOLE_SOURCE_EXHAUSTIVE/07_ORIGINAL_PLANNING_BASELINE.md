# Charger on Wheels
## Consolidated Product and Backend Architecture Planning

**Status:** Planning baseline  
**Date:** 2026-09-24  
**Scope:** Charger on Wheels platform backend, dedicated HAL, User side, Driver side, and unified Admin side.

---

# 1. Purpose

Charger on Wheels is a mobile EV charging platform in which a customer requests charging service, a driver operating a mobile charging vehicle is dispatched to the customer, charging is performed through an onboard charger, and the entire operational, charging, commercial, workforce, and administrative lifecycle is managed by the platform.

The system is not a copy of the existing EV-CMS, HAL, or Corporate Shuttle backend.

Instead, it reuses proven concepts and selected implementation patterns from:

1. **EV-CMS**
   - Customer accounts and EVs
   - Charging session/commercial lifecycle
   - Tariff and billing concepts
   - Payments, refunds, invoices, GST
   - Ratings/reviews
   - Support
   - Realtime projections
   - Idempotency
   - Durable outbox/fact processing
   - Auditability
   - Admin-facing charging/business operations

2. **Existing HAL**
   - Physical charger truth boundary
   - OCPP connection/runtime handling
   - Command delivery
   - Charging transaction evidence
   - Meter evidence
   - Reconnect/recovery
   - Durable facts
   - Reconciliation
   - Operation persistence
   - Raw trace/evidence

3. **Corporate Shuttle Backend**
   - Driver profile and KYC ideas
   - Driver verification lifecycle
   - Driver/vehicle operational concepts
   - Current-trip/current-work context
   - Admin assignment and visibility
   - Driver earnings/commission calculations
   - Historical snapshots
   - Realtime user/driver/admin refresh patterns
   - Driver ratings/support
   - Location/geofence-oriented operational workflows
   - Reusable vs trip-specific user data patterns

The new system must preserve semantic correctness instead of copying old tables or endpoints blindly.

---

# 2. Product Surfaces

The product has three first-class application surfaces:

## 2.1 User

The customer can:

- Register and authenticate.
- Maintain profile information.
- Save multiple EVs.
- Use a temporary EV for a service request without permanently saving it.
- See temporary EVs later in history.
- Promote a previously temporary EV into saved vehicles quickly.
- Save multiple service addresses.
- Use a temporary service address without permanently saving it.
- Retain temporary addresses in historical jobs.
- Promote a temporary address into saved addresses later.
- Request immediate or scheduled mobile charging service.
- Select charging preferences.
- See quote/fare breakdowns.
- Track job state.
- Track assigned driver/mobile unit where appropriate.
- Track live ETA/location where appropriate.
- See live charging state and charging data.
- See cost projection where appropriate.
- Pay for service.
- See charging/service history.
- View/download invoices.
- Rate/review service.
- Raise and track support issues.

## 2.2 Driver

The driver can:

- Apply to become a driver.
- Complete profile and KYC.
- Submit documents.
- View recruitment/verification status.
- View and manage operational profile.
- View schedules if assigned.
- Start/end a scheduled duty.
- Go online/offline when self-directed operation is allowed.
- Select or confirm the Vehicle + Charger combination being used.
- Use an admin-assigned combination when applicable.
- Select a known valid combination when allowed.
- Report that the real-world combination differs from system/admin records.
- Operate with a temporary/observed combination when policy permits.
- See the historical combination used for each duty session.
- Optionally define a driver-level dispatch geofence/service preference.
- Receive service requests/offers.
- Accept/reject jobs according to platform rules.
- Navigate to customer.
- Mark arrival and service preparation.
- Interact with charging workflow.
- See charger/HAL readiness and charging state.
- Complete service closeout.
- See sessions/history.
- See calculated earning/commission figures.
- See per-job, daily, weekly, monthly, and custom-range figures.
- See the breakdown explaining calculated figures.
- Report incidents, mismatches, or operational problems.
- Access support.

## 2.3 Admin

There is one unified Admin product.

There is **no CPO vs SuperAdmin product split** because the platform is not selling a multi-tenant charging network.

However, internal admin RBAC should still exist so different staff can have different capabilities, for example:

- Full Admin
- Operations
- Driver Recruitment
- Finance/Commercial
- Support
- Technical/HAL operations
- Read-only monitoring

Admin can:

- Manage users.
- Manage driver applications and KYC.
- Approve/reject/suspend/offboard drivers.
- Maintain full vehicle inventory.
- Maintain full charger and connector inventory.
- Track operational, maintenance, availability, and lifecycle state of assets.
- Manage Vehicle <-> Charger pairings.
- View inventory history, assignments, current usage, and availability.
- Assign Driver -> Vehicle -> Charger combinations.
- Create schedules.
- Leave drivers unscheduled where allowed.
- Manage dispatch/service zones.
- Manage customer/service pricing.
- Manage driver compensation policies.
- View all driver duty sessions.
- View expected vs observed asset pairings.
- Reconcile mismatch reports.
- Monitor live jobs.
- Monitor driver locations.
- Monitor vehicle/charger state.
- Monitor HAL state.
- View live charging data.
- View billing/payment/invoice state.
- View driver compensation figures.
- View ratings/reviews/support.
- View audit history.
- Manage system settings.

---

# 3. Core Architectural Principle

The system must distinguish:

- Intended administrative state
- Actual operational state
- Historical snapshot state
- Physical charger truth
- Commercial truth
- Derived projections

These must not be silently collapsed.

Examples:

- Admin may intend Charger A to be installed in Vehicle X.
- Driver may observe Charger B actually installed in Vehicle X.
- The duty session must record what was actually used.
- Admin must see the mismatch.
- The master registry should not be silently rewritten.
- Old duty sessions must remain historically correct after future edits.

Likewise:

- Driver pressing "start charging" does not prove charging started.
- HAL/OCPP evidence proves physical charging state.
- HAL ending a charging transaction does not automatically prove the entire service job is complete.
- User editing a saved EV later must not alter old service-job history.

---

# 4. Core Domain Model

The new system should be centered around a small number of strong domain objects.

## 4.1 Identity

- User
- AuthSession
- DeviceSession
- Role
- Permission
- AdminCapability

## 4.2 Customer

- CustomerProfile
- CustomerVehicle
- CustomerAddress
- ContactPreference

## 4.3 Driver Recruitment and Workforce

- DriverApplication
- DriverProfile
- DriverDocument
- DriverVerificationReview
- DriverEligibility
- DriverOperationalStatus
- DriverSchedule
- DriverScheduleOccurrence
- DriverDutySession
- DriverBreak/AvailabilityInterval

## 4.4 Fleet, Inventory, and Charging Assets

- ServiceVehicle
- VehicleInventoryRecord
- Charger
- ChargerInventoryRecord
- ChargerConnector
- ChargerCapability
- VehicleChargerPairing
- DriverAssetAssignment
- AssetReservation/Claim
- AssetMismatchReport
- AssetMaintenanceState
- AssetLifecycleEvent

## 4.5 Service and Dispatch

- ServiceRequest
- Quote
- ServiceJob
- JobAssignment
- DispatchOffer
- DispatchCandidate
- ServiceJobEvent
- ServiceAddressSnapshot
- CustomerVehicleSnapshot

## 4.6 Charging

- ChargingIntent
- ChargingSession
- ChargingTransactionLink
- MeterObservation
- ChargingProjection
- HALCommand
- HALFact
- HALTrace

## 4.7 Commercial

- PricingPolicy
- PricingRule
- PricingSnapshot
- FareComponent
- Payment
- Refund
- Invoice
- GSTSnapshot
- Discount/Promotion
- CommercialAdjustment

## 4.8 Driver Compensation

- CompensationPolicy
- CompensationRule
- CompensationPolicyVersion
- CompensationSnapshot
- CompensationLineItem
- CompensationAdjustment
- DriverEarningsSummary

There is no payout execution integration in the current scope.

## 4.9 Realtime and Operations

- LocationSample
- DutyLocationState
- ServiceJobRealtimeProjection
- ChargingRealtimeProjection
- DriverRealtimeProjection
- AdminOperationalProjection
- Notification
- SupportTicket
- RatingReview
- Incident
- AuditEvent

---

# 5. Reusable vs Temporary Customer Data

The platform must deliberately support both reusable saved data and one-off temporary data.

## 5.1 Customer Vehicles

A user may:

1. Select a saved EV.
2. Enter a temporary EV for this request.

Temporary EVs:

- Must remain visible in service history.
- Must not disappear after the job.
- Can later be promoted into saved vehicles.
- Must not cause historical job snapshots to change.

Recommended model:

- One normalized vehicle representation.
- A user-vehicle association or lifecycle field indicates whether it is currently saved/reusable.
- Every ServiceJob stores an immutable vehicle snapshot.

The immutable ServiceJob snapshot should include all information required to understand what the platform believed at job creation/confirmation time, including as applicable:

- Make
- Model
- Variant
- Registration number
- Battery capacity
- Connector support
- AC/DC support
- Maximum charge acceptance
- Other compatibility metadata

## 5.2 Customer Addresses

The same pattern applies to addresses.

A saved address may include:

- Label: Home, Office, Garage, Other
- Structured address fields
- Latitude
- Longitude
- Landmark
- Building/gate instructions
- Floor
- Contact instructions
- Geocode/provider metadata
- Default flag

A temporary service address:

- Is usable immediately.
- Remains visible in job history.
- Can later be saved.
- Must not retroactively change historical jobs.

Every ServiceJob stores an immutable service address snapshot.

---

# 6. Driver Recruitment Model

Recruitment must be a first-class lifecycle, not merely a boolean "verified" flag.

Recommended application lifecycle:

```text
DRAFT
-> SUBMITTED
-> UNDER_REVIEW
-> ACTION_REQUIRED
-> APPROVED
-> ONBOARDING
-> ACTIVE
```

Additional states may include:

```text
REJECTED
WITHDRAWN
SUSPENDED
OFFBOARDED
```

Recruitment/application truth must remain distinct from operational driver status.

A driver application can contain:

- Identity information
- Address
- Phone/email
- Aadhaar
- PAN
- Driving licence
- Licence expiry
- Bank information if the business needs it informationally
- Emergency contact
- Employment/contract classification
- Preferred/base operating area
- Required documents
- Admin notes
- Review history
- Training acknowledgements
- Terms acceptance

Important distinction:

```text
DriverApplication != DriverProfile != DriverOperationalState
```

An approved historical application does not imply that the driver is currently allowed to operate.

---

# 7. Driver Operational State

A separate operational state machine should represent live availability.

Example:

```text
OFF_DUTY
-> AVAILABLE
-> OFFERED
-> ASSIGNED
-> EN_ROUTE
-> AT_CUSTOMER
-> SERVICING
-> AVAILABLE
```

Supporting states may include:

```text
BREAK
UNAVAILABLE
EMERGENCY
OFFLINE
SUSPENDED
```

Driver schedule state and driver operational state must not be the same thing.

A driver can be:

- Inside an active work schedule but temporarily unavailable.
- Online without an admin schedule if platform policy allows.
- Assigned to a schedule but not yet started.
- Logged in but not operationally online.

---

# 8. Driver -> Vehicle -> Charger Model

This relationship must not be represented merely as three foreign keys on a driver.

The system should distinguish at least:

# 8A. Admin Vehicle and Charger Inventory

Admin must have a first-class inventory/asset registry for all service vehicles and chargers, independent of whether they are currently assigned to a driver.

The inventory is the platform's master operational registry.

## Vehicle Inventory

Admin should be able to:

- Add a vehicle.
- Edit vehicle details.
- Activate/deactivate a vehicle.
- Mark operational status.
- Mark maintenance/out-of-service state.
- View current charger pairing.
- View current driver assignment.
- View current duty-session usage.
- View historical pairings and assignments.
- View inspection/registration/insurance metadata where applicable.
- View last known operational activity.
- Search, sort, and filter by status/capability/location/assignment.
- See whether the vehicle is currently available, reserved, assigned, in use, under maintenance, or retired.

Vehicle inventory should support fields such as:

```text
vehicle_id
registration_number
make
model
variant
vehicle_type
ownership_type
operational_status
registration_valid_until
insurance_valid_until
inspection_status
maintenance_status
is_active
notes
created_at
updated_at
```

The exact schema can evolve, but inventory identity must remain stable.

## Charger Inventory

Admin should be able to:

- Add a charger.
- Edit charger metadata.
- Activate/deactivate a charger.
- Mark operational/maintenance state.
- View current vehicle pairing.
- View current driver/duty-session usage.
- View connector inventory.
- View power/capability metadata.
- View protocol support.
- View HAL identity and connectivity.
- View last-seen/last-known charger state.
- View charger faults.
- View historical pairings.
- Search, sort, and filter by protocol, connector type, power, status, vehicle, assignment, and connectivity.

Charger inventory should support fields such as:

```text
charger_id
asset_tag
serial_number
manufacturer
model
rated_power
protocol_family
protocol_version
hal_identity
operational_status
maintenance_status
is_active
last_seen_at
notes
created_at
updated_at
```

Connector inventory should be modeled separately where needed:

```text
connector_id
charger_id
connector_number
connector_type
max_power
status
capabilities
```

## Inventory State vs Runtime State

Inventory state is not the same as live runtime state.

Examples:

```text
Inventory: Charger is ACTIVE
HAL: Charger is currently OFFLINE

Inventory: Vehicle is AVAILABLE
DutySession: Vehicle is currently CLAIMED

Inventory: Charger A is paired with Vehicle X
Driver report: Charger B is physically present in Vehicle X
```

The system should preserve all of these truths separately.

## Inventory Availability

Admin should be able to see derived availability such as:

```text
AVAILABLE
RESERVED
ASSIGNED
IN_USE
MAINTENANCE
OUT_OF_SERVICE
RETIRED
```

This derived state should come from explicit inventory status plus active assignments/duty sessions, not from one mutable status field that can drift from reality.

## Inventory History

Do not overwrite pairing/assignment history.

Maintain effective-dated history for:

- Vehicle <-> Charger pairing
- Driver <-> Vehicle assignment
- Driver <-> Charger assignment
- Maintenance periods
- Deactivation/reactivation
- Inspection state changes

This allows Admin to answer:

> Which charger was in which vehicle on a specific date?

> Which driver was operating that combination?

> Was the asset actually available at that time?


## 8.1 VehicleChargerPairing

Represents intended/master-data physical pairing.

Example:

> Charger C is expected to be installed/carried in Vehicle V.

This can have history/effective periods.

## 8.2 DriverAssetAssignment

Represents admin intent.

Example:

> Driver D is assigned Vehicle V and Charger C for this schedule/period.

This may be:

- Optional
- Mandatory
- Time-bound
- Schedule-bound
- Reusable

## 8.3 DriverDutySession

Represents actual current operational reality.

A duty session should snapshot:

- Driver
- Schedule reference, if any
- Vehicle
- Charger
- Vehicle/charger pairing
- Pairing source
- Whether admin-assigned
- Whether driver-selected
- Whether temporarily observed
- Charger connectors/capabilities at start
- Effective service/geofence rules
- Started timestamp
- Ended timestamp
- Live/current location state
- Asset mismatch state
- Relevant eligibility state

Dispatch should use the current DutySession, not simply `driver.is_online`.

---

# 9. Going Online

The driver's online flow should validate actual operational readiness.

Before allowing a duty session to become dispatchable, backend should validate as applicable:

```text
Driver exists and is active
Driver recruitment/KYC status valid
Driver not suspended
Driver allowed to work now
Schedule requirements satisfied
Vehicle exists or temporary use is permitted
Vehicle operational/eligible
Vehicle inspection/registration valid where required
Charger exists or temporary observed use is permitted
Charger operational
Charger not already claimed by another active duty session
Vehicle not already claimed by another active duty session
Vehicle/charger pairing valid or explicitly treated as a reported mismatch
Required connector/capability information available
HAL charger identity recognized/reachable where required
No conflicting duty session
No disallowed overlapping schedule
```

Asset claiming must be concurrency-safe.

Two drivers must not be able to successfully claim the same vehicle or charger simultaneously unless explicit future policy supports shared use.

---

# 10. Temporary or Observed Driver Asset Combination

The driver side should mirror the saved-vs-temporary customer pattern.

When going online, the driver may:

1. Use an admin-assigned Vehicle + Charger combination.
2. Select a known eligible combination.
3. Report the actual combination being used when reality differs from system data.
4. Use a temporary observed combination when policy permits.

Temporary/observed combinations:

- Must remain in DutySession history.
- Must not disappear.
- Must be visible to Admin.
- Can later be reconciled/promoted into master data.
- Must not silently mutate the administrative registry.

Recommended mismatch model:

```text
expected_vehicle
expected_charger
observed_vehicle
observed_charger
status
reported_by
reported_at
note
evidence
reviewed_by
reviewed_at
resolution
```

Possible mismatch states:

```text
MISMATCH_REPORTED
ACKNOWLEDGED
CONFIRMED_CORRECTION
EXPECTED_RESTORED
REASSIGNED
REJECTED_REPORT
RESOLVED
```

The active DutySession should record which real-world combination was actually used.

---

# 11. Scheduling

Admin may schedule a driver or leave the driver self-directed.

## 11.1 Scheduled Driver

Admin can define:

- Planned start
- Planned end
- Assigned vehicle
- Assigned charger
- Base/service area
- Optional operational/geofence constraints
- Notes
- Mandatory or suggested asset assignment

Driver sees the relevant schedule and can:

```text
Start Schedule / Go Online
...
Go Offline / End Schedule
```

Track separately:

```text
planned_start
planned_end
actual_start
actual_end
```

Early/late starts and ends should be represented as facts, not hidden.

## 11.2 Unscheduled Driver

If permitted:

- Driver chooses when to go online/offline.
- Driver chooses/declares the current Vehicle + Charger combination.
- Dispatch eligibility still applies.
- Admin may still apply platform-wide restrictions.

## 11.3 Schedule History

Historical schedule records should preserve:

- Planned assignment
- Actual duty session
- Actual assets
- Deviations
- Attendance/availability intervals
- Breaks
- Admin corrections

---

# 12. Driver Geofencing

The driver may optionally define a preferred service/dispatch area for the current duty session.

Possible modes:

```text
NONE
RADIUS
ADMIN_ZONE
POLYGON   # future extension if useful
```

Important distinction:

```text
Platform service eligibility
AND
Admin operational restriction
AND
Driver voluntary preference
```

The effective area is the intersection of applicable constraints.

A driver preference must never expand beyond platform eligibility.

If no driver geofence is set:

- Driver remains eligible according to platform/admin constraints.
- Dispatch candidates can be sorted/ranked by distance/ETA and other ranking inputs.

---

# 13. Dispatch Architecture

Dispatch should be two-stage:

## 13.1 Eligibility

First determine valid candidates.

A candidate may require:

```text
Driver active
Driver online
DutySession active
Driver available
Schedule compatible
Driver location fresh enough
Within effective service area
Vehicle valid
Charger valid
Vehicle/charger pairing accepted
Requested connector supported
Requested charging mode supported
Power/capability sufficient
HAL operational state acceptable
No prohibited conflicting job
Mobile unit energy/capacity sufficient if applicable
Any customer-specific requirement satisfied
```

## 13.2 Ranking

Only valid candidates should be ranked.

Ranking inputs may include:

- ETA
- Distance
- Driver workload
- Current/queued jobs
- Mobile charger energy availability
- Job priority
- Customer charging preference
- Requested connector
- Fast-charge preference
- Driver preference/geofence
- Schedule commitments
- Admin priority
- Driver rating if business policy chooses to use it
- Future optimization inputs

Nearest-driver logic must never override capability compatibility.

---

# 14. Customer EV Compatibility and Charger Matching

Customer EV metadata can help determine charger requirements.

The platform may derive:

- Compatible connector types
- AC/DC capability
- Maximum accepted charging power
- Battery metadata
- Known fast-charging support

The user may also express service preference such as:

```text
Fastest available
DC fast charge
Normal charging
Target energy
Target SOC
```

Dispatch should match:

```text
Customer vehicle requirements
+
Customer charging preference
+
Driver DutySession Vehicle + Charger pairing
+
HAL-reported charger capabilities
```

HAL-reported operational capability should be preferred over stale assumptions where available.

---

# 15. Service Job as the Central Product Object

The central business object is the **ServiceJob**.

Not the OCPP session.
Not the payment.
Not the assignment.

Conceptually:

```text
User
  -> ServiceRequest
  -> Quote
  -> ServiceJob
       -> Address snapshot
       -> Customer vehicle snapshot
       -> Assignment history
       -> Driver duty session reference
       -> Service vehicle
       -> Charger
       -> ChargingSession(s)
       -> Pricing snapshot
       -> Payment(s)
       -> Invoice
       -> Driver compensation
       -> Rating/review
       -> Support/incident
```

A ServiceJob may contain multiple ChargingSessions.

Example:

- Driver arrives.
- Charging transaction starts.
- Charger faults.
- First transaction ends.
- Driver recovers.
- A second transaction starts.
- Charging completes.

Operationally this can remain one ServiceJob with multiple physical charging transactions.

Likewise, driver assignment may change without creating a new ServiceJob.

---

# 16. Service Job Lifecycle

A recommended high-level lifecycle:

```text
REQUESTED
-> QUOTED
-> DISPATCHING
-> ASSIGNED
-> ACCEPTED
-> EN_ROUTE
-> ARRIVED
-> SERVICE_PREPARING
-> CHARGING
-> WRAP_UP
-> COMPLETED
```

Supporting paths should include:

```text
CANCELLED
FAILED
NO_SHOW
REASSIGNING
EXPIRED
```

Exact transitions must be explicitly defined and validated.

The charging lifecycle remains a separate state machine.

---

# 17. Charging Lifecycle

The charging lifecycle should retain the proven EV-CMS/HAL principle:

- CMS owns customer/commercial intent.
- HAL owns physical charging/OCPP truth.
- Remote command acknowledgement is not equivalent to physical charging start.
- Real StartTransaction/transaction evidence creates authoritative physical charging state.
- Real meter observations create authoritative charging measurements.
- Real StopTransaction/transaction end evidence creates authoritative charging end state.

Example:

```text
ChargingIntent
-> HAL command dispatch
-> command accepted/rejected/unknown
-> physical TransactionStarted fact
-> active charging
-> meter observations
-> physical TransactionEnded fact
```

The ServiceJob should only react to normalized charging facts.

---

# 18. Pricing and Billing

The EV-CMS commercial model should be reused conceptually and adapted for mobile charging.

Customer price can contain two broad dimensions:

```text
MOBILITY / SERVICE
+
ENERGY / CHARGING
```

Possible charge components:

- Visit fee
- Distance/service fee
- Driver travel time fee
- Waiting fee
- Charging energy fee
- Charging time fee
- Fast-charging premium
- Convenience fee
- Priority/emergency fee
- Time-of-day rule
- Date/date-range rule
- Zone fee
- Tax
- Discount/promotion
- Adjustment

The pricing engine should be composable and snapshot applied commercial terms.

The customer should be able to see:

- Quote
- Fare breakdown
- Live projected cost where meaningful
- Final charged amount
- Taxes
- Payment state
- Invoice

Admin should be able to configure and inspect the same pricing system.

---

# 19. Driver Compensation

Driver compensation is a **calculation and reporting domain only** in current scope.

There is no integrated Razorpay payout or transfer execution.

The platform should:

- Calculate driver figures.
- Store them.
- Explain them.
- Aggregate them.
- Show them to Driver and Admin.
- Preserve historical rule versions.
- Support corrective adjustments.

It should not:

- Create Razorpay linked accounts.
- Execute driver payouts.
- Retry payouts.
- Maintain external payout transfer state.
- Claim that a driver has been paid.

Avoid payout-oriented statuses such as "paid" unless a future informational/manual accounting feature explicitly introduces them.

---

# 20. Compensation Policy Engine

The compensation system must support fully composable admin-configured rules.

Possible compensation components:

```text
Base per completed service job
Distance
Travel time
Waiting time
Charging time
Energy delivered
Revenue commission
Per-charge amount
Time-of-day modifier
Date/date-range modifier
Zone modifier
Driver-specific override
Driver-group modifier
Bonus
Penalty/adjustment
Minimum guarantee
Cap
Multiplier
```

Example:

```text
Rs 50 per completed job
+ Rs 8 per eligible travel km
+ Rs 1.50 per eligible travel minute
```

Additional rule:

```text
22:00-06:00
1.25x eligible distance and time earnings
```

Additional rule:

```text
Sep 26 - Oct 22
+ Rs 100 per completed job
```

Additional rule:

```text
Senior DC Operators
+ Rs 2 per delivered kWh
```

Driver-specific override:

```text
distance rate = Rs 10/km
```

---

# 21. Compensation Rule Composition

Rule combination semantics must be explicit.

Supported operators can include:

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM_GUARANTEE
CAP
```

Each rule should have:

- Priority
- Effective-from
- Effective-to
- Applicability conditions
- Scope
- Calculation basis
- Version
- Admin provenance
- Activation state

Recommended policy lifecycle:

```text
DRAFT
-> ACTIVE
-> RETIRED
```

Rules should be versioned, not destructively overwritten.

---

# 22. Time-Based Compensation Semantics

Time-of-day rules create edge cases and must define a basis.

Example:

A job runs from 21:45 to 22:35 and night compensation starts at 22:00.

The rule must explicitly state whether it applies by:

```text
JOB_START
JOB_END
EVENT_TIME
INTERVAL_PRORATED
```

Different components may use different bases.

For interval-prorated rules:

- Time should be split accurately.
- Distance should be split based on trace/timestamps if required.
- The system should not arbitrarily give the entire job one rate.

---

# 23. Authoritative Inputs for Compensation

Where possible, compensation should use trusted system facts.

Examples:

```text
Travel distance
<- trusted GPS/location trace

Travel time
<- dispatch/service lifecycle timestamps

Waiting time
<- arrival -> service/charging readiness

Charging time
<- HAL transaction evidence

Energy delivered
<- HAL meter evidence

Completed charging sessions
<- ServiceJob + HAL charging completion facts

Revenue
<- finalized commercial/invoice facts
```

Driver-entered freeform values should not become authoritative financial metrics without validation/admin approval.

---

# 24. Compensation Ledger and Explainability

Do not store only one total.

Store line items.

Example:

```text
Completed-job component       Rs  50.00
Travel distance 12 km x 10    Rs 120.00
Travel time 35 min x 1.50     Rs  52.50
Night multiplier              Rs  43.13
Festival bonus                Rs 100.00
---------------------------------------
Total                         Rs 365.63
```

Each line item should reference:

- Compensation policy
- Policy version
- Rule
- Rule version
- Source facts
- Quantity
- Rate
- Operator
- Calculated amount
- Calculation timestamp

Corrections should create compensating adjustment entries instead of silently rewriting settled historical calculations.

---

# 25. Driver Earnings Views

Driver can see:

- Current duty-session figures
- Today's figures
- Job-by-job figures
- Distance/time/charging breakdown
- Daily totals
- Weekly totals
- Monthly totals
- Custom date range
- Historical adjustments
- Rule/component explanation

Admin can see the same figures with broader filters and analytics.

The system does not execute the actual wage/payout transfer.

---

# 26. Realtime Architecture

Realtime needs are broader than the old EV-CMS.

## 26.1 User Realtime

User may receive updates for:

- Service request state
- Dispatch state
- Driver assigned
- Driver identity where appropriate
- ETA
- Driver/mobile unit location
- Driver arrival
- Service preparation
- Charger readiness
- Charging start
- Live charging metrics
- Energy
- SoC where supported
- Cost projection
- Charging stop
- Wrap-up
- Job completion
- Payment/invoice changes

## 26.2 Driver Realtime

Driver may receive:

- Schedule changes
- Assignment changes
- New offers
- Job changes
- Customer/service location
- Navigation inputs
- Charger/HAL readiness
- Charging state
- Faults
- Admin pairing corrections
- Compensation calculation updates
- Support/incident updates

## 26.3 Admin Realtime

Admin may monitor:

- Drivers online/offline
- Active DutySessions
- Schedules
- Driver locations
- Vehicle assignments
- Charger assignments
- Pairing mismatches
- Live service jobs
- Dispatch state
- Charging sessions
- HAL health
- Charger faults
- Payments
- Invoices
- Compensation figures
- Incidents
- Ratings/reviews/support

## 26.4 Realtime Philosophy

Realtime events should normally tell clients that state changed.

Authoritative APIs should remain the source for full state.

Avoid making ephemeral WebSocket messages the sole durable truth.

Use durable event/fact/outbox patterns where events affect important state.

---

# 27. Dedicated Charger-on-Wheels HAL

Charger on Wheels should have its own separately hosted HAL.

It should have:

- Separate repository
- Separate service
- Separate database/state where required
- Independent deployment
- Independent migration lifecycle
- Independent monitoring
- Independent recovery

Do not couple it operationally to the existing EV-CMS HAL instance.

---

# 28. HAL Architectural Goal

The new HAL must be protocol-neutral at its core.

It should not be designed as:

> OCPP 1.6 code plus later patches for 2.x.

It should be:

> A charging control platform with replaceable protocol adapters.

High-level architecture:

```text
CMS
 |
 | normalized commands/facts
 v
HAL Core
 |
 +-- Charger identity
 +-- Connection model
 +-- Capability model
 +-- Transaction abstraction
 +-- Command orchestration
 +-- Meter normalization
 +-- State normalization
 +-- Fault normalization
 +-- Operation persistence
 +-- Recovery
 +-- Reconciliation
 +-- Fact outbox
 +-- Trace/evidence
 |
 +-- OCPP 1.6 adapter
 +-- OCPP 2.0.x adapter
 +-- OCPP 2.1 adapter
 +-- Future OCPP adapter
 +-- Vendor/proprietary adapter
 +-- Simulator/test adapter
```

---

# 29. Protocol-Neutral HAL Commands

CMS should issue semantic commands such as:

```text
StartCharging
StopCharging
Reset
UnlockConnector
SetChargingLimit
ChangeAvailability
RequestDiagnostics
GetCapabilities
```

CMS should not need to know protocol-specific message names.

Examples of protocol details that should remain inside adapters:

```text
RemoteStartTransaction
RequestStartTransaction
SetChargingProfile
```

---

# 30. Protocol-Neutral HAL Facts

HAL should normalize protocol events into stable facts such as:

```text
ChargerConnected
ChargerDisconnected
ConnectorStateChanged
TransactionStarted
TransactionUpdated
TransactionEnded
MeterSampleObserved
StateOfChargeObserved
FaultObserved
CapabilityChanged
CommandAccepted
CommandRejected
CommandOutcomeUnknown
```

CMS consumes normalized facts, not OCPP-version-specific payloads.

---

# 31. HAL Capability Model

Protocol/version does not guarantee identical charger behavior.

Maintain normalized runtime capabilities.

Example:

```text
protocol = OCPP_2_0_1

supports_remote_start = true
supports_remote_stop = true
supports_unlock = true
supports_smart_charging = true
supports_soc = true
supports_iso15118 = false
supports_reservation = false
supports_firmware_management = true

connectors = [...]
meter_measurands = [...]
vendor_extensions = [...]
```

Dispatch and CMS can use these capabilities without understanding how each adapter discovered them.

---

# 32. Composable HAL Features

Avoid one giant adapter class.

Prefer capability-oriented adapter components such as:

```text
ProtocolAdapter
  ConnectionHandler
  TransactionHandler
  MeteringHandler
  CommandHandler
  SmartChargingHandler
  DiagnosticsHandler
  FirmwareHandler
  SecurityHandler
```

Adapters implement only what the protocol/device supports.

Possible implementation layout:

```text
hal/
  core/
  protocols/
    ocpp16/
    ocpp201/
    ocpp21/
  vendors/
    vendor_x/
    vendor_y/
  simulator/
```

Vendor-specific behavior must not leak into shared business semantics.

---

# 33. Raw Evidence and Normalized Facts

HAL should retain both:

1. Normalized semantic facts for CMS/business logic.
2. Raw protocol evidence for diagnostics, reconciliation, auditing, and debugging.

Example:

A raw OCPP message may be normalized to:

```text
TransactionStarted
```

but the source evidence should still be available for technical investigation.

This provides:

```text
stable business semantics
+
preserved technical truth
```

---

# 34. HAL Reliability Requirements

Carry forward the strong reliability ideas from the existing HAL:

- Durable operation persistence
- Idempotency
- Operation identity
- Command delivery state
- Explicit uncertain-delivery handling
- Recovery workers
- Reconnect reconciliation
- Fact outbox
- Trace outbox
- Retry policy
- Duplicate fact handling
- Integrity checks
- Auditable state transitions
- Raw evidence retention
- No blind replay after uncertain physical execution

---

# 35. CMS <-> HAL Boundary

CMS and HAL remain separately authoritative.

## CMS owns

- User/customer truth
- Driver/workforce truth
- ServiceJob truth
- Pricing
- Billing
- Payment
- Invoice
- Compensation
- Dispatch
- Admin policies
- Customer-facing state
- Historical business records

## HAL owns

- Physical charger connection truth
- Protocol runtime
- Charger commands
- Charging transaction identity
- Meter observations
- Protocol faults/state
- Reconnect/recovery
- Raw charger evidence

No shared database.

Integration should use explicit authenticated contracts.

---

# 36. Service Vehicle, Charger, and EVSE Separation

Do not model vehicle and charger as the same entity.

Keep separate:

```text
ServiceVehicle
MobileChargingUnit / Charger
Connector(s)
```

Even if initially one charger is permanently installed in one vehicle.

This permits later:

- Charger swaps
- Vehicle swaps
- Hardware replacement
- Maintenance
- Multiple connectors
- Multiple chargers per service vehicle
- Asset history
- Battery/energy-store modeling
- Charger upgrades
- Protocol version differences

---

# 37. Auditability

Important changes should be auditable.

Examples:

- Driver KYC review
- Driver suspension
- Schedule edits
- Vehicle assignment changes
- Charger assignment changes
- Pairing corrections
- Driver mismatch reports
- Pricing changes
- Compensation policy changes
- Manual job changes
- Manual charging/admin interventions
- Payment/refund changes
- Support/incident resolution

Audit records should preserve:

- Actor
- Action
- Target
- Previous state where practical
- New state
- Timestamp
- Reason/note
- Correlation/request ID

---

# 38. Historical Snapshot Principle

Master data is mutable.

Historical business/operational truth is not.

Snapshot at the relevant boundary:

- Customer vehicle
- Service address
- Pricing policy/rules
- Tax configuration
- Driver compensation rules
- DutySession asset combination
- Charger capability state where required
- Driver assignment
- Relevant contact/identity information

Future edits must not silently rewrite historical service records.

---

# 39. Correction Principle

Reality can differ from configured data.

The system should support correction without destroying history.

Preferred model:

```text
Observed fact
-> discrepancy recorded
-> temporary operational handling where safe
-> admin reconciliation
-> master data correction if appropriate
-> historical record preserved
```

Do not force users/drivers/admin to operate on known-false state merely to maintain nominal consistency.

---

# 40. Non-Goals / Explicit Exclusions

Current scope does **not** include:

- CPO tenancy
- CPO vs SuperAdmin product separation
- Selling a multi-tenant charging network platform
- Driver payout execution through Razorpay
- Razorpay Route linked-account management for drivers
- Driver transfer retry engine
- External wage/payment settlement execution

Razorpay may still be used for customer-facing payment if chosen, as inherited from EV-CMS commercial patterns, but driver compensation is calculation/reporting only.

---

# 41. Important Reuse Decisions

## Reuse strongly

From EV-CMS/HAL:

- Charging truth boundary
- Session/fact model
- HAL command/fact contract philosophy
- Idempotency
- Outbox
- Reconciliation
- Realtime charging projections
- Customer payments
- Refunds
- Invoice generation
- GST concepts
- Ratings/reviews
- Support
- Auditability
- OpenAPI discipline
- Durable state transitions

From Shuttle:

- Driver profile/KYC concepts
- Driver verification lifecycle
- Driver/vehicle operating context
- Current-work context
- Admin assignment ideas
- Realtime per-surface refresh concepts
- Earnings/commission calculation ideas
- Adjustment/ledger concepts
- Location/geofence workflows
- Historical snapshot thinking

## Adapt heavily

- User vehicle/profile model
- Driver trip/current-trip concepts
- Global commission setting
- Existing vehicle assignment model
- Existing realtime implementation
- Existing KYC implementation
- Existing payout calculations

## Do not reuse semantically

From EV-CMS:

- CPO tenancy
- CPO ownership model
- SuperAdmin/CPO split
- CPO settlement model

From Shuttle:

- Route/stop/seat booking semantics where irrelevant
- Payout transfer execution
- Razorpay linked-account driver transfer machinery
- Simple single global commission as the final compensation architecture

---

# 42. Suggested Backend Module Boundaries

A modular monolith is suitable initially if boundaries are enforced clearly.

Possible Go package/domain layout:

```text
cmd/
internal/
  auth/
  users/
  addresses/
  customervehicles/

  driverrecruitment/
  drivers/
  schedules/
  duty/
  availability/

  fleet/
  vehicles/
  chargers/
  pairings/
  assignments/

  dispatch/
  servicejobs/
  location/

  charging/
  halclient/
  halfacts/

  pricing/
  payments/
  refunds/
  invoices/
  tax/

  compensation/

  ratings/
  support/
  incidents/
  notifications/
  realtime/
  audit/

  admin/
```

HAL remains a separate service/repository.

---

# 43. Core Invariants

The implementation should enforce the following invariants.

1. One active DutySession cannot silently claim assets already exclusively claimed by another incompatible DutySession.
2. Dispatch only uses eligible candidates.
3. Incompatible charger/customer combinations are not offered merely because they are nearby.
4. Historical ServiceJobs retain vehicle/address/commercial snapshots.
5. Historical DutySessions retain actual vehicle/charger context.
6. Driver mismatch reporting does not silently rewrite master data.
7. Physical charging state comes from HAL facts, not UI intent.
8. ServiceJob lifecycle and ChargingSession lifecycle remain separate.
9. Customer pricing and driver compensation remain separate.
10. Compensation rule edits do not retroactively rewrite finalized historical figures.
11. Driver compensation is not represented as paid merely because it was calculated.
12. Protocol-specific OCPP semantics do not leak into CMS contracts.
13. Vendor-specific behavior does not leak into HAL core semantics.
14. Important external actions are idempotent or safely reconciled.
15. Realtime is not the sole durable source of important state.
16. Admin schedule intent and actual driver operation are both preserved.
17. Temporary customer/driver data remains historically visible and may later be promoted to reusable master data.
18. Master data updates never silently mutate old history.

---

# 44. Failure and Edge Cases to Design For

The system must be designed for more than the happy path.

Examples:

- Driver goes offline unexpectedly.
- Driver accepts job then loses connectivity.
- Driver is reassigned.
- Driver uses wrong vehicle.
- Driver uses wrong charger.
- Admin data is stale.
- Vehicle and charger were swapped physically.
- Two drivers try to claim the same charger.
- Driver location becomes stale.
- Customer changes location.
- Customer vehicle information is wrong.
- Charger supports the connector but not required power.
- Charger appears online but cannot start.
- OCPP command times out after physical success.
- HAL reconnects during charging.
- Charging transaction restarts.
- Multiple charging transactions exist for one ServiceJob.
- Meter values arrive late/out of order.
- Payment succeeds while API response is lost.
- Duplicate webhook/fact arrives.
- Pricing changes mid-job.
- Compensation policy changes mid-job.
- Schedule changes during active duty.
- Driver crosses time-of-day compensation boundaries.
- Driver geofence changes during duty.
- Mobile charger energy becomes insufficient.
- User cancels before dispatch.
- User cancels after dispatch.
- User cancels after arrival.
- Customer no-show.
- Driver no-show.
- Charger fault.
- Vehicle breakdown.
- HAL unavailable.
- CMS unavailable.
- Realtime unavailable while durable API state remains correct.

---

# 45. Implementation Philosophy

The system should be implemented around:

- Explicit state machines
- Explicit ownership
- Explicit contracts
- Strong idempotency
- Durable outboxes
- Historical snapshots
- Immutable evidence
- Corrective records instead of destructive rewrites
- Capability-driven behavior
- Replaceable protocol adapters
- Low-blast-radius modules
- Auditable admin actions
- Clear failure recovery
- Deterministic rule engines
- Strong migrations
- OpenAPI/Swagger as a first-class deliverable
- Runtime/source parity verification
- Integration tests with real PostgreSQL
- End-to-end virtual charger tests
- Later physical charger acceptance

---

# 46. Suggested Implementation Sequence

A practical implementation sequence should minimize rework.

## Phase 1 - Foundation

- Repository/module conventions
- Authentication
- Role/capability model
- User profiles
- Driver profile/recruitment foundation
- Admin foundation
- Audit foundation
- Outbox/realtime foundation
- Migration discipline
- OpenAPI discipline

## Phase 2 - Customer Master Data

- Saved addresses
- Temporary addresses
- Address promotion
- Saved EVs
- Temporary EVs
- EV promotion
- Immutable snapshots

## Phase 3 - Workforce and Fleet

- Driver recruitment
- KYC/review
- Driver eligibility
- Service vehicles
- Chargers
- Connectors/capabilities
- Vehicle-charger pairings
- Asset mismatch reporting
- Admin assignments

## Phase 4 - Schedule and Duty

- Driver schedules
- Schedule occurrences
- Duty sessions
- Go online/offline
- Start/end schedule
- Asset claim locking
- Optional driver geofence
- Live location

## Phase 5 - Dispatch and Service Jobs

- Service requests
- Quote
- ServiceJob
- Candidate eligibility
- Ranking
- Dispatch offers
- Assignment/reassignment
- Job state machine
- User/driver/admin realtime

## Phase 6 - Dedicated HAL

- Protocol-neutral HAL core
- OCPP 1.6 adapter
- Capability model
- Facts
- Commands
- Recovery
- Trace
- Reconciliation
- CMS contract

## Phase 7 - Charging Integration

- Charging intent
- HAL command dispatch
- HAL fact ingestion
- Charging sessions
- Meter data
- SoC
- Live projections
- Multi-transaction ServiceJob handling

## Phase 8 - Pricing and Customer Commercials

- Pricing policy engine
- Quote snapshots
- Finalization
- Customer payment
- Refund
- GST
- Invoice

## Phase 9 - Driver Compensation

- Compensation policy engine
- Rule composition
- Effective ranges
- Time-of-day semantics
- Source-fact binding
- Ledger line items
- Adjustments
- Driver/Admin summaries

## Phase 10 - Product Completeness

- Ratings/reviews
- Support
- Incidents
- Notifications
- Admin analytics
- Exports
- Operational dashboards
- Recovery tooling

## Phase 11 - Protocol Expansion

- OCPP 2.0.x adapter
- OCPP 2.1 adapter if required
- Vendor extensions
- Future protocol adapters

---

# 47. Verification and Acceptance

"Implemented" must not mean only "compiles".

Verification should include:

## Unit tests

- State transition tests
- Pricing rule tests
- Compensation rule tests
- Eligibility tests
- Ranking tests
- Geofence tests
- Snapshot tests
- Asset-claim tests
- Adapter tests

## Database integration

- Real PostgreSQL
- Migration up/down where safe
- Concurrency
- Unique/exclusion constraints
- Idempotency
- Transaction rollback behavior

## Service integration

- CMS <-> HAL commands
- HAL <-> CMS facts
- Duplicate facts
- Integrity conflicts
- Timeouts
- Uncertain delivery
- Recovery

## End-to-end

At minimum:

```text
User creates request
-> temporary/saved vehicle and address
-> quote
-> dispatch
-> driver duty session selected
-> matching Vehicle + Charger validated
-> driver assigned
-> driver travels
-> arrival
-> charging command
-> real transaction start
-> meter updates
-> transaction stop
-> ServiceJob wrap-up
-> final price
-> payment
-> invoice
-> driver compensation calculation
-> history/realtime/admin views agree
```

Also test:

- Reassignment
- Wrong pairing report
- Temporary driver pairing
- Schedule mode
- Unscheduled mode
- Geofenced mode
- No driver geofence
- Charger incompatibility
- HAL reconnect
- Multiple charging transactions
- Pricing change during job
- Compensation rule boundary crossing

---

# 48. Definition of Done

A feature is not done until:

1. Domain semantics are defined.
2. Ownership is clear.
3. Persistence is correct.
4. API contract is explicit.
5. Authorization is enforced.
6. Idempotency is considered.
7. Failure behavior is defined.
8. Recovery behavior is defined.
9. Historical impact is defined.
10. Realtime impact is defined.
11. Audit impact is defined.
12. Migration impact is handled.
13. Tests cover happy and important failure paths.
14. OpenAPI is updated.
15. Documentation is updated.
16. End-to-end behavior is verified where possible.
17. No old assumption silently contradicts the new behavior.
18. Completion claims distinguish source correctness from runtime/physical acceptance.

---

# 49. Final Architectural Summary

Charger on Wheels is best understood as:

```text
Mobile field service
+
EV charging CMS
+
OCPP control platform
+
Dispatch
+
Driver workforce
+
Fleet operations
+
Customer commerce
+
Driver compensation analytics
```

Its central business object is the **ServiceJob**.

Its central driver runtime object is the **DriverDutySession**.

Its central physical charging authority is the **dedicated HAL**.

Its central design rule is:

> Preserve intended state, observed reality, physical evidence, commercial truth, and historical snapshots separately, then compose them explicitly.

The platform should be built so that normal operations are easy, but abnormal real-world conditions are also representable without lying to the system.

That includes:

- Drivers swapping vehicles
- Chargers moving between vehicles
- Admin records being stale
- Temporary customer vehicles
- Temporary service addresses
- Temporary/observed driver asset combinations
- Schedule deviations
- Optional driver geofences
- Reassignment
- Charger faults
- Multiple OCPP transactions
- Uncertain command delivery
- Pricing changes
- Compensation changes
- Future OCPP versions

The dedicated HAL must remain protocol-neutral and adapter-driven so OCPP 1.6, OCPP 2.0.x, OCPP 2.1, future OCPP revisions, vendor-specific protocols, or test/simulator transports can be added without forcing the CMS or HAL core to be rewritten.

This document is the planning baseline for the new Charger on Wheels backend architecture.
