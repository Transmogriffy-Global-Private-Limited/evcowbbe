> PACKAGE STATUS: NON-NORMATIVE FOCUSED VIEW. `01_CANONICAL_FULL_BLUEPRINT.md` is the only design authority in this ZIP. This file exists for lower-context reading and provenance; it MUST NOT introduce a requirement that is absent from the canonical blueprint. If wording differs, canonical wins.

# Charger on Wheels - User App Preserved Contract and Product Flow Blueprint

This is the standalone User App implementation contract extracted from the canonical Charger-on-Wheels blueprint. It preserves mature User App behaviors that remain semantically correct while adapting CPO-local EV-CMS assumptions to the single-platform Charger-on-Wheels product.

It covers identity/session behavior, saved and temporary customer data, quoting/jobs, charging progress vs physical truth, payments, invoice, ratings, support, realtime recovery, error handling, idempotency expectations, and end-to-end acceptance. The User App never calls HAL directly and never becomes an alternate source of charging/commercial truth.

---

# 3. Architectural Laws and Invariants

These rules are global and must hold across every module.

## 3.1 Separate different kinds of truth

The system MUST preserve these as distinct concepts:

- Administrative/intended state.
- Observed real-world operational state.
- Physical charger/protocol truth.
- Historical snapshot state.
- Customer commercial truth.
- Driver compensation truth.
- Derived/realtime projections.

No convenience field may silently collapse them.

Examples:

- Admin pairing says Vehicle V1 carries Charger C1.
- Driver reports Vehicle V1 actually carries Charger C2.
- Current duty may proceed with observed C2 if policy permits.
- Admin sees a mismatch requiring reconciliation.
- Master pairing remains unchanged until deliberately corrected.
- Historical duty remains permanently tied to the actual observed combination used.

## 3.2 History does not mutate because master data changes

Every historical ServiceJob MUST preserve its own vehicle, service-address, pricing, tax, assignment, and relevant identity snapshots.

Every DriverDutySession MUST preserve its actual vehicle/charger context.

Every finalized compensation result MUST preserve the policy/rule versions and source facts used.

Every invoice MUST preserve the commercial facts used to create it.

Editing a CustomerVehicle, CustomerAddress, ServiceVehicle, Charger, pricing policy, compensation policy, driver profile, or admin assignment later MUST NOT rewrite historical records.

## 3.3 Physical charging truth comes from HAL facts

UI intent, CMS command dispatch, socket write success, or charger command acceptance MUST NOT be represented as a physical charging start.

Physical charging start requires normalized HAL transaction evidence.

Energy delivered requires normalized meter evidence.

Physical charging end requires normalized HAL transaction-end evidence or an explicit reconciled equivalent.

## 3.4 Service lifecycle and charging lifecycle are independent

A ServiceJob may be ARRIVED or SERVICE_PREPARING before physical charging starts.

A physical transaction may end while the ServiceJob remains in WRAP_UP.

A charger fault may end one ChargingSession while the same ServiceJob later starts another ChargingSession.

## 3.5 Customer price and driver compensation are separate engines

They may consume overlapping facts, but they MUST have independent policies, snapshots, ledgers, correction semantics, and administrative permissions.

Customer price changes MUST NOT implicitly change driver compensation.

Driver compensation changes MUST NOT change customer invoices.

## 3.6 External mutations are idempotent or reconcilable

Any mutation that can be retried across network boundaries MUST have one of:

- durable idempotency key semantics;
- a stable operation identity plus exact reconciliation;
- a provider-native idempotency mapping stored durably.

In-memory dedupe is never sufficient for externally retried business mutations.

## 3.7 Realtime is advisory, durable state is recoverable

Realtime messages tell clients that state changed and MAY carry a safe projection.

The client MUST be able to recover authoritative current state using HTTP APIs after disconnect/reconnect.

No critical state transition exists only in WebSocket memory.

## 3.8 Feature completeness remains invariant under extension

Adding a new adapter, vehicle type, charger protocol, pricing component, compensation component, user role, or realtime consumer MUST NOT degrade already-supported correctness properties.

Existing paths retain authorization, idempotency, auditability, verification, and documentation guarantees after extension.

## 3.9 Every actor is a real user

Customer, driver, dispatcher, recruiter, finance operator, support operator, technical/HAL operator, read-only observer, automated worker, CMS, HAL, and external payment provider are all first-class actors with explicit contracts and failure modes.

---

# 4. Chosen Technical Shape

## 4.1 CMS/backend

The initial Charger-on-Wheels CMS SHOULD be a modular monolith because the domains are strongly transactional and still one product boundary.

Chosen baseline:

- Go 1.25.
- Gin HTTP stack.
- PostgreSQL as durable truth.
- Versioned SQL migrations.
- OpenAPI 3.x as machine contract.
- Structured JSON logging.
- Durable database outbox workers for externally visible side effects.
- WebSocket or SSE realtime fanout built from durable/authoritative state changes, not as a source of truth.

The implementation MUST keep package boundaries strong enough that later extraction remains possible without changing domain semantics.

## 4.2 HAL

HAL is a separate Go service/repository/process with its own persistence and deployment lifecycle.

It MUST be protocol-neutral in the core and adapter-driven at the edges.

The first physical-protocol adapter is OCPP 1.6 unless hardware requirements force another initial protocol.

OCPP 2.0.1, OCPP 2.1, vendor adapters, and simulator adapters are additive extensions of the same normalized core.

## 4.3 Databases

CMS and HAL MUST use separate PostgreSQL databases and MUST NOT share tables or database credentials.

Cross-service communication uses authenticated HTTP and/or durable callback/fact delivery contracts.

## 4.4 Recommended repositories

Logical repository identities:

- `charger-on-wheels-backend`
- `charger-on-wheels-hal`

The exact Git organization/remote may be chosen during bootstrap. Once created, repository identity becomes part of the deployment contract and must be documented.

---

# 5. System Context and Deployment Topology

## 5.1 Logical topology

```text
User App -----------\
Driver App ----------> Charger-on-Wheels CMS/API -----> PostgreSQL (CMS)
Admin App -----------/          |   |   |
                               |   |   +--> Mail/notification providers
                               |   +------> Razorpay customer payments
                               +----------> Dedicated HAL API
                                              |
                                              +--> PostgreSQL (HAL)
                                              +--> charger WebSocket/OCPP/proprietary links
```

## 5.2 Trust boundaries

- User/Driver/Admin clients are untrusted network clients.
- CMS auth context is authoritative for human identity.
- CMS MUST NOT trust arbitrary client-supplied actor IDs, driver IDs, or admin capability claims.
- HAL is a trusted service only after service-to-service authentication succeeds.
- Charger-provided data is physical evidence but still untrusted input and must be validated/normalized.
- Razorpay/webhook payloads are trusted only after signature verification and replay/idempotency handling.

## 5.3 Environment tiers

At minimum:

- local development;
- shared development/integration;
- staging/pre-production;
- production.

Development and staging MUST use separate databases and separate HAL identities from production.

No production database may be used as an automated test database.

---

# 7. Identity, Authentication, Authorization, and Sessions

## 7.1 Principal types

Use distinct authenticated principal types:

- `CUSTOMER`
- `DRIVER`
- `ADMIN`
- `SERVICE`

A customer ID must never be interpreted as a driver/admin user ID even if UUID types are identical.

## 7.2 Accounts

V1 uses one common credential-bearing account layer; Customer, Driver, and Admin domain principals and authorization remain separate. Canonical Section 7.2 contains the frozen rules.

Recommended durable model:

```text
accounts
account_sessions
account_devices
customer_profiles
driver_profiles
admin_memberships
roles
capabilities
role_capabilities
admin_capability_overrides
```

## 7.3 Session requirements

Human sessions MUST support:

- revocation;
- expiration;
- device/session listing;
- refresh rotation if refresh tokens are used;
- server-side invalidation on suspension/offboarding where required;
- last-used metadata without logging secrets.

## 7.4 Admin RBAC

Admin access is capability-based. Role names are convenience bundles only.

Initial role bundles:

- `FULL_ADMIN`
- `OPERATIONS`
- `DRIVER_RECRUITMENT`
- `FINANCE_COMMERCIAL`
- `SUPPORT`
- `TECHNICAL_HAL`
- `READ_ONLY`

Capabilities, not role names, authorize endpoints.

Suggested capability namespace:

```text
users.read
users.manage

drivers.read
drivers.review
drivers.manage
drivers.suspend

fleet.read
fleet.manage
fleet.maintenance
fleet.assign

schedules.read
schedules.manage

dispatch.read
dispatch.manage
dispatch.override

jobs.read
jobs.manage
jobs.cancel
jobs.reassign

charging.read
charging.command
charging.reconcile
charging.trace.read

pricing.read
pricing.manage

payments.read
payments.manage
refunds.manage
invoices.read
invoices.manage

compensation.read
compensation.manage
compensation.adjust

ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage

system.settings.read
system.settings.manage
audit.read
```

Explicit DENY overrides role defaults if membership-level overrides are implemented.

## 7.5 Service authentication

CMS <-> HAL MUST use service credentials independent of human auth.

Service requests MUST include:

- authenticated service identity;
- request/correlation ID;
- stable operation/fact ID for idempotent operations;
- frozen v1 service authentication uses TLS plus separate opaque bearer credentials for command, fact, and trace planes; canonical Section 7.5 is authoritative.

---

# 8. Universal HTTP/API Contract

## 8.1 Versioning

Initial public API prefix:

```text
/api/v1
```

Internal CMS-only service API prefix:

```text
/internal/v1
```

The separately hosted HAL is its own service and deliberately uses its own service-major root:

```text
/v1
```

Therefore `HAL_ORIGIN + /v1/...` is not a public CMS route and does not conflict with CMS `/internal/v1/...`. Browser/mobile clients never receive the HAL origin or service credentials.

Breaking contract changes require a new version or a backwards-compatible migration strategy.

## 8.2 Envelope

Success responses SHOULD use the resource directly unless pagination/metadata requires an envelope.

Errors use one canonical shape:

```json
{
  "error": {
    "code": "JOB_INVALID_TRANSITION",
    "message": "The job cannot move from ARRIVED to COMPLETED.",
    "request_id": "...",
    "details": {}
  }
}
```

`message` is safe for the client. Internal stack traces, SQL text, secrets, and provider payloads MUST NOT be returned.

## 8.3 Pagination

Use keyset pagination for growing operational/history collections.

Default page size: 20. Maximum: 100 unless an endpoint explicitly documents otherwise.

Ordering must be deterministic, typically:

```text
created_at DESC, id DESC
```

Cursor fields must encode every sort key required to avoid duplicates/skips.

## 8.4 Filtering and sorting

Filtering happens in SQL before LIMIT.

Every list endpoint documents:

- allowed filters;
- allowed sort keys;
- default sort;
- null ordering where relevant;
- full-text/search fields if `q` is accepted.

## 8.5 Idempotency header

Business-create and side-effecting retryable endpoints use:

```text
Idempotency-Key: <client-generated opaque key>
```

Scope is at least authenticated principal + HTTP operation + idempotency key.

Same key + semantically same request returns the same committed result.

Same key + conflicting request returns `409 IDEMPOTENCY_KEY_REUSED`.

## 8.6 Optimistic concurrency

Admin edits of mutable configuration SHOULD use either:

- `version` integer checked in the mutation; or
- strong ETag/If-Match.

Conflicts return 409 rather than silently overwriting a newer edit.

---

# 9. Global Persistence Conventions

## 9.1 IDs

Use UUID primary keys generated server-side, preferably UUIDv7 where implementation support is stable.

Provider IDs, charger protocol IDs, registration numbers, and human-readable job numbers are alternate identifiers, not primary keys.

## 9.2 Time

- Store all event timestamps as timezone-aware PostgreSQL `timestamptz` in UTC.
- Store an explicit IANA timezone on policies where local time affects behavior.
- Default business timezone for India deployment: `Asia/Kolkata`.
- Never compute compensation/time-window rules using server-local implicit timezone.

## 9.3 Money

Store monetary minor units as integers plus ISO currency code.

For INR:

```text
amount_minor = paise
currency = INR
```

Do not use binary floating point for money.

## 9.4 Energy and measurements

Choose canonical internal units and document them:

- energy: Wh integer where possible;
- power: W integer where possible;
- distance: meters integer;
- duration: milliseconds or seconds integer;
- latitude/longitude: decimal numeric precision sufficient for location;
- percentage/SoC: numeric/decimal with explicit range.

API may expose convenient derived units, but durable facts remain canonical.

## 9.5 Soft deletion

Use soft deactivation for identities/assets/configuration that must remain referentially visible to history.

Do not physically delete a driver, vehicle, charger, pricing policy, compensation policy, or saved customer object while history references it unless an explicit anonymization/retention process exists.

## 9.6 Audit columns

Mutable administrative/master tables SHOULD include:

```text
created_at
created_by
updated_at
updated_by
version
```

Historical event tables normally append new rows instead of updating semantic history.

---

# 10. Customer Domain Blueprint

## 10.1 Customer profile

`customer_profiles` minimum fields:

```text
id
account_id
full_name
primary_email
primary_phone
status              # ACTIVE, SUSPENDED, CLOSED
created_at
updated_at
```

Phone/email verification state belongs in auth/contact records rather than inferred from non-null values.

## 10.2 Saved customer vehicles

`customer_vehicles`:

```text
id
customer_id
make
model
variant
registration_number
battery_capacity_wh
supports_ac
supports_dc
max_ac_power_w
max_dc_power_w
connector_types[] or normalized relation
is_saved
is_active
created_at
updated_at
version
```

`is_saved=false` may represent a previously temporary object promoted into a reusable normalized record only if the chosen model preserves history. The authoritative history remains the ServiceJob snapshot.

## 10.3 Saved addresses

`customer_addresses`:

```text
id
customer_id
label
line1
line2
locality
city
state
postal_code
country_code
latitude
longitude
landmark
building_instructions
floor
contact_instructions
geocode_provider
geocode_provider_place_id
is_default
is_active
created_at
updated_at
version
```

Only one active default address per customer should be enforced transactionally.

## 10.4 Temporary data

A request can use:

- existing saved vehicle ID;
- inline temporary vehicle object;
- existing saved address ID;
- inline temporary address object.

The backend snapshots the resolved representation into the ServiceJob regardless of source.

A temporary object does not need to become saved master data merely because a job exists.

## 10.5 Promotion

Promotion endpoints copy eligible historical snapshot fields into new or existing saved master data under the customer account.

Promotion MUST NOT replace the historical snapshot or make history refer to the newly saved row as its source of truth.

Recommended endpoints:

```text
POST /api/v1/app/jobs/{job_id}/vehicle/promote
POST /api/v1/app/jobs/{job_id}/address/promote
```

Idempotency is required because clients may retry after timeout.

---

# 16. Service Request, Quote, and ServiceJob Blueprint

## 16.1 ServiceRequest

A ServiceRequest is the customer's expressed request before an operational job is fully committed.

Fields:

```text
id
customer_id
request_type            # IMMEDIATE, SCHEDULED
requested_for nullable
requested_vehicle_source # SAVED, TEMPORARY
requested_address_source # SAVED, TEMPORARY
vehicle_input jsonb
address_input jsonb
charging_preference jsonb
status                  # DRAFT, QUOTED, CONFIRMED, EXPIRED, CANCELLED
created_at
updated_at
```

## 16.2 Quote

A Quote is a time-bounded commercial offer derived from current request facts and pricing policy.

`quotes`:

```text
id
service_request_id
customer_id
pricing_policy_id
pricing_policy_version
currency
estimated_components jsonb
estimated_total_minor
valid_until
assumptions jsonb
status                 # ACTIVE, ACCEPTED, EXPIRED, SUPERSEDED
created_at
```

A quote is an estimate unless the component is explicitly guaranteed.

The quote MUST disclose important non-guaranteed dimensions, for example energy/time finalization based on actual charging.

## 16.3 Job creation boundary

Accepting a valid quote creates the ServiceJob transactionally or through an idempotent orchestration boundary.

At creation, snapshot:

- customer identity relevant to service/invoice;
- service address;
- customer EV;
- requested charging preference;
- accepted quote/pricing inputs;
- initial tax context if applicable;
- scheduling target;
- source request and quote IDs.

## 16.4 ServiceJob record

`service_jobs` minimum durable shape:

```text
id
job_number
customer_id
service_request_id
accepted_quote_id
status
status_reason nullable
request_type
requested_for nullable

service_address_snapshot jsonb
customer_vehicle_snapshot jsonb
charging_preference_snapshot jsonb

current_offer_id nullable
current_assignment_id nullable
current_duty_session_id nullable
current_vehicle_id nullable
current_charger_id nullable

pricing_snapshot_id nullable
final_price_minor nullable
currency

created_at
confirmed_at
dispatch_started_at nullable
assigned_at nullable
accepted_at nullable
en_route_at nullable
arrived_at nullable
service_preparing_at nullable
charging_started_at nullable
charging_ended_at nullable
wrap_up_at nullable
completed_at nullable
cancelled_at nullable
failed_at nullable

version
```

Timestamps are facts for the first/authoritative transition where semantically appropriate; event history preserves all transitions.

## 16.5 ServiceJob state machine

Canonical states:

```text
REQUESTED
QUOTED
DISPATCHING
ASSIGNED
ACCEPTED
EN_ROUTE
ARRIVED
SERVICE_PREPARING
CHARGING
WRAP_UP
COMPLETED
REASSIGNING
CANCELLED
FAILED
NO_SHOW
EXPIRED
```

In the persisted implementation, `REQUESTED` and `QUOTED` may remain pre-Job request states if ServiceJob is only created on quote acceptance. If so, the ServiceJob itself begins at `DISPATCHING` (or scheduled equivalent). The public product lifecycle may still show request/quote phases. Do not duplicate objects merely to satisfy a label.

## 16.6 Required transition graph

Minimum legal path:

```text
DISPATCHING -> ASSIGNED | CANCELLED | EXPIRED | FAILED
ASSIGNED -> ACCEPTED | DISPATCHING | REASSIGNING | CANCELLED | FAILED
ACCEPTED -> EN_ROUTE | REASSIGNING | CANCELLED | FAILED
EN_ROUTE -> ARRIVED | REASSIGNING | CANCELLED | FAILED | NO_SHOW
ARRIVED -> SERVICE_PREPARING | REASSIGNING | CANCELLED | FAILED | NO_SHOW
SERVICE_PREPARING -> CHARGING | REASSIGNING | CANCELLED | FAILED
CHARGING -> WRAP_UP | FAILED
WRAP_UP -> COMPLETED | FAILED
REASSIGNING -> DISPATCHING | ASSIGNED | CANCELLED | FAILED
```

Additional transition from `ARRIVED` directly to `WRAP_UP` is permitted only for an explicit zero-charge/aborted-service closeout reason and commercial policy that can finalize it.

`COMPLETED`, `CANCELLED`, `FAILED`, `NO_SHOW`, `EXPIRED` are terminal for the job lifecycle. Corrections use administrative correction records, refunds/adjustments, support, or incident workflows rather than reopening history casually.

## 16.7 Transition authorization

Every transition declares allowed actor(s):

- Customer.
- Assigned Driver.
- Admin capability.
- System worker.
- HAL fact handler.

No generic `PATCH status` endpoint is allowed for User or Driver.

Admin overrides use explicit action endpoints with reason and audit trail.

## 16.8 Job event history

`service_job_events` is append-only:

```text
id
service_job_id
event_type
from_status nullable
to_status nullable
actor_type
actor_id nullable
occurred_at
reason_code nullable
metadata jsonb
request_id
```

This is not a substitute for domain-specific records such as assignments, payments, or charging sessions; it is the high-level job timeline.

---

# 18. Charging CMS Domain Blueprint - Preserved Mature Flow

This section is deliberately based on the proven behavioral architecture in `ev-cms-backend-new` and `ocpp-hal-go-new`, adapted to Charger on Wheels rather than copied mechanically.

The inheritance rule is:

1. Preserve the truth boundaries, identifier discipline, idempotency, ambiguity handling, projection/freshness rules, and recovery model.
2. Replace CPO-specific and fixed-station assumptions with Charger-on-Wheels ServiceJob, DriverDutySession, ServiceVehicle, and mobile Charger context.
3. Do not make the new services wire-compatible with EV-CMS merely for familiarity. The new contract is free to rename additive fields where the new domain genuinely differs, but semantic safety MUST remain equivalent or stronger.
4. A future simplification is allowed only if it can prove that the removed distinction cannot exist in Charger-on-Wheels reality.

## 18.1 Separate start intent, physical session, stop request, and general charger operation

Do not use one generic `ChargingIntent` row to mean all of the following:

- commercial/admission request to start charging;
- a physical charging session;
- a stop request;
- an administrative charger operation such as reset/unlock/availability;
- a HAL transport attempt.

Those are different concepts and have different recovery rules.

The CMS MUST model at least:

```text
ChargingStartIntent
ChargingSession
ChargingStopRequest
ChargerOperation        # non-start/stop administrative/technical commands
HALCommandRecord        # CMS projection of the HAL command identity/state
HALFactReceipt
HALChargerMapping
HALChargerRuntime
HALConnectorRuntime
```

`ServiceJob` remains the business parent. A physical charging session does not replace the ServiceJob.

## 18.2 Identifier chain

The following identities are distinct and MUST never be inferred from one another:

```text
service_job_id
assignment_id
duty_session_id
cms_charger_id
public/display charger identity
charger_protocol_identity
cms_connector_id
protocol_connector_number
cms_start_intent_id
cms_charging_session_id
cms_command_id
app_charging_credential / protocol authorization token
hal_command_id
hal_transaction_id
protocol_transaction_id
hal_fact_id
```

Rules:

- CMS owns all `cms_*`, ServiceJob, assignment, duty, customer, driver, and commercial identities.
- HAL owns `hal_command_id`, `hal_transaction_id`, protocol connection state, and the protocol transaction identity allocated/accepted by the protocol runtime.
- `charger_protocol_identity` is mapping evidence, not the CMS primary key.
- Connector number is protocol addressing, not a CMS connector UUID.
- A public/display charger ID is not a protocol identity unless the mapping explicitly says so.
- No recovery may correlate by "latest transaction", charger plus time window, display ID, or guessed connector.
- Zero UUIDs, empty identifiers, malformed UUIDs, and inconsistent identity chains are invalid rather than aliases for unknown.
- Unknown is represented by NULL/absence, never an all-zero UUID.

For OCPP 1.6, the exact `transactionId` is allocated by the Central System/HAL only when the charger-originated `StartTransaction` is accepted. CMS MUST never fabricate or substitute it.

## 18.3 One-use charging credential

The initial app-controlled charging vertical SHOULD preserve the proven one-use credential model.

Before requesting remote start, CMS creates a short-lived opaque credential, for example:

```text
cowv1_<random>
```

The credential is:

- generated by CMS;
- bound to one ChargingStartIntent;
- bound to the intended charger and connector where connector selection is known;
- associated with the owning customer and ServiceJob inside CMS;
- optionally associated with the current assignment/duty session for audit;
- short-lived;
- one-use;
- replay-resistant;
- never equal to a customer, driver, job, session, or database UUID;
- secret operational material and therefore redacted from logs, traces, analytics, errors, and external notifications.

CMS SHOULD persist only the credential hash after successful command construction whenever raw-value replay is not required. The raw value crosses to HAL only through the authenticated start-command boundary.

If the new HAL adapter/protocol does not require an idTag-like value, the semantic credential still remains useful as the one-use authorization/correlation token between CMS admission and physical-start evidence. An adapter may translate or omit the protocol representation, but the CMS intent still has a distinct authorization identity.

## 18.4 Commercial/admission boundary before start

A ChargingStartIntent is created only after CMS has established everything that must be true before asking hardware to energize.

The exact customer payment strategy is intentionally a pre-burner product decision elsewhere in this blueprint. Therefore Charger-on-Wheels MUST preserve the mature ordering without hard-coding the old wallet model.

In one CMS transaction, as applicable:

1. authenticate the initiating actor;
2. load and lock the ServiceJob/current assignment where required;
3. prove the job is in a start-eligible state;
4. prove the driver/duty session/actual vehicle/charger context is the current operational context;
5. validate customer EV versus connector/charger compatibility;
6. derive trusted customer/service scope server-side;
7. resolve the effective customer pricing policy and active tax configuration;
8. freeze the charging-relevant pricing/tax snapshot or reference the already-frozen ServiceJob commercial snapshot according to the selected pricing design;
9. calculate any required affordability, deposit, authorization, prepaid balance, or spending-safety boundary according to the chosen payment strategy;
10. create the corresponding durable funding reservation/hold only if that strategy actually has one;
11. generate the one-use charging credential;
12. create the immutable ChargingStartIntent;
13. create the CMS command identity and immutable dispatch envelope;
14. emit only the internal domain/outbox records that belong to the committed CMS transaction.

No network call to HAL occurs inside that database transaction.

If the eventual business model is post-service collection with no funding reservation, step 9 records admission policy and step 10 is absent. Do not invent a fake wallet hold simply to imitate EV-CMS.

## 18.5 Mapping synchronization and race closure

CMS owns the intended charger/connector inventory and mapping. HAL owns protocol connectivity and validates that command destinations match an approved mapping.

Before a first start can be attempted on a mapping revision, CMS MUST ensure HAL knows the committed mapping.

Recommended ordering, preserving the mature system:

```text
committed CMS charger/connector inventory
-> mapping state PENDING/RECONCILIATION_REQUIRED if not synchronized
-> authenticated idempotent mapping PUT to HAL
-> mapping SYNCHRONIZED
-> create/freeze charging admission transaction
-> reconfirm mapping revision immediately before RequestStart
-> send start only if the exact frozen destination is still valid
```

The second confirmation closes the race where the physical/admin mapping changes between commercial admission and network dispatch.

If the prerequisite mapping fails before any commercial/start-intent transaction is committed:

```text
reject start
no ChargingStartIntent
no funding hold/reservation
no command record
```

If post-commit mapping confirmation fails before HAL start invocation:

```text
terminalize the unattempted command
release only the still-unspent funding reservation if one exists
terminalize the start intent as REJECTED or EXPIRED as appropriate
return a stable mapping-unavailable error
```

Do not leave a durable funding reservation attached to a command proven never to have crossed the HAL boundary.

## 18.6 ChargingStartIntent lifecycle

Use an explicit state machine equivalent to the mature flow:

```text
REQUESTED
ACCEPTED_FOR_DELIVERY
PROTOCOL_ACKNOWLEDGED
ACTUALLY_STARTED
REJECTED
EXPIRED
RECONCILIATION_REQUIRED
```

Meaning:

| State | Durable meaning |
| --- | --- |
| `REQUESTED` | CMS admission, immutable start intent, commercial snapshot, credential, and any required funding reservation are committed. HAL has not yet durably accepted the logical start command. |
| `ACCEPTED_FOR_DELIVERY` | HAL durably knows the logical start command. This does not mean OCPP/protocol acceptance and does not mean charging started. |
| `PROTOCOL_ACKNOWLEDGED` | The charger/protocol accepted the remote-start command. This still does not prove physical charging start. |
| `ACTUALLY_STARTED` | Authoritative charger-originated transaction-start evidence passed the complete identifier/correlation checks and materialized one CMS ChargingSession. |
| `REJECTED` | The start cannot proceed and no authoritative start evidence exists. |
| `EXPIRED` | The approved start window ended without authoritative physical-start evidence. |
| `RECONCILIATION_REQUIRED` | Delivery, identity, mapping, late evidence, or correlation is ambiguous and truth cannot safely be concluded. |

Allowed transition principles:

```text
REQUESTED -> ACCEPTED_FOR_DELIVERY | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
ACCEPTED_FOR_DELIVERY -> PROTOCOL_ACKNOWLEDGED | ACTUALLY_STARTED | REJECTED | EXPIRED | RECONCILIATION_REQUIRED
PROTOCOL_ACKNOWLEDGED -> ACTUALLY_STARTED | EXPIRED | RECONCILIATION_REQUIRED
REJECTED -> RECONCILIATION_REQUIRED only on contrary late evidence
EXPIRED -> RECONCILIATION_REQUIRED only on contrary late evidence
RECONCILIATION_REQUIRED -> evidence-backed state only
```

A remote-start timeout after possible transmission is never `REJECTED` merely because CMS did not receive a response.

## 18.7 No CMS ChargingSession before physical-start evidence

There MUST be no normal materialized ChargingSession just because:

- the user/driver tapped Start;
- CMS created a start intent;
- CMS sent an HTTP request;
- HAL persisted the command;
- HAL returned `202`;
- the protocol returned RemoteStart accepted.

A CMS ChargingSession is materialized only from authoritative normalized transaction-start evidence with a valid identifier chain.

Initial CMS ChargingSession states:

```text
ACTIVE
STOP_PENDING
RECONCILIATION_REQUIRED
COMPLETED
FAILED             # only for evidence-backed non-commercial failure semantics
```

`ACTIVE` requires the real transaction-start fact. `STOP_PENDING` is a CMS projection indicating a durable stop request exists while physical completion remains absent. `RECONCILIATION_REQUIRED` preserves occupancy and blocks unsafe duplicate settlement/starts when physical truth is incomplete.

## 18.8 Materializing transaction-start evidence

For `transaction.started`, CMS MUST validate before session creation:

- immutable fact ID/digest integrity;
- known supported schema version;
- exact CMS charger mapping;
- exact CMS connector mapping;
- charger protocol identity;
- connector number;
- nonzero HAL command identity where contract requires it;
- exact CMS command identity;
- exact ChargingStartIntent identity;
- one-use credential/hash correlation;
- HAL transaction identity;
- protocol transaction identity where present;
- receipt/order/timestamp policy;
- current start intent has not already materialized a different transaction;
- no conflicting nonzero identity was previously accepted.

One accepted start fact materializes exactly one CMS session for that start intent.

A duplicate identical fact is a no-op success. A same fact ID with altered immutable content is an integrity violation. A different fact claiming a conflicting transaction identity moves the affected CMS truth to reconciliation rather than choosing whichever arrived last.

## 18.9 ChargingSession persistence

`charging_sessions` SHOULD include at least:

```text
id
service_job_id
assignment_id
duty_session_id
customer_id
charger_id
connector_id
start_intent_id UNIQUE
start_command_id
hal_command_id nullable
hal_transaction_id UNIQUE nullable
protocol_transaction_id nullable
state
started_at
completed_at nullable
meter_start_wh
latest_meter_wh nullable
meter_stop_wh nullable
consumed_wh nullable
latest_meter_sequence nullable
latest_meter_observed_at nullable
initial_soc_percent nullable
latest_soc_percent nullable
latest_soc_sequence nullable
latest_soc_observed_at nullable
final_soc_percent nullable
settlement_state
reconciliation_reason nullable
created_at
updated_at
```

The exact schema may split projection tables, but uniqueness and identity-chain semantics MUST remain enforceable at the database/service boundary.

## 18.10 Meter evidence

Energy across CMS/HAL uses integer Wh as the durable cross-service unit unless a future measurement explicitly requires a different exact representation.

HAL emits immutable `transaction.meter` facts only from accepted protocol evidence.

Each accepted meter fact carries enough information to prove:

```text
hal_transaction_id
protocol_transaction_id
cms_start_intent_id
cms_charger_id / mapped identity chain
cms_connector_id / connector number chain
meter_sequence
meter_value_wh
consumed_wh
meter_observed_at
```

Rules:

- Never interpolate a missing meter reading.
- Never estimate authoritative energy from charger rated power and elapsed time.
- CMS may compute UI projections from measured facts, but the displayed result must remain distinguishable from authoritative final settlement values.
- CMS advances the current meter projection only on a strictly newer accepted sequence.
- Delayed older facts remain receipts/evidence and MUST NOT regress the live projection.
- Consumption cannot silently become negative because a register rolled backward.
- Completion uses an evidence-backed nondecreasing final meter policy.
- The inherited one-Wh quantization exception MAY be retained for adapters/hardware where proven relevant: a raw final register exactly one Wh below the latest temporally eligible accepted sample may be preserved as raw evidence while the normalized billable cumulative meter remains nondecreasing and the normalization is explicitly tagged. Do not generalize this tolerance without evidence.

## 18.11 SoC evidence is independent from energy

State of Charge is a separate optional evidence stream.

Rules:

- Missing SoC means unknown, never zero.
- SoC MUST NOT be derived from delivered Wh and nominal battery capacity as if it were charger truth.
- SoC-only evidence does not invent an energy sample.
- Energy-only evidence does not copy a cached SoC into a new observation.
- SoC has its own sequence and observed timestamp.
- SoC freshness is calculated independently even if it uses the same configured stale duration initially.
- A completed session's `final_soc_percent` is the last accepted observation, not necessarily a stop-time measurement unless its timestamp proves that.

A future target-SOC stop rule is allowed only when the chosen charger/protocol evidence is trustworthy enough for that rule. Otherwise target SOC is advisory rather than a guaranteed physical cutoff.

## 18.12 Stop request and completion are different truths

Stop may be initiated by:

- assigned Driver;
- Customer if enabled by product policy;
- authorized Admin technical/operations capability;
- CMS automatic charging target logic;
- funding/commercial safety logic;
- HAL deadline/energy threshold derived from CMS instructions;
- charger/local hardware/operator without any CMS stop request.

A stop request creates/reuses a durable `ChargingStopRequest` and CMS command identity.

The HAL response to RemoteStop or equivalent is command evidence only.

The ChargingSession remains `ACTIVE` or `STOP_PENDING` until authoritative transaction-completion evidence is accepted.

A spontaneous charger-originated end MUST be processed even if there is no CMS stop command.

## 18.13 Stop provenance

Preserve business/request provenance separately from protocol completion reason.

The session/completion projection may include:

```text
requested_stop_initiator
requested_stop_reason
protocol_stop_reason
```

Examples:

```text
requested_stop_initiator = SYSTEM
requested_stop_reason    = ENERGY_LIMIT
protocol_stop_reason     = Remote
```

`Remote` is protocol evidence, not the business reason the platform decided to stop.

If the charger stopped locally, `requested_stop_*` may be NULL while `protocol_stop_reason` is present.

## 18.14 Completion and settlement

Only authoritative `transaction.completed` evidence, or an exact HAL transaction-reconciliation snapshot satisfying the same evidence requirements, can physically complete a CMS ChargingSession.

CMS validates:

- exact HAL transaction identity;
- exact protocol transaction identity where applicable;
- exact start-intent/charger/connector chain;
- final meter non-regression;
- completion time not earlier than accepted start;
- no conflicting terminal evidence;
- optional stop provenance fields as provenance only.

Then one CMS transaction performs the idempotent completion side effects that are enabled for the selected business model:

1. lock session and commercial/funding rows in canonical order;
2. persist final physical metrics;
3. finalize pricing from frozen commercial terms and accepted physical facts;
4. perform the allowed payment/capture/debit/release operation exactly once;
5. record commercial ledger/adjustment records;
6. mark settlement result;
7. finalize or enqueue invoice generation according to invoice design;
8. emit durable domain/operational events;
9. transition the ServiceJob toward `WRAP_UP` only when field-service invariants allow it.

Repeated fact delivery or reconciliation MUST NOT create a second payment, debit, capture, refund, invoice, or compensation source fact.

## 18.15 Start ambiguity recovery

A network error after RequestStart may mean any of:

- HAL never received the command;
- HAL persisted it but CMS lost the response;
- HAL transmitted to the charger and the response was lost;
- charging physically started and the fact is delayed.

Therefore:

```text
possible RequestStart delivery
-> RECONCILIATION_REQUIRED
-> exact GET by original cms_command_id
```

Exact command lookup outcomes:

```text
command exists
    -> project HAL command state
    -> retain admission/funding reservation
    -> do not create a new command

canonical 404 / confirmed absent
    -> only if no materialized session exists and identity locks prove absence
    -> mark command CONFIRMED_ABSENT
    -> release unspent funding reservation if any
    -> REJECTED, or EXPIRED if the start window has elapsed

401/403/409/422/5xx/timeout/malformed response
    -> retain RECONCILIATION_REQUIRED
    -> retain occupancy/funding safety
    -> bounded retry of the same exact lookup
```

For an accepted/unmaterialized start that remains unresolved beyond a configured threshold, CMS SHOULD also query the exact transaction by `cms_start_intent_id`. A valid returned HAL transaction is fed through the same locked materializer as a normal `transaction.started` fact.

A 404 transaction lookup is not enough by itself to prove the command never crossed the boundary. Reconcile the exact command too.

Late physical-start evidence after CMS believed the intent rejected/expired is never discarded. Preserve it and move the intent to reconciliation; do not silently create a normal session or automatically send a stop unless separately authorized by safety policy.

## 18.16 Completion recovery for missing/delayed fact delivery

For a materialized CMS session with known `hal_transaction_id` and no completion:

```text
GET exact HAL transaction by hal_transaction_id
```

Possible outcomes:

```text
matching terminal transaction with valid completion evidence
    -> reuse the exact same locked finalization path as transaction.completed fact ingress

active/nonterminal transaction
    -> keep session open; no synthetic completion

404 / timeout / HAL unavailable / 5xx
    -> keep occupancy and financial state unchanged; retry later

malformed/conflicting identity, meter, or time evidence
    -> mark session RECONCILIATION_REQUIRED
    -> do not settle or clear occupancy by guesswork
```

A bounded fair cursor SHOULD prevent one old failing session from monopolizing every recovery pass.

## 18.17 Multiple physical starts within one ServiceJob

Charger-on-Wheels retains the plan that one ServiceJob may have multiple physical charging attempts.

The safe initial rule is:

- one accepted physical transaction start creates one CMS ChargingSession;
- if that physical session completes/fails and a later recovery start occurs, create a new ChargingStartIntent and a new ChargingSession under the same ServiceJob;
- do not mutate the first session into a second physical transaction merely to make the UI look continuous;
- the final ServiceJob commercial and driver-compensation engines aggregate the explicitly eligible physical facts across those sessions.

If a future protocol supports one logical transaction surviving transport reconnection, HAL keeps one HAL transaction and the CMS session remains one session. Transport reconnect alone is not a reason to split a charging session.

## 18.18 Customer/Driver initiation policy

Who is allowed to request physical charging start is a product policy, but the backend contract is not duplicated per actor.

For the initial field-service flow:

- Driver start is expected after arrival and preparation.
- Customer MAY be allowed to confirm/readiness-authorize start if product UX requires it.
- Admin MAY request start only under an explicitly capability-gated operational intervention flow with reason/audit.

All actors converge on the same CMS `RequestChargingStart` domain method, which derives trusted IDs from current ServiceJob/assignment context rather than accepting arbitrary charger/driver/customer ownership IDs from the client.

---

# 21. Pricing Engine Blueprint

## 21.1 Pricing ownership

CMS owns all customer-facing commercial truth.

Pricing is configured by Admin, evaluated by CMS, snapshotted at quote/job/finalization boundaries, and never delegated to Driver or HAL.

## 21.2 Policy model

Use versioned policies rather than one mutable global price table.

```text
pricing_policies
  id
  name
  status              # DRAFT, ACTIVE, RETIRED
  currency
  timezone
  effective_from
  effective_to nullable
  version
  created_by
  created_at
  activated_at nullable
  retired_at nullable
```

`pricing_rules`:

```text
id
pricing_policy_id
component_type
operator
priority
conditions jsonb
calculation jsonb
effective_from
effective_to nullable
is_enabled
rule_version
created_at
```

Policies/rules referenced by historical snapshots are never destructively rewritten.

## 21.3 Initial price components

The engine MUST be able to represent these components independently:

```text
VISIT_FEE
DISTANCE_FEE
TRAVEL_TIME_FEE
WAITING_TIME_FEE
ENERGY_FEE
CHARGING_TIME_FEE
FAST_CHARGE_PREMIUM
CONVENIENCE_FEE
PRIORITY_FEE
TIME_WINDOW_MODIFIER
DATE_WINDOW_MODIFIER
ZONE_FEE
DISCOUNT
PROMOTION
MANUAL_ADJUSTMENT
TAX
```

Not every deployment must activate every component.

## 21.4 Rule operators

Supported operators:

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM
MAXIMUM
CAP
```

Operator semantics MUST be deterministic.

Recommended evaluation order:

1. establish raw measurable quantities;
2. calculate base component rules;
3. apply component-specific overrides;
4. apply multipliers/modifiers in ascending priority;
5. apply minimum/maximum/caps;
6. apply discounts/promotions according to explicit stacking rules;
7. calculate tax on explicitly defined taxable bases;
8. apply manual post-finalization adjustments only as separate ledger entries, never by mutating original line items.

## 21.5 Applicability conditions

Rules may condition on bounded, explicit dimensions:

- service type;
- zone;
- customer segment if introduced;
- connector/charging mode;
- charger power band;
- day of week;
- local time window;
- date/date range;
- immediate vs scheduled request;
- priority/emergency flag;
- distance band;
- waiting duration band;
- energy band;
- promotion code.

Do not permit arbitrary executable expressions from Admin input.

## 21.6 Quote calculation

Quote uses known facts and documented assumptions.

Example:

```text
fixed visit fee                        known
estimated travel distance/time         estimated
energy fee                             estimated by requested target / known battery data
waiting                                usually unknown / shown as conditional
final tax                              estimated from quoted taxable components
```

Every estimated component SHOULD expose:

```text
component_type
quantity_estimate
unit
rate
amount_minor
is_estimate
assumption
```

## 21.7 Finalization

Final customer price uses authoritative actual facts where the rule requires them:

- route/eligible travel distance from trusted location/route facts;
- eligible travel duration from job timestamps;
- waiting duration from defined lifecycle boundaries;
- charging time from HAL transaction facts;
- energy from HAL meter facts;
- applicable local-time/date windows from timestamps plus policy timezone;
- accepted promotions from durable promotion records.

Pricing policy changes after the quote/job boundary MUST NOT silently change the already accepted policy snapshot unless product explicitly defines re-quote behavior before dispatch.

## 21.8 PricingSnapshot

`pricing_snapshots` MUST persist:

```text
id
service_job_id
source_quote_id
policy_id
policy_version
currency
timezone
rule_snapshot jsonb
input_snapshot jsonb
created_at
```

Final line items:

```text
customer_charge_line_items
  id
  service_job_id
  pricing_snapshot_id
  component_type
  quantity
  unit
  rate_minor nullable
  operator
  amount_minor
  taxability_code nullable
  source_fact_refs jsonb
  calculation_metadata jsonb
  created_at
```

Final amount is the sum of immutable finalized line items plus explicit later adjustment/refund semantics.

## 21.9 Cancellation/no-show pricing

Cancellation and no-show charges are policy rules, not hard-coded branches.

Conditions may include lifecycle state and timing:

- before assignment;
- after assignment;
- after driver en route;
- after arrival;
- customer no-show;
- driver/platform failure.

Platform-caused failures SHOULD default to no customer penalty unless an explicit business rule says otherwise.

The exact monetary rates remain Admin policy data, not source-code constants.

---

# 22. Payment Blueprint

## 22.1 Provider

Initial customer payment provider: Razorpay.

The provider integration MUST be replaceable behind a payment service contract so core ServiceJob semantics are not Razorpay-specific.

## 22.2 Payment model

`payments`:

```text
id
service_job_id
customer_id
provider
provider_order_id nullable
provider_payment_id nullable
currency
amount_minor
purpose
status
idempotency_key
created_at
updated_at
```

Canonical status:

```text
CREATED
PENDING
AUTHORIZED
CAPTURED
FAILED
CANCELLED
REFUND_PENDING
PARTIALLY_REFUNDED
REFUNDED
```

Do not infer CAPTURED from client callback alone.

## 22.3 Payment order creation

Payment order creation is idempotent.

The backend stores the provider order identity before returning it when possible.

A retry with the same idempotency key reuses the same logical payment order.

## 22.4 Verification

Provider success is established through authenticated server verification:

- signature verification for client-returned payment proof where applicable;
- provider API reconciliation where needed;
- webhook processing;
- idempotent status advancement.

A client telling the backend `payment_success=true` is never authoritative.

## 22.5 Webhooks

Webhook ingress MUST:

1. verify provider signature before parsing into trusted events;
2. persist provider event ID/hash;
3. reject or idempotently accept duplicates;
4. process within a transaction;
5. maintain monotonic payment semantics unless explicit provider correction is supported;
6. emit durable internal event after commit.

## 22.6 Payment timing

The exact customer commercial flow may use preauthorization/hold, deposit, or final payment depending on Razorpay capabilities and business choice.

The blueprint requirement is invariant:

- the platform must not allow a payment race to rewrite finalized job facts;
- final charge amount must be tied to finalized pricing line items;
- any delta between pre-collected amount and final amount has an explicit settlement/refund/additional-charge path;
- failure to collect final money is a commercial state, not a reason to falsify ServiceJob physical completion.

## 22.7 Payment vs job completion

`ServiceJob.COMPLETED` means the field service completed successfully.

Payment may still require reconciliation.

Admin and User views must expose both service status and payment status instead of encoding one into the other.

---

# 23. Refunds and Commercial Adjustments

## 23.1 Refund model

`refunds`:

```text
id
payment_id
service_job_id
amount_minor
currency
reason_code
reason_note nullable
status               # REQUESTED, SUBMITTED, SUCCEEDED, FAILED, CANCELLED
provider_ref nullable
idempotency_key
requested_by_actor_type
requested_by_actor_id
created_at
updated_at
```

## 23.2 Refund safety

Refund request MUST validate:

- captured refundable payment exists;
- requested amount does not exceed remaining refundable amount;
- same logical refund has not already succeeded/pended;
- actor has permission;
- reason is recorded.

Provider timeouts are reconciled by stable refund identity/provider status before retrying.

## 23.3 Manual commercial adjustments

Corrections after invoice/finalization are explicit adjustment records.

Never silently rewrite historical base pricing line items.

Adjustment types may include:

```text
CUSTOMER_CREDIT
CUSTOMER_DEBIT
GOODWILL_CREDIT
DISPUTE_CORRECTION
TAX_CORRECTION
ROUNDING_CORRECTION
```

Accounting/invoice handling for post-invoice tax corrections must comply with the chosen GST/accounting process and may require credit/debit-note features in a later scope.

---

# 24. GST and Invoice Blueprint

## 24.1 Tax snapshots

The system MUST snapshot tax-relevant configuration used for a finalized job/invoice.

`gst_snapshots` may include:

```text
supplier legal name
supplier GSTIN
supplier address
place of supply
customer tax identity if supplied
SAC/HSN classifications as applicable
rates
component taxability
CGST/SGST/IGST split
rounding rules
```

Do not recalculate old invoices from current tax configuration.

## 24.2 Invoice lifecycle

Canonical states:

```text
PENDING
GENERATING
READY
FAILED
VOIDED
```

A READY invoice artifact is immutable.

If a correction legally requires a new document, create a new version/corrective document rather than regenerating the same historical file in place.

## 24.3 Invoice artifact storage

Invoices are private artifacts.

Requirements:

- non-public storage;
- access only through authenticated authorization-checked API or signed short-lived delivery mechanism;
- checksum stored;
- renderer/version stored;
- no predictable public static URL;
- backup/retention policy.

## 24.4 Invoice creation flow

1. Service commercial finalization completes.
2. Payment state reaches the configured invoice eligibility boundary.
3. Durable invoice generation intent is created.
4. Worker loads frozen job/pricing/GST/customer/supplier facts.
5. Renderer produces deterministic PDF/artifact.
6. Artifact checksum and metadata are stored.
7. Invoice becomes READY atomically with artifact registration.
8. Notification/mail intent is enqueued after commit.

Rendering failure leaves recoverable FAILED/PENDING state and never marks READY without an artifact.

## 24.5 Download permissions

- User: own job invoice only.
- Admin Finance/Commercial: any invoice permitted by capability.
- Driver: no customer invoice by default.

---

# 26. Ratings and Reviews

## 26.1 Ownership

A customer may rate only a ServiceJob they own and that reached an eligible terminal state.

Initial eligible state: `COMPLETED`.

## 26.2 Rating model

`ratings_reviews`:

```text
id
service_job_id
customer_id
driver_id nullable
rating integer          # 1..5
review_text nullable
created_at
updated_at
version
```

Enforce one rating per customer + ServiceJob.

Customer may edit their own rating/review.

## 26.3 Privacy

User-facing aggregates MUST NOT expose identities of other customers.

Admin may see review text and associated operational context under `ratings.read`.

Driver may see their own aggregate and review text only according to product policy; customer contact/identity should not be exposed merely because a review exists.

## 26.4 Aggregates

Average/rating count SHOULD be computed from authoritative ratings or a rebuildable projection.

If a projection is used for scale, it is derived and must be repairable.

---

# 27. Support and Incident Blueprint

Support and incidents are separate concepts.

- Support: customer/driver asks for assistance or reports a service issue conversationally.
- Incident: operational/safety/technical event requiring structured investigation or resolution.

## 27.1 Support channels

Initial channels:

```text
CUSTOMER_PLATFORM
DRIVER_PLATFORM
```

A support ticket MUST have exactly one owner plane.

## 27.2 Ticket model

```text
support_tickets
  id
  channel
  customer_id nullable
  driver_id nullable
  service_job_id nullable
  subject
  status
  priority
  created_at
  updated_at
  closed_at nullable
```

Status:

```text
OPEN
IN_PROGRESS
RESOLVED
CLOSED
```

Customer/Driver replies to RESOLVED/CLOSED MAY reopen to OPEN under the same durable rules used in the mature EV-CMS support model.

## 27.3 Messages

`support_messages` is append-only.

App-side projections expose author class (`CUSTOMER`, `DRIVER`, `SUPPORT`) rather than unnecessary staff identity.

Private internal notes are separate records and MUST NOT leak to User/Driver clients or outbound mail.

## 27.4 Reply idempotency

Replies require idempotency key and durable uniqueness.

Duplicate retry must not create duplicate message, event, or notification intent.

## 27.5 Incident model

`incidents`:

```text
id
service_job_id nullable
duty_session_id nullable
driver_id nullable
vehicle_id nullable
charger_id nullable
type
severity
status              # OPEN, INVESTIGATING, MITIGATED, RESOLVED, CLOSED
reported_by_actor_type
reported_by_actor_id
reported_at
summary
resolution nullable
resolved_at nullable
```

Examples:

- vehicle breakdown;
- charger fault;
- asset mismatch;
- safety event;
- customer dispute;
- driver emergency;
- HAL unrecoverable fault.

High-severity incidents may block asset/driver eligibility through explicit operational holds rather than silently modifying unrelated master records.

---

# 28. Notification Blueprint

## 28.1 Durable notification intent

Important notifications are produced through a durable outbox after the authoritative transaction commits.

Channels may include:

- in-app;
- push;
- email;
- SMS if later integrated.

## 28.2 Notification content rule

Do not copy sensitive freeform support message bodies, raw KYC, auth data, or raw protocol payloads into external notification payloads.

Use bounded metadata and deep links.

## 28.3 Preference model

Customer/Driver notification preferences may disable optional categories, but mandatory security/safety/legal messages remain governed by platform policy.

Preferences are scoped by notification category and channel.

## 28.4 Delivery states

```text
PENDING
CLAIMED
SENT
FAILED_RETRYABLE
FAILED_TERMINAL
CANCELLED
```

`SENT` means accepted by the configured provider, not necessarily read by the human unless the provider supplies a separate delivery/read fact.

---

# 29. Realtime Blueprint

## 29.1 Purpose

Realtime improves responsiveness. It does not replace durable HTTP state.

## 29.2 Subscription scope

A client may subscribe only to resources it is authorized to read.

Suggested channels/topics:

```text
user:{customer_id}
job:{service_job_id}
driver:{driver_id}
duty:{duty_session_id}
admin:operations
admin:hal
```

Server authorization derives IDs from auth context and resource permissions. Clients cannot subscribe to arbitrary user/driver topics by guessing IDs.

## 29.3 Event envelope

```json
{
  "event_id": "...",
  "type": "service_job.updated",
  "resource_type": "service_job",
  "resource_id": "...",
  "occurred_at": "...",
  "version": 17,
  "request_id": "...",
  "data": { }
}
```

For important state, `data` may be only a compact projection. REST remains recovery authority.

## 29.4 Ordering

Per-resource version or sequence is recommended so clients can detect missed/out-of-order events.

Clients receiving version 15 after version 17 ignore stale data.

A gap can trigger REST refresh.

## 29.5 User realtime

User may receive:

- request/quote expiry;
- dispatch progress;
- assignment;
- driver/mobile unit public projection;
- ETA/location updates;
- arrival;
- charging readiness;
- physical charging start;
- live energy/power/SoC where available;
- projected cost;
- charging end;
- wrap-up/completion;
- payment/invoice changes;
- support updates.

## 29.6 Driver realtime

Driver may receive:

- schedule changes;
- offer created/withdrawn/expired;
- assignment changes;
- job/customer service-location projection;
- admin correction of pairing;
- HAL readiness/fault state;
- charging state;
- compensation calculation completion;
- support/incident updates.

## 29.7 Admin realtime

Admin may receive broad operational invalidations/projections by capability:

- online drivers;
- duty sessions;
- locations;
- dispatch queues;
- jobs;
- asset mismatch;
- charger/HAL connectivity;
- faults;
- payment exceptions;
- invoice failures;
- support/incident queues.

Do not push secrets or full sensitive records over a generic operations stream.

# 31. Public API Surface - User App

The exact request/response schemas belong in OpenAPI. This section defines required semantic operations.

## 31.1 Authentication/profile

The User App preserves the mature verified email + password + OTP flow, adapted to the single Charger-on-Wheels platform account model.

```text
POST   /api/v1/app/auth/signup
POST   /api/v1/app/auth/signup/verify
POST   /api/v1/app/auth/signup/resend

POST   /api/v1/app/auth/login
POST   /api/v1/app/auth/login/verify
POST   /api/v1/app/auth/login/resend

POST   /api/v1/app/auth/refresh
POST   /api/v1/app/auth/logout
POST   /api/v1/app/auth/logout-all
GET    /api/v1/app/auth/sessions
DELETE /api/v1/app/auth/sessions/{session_id}

POST   /api/v1/app/auth/password/forgot
POST   /api/v1/app/auth/password/reset/resend
POST   /api/v1/app/auth/password/reset
POST   /api/v1/app/auth/password/change

GET    /api/v1/app/me
PATCH  /api/v1/app/profile
```

There is no `X-CPO-App-ID` or CPO-local account scope. The authenticated Customer account belongs to this platform. Email uniqueness and any future multi-brand partitioning are CMS domain rules, not client-supplied tenant selection.

## 31.2 Saved vehicles

```text
GET    /api/v1/app/vehicles
POST   /api/v1/app/vehicles
GET    /api/v1/app/vehicles/{vehicle_id}
PATCH  /api/v1/app/vehicles/{vehicle_id}
DELETE /api/v1/app/vehicles/{vehicle_id}      # deactivate/remove from saved list
```

Deletion does not alter historical snapshots.

## 31.3 Saved addresses

```text
GET    /api/v1/app/addresses
POST   /api/v1/app/addresses
GET    /api/v1/app/addresses/{address_id}
PATCH  /api/v1/app/addresses/{address_id}
DELETE /api/v1/app/addresses/{address_id}
POST   /api/v1/app/addresses/{address_id}/make-default
```

## 31.4 Service request and quote

```text
POST /api/v1/app/service-requests
GET  /api/v1/app/service-requests/{request_id}
POST /api/v1/app/service-requests/{request_id}/quote
POST /api/v1/app/quotes/{quote_id}/accept
```

Quote acceptance is idempotent.

## 31.5 Jobs

```text
GET  /api/v1/app/jobs
GET  /api/v1/app/jobs/{job_id}
POST /api/v1/app/jobs/{job_id}/cancel
GET  /api/v1/app/jobs/{job_id}/live
POST /api/v1/app/jobs/{job_id}/vehicle/promote
POST /api/v1/app/jobs/{job_id}/address/promote
```

User can only read/cancel their own jobs and only at allowed lifecycle points.

## 31.6 Charging

If product permits user-initiated stop:

```text
POST /api/v1/app/jobs/{job_id}/charging/stop
```

There is no user endpoint that claims physical start by setting status.

Live charging reads come through job/live projection endpoints.

## 31.7 Payments

```text
POST /api/v1/app/jobs/{job_id}/payments/orders
POST /api/v1/app/payments/{payment_id}/verify
GET  /api/v1/app/jobs/{job_id}/payments
```

Provider client secret/server credentials never go to User App.

## 31.8 Invoices

```text
GET /api/v1/app/jobs/{job_id}/invoice
GET /api/v1/app/invoices/{invoice_id}/download
```

## 31.9 Ratings

```text
GET /api/v1/app/ratings
GET /api/v1/app/jobs/{job_id}/rating
PUT /api/v1/app/jobs/{job_id}/rating
```

`PUT` gives natural idempotent replace semantics for the customer's own rating.

## 31.10 Support

```text
GET  /api/v1/app/support/tickets
POST /api/v1/app/support/tickets
GET  /api/v1/app/support/tickets/{ticket_id}
POST /api/v1/app/support/tickets/{ticket_id}/replies
```

---

## 31.11 Preserved User App architecture rules

The User App inherits the mature EV-CMS client/server rules where they remain semantically valid for Charger on Wheels.

The client architecture is:

```text
User App
  -> Charger-on-Wheels CMS public API
CMS
  -> payment provider when needed
  -> dedicated HAL through private service contracts
HAL
  -> physical charger
```

The User App NEVER:

- calls HAL directly;
- receives HAL service credentials;
- creates a physical charging session because a start command was accepted;
- invents meter, power, voltage, current, SoC, ETA, payment, or completion truth;
- supplies trusted customer/driver/admin ownership IDs to select server scope;
- derives final bill from live displayed metrics;
- treats a realtime event as more authoritative than the corresponding CMS durable snapshot.

The CMS API is the sole app-facing business boundary.

## 31.12 User authentication and session semantics

The initial User App authentication flow is defined, not left open.

### Signup

1. `POST /auth/signup` receives normalized email, password, full name, and optional phone.
2. Password length is 10-128 characters before any stronger password policy configured by security review.
3. Full name is trimmed, non-empty, maximum 255 characters.
4. Phone is optional and, when supplied, is a normalized international-compatible value with 7-15 digits and optional leading `+`.
5. CMS creates an expiring signup challenge and queues OTP delivery only after the challenge is durable.
6. Response is `202` with:

```json
{
  "challenge_id": "<opaque-or-uuid-id>",
  "expires_at": "<rfc3339-utc>",
  "resend_available_at": "<rfc3339-utc>"
}
```

7. `POST /auth/signup/verify` accepts that challenge ID + six-digit code and atomically creates the verified Customer account/profile. It returns `201`. Signup completion does not silently log the user in; the app enters the login flow.
8. `POST /auth/signup/resend` replaces the challenge/code. The previous challenge becomes unusable immediately. The client replaces all stored challenge/timing fields atomically.

### Login

1. `POST /auth/login` verifies email/password without creating app-authenticated state. Invalid account/password share one generic credential failure to avoid account enumeration.
2. Valid credentials create an expiring login OTP challenge and return `202 ChallengeResponse`.
3. `POST /auth/login/verify` accepts challenge ID + code. Only this operation creates the authenticated server session and returns the token bundle.
4. `POST /auth/login/resend` replaces the current login challenge and invalidates the old code.
5. After token receipt, the client calls `GET /me` and treats that response as the bootstrap business identity/profile state.

### Access/refresh/session rules

The token bundle uses:

- short-lived bearer access token;
- opaque refresh token;
- server session ID/expiry metadata;
- one-time rotating refresh semantics.

A successful `POST /auth/refresh` consumes the supplied refresh token and atomically returns a new access token and refresh token. The client replaces both before releasing queued requests. Reusing an already-consumed refresh token is treated as possible theft and revokes the affected session/session family according to the server auth policy.

Client rule:

```text
one refresh in flight per app process
```

If several API requests receive `401` concurrently, they wait for one refresh promise/mutex rather than consuming the same one-use refresh token multiple times. If refresh fails because the credential is invalid, consumed, expired, or revoked, clear authenticated local state and do not loop.

`GET /auth/sessions` lists only the current customer's sessions. `DELETE /auth/sessions/{session_id}` revokes one owned session. Revoking the current session immediately clears local authenticated state. `POST /auth/logout` revokes the current session; `POST /auth/logout-all` revokes all customer sessions.

### Password recovery/change

`POST /auth/password/forgot` is enumeration-safe: the HTTP response does not disclose whether the email exists. If eligible, the recovery message contains the recovery challenge identifier, OTP/code, and expiry needed by the client.

`POST /auth/password/reset/resend` replaces the recovery challenge/code and invalidates the prior pair.

`POST /auth/password/reset` accepts:

```json
{
  "challenge_id": "<recovery-id>",
  "code": "<six-digit-code>",
  "new_password": "<10-to-128-character-password>"
}
```

Successful forgotten-password reset revokes existing sessions and invalidates outstanding login/recovery challenges according to the auth transaction, then the app returns to login.

`POST /auth/password/change` requires the current password plus a different valid new password and revokes all active sessions after the password changes, including the current session.

### Profile

`GET /me` returns the authenticated Customer identity/profile and the minimum app bootstrap state. `PATCH /profile` updates only editable profile fields such as `full_name` and nullable phone. Email, auth state, roles/capabilities, payment state, jobs, and identifiers are not mutable through profile editing.

### Storage and secrecy

On mobile, refresh credentials SHOULD use OS-protected secure storage. Passwords, OTPs, access tokens, refresh tokens, recovery IDs, and challenge codes MUST NOT be placed in URLs, analytics, crash reports, screenshots, logs, or ordinary unencrypted preferences. Server challenge/OTP values are stored only as cryptographically appropriate hashes/encrypted secrets according to their verification purpose and are rate-limited for start, verify, and resend.

## 31.13 User API error envelope

All handled User App errors use a stable machine-readable envelope:

```json
{
  "error": {
    "code": "stable_machine_code",
    "message": "Human-readable message"
  }
}
```

Clients branch on `error.code`, not English wording.

Common semantic classes use the canonical uppercase registry from Appendix C:

```text
400 INVALID_REQUEST / VALIDATION_FAILED
401 UNAUTHENTICATED / INVALID_CREDENTIALS / INVALID_REFRESH_TOKEN
403 FORBIDDEN / BUSINESS_ADMISSION_DENIED
404 RESOURCE_NOT_FOUND
409 STATE_CONFLICT / IDEMPOTENCY_KEY_REUSED / RECONCILIATION_REQUIRED
410 RESOURCE_EXPIRED
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE / DEPENDENCY_UNAVAILABLE
```

A privacy-safe `404` SHOULD be used where revealing that another user's job/ticket/session exists would disclose cross-user existence.

Automatic client retries are limited to clearly safe reads and explicitly retryable transient failures. Mutation retries use the same idempotency identity; the app never creates a fresh logical charging/payment/support mutation simply because it missed a response.

## 31.14 User charging projection contract

A User App job detail/live response MUST expose start progress and physical session state as separate concepts.

Recommended projection shape:

```json
{
  "charging": {
    "start": {
      "start_intent_id": "<uuid>",
      "status": "REQUESTED|ACCEPTED_FOR_DELIVERY|PROTOCOL_ACKNOWLEDGED|ACTUALLY_STARTED|REJECTED|EXPIRED|RECONCILIATION_REQUIRED",
      "session_id": null
    },
    "session": null
  }
}
```

After physical start:

```json
{
  "charging": {
    "start": {
      "start_intent_id": "<uuid>",
      "status": "ACTUALLY_STARTED",
      "session_id": "<uuid>"
    },
    "session": {
      "id": "<uuid>",
      "state": "ACTIVE|STOP_PENDING|RECONCILIATION_REQUIRED|COMPLETED|FAILED",
      "started_at": "<rfc3339>",
      "completed_at": null,
      "meter": {
        "consumed_wh": 1234,
        "observed_at": "<rfc3339>",
        "freshness": "FRESH|STALE|UNKNOWN"
      },
      "soc": {
        "percent": "54.0",
        "observed_at": "<rfc3339>",
        "freshness": "FRESH|STALE|UNKNOWN"
      }
    }
  }
}
```

Fields may differ in final OpenAPI, but semantics are mandatory.

UI state rules:

- `REQUESTED`: show start request accepted by CMS, not charging.
- `ACCEPTED_FOR_DELIVERY`: HAL durably knows the request, not charging.
- `PROTOCOL_ACKNOWLEDGED`: charger accepted the protocol command, still not charging.
- `ACTUALLY_STARTED` plus `session_id`: transition to the active-charging screen.
- `RECONCILIATION_REQUIRED`: show "confirming charger state" or equivalent product copy and continue durable recovery. Never send another start.
- `REJECTED`/`EXPIRED`: terminal for that intent; a new user/driver action may create a fresh intent only after backend says the connector/job is start-eligible again.

The UI MUST NOT remain indefinitely in an optimistic local "starting" state after network loss. Refetch the CMS start/job projection.

## 31.15 User start and stop endpoints

The baseline public read surface SHOULD include an explicit charging projection:

```text
GET /api/v1/app/jobs/{job_id}/charging
```

It returns the current job-owned start progress and materialized session, if any.

If customer-controlled start is enabled:

```text
POST /api/v1/app/jobs/{job_id}/charging/start
```

If it is not enabled, that route is absent or returns a stable policy denial. The customer cannot emulate Driver start by posting charger IDs to a hidden endpoint.

If customer stop is enabled:

```text
POST /api/v1/app/jobs/{job_id}/charging/stop
```

A successful stop request returns `202 Accepted` with durable stop-progress state. It does NOT return or imply `COMPLETED` unless completion raced and the response explicitly embeds an already-completed authoritative snapshot.

The app then recovers through `GET /jobs/{job_id}/charging` or the live-job snapshot/stream.

## 31.16 User live meter and SoC rules

The app receives committed CMS projections only.

For energy:

- use integer Wh from backend as the base exact value;
- display kWh by presentation conversion only;
- never sum browser samples to create authoritative energy;
- never extrapolate between samples;
- stale/unknown evidence remains stale/unknown.

For SoC:

- nullable means unknown;
- never show missing SoC as 0%;
- never derive SoC from delivered Wh/battery capacity and label it charger SoC;
- show observation time/freshness when useful;
- final SoC is the last accepted observation, not guaranteed stop-time truth.

For power/current/voltage if later exposed:

- label them live observations;
- missing observation is unknown;
- do not use them to reconstruct billing energy in the client.

## 31.17 User charger/mobile-unit readiness projection

The User App may display the assigned mobile unit/charger readiness after assignment, but it receives the CMS-derived projection, not raw HAL state.

Preserve distinct reasons such as:

```text
ONLINE / OFFLINE / UNKNOWN / STALE
connector AVAILABLE / CHARGING / FAULTED / STALE / UNKNOWN
CMS inventory ineligible
asset mismatch unresolved
job occupies connector
```

Do not collapse every non-chargeable condition into `OFFLINE`.

The frontend can present a simplified message, but the API retains a stable machine reason so recovery/QA/analytics can distinguish the cause.

## 31.18 User history semantics

Charging attempt history under a ServiceJob contains only real materialized ChargingSessions.

Failed/rejected/expired start intents that never produced physical-start evidence are start-attempt history, not fake charging sessions.

For jobs with more than one physical charging attempt, the detail API can expose:

```text
job.charging_sessions[]
```

ordered by actual start time and stable ID.

A history card/detail MAY include:

- ServiceJob identity/number;
- driver/mobile-unit public context;
- service address snapshot;
- customer vehicle snapshot;
- charging session IDs;
- actual start/end times;
- committed energy;
- initial/latest/final observed SoC when present;
- requested stop provenance;
- protocol stop reason;
- final customer price only after commercial finalization;
- payment/settlement state;
- invoice state;
- rating state.

Do not render a stored zero as a final amount/energy when the value is actually not finalized.

History lists use bounded keyset pagination. A stable default/max limit and deterministic tie-breaker are required; offset pagination SHOULD NOT be used for frequently changing chronological history.

## 31.19 Stop provenance in the User App

The API keeps these concepts separate:

```text
requested_initiator
requested_reason
protocol_reason
```

The frontend SHOULD map them through product-owned presentation copy.

It must not show raw OCPP reason codes as if they explain the business decision. For example, protocol `Remote` may correspond to a customer target, driver action, Admin action, or funding safety stop.

## 31.20 User payment verification rules

Provider UI/redirect success is not final CMS payment truth.

The app:

1. requests order/payment intent from CMS;
2. performs only the provider client-side step allowed by the chosen payment integration;
3. returns provider result identifiers/signature to the documented CMS verification endpoint;
4. refetches CMS payment/job state;
5. trusts CMS durable state.

On response loss, recover the existing payment/order by CMS/provider identity. Do not create a replacement order unless backend explicitly says the previous operation is terminal/absent.

Exact money values are decimal strings or integer minor units according to the canonical contract; the frontend MUST NOT use binary floating point for authoritative totals.

## 31.21 User invoice rules

Invoice readiness is distinct from ServiceJob physical completion and payment attempt.

The User App MUST distinguish at least:

```text
NOT_ELIGIBLE
PENDING
READY
UNAVAILABLE / FAILED
```

A READY historical invoice is immutable. The client downloads it through an authenticated CMS route or approved short-lived delivery mechanism; it never guesses a filesystem/object-storage path.

A missing/pending invoice does not cause the frontend to locally generate a tax invoice.

## 31.22 User rating/review rules

Preserve one durable customer rating per eligible ServiceJob unless product explicitly chooses per-ChargingSession ratings.

Recommended surface:

```text
GET /api/v1/app/jobs/{job_id}/rating
PUT /api/v1/app/jobs/{job_id}/rating
GET /api/v1/app/ratings
```

`PUT` creates or replaces the owner's rating idempotently.

Eligibility:

- customer owns the job;
- job is completed under the rating policy;
- one logical rating per rating target;
- no other customer's identity is exposed through customer-facing aggregates/reviews.

If public review text is added later, define moderation/privacy separately. Do not leak another user's name merely because a review exists.

## 31.23 User support rules

For Charger-on-Wheels, the customer support channel is conceptually:

```text
CUSTOMER_PLATFORM
```

not the inherited EV-CMS `CUSTOMER_CPO` channel.

Preserve the durable support mechanics:

- server derives customer ownership from bearer context;
- customer can see only their own tickets;
- privacy-safe not-found for another customer's ticket;
- append-only replies;
- reply idempotency key;
- explicit status graph;
- customer reply to `RESOLVED` or `CLOSED` MAY reopen atomically to `OPEN`;
- same-state mutation has no duplicate side effect;
- mail/push is notification, never the support source of truth;
- freeform support message bodies are not copied into broad notification/event payloads;
- Admin internal identities/notes are not leaked to the User App.

Recommended status graph:

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> CLOSED | OPEN
CLOSED -> OPEN
```

## 31.24 User realtime recovery contract

Charger-on-Wheels SHOULD preserve the two-layer realtime model:

1. durable scoped operational-event stream for invalidation/replay;
2. full current live-job/session snapshot stream for normal active-screen rendering.

Recommended public endpoints:

```text
GET /api/v1/app/operations/events?after_id=<cursor>&limit=<bounded>
GET /api/v1/app/operations/realtime/stream
GET /api/v1/app/operations/live-jobs/snapshot
GET /api/v1/app/operations/live-jobs
```

`live-jobs` as SSE sends:

- one complete current collection immediately after authorization;
- complete replacement snapshots after relevant committed changes.

The frontend replaces that collection. It does not merge guessed partial deltas into a stale object graph.

The generic operational stream uses durable numeric/event cursor semantics:

```text
REST catch-up
-> remember last handled event ID
-> connect SSE
-> process at-least-once events
-> refresh affected REST/live snapshot
```

On reconnect:

- send the last handled ID through `after_id` or `Last-Event-ID` according to the canonical API;
- query parameter wins if both are supplied;
- on cursor-expired conflict, discard the old cursor, refetch authoritative REST/live snapshot, then resume from the current retained range;
- after access-token rotation, reconnect using the new authorization;
- on app resume from background after a material interval, perform snapshot catch-up before trusting the old stream state.

SSE heartbeats maintain transport liveness and MAY revalidate auth/session scope. They do not invent business events.

## 31.25 User realtime event rules

Realtime events are at-least-once invalidation/projection signals.

The User App MUST:

- dedupe event IDs;
- ignore stale per-resource versions/sequences;
- refetch on a detected gap when required;
- never use a meter-change event payload as a replacement for the canonical session projection unless that event type is explicitly defined as a full replacement snapshot;
- keep the UI useful during realtime outage using REST/snapshot polling;
- recover after disconnect without creating duplicate mutations.

Recommended event names include:

```text
service_job.changed
dispatch.changed
driver.public_location_changed
charging.command_changed
charging.session_changed
charging.meter_changed
charging.soc_changed
payment.changed
invoice.changed
support.changed
```

Location streams may be higher frequency and can use a specialized ephemeral channel, but job/charging/commercial truth remains recoverable from CMS durable state.

## 31.26 User frontend state and security checklist

The frontend implementation MUST:

- model signup verification, login verification, and password recovery as separate state machines if OTP/challenge flows are used;
- keep tokens/OTPs/recovery IDs out of logs and analytics;
- treat timestamps as UTC instants and localize only at presentation;
- disable duplicate submit while a mutation is in flight;
- preserve server idempotency key while retrying an uncertain mutation;
- escape review/support/free-text content;
- never render raw HTML from untrusted server/user text;
- clear state after logout/session revocation/password reset as defined by the API;
- invalidate/refetch job state after any mutation instead of manually forcing a final status;
- keep API origin in deployment configuration, not user-editable profile/deep-link input.

## 31.27 User acceptance matrix

A User App release is not complete until these journeys pass against the matching CMS contract:

| Journey | Pass condition | Failure/recovery requirement |
| --- | --- | --- |
| Auth/refresh | login reaches verified authenticated state; refresh rotates token pair exactly once | concurrent 401s share one refresh; invalid/reused refresh clears auth without loop |
| Saved vehicle/address | create/edit/remove affects reusable data while old ServiceJob snapshots stay unchanged | stale edits do not mutate history |
| Service request/quote | saved or temporary EV/address creates a quote and accepted job with immutable snapshots | expired/stale quote returns explicit re-quote/conflict flow |
| Dispatch tracking | assignment, driver public projection, ETA/location converge | realtime loss recovers from job snapshot |
| Charging start | start progress becomes `ACTUALLY_STARTED` only after physical fact | ambiguity remains inspectable and never duplicates start |
| Live charging | energy/SoC/freshness reflect CMS accepted evidence | stale/missing values remain unknown/stale, not fabricated |
| Stop | stop request is durable; completion occurs only from physical completion evidence | lost response recovers existing stop/session, never duplicate physical command |
| Payment | CMS state agrees with provider verification | provider UI alone cannot mark paid |
| Invoice | READY artifact downloads and matches finalized job | pending/unavailable states remain explicit |
| Rating | owner can create/read/replace own eligible rating | no other customer identity leakage |
| Support | owner can create/read/reply; closed/resolved reply reopens when policy says so | mail/push loss does not lose ticket state |
| Realtime | REST catch-up + stream converges after reconnect/token rotation | cursor expiry forces snapshot recovery rather than guessed delta merge |

---

# 34. API Consumer Contracts and Projection Rules

## 34.1 User projection

User job projection may expose:

- job number/status;
- service location snapshot;
- own vehicle snapshot;
- public driver identity subset after assignment;
- public service vehicle identity subset;
- ETA/location only while operationally relevant;
- charging metrics;
- pricing/payment/invoice state;
- own support/rating.

It MUST NOT expose:

- driver KYC;
- driver phone/email unless explicitly required by product policy;
- Admin identities;
- internal dispatch scores;
- raw HAL traces;
- internal incident notes;
- internal compensation.

## 34.2 Driver projection

Driver may see only data necessary for current/own work:

- assigned customer display/contact information required for service;
- exact service location/instructions;
- customer vehicle snapshot;
- charging preference;
- job/payment information only to the extent operationally required;
- own compensation.

Driver MUST NOT see full customer account/security history.

## 34.3 Admin projection

Admin receives data by capability and need, not one giant universal object.

High-sensitivity KYC, payment, raw trace, and audit data should have separately authorized endpoints/fields.

---

# 35. Idempotency Matrix

At minimum, these operations require durable idempotency or stable operation identity:

| Operation | Mechanism |
| --- | --- |
| Quote acceptance / ServiceJob creation | `Idempotency-Key` |
| Driver duty start | `Idempotency-Key` + unique active-duty constraint |
| Driver offer accept | offer identity + transactional winner |
| Driver job transition actions | action idempotency / current-state same-result semantics |
| Charging start | `Idempotency-Key` -> `ChargingStartIntent` -> immutable `cms_command_id` -> one HAL start command |
| Charging stop | `Idempotency-Key` -> `ChargingStopRequest` -> immutable `cms_command_id` -> one HAL stop command; completion still requires physical completion evidence |
| Payment order creation | `Idempotency-Key` + provider order identity |
| Payment verification/webhook | provider event/payment identity |
| Refund | `Idempotency-Key` + provider refund identity |
| Invoice generation intent | unique invoice/job/version key |
| Support reply | `Idempotency-Key` |
| Notification/outbox delivery | outbox row/event identity |
| HAL fact ingest | immutable `fact_id` |
| HAL start/stop command | immutable `cms_command_id` plus durable `hal_command_id`; retry/reconcile same identity |
| Generic administrative HAL operation | immutable `cms_operation_id` plus durable HAL operation identity; no automatic replay after possible delivery |
| Promotion of temp vehicle/address | `Idempotency-Key` / unique promotion record |
| Compensation finalization | unique job/assignment calculation version |
| Compensation adjustment | `Idempotency-Key` |

Idempotency records MUST have a retention policy long enough to cover realistic mobile retry behavior and external provider retries.

---

# 39. Failure Classification and Recovery

Failures MUST be classified so retries do not make reality worse.

## 39.1 Classes

```text
VALIDATION
AUTHORIZATION
CONFLICT
TRANSIENT_INTERNAL
TRANSIENT_EXTERNAL
TERMINAL_EXTERNAL
OUTCOME_UNKNOWN
INTEGRITY_VIOLATION
```

## 39.2 Retry policy

- Validation/auth/conflict: caller must change state/input; no blind server retry.
- Transient internal: bounded automatic retry if operation is safe/idempotent.
- Transient external before known delivery: bounded retry.
- Outcome unknown after possible physical/payment side effect: reconcile by stable identity before retry.
- Integrity violation: stop, alert, preserve evidence.

## 39.3 Stop conditions

Workers MUST stop automatic retries and surface operational attention when:

- semantic conflict appears;
- same identity maps to conflicting payload;
- repeated failures exceed policy;
- physical command outcome remains unknown beyond reconciliation horizon;
- provider/charger reports impossible transition;
- database constraint indicates an unexpected invariant breach.

---

# 40. Security and Privacy Blueprint

## 40.1 Authentication secrets

Passwords, OTPs, refresh tokens, service credentials, Razorpay secrets, webhook secrets, and private keys MUST never be logged.

Store password hashes with a modern password hashing algorithm if passwords are used.

OTP codes are short-lived, rate-limited, and stored only in protected/hashed form where possible.

## 40.2 PII

Sensitive fields include:

- phone/email;
- addresses/location history;
- KYC documents/numbers;
- driving licence;
- bank information if stored;
- exact driver/customer traces;
- support free text;
- invoice/customer tax info.

APIs return the minimum projection required for that actor.

## 40.3 KYC document storage

- private object/file storage;
- random opaque object identifiers;
- MIME/type and size validation;
- malware scanning if infrastructure supports it;
- authorization on every fetch;
- short-lived signed URLs if used;
- audit reads for highly sensitive documents where practical.

## 40.4 Input safety

All user-generated free text is untrusted.

Frontend must escape reviews/support/notes.

Backend must use parameterized SQL and never interpolate user strings into queries.

## 40.5 Rate limiting

At minimum rate-limit:

- login/OTP/recovery;
- registration;
- quote creation abuse;
- support spam;
- location ingestion by device;
- provider callback endpoints according to provider expectations;
- HAL internal ingress by authenticated service/size limits.

## 40.6 Authorization test requirement

Every protected route family requires tests for:

- unauthenticated rejection;
- wrong principal type;
- wrong owner/resource;
- missing capability;
- positive allowed path.

---

# 43. Data Retention, Privacy, and Archival

Retention MUST be explicit per data class rather than "keep everything forever" by accident.

Suggested categories:

- legal/financial invoices/payments/refunds: long-term according to accounting/legal obligations;
- ServiceJob commercial history: long-term;
- compensation ledger: long-term business record;
- audit: long-term security/business record;
- raw driver GPS samples: bounded operational retention, with aggregates/history kept as needed;
- raw HAL protocol traces: bounded technical retention, longer around incidents;
- idempotency keys: bounded but long enough for retries;
- notification delivery attempts: bounded after terminal state;
- expired sessions/tokens: security retention as needed;
- KYC: lifecycle/legal retention policy with deletion/anonymization process.

A future privacy deletion/anonymization workflow must preserve legal/financial integrity while removing or pseudonymizing data that is no longer required.

---

# 47. End-to-End User Flow

## 47.1 Immediate service, normal path

```text
User authenticates
-> chooses saved or temporary EV
-> chooses saved or temporary location
-> chooses charging preference
-> creates ServiceRequest
-> backend validates serviceability
-> backend creates Quote from active PricingPolicy
-> user accepts Quote
-> ServiceJob created with immutable snapshots
-> dispatch attempt starts
-> eligible drivers determined
-> ranked candidate offered
-> driver accepts
-> assignment frozen/current
-> user sees assigned driver/mobile unit
-> driver begins EN_ROUTE
-> driver location updates User/Admin projection
-> driver arrives
-> backend records arrival validation
-> driver enters SERVICE_PREPARING
-> actual charger/connector compatibility revalidated
-> authorized User/Driver policy requests charging start
-> CMS validates job/duty/asset/readiness and commercial admission
-> CMS durably creates ChargingStartIntent + frozen commercial inputs + one-use credential hash + immutable cms_command_id
-> CMS confirms the committed charger/connector mapping and submits that exact start command to HAL
-> start progresses through REQUESTED / ACCEPTED_FOR_DELIVERY / PROTOCOL_ACKNOWLEDGED or RECONCILIATION_REQUIRED; none means charging started
-> authoritative HAL `transaction.started` fact with the exact identity chain arrives
-> CMS materializes exactly one ACTIVE ChargingSession and marks the start intent ACTUALLY_STARTED
-> ServiceJob enters CHARGING from materialized physical-start evidence
-> monotonic meter/SoC/connection/connector facts update durable CMS projections
-> user/driver/admin see CMS projection; realtime is recoverable from REST/snapshot
-> stop request creates one durable ChargingStopRequest/command, or the charger may stop spontaneously
-> RemoteStop acknowledgement leaves the session open
-> authoritative HAL `transaction.completed` fact, or exact completed-transaction reconciliation, finalizes the session exactly once
-> ServiceJob enters WRAP_UP
-> final physical/source facts collected
-> PricingEngine finalizes customer line items
-> payment settlement/reconciliation reaches required boundary
-> invoice generated from frozen facts
-> CompensationEngine calculates driver line items
-> driver completes closeout
-> ServiceJob becomes COMPLETED when completion invariants pass
-> User history/payment/invoice/rating surfaces agree
-> Driver history/earnings agree
-> Admin sees same durable truth through broader projection
```

## 47.2 Scheduled service

Scheduled request adds:

- `requested_for` window;
- dispatch worker begins within configured lead window;
- quote validity/repricing policy explicitly determines whether original quote remains valid until service;
- scheduled dispatch respects driver schedules and asset availability at the target time;
- customer is notified on material assignment/availability changes.

No fake assignment is created hours early merely to reserve appearance of certainty unless an explicit reservation mechanism owns that truth.

---

# 50. Completion Invariants

A ServiceJob may transition to `COMPLETED` only when all applicable invariants are true.

Minimum invariants:

1. Job is in `WRAP_UP`.
2. No active physical charging transaction remains for the job.
3. No `ChargingStartIntent`, `ChargingStopRequest`, or physical-delivery command remains unresolved without an explicit reconciliation disposition. A start in `RECONCILIATION_REQUIRED` blocks replacement start on the same job/asset until exact evidence resolves it; an unresolved stop never allows CMS to claim physical completion. Generic administrative charger-operation ambiguity is tracked separately and blocks job completion only when that specific operation is defined as a safety prerequisite.
4. Final charging metrics have been frozen or explicitly marked unavailable with reason.
5. Final pricing has been calculated or a deliberate zero/exception commercial disposition exists.
6. The current assignment has a closeout disposition.
7. Required driver closeout fields are present.
8. Any mandatory incident/blocking exception is resolved or explicitly transferred to post-service handling.
9. Job history/event write succeeds in the same transaction.

Payment capture and invoice readiness SHOULD NOT be required to mark physical field service complete unless the business explicitly chooses a pre-completion collection rule. Their state remains visible independently.

Driver compensation MAY be calculated asynchronously after completion but must be derived from frozen source facts and eventually converge.

---

# 51. Cancellation, No-Show, and Failure Matrix

Cancellation semantics depend on actor and lifecycle state.

## 51.1 Customer cancellation

Customer MAY cancel when policy permits.

At minimum, cancellation should be possible before physical charging begins. After physical charging begins, use stop + wrap-up/commercial finalization rather than pretending the service never happened.

Recommended state handling:

```text
DISPATCHING -> CANCELLED
ASSIGNED -> CANCELLED
ACCEPTED -> CANCELLED
EN_ROUTE -> CANCELLED
ARRIVED -> CANCELLED or NO_SHOW depending facts
SERVICE_PREPARING -> CANCELLED if no physical charge started
CHARGING -> not direct CANCELLED; stop charging, finalize delivered service, then terminal disposition
```

Cancellation fee is pricing-policy driven.

## 51.2 Driver cancellation/unavailability

Driver cannot simply mark the customer job cancelled.

A driver unable to continue reports an operational reason. Backend/Admin decides:

- reassign job;
- fail job;
- cancel due platform/driver cause;
- create incident.

The assignment ends with reason; the ServiceJob remains independent.

## 51.3 Customer no-show

A no-show requires arrival/attempt evidence and policy-defined waiting threshold or Admin override.

Do not let Driver immediately mark NO_SHOW without server-side timing/location checks where available.

## 51.4 Driver no-show

If an assigned driver fails to progress/arrive:

- system/admin may mark assignment failed;
- job enters `REASSIGNING`;
- incident/driver performance evidence may be recorded;
- customer is not blamed commercially.

## 51.5 Failure taxonomy

`FAILED` job requires a reason code such as:

```text
NO_COMPATIBLE_DRIVER
VEHICLE_BREAKDOWN
CHARGER_FAULT
HAL_UNAVAILABLE
UNSAFE_SERVICE_CONDITIONS
CUSTOMER_VEHICLE_INCOMPATIBLE
LOCATION_INACCESSIBLE
PAYMENT_POLICY_BLOCK
PLATFORM_TECHNICAL_FAILURE
OTHER_ADMIN_RESOLVED_FAILURE
```

A human-readable note may supplement but never replace structured reason.

---

# 54. Derived Projections and Rebuildability

Derived projections improve read performance but cannot become hidden sources of truth.

Candidate projections:

- current driver location;
- driver current duty summary;
- current job live projection;
- charger runtime projection;
- admin operations dashboard counters;
- driver earnings summaries;
- customer rating aggregates.

For each projection, document:

- source tables/events;
- update trigger/worker;
- staleness semantics;
- rebuild/reconciliation method;
- what happens if projection update fails.

A failed projection update must not roll back already committed physical/commercial truth unless the projection itself is part of the transaction intentionally.

---

# 55. Search, Filtering, and Operational Query Rules

Operational list APIs MUST be useful to real admins, not only technically paginated.

## 55.1 Drivers

Filter/sort by:

- recruitment status;
- operational status;
- eligibility;
- on-duty/off-duty;
- schedule window;
- active job;
- base zone;
- document expiry/block reason;
- name/phone/email search with privacy controls.

## 55.2 Fleet

Filter/sort by:

- active/retired;
- maintenance;
- availability derived state;
- vehicle/charger pairing;
- current driver/duty;
- connector type;
- power;
- protocol;
- HAL online/staleness;
- last activity.

## 55.3 Jobs

Filter/sort by:

- status;
- created/requested time;
- scheduled/immediate;
- customer;
- driver;
- vehicle;
- charger;
- payment state;
- invoice state;
- incident/support association;
- exception state;
- zone;
- age in current state.

## 55.4 Finance/compensation

Filter by date ranges using explicit timezone semantics and bounded exports.

Large exports should be asynchronous durable export jobs, not unbounded API responses.

---

# 57. Testing Strategy

Testing is layered by the kind of claim being made.

## 57.1 Unit tests

Mandatory areas:

- every state transition table;
- customer pricing rule evaluation;
- compensation rule evaluation;
- time-window/interval prorating;
- dispatch eligibility;
- dispatch ranking deterministic tie-break;
- geofence intersection;
- snapshot construction;
- authorization decisions;
- cancellation/no-show rules;
- HAL adapter normalization;
- payment/refund state transitions;
- invoice calculation inputs;
- privacy projection shaping.

## 57.2 PostgreSQL integration tests

Run against explicit disposable PostgreSQL.

Must test:

- migrations from empty DB;
- up/down where down is safe;
- uniqueness/exclusion constraints;
- active DutySession uniqueness;
- asset claim race;
- offer acceptance race;
- idempotency duplicate/conflict;
- outbox atomicity;
- duplicate HAL fact ingest;
- transaction rollback;
- version/optimistic concurrency;
- historical FK behavior;
- policy version immutability.

## 57.3 Service integration

CMS-HAL:

- mapping create/update and post-commit reconfirmation;
- start command durable acceptance without session materialization;
- protocol acknowledgement without session materialization;
- authoritative `transaction.started` materializes exactly one session;
- command explicit rejection;
- HTTP timeout before HAL durable acceptance;
- HTTP timeout after HAL persisted/possibly delivered command;
- exact `cms_command_id` reconciliation and confirmed absence;
- exact `cms_start_intent_id` transaction reconciliation;
- late start fact after rejected/expired intent;
- duplicate identical fact is success/no-op;
- same fact ID with changed digest is integrity conflict;
- out-of-order connection/connector/meter/SoC sequence cannot regress projection;
- stop acknowledgement does not complete session;
- spontaneous charger-originated completion is accepted when identity chain validates;
- missing completion fact recovered by exact `hal_transaction_id` and same finalizer;
- reconnect/restart during active transaction;
- CMS outage while HAL fact outbox accumulates;
- HAL outage while CMS preserves durable intent/session truth;
- generic admin charger operation uses pre-I/O delivery fence and no-replay exact-ID recovery;
- slow generic operation recovery cannot delay charging deadline/automatic-stop worker;
- multiple physical sessions under one ServiceJob.

Payments:

- order retry;
- callback success + webhook duplicate;
- webhook before client verify;
- provider timeout;
- captured payment with lost API response;
- refund timeout/reconciliation.

## 57.4 End-to-end simulator tests

At minimum script these flows:

### E2E-01 happy path saved data

Saved EV + saved address -> quote -> dispatch -> charge -> payment -> invoice -> compensation -> rating.

### E2E-02 temporary customer data

Temporary EV/address -> completed job -> history retains snapshots -> promote both -> old history unchanged.

### E2E-03 scheduled driver

Admin schedule + assigned assets -> driver starts occurrence -> job -> planned vs actual times preserved.

### E2E-04 unscheduled driver

Driver self-starts duty under permitted policy -> selects eligible assets -> receives job.

### E2E-05 pairing mismatch

Admin expects C1, driver observes C2 -> report -> allowed temporary operation -> job uses C2 snapshot -> Admin reconciles later -> old duty remains C2.

### E2E-06 no compatible charger

Nearby drivers exist but connector/capability incompatible -> no invalid offer -> Admin diagnostic explains exclusion.

### E2E-07 start response lost after possible physical success

CMS creates one ChargingStartIntent/command -> HAL durably persists and sends start -> response is lost -> CMS enters `RECONCILIATION_REQUIRED` without a replacement command -> exact command/transaction lookup or immutable `transaction.started` fact proves the same attempt -> exactly one ChargingSession materializes.

### E2E-08 charger fault and restart

Transaction S1 ends unexpectedly -> same ServiceJob remains active -> recovery -> S2 starts -> final billing aggregates eligible facts.

### E2E-09 driver reassignment

D1 en route then breaks down -> assignment closes -> D2 assigned -> one ServiceJob -> compensation split by authoritative intervals.

### E2E-10 customer cancel after dispatch

Cancellation policy line item applied, assignment closed, no charging started, no fake energy/invoice facts.

### E2E-11 customer no-show

Arrival evidence + waiting threshold -> no-show -> policy charge -> compensation rule as configured.

### E2E-12 policy changes mid-job

Pricing and compensation policy edited/activated after job started -> job uses frozen versions defined by snapshot boundary.

### E2E-13 time boundary compensation

Driver work crosses night-rate boundary -> interval-prorated line items match exact minutes/distance basis.

### E2E-14 payment duplicate/recovery

Captured payment, lost response, duplicate webhook -> one captured logical payment.

### E2E-15 realtime disconnect

User/Driver/Admin lose realtime -> reconnect -> REST current state is correct -> subsequent versioned events converge.

## 57.5 Physical hardware acceptance

Before production readiness for a charger model/protocol:

- connect/disconnect;
- remote start/stop;
- transaction IDs;
- meter values;
- SoC if claimed;
- faults;
- reconnect during transaction;
- network loss;
- charger reboot;
- uncertain command outcome;
- connector mapping;
- max power/capability reporting;
- repeated sessions;
- time synchronization behavior;
- vendor deviations.

Simulator acceptance is not physical hardware acceptance.

---

# 58. Verification Gates for Every Work Item

Every meaningful burner/work item has four separate gates.

## Gate A: semantic/design

- scope and non-goals explicit;
- domain owner clear;
- state transition defined;
- persistence/constraints defined;
- authorization defined;
- idempotency defined;
- failure/recovery defined;
- history/realtime/audit impact defined.

## Gate B: source

- formatting/lint;
- focused tests;
- broad unit/integration tests;
- OpenAPI/runtime parity;
- documentation verifier;
- migration checks;
- `git diff --check`;
- no unrelated changes.

## Gate C: integration/runtime

- migrations applied to target environment intentionally;
- service healthy/readiness;
- changed routes behave under auth boundaries;
- workers healthy;
- logs clean of new panics/fatals;
- external integration tested or explicitly marked unverified.

## Gate D: physical/external acceptance where relevant

- real Razorpay provider behavior;
- real email/push provider acceptance;
- real HAL-to-charger behavior;
- real hardware acceptance.

A feature can be source-complete but not physically accepted. The completion statement must say which gate was reached.

---

# 62. Project Documentation Set

The repository should maintain at minimum:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/DEVELOPMENT_PLAN.md
docs/AI_CHANGELOG.md

docs/architecture/SYSTEM_ARCHITECTURE.md
docs/architecture/DOMAIN_MODEL.md
docs/architecture/STATE_MACHINES.md
docs/architecture/CMS_HAL_BOUNDARY.md
docs/architecture/CHARGING_TRUTH_MODEL.md

docs/contracts/openapi/openapi.yaml
docs/contracts/api/user-app.md
docs/contracts/api/driver-app.md
docs/contracts/api/admin.md
docs/contracts/api/internal-hal.md
docs/contracts/hal/CMS_HAL_CHARGING_V1.md
docs/contracts/realtime/events.md
docs/contracts/configuration.md

docs/handoffs/USER_APP_FE_HANDOFF.md
docs/handoffs/DRIVER_APP_FE_HANDOFF.md
docs/handoffs/ADMIN_FE_HANDOFF.md

docs/guides/operations/dev-hosting.md
docs/guides/operations/deployment.md
docs/guides/operations/rollback-recovery.md
docs/guides/operations/charger-onboarding.md
docs/guides/operations/incident-response.md

docs/work/active/
docs/work/archive/
```

HAL repository has its own equivalent architecture, adapter, operation-state, simulator, and hosting docs.

---

# 67. Definition of Done - Project Level

The project is not production-ready merely because all endpoints exist.

Production readiness requires:

1. User flow accepted end-to-end.
2. Driver recruitment + operational flow accepted end-to-end.
3. Admin can operate and recover abnormal flows.
4. Dispatch handles eligibility/races/reassignment.
5. Dedicated HAL survives reconnect/restart/uncertain operation tests.
6. At least one target physical charger model is hardware-accepted.
7. Pricing fixtures and real job calculations agree.
8. Razorpay production integration is verified at the intended flow boundary.
9. Refund flow verified.
10. Invoice artifact + download + delivery path verified.
11. Compensation ledger is explainable and stable across policy changes.
12. Realtime reconnects recover from REST.
13. Authorization/privacy tests cover all three human planes.
14. Backups and restore are tested.
15. Deployment/rollback runbook is exercised.
16. Monitoring alerts on critical backlogs/failures.
17. Documentation and OpenAPI match runtime.
18. No known unresolved integrity issue is hidden behind UI workarounds.
19. Known external/unverified boundaries are documented explicitly.

---

# 69. Decisions That Must Be Resolved Before Their Burner

These are genuine external/business/hardware inputs that cannot be truthfully invented in architecture:

1. Exact Charger-on-Wheels physical hardware models and connector configurations.
2. Whether the mobile unit has onboard energy storage and how its SoC/capacity is obtained.
3. Exact customer payment capture strategy supported/desired with Razorpay: upfront, deposit, authorization-like pattern, or post-service collection.
4. Legal/business invoice and GST classification details for mobility/service vs energy components.
5. Required KYC document set and storage/compliance retention requirements.
6. Client platform decisions that affect push provider/device token implementation.
7. Exact navigation/maps provider if server-side ETA/routing is required.
8. Production infrastructure/hostnames/secrets/storage provider.

The implementation program does not wait on these globally. It defers only the burner whose exact behavior depends on them, using explicit interfaces in the meantime.

---

# 71. Final Build Principle

Charger on Wheels must make the normal path easy without forcing abnormal real-world conditions into false data.

The implementation therefore preserves, separately and explicitly:

```text
what Admin intended
what Driver actually used
what the charger physically did
what the customer commercially owes
what the driver compensation engine calculated
what happened historically
what realtime currently projects
```

Then it composes those truths into User, Driver, and Admin experiences through explicit contracts.

The stable center is the ServiceJob. The operational driver context is the DriverDutySession. The physical charging authority is the dedicated HAL. PostgreSQL-backed durable state is the recovery authority. Realtime is an accelerator. Policies are versioned. History is not rewritten for convenience. Physical side effects are never inferred from optimistic UI actions.

That is the implementation blueprint.

---

# Appendix C. Canonical Error Code Registry

HTTP status and machine error code are both part of the contract.

## C.1 Common

```text
400 INVALID_REQUEST
400 VALIDATION_FAILED
401 UNAUTHENTICATED
403 FORBIDDEN
404 RESOURCE_NOT_FOUND
409 VERSION_CONFLICT
409 IDEMPOTENCY_KEY_REUSED
409 STATE_CONFLICT
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE
```

Privacy-sensitive ownership failures SHOULD use `404 RESOURCE_NOT_FOUND` instead of revealing that another user's resource exists.

## C.2 Driver/duty

```text
409 DRIVER_NOT_ELIGIBLE
409 DRIVER_ALREADY_ON_DUTY
409 DUTY_NOT_ACTIVE
409 DUTY_HAS_ACTIVE_JOB
409 VEHICLE_ALREADY_CLAIMED
409 CHARGER_ALREADY_CLAIMED
409 ASSET_NOT_OPERATIONAL
409 ASSET_PAIRING_MISMATCH_BLOCKED
409 CHARGER_HAL_IDENTITY_UNKNOWN
409 DRIVER_LOCATION_STALE
```

## C.3 Dispatch/job

```text
409 OFFER_EXPIRED
409 OFFER_NO_LONGER_AVAILABLE
409 JOB_NOT_ASSIGNABLE
409 JOB_INVALID_TRANSITION
409 JOB_ALREADY_TERMINAL
409 JOB_HAS_ACTIVE_CHARGING
422 NO_ELIGIBLE_DRIVER
422 CUSTOMER_LOCATION_UNSERVICEABLE
422 CUSTOMER_VEHICLE_INCOMPATIBLE
```

`NO_ELIGIBLE_DRIVER` may be represented as job/dispatch state rather than direct request failure depending on operation.

## C.4 Charging/HAL

```text
409 CHARGING_ALREADY_ACTIVE
409 CHARGING_NOT_ACTIVE
409 CHARGING_START_IN_PROGRESS
409 RECONCILIATION_REQUIRED
409 HAL_COMMAND_IDEMPOTENCY_CONFLICT
409 HAL_FACT_INTEGRITY_VIOLATION
409 HAL_START_EVIDENCE_CONFLICT
409 CHARGING_STOP_IN_PROGRESS
410 CHARGING_START_EXPIRED
422 CHARGER_CAPABILITY_UNSUPPORTED
422 CONNECTOR_INCOMPATIBLE
503 HAL_UNAVAILABLE
503 CHARGER_MAPPING_UNAVAILABLE
```

## C.5 Payments/invoices

```text
409 PAYMENT_ALREADY_CAPTURED
409 PAYMENT_AMOUNT_MISMATCH
409 REFUND_EXCEEDS_REFUNDABLE_AMOUNT
409 REFUND_ALREADY_IN_PROGRESS
422 PAYMENT_VERIFICATION_FAILED
503 PAYMENT_PROVIDER_UNAVAILABLE
409 INVOICE_NOT_READY
409 INVOICE_ALREADY_READY
```

## C.6 Policies

```text
409 POLICY_VERSION_CONFLICT
409 POLICY_EFFECTIVE_RANGE_CONFLICT
409 ACTIVE_POLICY_IMMUTABLE
422 RULE_CONFIGURATION_INVALID
```

---

# Appendix D. Initial Operational Defaults and Knobs

These values are implementation defaults, not eternal business rules. They live in validated configuration or Admin policy and can be changed without changing semantics.

## D.1 API

```text
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100
DEFAULT_TIMEZONE=Asia/Kolkata
```

## D.2 Dispatch

Initial normal strategy:

```text
SEQUENTIAL
```

`DIRECT_ASSIGNMENT` is an explicit Admin action. `BATCHED` is not implemented initially.

No hard-coded offer timeout or scheduled dispatch lead time is mandated by architecture because those materially affect field operations. They MUST be explicit configuration before shared staging is enabled. Startup should reject an environment that enables dispatch without required timing values.

Required knobs:

```text
DISPATCH_OFFER_TTL_SECONDS
DISPATCH_RETRY_MIN_SECONDS
DISPATCH_RETRY_MAX_SECONDS
SCHEDULED_DISPATCH_LEAD_MINUTES
DISPATCH_MAX_LOCATION_AGE_SECONDS
ARRIVAL_VALIDATION_RADIUS_METERS
```

## D.3 Location

Client reporting cadence is a mobile-product/battery tradeoff, so the server defines freshness/maximum ingest rate, while Driver App chooses cadence within contract.

Server MUST reject abusive/implausible rates and accept batch recovery for offline periods.

## D.4 Workers

Every worker has configurable:

```text
BATCH_SIZE
POLL_INTERVAL
LEASE_DURATION
MAX_ATTEMPTS or terminal policy
BACKOFF_MIN
BACKOFF_MAX
```

No worker may use an unbounded immediate retry loop.

## D.5 Realtime

Required knobs:

```text
MAX_CONNECTIONS_PER_ACCOUNT
HEARTBEAT_INTERVAL
CLIENT_IDLE_TIMEOUT
MAX_OUTBOUND_QUEUE_PER_CONNECTION
```

Backpressure disconnects a slow client rather than consuming unbounded memory. Client recovers with REST.

---

# Appendix E. Operational Recovery Playbooks

These are behavioral playbooks. Exact shell commands belong in environment-specific operations docs.

## E.1 Driver app loses connectivity while en route

1. Server keeps assignment/job authoritative.
2. Location becomes stale after configured threshold.
3. Admin sees stale-location warning.
4. Driver app reconnects and fetches current duty/job via REST.
5. Buffered valid location samples may upload in batch.
6. No assignment is automatically cancelled solely because one realtime socket dropped.
7. Escalation/reassignment follows dispatch operations policy if staleness exceeds business threshold.

## E.2 Driver app loses connectivity during charging

1. HAL continues owning physical charger truth independently of Driver App.
2. CMS continues ingesting HAL facts.
3. User/Admin can still see charging projection if CMS/HAL links remain healthy.
4. Reconnected Driver App fetches job/charging state.
5. Never infer stop/start from Driver App reconnect state.

## E.3 CMS temporarily unavailable during active charging

1. HAL persists operation/transaction/facts locally.
2. Charger session continues according to physical/protocol reality.
3. HAL fact outbox retries delivery.
4. CMS restart recovers database state.
5. HAL delivers missed facts idempotently.
6. CMS reconciles transaction links/projections.
7. No new physical command is replayed unless operation identity proves it safe.

## E.4 HAL restarts during active charging

1. HAL reconnect supervisor restores charger connection.
2. Protocol adapter reconciles active transaction state.
3. Existing stable HAL transaction is recovered or a reconciliation record explains identity change where protocol makes exact restoration impossible.
4. CMS receives no duplicate semantic start if same transaction is proven.
5. Raw evidence links restart/reconnect chain.

## E.5 Start command times out

1. CMS marks the existing ChargingStartIntent/command `RECONCILIATION_REQUIRED` when RequestStart may have crossed the boundary.
2. Keep the original `cms_command_id`, hold/reservation, start intent, one-use credential binding, and immutable destination evidence. Do not create a replacement start automatically.
3. Reconcile `GET /v1/remote-commands?cms_command_id={uuid}` by the exact original command identity.
4. If HAL returns the exact command, project that command state and continue waiting/reconciling for authoritative transaction evidence.
5. If HAL returns canonical `404` for that exact durable command and CMS proves no materialized session exists, atomically release only the still-reserved commercial hold/reservation and terminalize the intent `REJECTED` or `EXPIRED` according to its window.
6. For an accepted/unmaterialized start past the reconcile threshold, query `GET /v1/transactions?cms_start_intent_id={uuid}`. A matching transaction uses the same locked materializer as a normal `transaction.started` fact.
7. Any non-404 lookup failure or conflicting/malformed evidence keeps reconciliation state; it never becomes absence by timeout.
8. Late physical-start evidence after `REJECTED`/`EXPIRED` is retained and moves the attempt into reconciliation rather than silently fabricating a normal session.
9. If unresolved beyond the operational horizon, alert Technical Admin while continuing safe exact-ID recovery according to retention policy.

## E.6 Payment API response lost after capture

1. Keep logical payment identity/provider order.
2. Do not create a second charge automatically.
3. Reconcile provider state by provider identity/webhook/API.
4. Mark CAPTURED idempotently if proven.
5. User client retry returns same logical payment result.

## E.7 Invoice generation fails

1. Payment/job truth remains untouched.
2. Invoice stays FAILED/PENDING with error classification.
3. Worker retries retryable renderer/storage errors.
4. Admin sees failure and may explicitly retry.
5. READY is never set without verified artifact metadata/checksum.

## E.8 No drivers available

1. DispatchAttempt becomes EXHAUSTED.
2. Job remains truthfully unassigned/dispatching subject to policy.
3. User receives availability/delay state.
4. Retry worker reevaluates fresh candidates, not stale ranking.
5. Admin sees reason/age.
6. Job expires only under explicit policy/deadline.

## E.9 Assigned driver breaks down

1. Driver reports problem/incident.
2. Current assignment ends with reason.
3. Duty becomes UNAVAILABLE or ends depending reality.
4. Job enters REASSIGNING.
5. New dispatch attempt selects another eligible duty.
6. Historical assignment remains.
7. Compensation uses facts attributable to each assignment.

## E.10 Customer location changes after assignment

1. User cannot silently overwrite ServiceJob service-address snapshot.
2. Submit relocation/change request.
3. Backend assesses serviceability, price impact, and current assignment feasibility.
4. If accepted, create an explicit address-change event/new operational snapshot version while preserving original request snapshot.
5. Requote/reassign if required.
6. If not supported initially, customer must cancel and create a new request; API says so explicitly.

The initial implementation SHOULD choose one of these semantics before enabling mid-job relocation. Do not silently mutate coordinates.

---

# Appendix F. Acceptance Evidence Matrix

A claim of completion should name evidence level.

| Claim | Minimum evidence |
| --- | --- |
| Domain implemented | source + unit tests |
| DB invariant enforced | disposable PostgreSQL integration test |
| API contract implemented | OpenAPI/runtime parity + auth tests |
| Worker reliable | retry/lease/integration tests + runtime backlog metrics |
| CMS-HAL command flow works | service integration test |
| OCPP adapter works logically | scripted simulator acceptance |
| Charger model works physically | real hardware acceptance |
| Payment flow works | provider test/live acceptance at claimed boundary |
| Refund works | provider acceptance |
| Invoice generation works | generated artifact checksum + authorized download |
| Email/push works | provider accepted delivery request; do not claim recipient read |
| Deployment works | target runtime health + changed-feature smoke + logs |
| Rollback works | exercised compatible rollback/recovery path |
| Production ready | project-level Definition of Done plus all critical external boundaries accepted |

---

# Appendix G. Blueprint Change Control

Once implementation starts, this blueprint itself follows change discipline.

A semantic change must identify:

1. reason/new evidence;
2. affected actors;
3. affected state machines;
4. persistence/migration impact;
5. API/OpenAPI impact;
6. worker/realtime impact;
7. security/privacy impact;
8. historical compatibility;
9. rollout/rollback plan;
10. affected tests/docs;
11. whether existing mobile/frontends remain compatible.

Do not update only this document while leaving runtime semantics unchanged, and do not change runtime semantics without updating the authoritative contract set.

