> PACKAGE STATUS: NON-NORMATIVE FOCUSED VIEW. `01_CANONICAL_FULL_BLUEPRINT.md` is the only design authority in this ZIP. This file exists for lower-context reading and provenance; it MUST NOT introduce a requirement that is absent from the canonical blueprint. If wording differs, canonical wins.

# Charger on Wheels - Driver, Admin, Fleet, Duty, Dispatch, and Field Operations Blueprint

This focused blueprint contains the operational side of Charger on Wheels: driver recruitment and eligibility, fleet/charger inventory, scheduling, DutySession truth, asset claims, geospatial state, dispatch, assignment/reassignment, field-service lifecycle, Admin capabilities, Driver APIs, and operational recovery.

The canonical full blueprint remains authoritative; this file exists so Driver/Admin/operations work can be implemented without carrying unrelated commercial and frontend detail in every working session.

---

# 3. Architectural Laws and Invariants

These rules are global and must hold across every module.

## 3.1 Separate different kinds of truth

The system MUST preserve these as distinct concepts:

- Administrative/intended state.
- Observed real-world operational state.
- Physical charger/protocol truth.
- Historical snapshot state.
- Customer commercial truth.
- Driver compensation truth.
- Derived/realtime projections.

No convenience field may silently collapse them.

Examples:

- Admin pairing says Vehicle V1 carries Charger C1.
- Driver reports Vehicle V1 actually carries Charger C2.
- Current duty may proceed with observed C2 if policy permits.
- Admin sees a mismatch requiring reconciliation.
- Master pairing remains unchanged until deliberately corrected.
- Historical duty remains permanently tied to the actual observed combination used.

## 3.2 History does not mutate because master data changes

Every historical ServiceJob MUST preserve its own vehicle, service-address, pricing, tax, assignment, and relevant identity snapshots.

Every DriverDutySession MUST preserve its actual vehicle/charger context.

Every finalized compensation result MUST preserve the policy/rule versions and source facts used.

Every invoice MUST preserve the commercial facts used to create it.

Editing a CustomerVehicle, CustomerAddress, ServiceVehicle, Charger, pricing policy, compensation policy, driver profile, or admin assignment later MUST NOT rewrite historical records.

## 3.3 Physical charging truth comes from HAL facts

UI intent, CMS command dispatch, socket write success, or charger command acceptance MUST NOT be represented as a physical charging start.

Physical charging start requires normalized HAL transaction evidence.

Energy delivered requires normalized meter evidence.

Physical charging end requires normalized HAL transaction-end evidence or an explicit reconciled equivalent.

## 3.4 Service lifecycle and charging lifecycle are independent

A ServiceJob may be ARRIVED or SERVICE_PREPARING before physical charging starts.

A physical transaction may end while the ServiceJob remains in WRAP_UP.

A charger fault may end one ChargingSession while the same ServiceJob later starts another ChargingSession.

## 3.5 Customer price and driver compensation are separate engines

They may consume overlapping facts, but they MUST have independent policies, snapshots, ledgers, correction semantics, and administrative permissions.

Customer price changes MUST NOT implicitly change driver compensation.

Driver compensation changes MUST NOT change customer invoices.

## 3.6 External mutations are idempotent or reconcilable

Any mutation that can be retried across network boundaries MUST have one of:

- durable idempotency key semantics;
- a stable operation identity plus exact reconciliation;
- a provider-native idempotency mapping stored durably.

In-memory dedupe is never sufficient for externally retried business mutations.

## 3.7 Realtime is advisory, durable state is recoverable

Realtime messages tell clients that state changed and MAY carry a safe projection.

The client MUST be able to recover authoritative current state using HTTP APIs after disconnect/reconnect.

No critical state transition exists only in WebSocket memory.

## 3.8 Feature completeness remains invariant under extension

Adding a new adapter, vehicle type, charger protocol, pricing component, compensation component, user role, or realtime consumer MUST NOT degrade already-supported correctness properties.

Existing paths retain authorization, idempotency, auditability, verification, and documentation guarantees after extension.

## 3.9 Every actor is a real user

Customer, driver, dispatcher, recruiter, finance operator, support operator, technical/HAL operator, read-only observer, automated worker, CMS, HAL, and external payment provider are all first-class actors with explicit contracts and failure modes.

---

# 4. Chosen Technical Shape

## 4.1 CMS/backend

The initial Charger-on-Wheels CMS SHOULD be a modular monolith because the domains are strongly transactional and still one product boundary.

Chosen baseline:

- Go 1.25.
- Gin HTTP stack.
- PostgreSQL as durable truth.
- Versioned SQL migrations.
- OpenAPI 3.x as machine contract.
- Structured JSON logging.
- Durable database outbox workers for externally visible side effects.
- WebSocket or SSE realtime fanout built from durable/authoritative state changes, not as a source of truth.

The implementation MUST keep package boundaries strong enough that later extraction remains possible without changing domain semantics.

## 4.2 HAL

HAL is a separate Go service/repository/process with its own persistence and deployment lifecycle.

It MUST be protocol-neutral in the core and adapter-driven at the edges.

The first physical-protocol adapter is OCPP 1.6 unless hardware requirements force another initial protocol.

OCPP 2.0.1, OCPP 2.1, vendor adapters, and simulator adapters are additive extensions of the same normalized core.

## 4.3 Databases

CMS and HAL MUST use separate PostgreSQL databases and MUST NOT share tables or database credentials.

Cross-service communication uses authenticated HTTP and/or durable callback/fact delivery contracts.

## 4.4 Recommended repositories

Logical repository identities:

- `charger-on-wheels-backend`
- `charger-on-wheels-hal`

The exact Git organization/remote may be chosen during bootstrap. Once created, repository identity becomes part of the deployment contract and must be documented.

---

# 5. System Context and Deployment Topology

## 5.1 Logical topology

```text
User App -----------\
Driver App ----------> Charger-on-Wheels CMS/API -----> PostgreSQL (CMS)
Admin App -----------/          |   |   |
                               |   |   +--> Mail/notification providers
                               |   +------> Razorpay customer payments
                               +----------> Dedicated HAL API
                                              |
                                              +--> PostgreSQL (HAL)
                                              +--> charger WebSocket/OCPP/proprietary links
```

## 5.2 Trust boundaries

- User/Driver/Admin clients are untrusted network clients.
- CMS auth context is authoritative for human identity.
- CMS MUST NOT trust arbitrary client-supplied actor IDs, driver IDs, or admin capability claims.
- HAL is a trusted service only after service-to-service authentication succeeds.
- Charger-provided data is physical evidence but still untrusted input and must be validated/normalized.
- Razorpay/webhook payloads are trusted only after signature verification and replay/idempotency handling.

## 5.3 Environment tiers

At minimum:

- local development;
- shared development/integration;
- staging/pre-production;
- production.

Development and staging MUST use separate databases and separate HAL identities from production.

No production database may be used as an automated test database.

---

# 6. Repository and Module Ownership

Recommended CMS package layout:

```text
cmd/
  api/
  migrate/
  worker/                 # optional split entrypoint later

internal/
  platform/
    config/
    db/
    httpx/
    authn/
    authz/
    idempotency/
    outbox/
    audit/
    observability/
    realtime/

  users/
  customerprofiles/
  customervehicles/
  customeraddresses/

  driverrecruitment/
  drivers/
  schedules/
  duty/
  availability/

  fleet/
  vehicles/
  chargers/
  connectors/
  pairings/
  assignments/
  maintenance/

  dispatch/
  servicejobs/
  locations/

  charging/
  halclient/
  halfacts/

  pricing/
  payments/
  refunds/
  invoices/
  tax/

  compensation/

  ratings/
  support/
  incidents/
  notifications/

  admin/
```

The package names can be refined during bootstrap, but ownership MUST remain domain-oriented rather than one giant handlers/services/models structure.

Recommended HAL layout:

```text
cmd/
  hal/
  simulator/
  migrate/

internal/
  core/
    charger/
    connection/
    capability/
    transaction/
    command/
    metering/
    state/
    faults/
    operations/
    recovery/
    reconciliation/
    facts/
    trace/

  protocols/
    ocpp16/
    ocpp201/
    ocpp21/

  vendors/
  simulator/
  cmsclient/
  platform/
```

---

# 7. Identity, Authentication, Authorization, and Sessions

## 7.1 Principal types

Use distinct authenticated principal types:

- `CUSTOMER`
- `DRIVER`
- `ADMIN`
- `SERVICE`

A customer ID must never be interpreted as a driver/admin user ID even if UUID types are identical.

## 7.2 Accounts

V1 uses one common credential-bearing account layer; Customer, Driver, and Admin domain principals and authorization remain separate. Canonical Section 7.2 contains the frozen rules.

Recommended durable model:

```text
accounts
account_sessions
account_devices
customer_profiles
driver_profiles
admin_memberships
roles
capabilities
role_capabilities
admin_capability_overrides
```

## 7.3 Session requirements

Human sessions MUST support:

- revocation;
- expiration;
- device/session listing;
- refresh rotation if refresh tokens are used;
- server-side invalidation on suspension/offboarding where required;
- last-used metadata without logging secrets.

## 7.4 Admin RBAC

Admin access is capability-based. Role names are convenience bundles only.

Initial role bundles:

- `FULL_ADMIN`
- `OPERATIONS`
- `DRIVER_RECRUITMENT`
- `FINANCE_COMMERCIAL`
- `SUPPORT`
- `TECHNICAL_HAL`
- `READ_ONLY`

Capabilities, not role names, authorize endpoints.

Suggested capability namespace:

```text
users.read
users.manage

drivers.read
drivers.review
drivers.manage
drivers.suspend

fleet.read
fleet.manage
fleet.maintenance
fleet.assign

schedules.read
schedules.manage

dispatch.read
dispatch.manage
dispatch.override

jobs.read
jobs.manage
jobs.cancel
jobs.reassign

charging.read
charging.command
charging.reconcile
charging.trace.read

pricing.read
pricing.manage

payments.read
payments.manage
refunds.manage
invoices.read
invoices.manage

compensation.read
compensation.manage
compensation.adjust

ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage

system.settings.read
system.settings.manage
audit.read
```

Explicit DENY overrides role defaults if membership-level overrides are implemented.

## 7.5 Service authentication

CMS <-> HAL MUST use service credentials independent of human auth.

Service requests MUST include:

- authenticated service identity;
- request/correlation ID;
- stable operation/fact ID for idempotent operations;
- frozen v1 service authentication uses TLS plus separate opaque bearer credentials for command, fact, and trace planes; canonical Section 7.5 is authoritative.

---

# 8. Universal HTTP/API Contract

## 8.1 Versioning

Initial public API prefix:

```text
/api/v1
```

Internal CMS-only service API prefix:

```text
/internal/v1
```

The separately hosted HAL is its own service and deliberately uses its own service-major root:

```text
/v1
```

Therefore `HAL_ORIGIN + /v1/...` is not a public CMS route and does not conflict with CMS `/internal/v1/...`. Browser/mobile clients never receive the HAL origin or service credentials.

Breaking contract changes require a new version or a backwards-compatible migration strategy.

## 8.2 Envelope

Success responses SHOULD use the resource directly unless pagination/metadata requires an envelope.

Errors use one canonical shape:

```json
{
  "error": {
    "code": "JOB_INVALID_TRANSITION",
    "message": "The job cannot move from ARRIVED to COMPLETED.",
    "request_id": "...",
    "details": {}
  }
}
```

`message` is safe for the client. Internal stack traces, SQL text, secrets, and provider payloads MUST NOT be returned.

## 8.3 Pagination

Use keyset pagination for growing operational/history collections.

Default page size: 20. Maximum: 100 unless an endpoint explicitly documents otherwise.

Ordering must be deterministic, typically:

```text
created_at DESC, id DESC
```

Cursor fields must encode every sort key required to avoid duplicates/skips.

## 8.4 Filtering and sorting

Filtering happens in SQL before LIMIT.

Every list endpoint documents:

- allowed filters;
- allowed sort keys;
- default sort;
- null ordering where relevant;
- full-text/search fields if `q` is accepted.

## 8.5 Idempotency header

Business-create and side-effecting retryable endpoints use:

```text
Idempotency-Key: <client-generated opaque key>
```

Scope is at least authenticated principal + HTTP operation + idempotency key.

Same key + semantically same request returns the same committed result.

Same key + conflicting request returns `409 IDEMPOTENCY_KEY_REUSED`.

## 8.6 Optimistic concurrency

Admin edits of mutable configuration SHOULD use either:

- `version` integer checked in the mutation; or
- strong ETag/If-Match.

Conflicts return 409 rather than silently overwriting a newer edit.

---

# 9. Global Persistence Conventions

## 9.1 IDs

Use UUID primary keys generated server-side, preferably UUIDv7 where implementation support is stable.

Provider IDs, charger protocol IDs, registration numbers, and human-readable job numbers are alternate identifiers, not primary keys.

## 9.2 Time

- Store all event timestamps as timezone-aware PostgreSQL `timestamptz` in UTC.
- Store an explicit IANA timezone on policies where local time affects behavior.
- Default business timezone for India deployment: `Asia/Kolkata`.
- Never compute compensation/time-window rules using server-local implicit timezone.

## 9.3 Money

Store monetary minor units as integers plus ISO currency code.

For INR:

```text
amount_minor = paise
currency = INR
```

Do not use binary floating point for money.

## 9.4 Energy and measurements

Choose canonical internal units and document them:

- energy: Wh integer where possible;
- power: W integer where possible;
- distance: meters integer;
- duration: milliseconds or seconds integer;
- latitude/longitude: decimal numeric precision sufficient for location;
- percentage/SoC: numeric/decimal with explicit range.

API may expose convenient derived units, but durable facts remain canonical.

## 9.5 Soft deletion

Use soft deactivation for identities/assets/configuration that must remain referentially visible to history.

Do not physically delete a driver, vehicle, charger, pricing policy, compensation policy, or saved customer object while history references it unless an explicit anonymization/retention process exists.

## 9.6 Audit columns

Mutable administrative/master tables SHOULD include:

```text
created_at
created_by
updated_at
updated_by
version
```

Historical event tables normally append new rows instead of updating semantic history.

---

# 11. Driver Recruitment and Workforce Blueprint

## 11.1 Recruitment state machine

Canonical `DriverApplication.status`:

```text
DRAFT
SUBMITTED
UNDER_REVIEW
ACTION_REQUIRED
APPROVED
ONBOARDING
ACTIVE
REJECTED
WITHDRAWN
```

Operational suspension/offboarding is NOT represented by mutating an old application back out of APPROVED/ACTIVE.

## 11.2 Allowed recruitment transitions

```text
DRAFT -> SUBMITTED | WITHDRAWN
SUBMITTED -> UNDER_REVIEW | WITHDRAWN
UNDER_REVIEW -> ACTION_REQUIRED | APPROVED | REJECTED
ACTION_REQUIRED -> SUBMITTED | WITHDRAWN
APPROVED -> ONBOARDING
ONBOARDING -> ACTIVE
```

Any exceptional administrative correction requires a dedicated audited override action, not arbitrary status PATCH.

## 11.3 Driver profile

Created when the application reaches the configured onboarding boundary.

`driver_profiles`:

```text
id
account_id
source_application_id
full_name
phone
email
base_operating_area_id
employment_classification
operational_status
eligibility_status
suspended_at
offboarded_at
created_at
updated_at
version
```

## 11.4 KYC/document records

Documents are separate durable records with type, secure storage reference, verification state, expiry, and review history.

Sensitive documents MUST NOT be exposed in list endpoints by default.

Recommended states:

```text
SUBMITTED
UNDER_REVIEW
VERIFIED
REJECTED
EXPIRED
REPLACED
```

A replacement creates a new document version/record; it does not erase historical review evidence.

## 11.5 Eligibility

Driver eligibility is a derived decision backed by explicit durable reasons.

A driver is dispatch-eligible only if all mandatory conditions are true, including:

- profile active;
- not suspended/offboarded;
- required KYC verified and not expired;
- required driving licence valid;
- training/terms requirements met;
- no blocking compliance issue;
- active duty session in dispatchable state.

The API SHOULD expose both overall eligibility and machine-readable blocking reasons.

---

# 12. Fleet, Vehicle, Charger, Connector, and Pairing Blueprint

## 12.1 ServiceVehicle

`service_vehicles` master fields:

```text
id
registration_number
asset_tag
make
model
variant
vehicle_type
ownership_type
registration_valid_until
insurance_valid_until
inspection_status
operational_status
maintenance_status
is_active
notes
created_at
updated_at
version
```

Recommended operational status enum:

```text
AVAILABLE
OUT_OF_SERVICE
RETIRED
```

Do not overload this field with transient claimed/assigned state.

## 12.2 Charger

`chargers` master fields:

```text
id
asset_tag
serial_number
manufacturer
model
rated_power_w
protocol_family
protocol_version
hal_identity
operational_status
maintenance_status
is_active
notes
created_at
updated_at
version
```

Live HAL connectivity is projected separately.

## 12.3 Charger connectors

`charger_connectors`:

```text
id
charger_id
connector_number
connector_type
max_power_w
supports_ac
supports_dc
is_active
created_at
updated_at
```

One charger may have multiple connectors.

## 12.4 Runtime capability projection

CMS stores a HAL-derived projection, not the protocol source of truth:

```text
charger_capability_projection
  charger_id
  observed_at
  protocol
  supports_remote_start
  supports_remote_stop
  supports_unlock
  supports_smart_charging
  supports_soc
  supports_iso15118
  supports_reservation
  connector capability snapshot
  source_hal_fact_id
```

Staleness is explicit. A capability observation has an `observed_at`; it is never treated as timeless truth.

## 12.5 Vehicle-Charger pairing history

`vehicle_charger_pairings` is effective-dated:

```text
id
vehicle_id
charger_id
effective_from
effective_to
status              # ACTIVE, ENDED, INVALIDATED
source               # ADMIN, RECONCILIATION
created_by
created_at
reason
```

Only one active exclusive vehicle pairing per charger is allowed if hardware is physically exclusive.

If future hardware permits multiple chargers per vehicle, the schema supports it without changing charger identity.

## 12.6 Driver asset assignment

`driver_asset_assignments` represents admin intent, not actual use:

```text
id
driver_id
schedule_id nullable
schedule_occurrence_id nullable
vehicle_id nullable
charger_id nullable
assignment_mode       # REQUIRED, SUGGESTED
valid_from
valid_to
created_by
created_at
ended_at
```

## 12.7 Derived inventory availability

Admin inventory APIs derive one of:

```text
AVAILABLE
RESERVED
ASSIGNED
IN_USE
MAINTENANCE
OUT_OF_SERVICE
RETIRED
```

Derivation inputs include master operational state, maintenance intervals, active reservations/claims, active duty sessions, and current assignments.

No single mutable field is allowed to pretend to be all of these truths.

# 13. Schedule, Duty, Availability, and Asset Claim Blueprint

## 13.1 Schedule model

A DriverSchedule represents planned work. It does not itself make the driver online or dispatchable.

Recommended structure:

```text
driver_schedules
  id
  driver_id
  timezone
  recurrence_type        # ONE_OFF, RECURRING
  recurrence_rule nullable
  planned_start
  planned_end
  service_zone_id nullable
  assigned_vehicle_id nullable
  assigned_charger_id nullable
  assignment_mode         # REQUIRED, SUGGESTED, NONE
  status                  # DRAFT, ACTIVE, CANCELLED, RETIRED
  notes
  created_by
  created_at
  updated_at
  version
```

Recurring schedules MUST materialize bounded occurrences so actual work can reference a stable occurrence rather than an ever-changing recurrence expression.

`driver_schedule_occurrences`:

```text
id
schedule_id
driver_id
planned_start
planned_end
status                    # PLANNED, STARTED, MISSED, CANCELLED, COMPLETED
actual_duty_session_id nullable
created_at
```

A later edit to the recurring schedule MUST NOT rewrite an occurrence that has started or completed.

## 13.2 DutySession state machine

Canonical `DriverDutySession.status`:

```text
STARTING
AVAILABLE
OFFERED
ASSIGNED
EN_ROUTE
AT_CUSTOMER
SERVICING
BREAK
UNAVAILABLE
ENDING
ENDED
ABORTED
```

`OFF_DUTY` is represented by absence of an active duty session, not by keeping a permanent row in OFF_DUTY.

A driver may have at most one nonterminal duty session at a time.

## 13.3 DutySession record

`driver_duty_sessions` MUST snapshot actual operational context:

```text
id
driver_id
schedule_occurrence_id nullable
started_at
ended_at nullable
status

expected_vehicle_id nullable
expected_charger_id nullable
actual_vehicle_id nullable
actual_charger_id nullable
pairing_source         # ADMIN_ASSIGNED, DRIVER_SELECTED, OBSERVED_TEMPORARY, RECONCILED
pairing_mismatch       boolean

vehicle_snapshot jsonb
charger_snapshot jsonb
connector_snapshot jsonb
eligibility_snapshot jsonb
service_area_snapshot jsonb

start_location_lat nullable
start_location_lon nullable
last_location_at nullable
end_reason nullable
created_at
updated_at
version
```

The snapshots are historical support, not substitutes for normalized foreign keys.

## 13.4 Starting duty / going online

The backend MUST run the following as one logical transaction plus external HAL checks where required:

1. Authenticate Driver principal.
2. Lock driver operational row/advisory key to prevent concurrent starts.
3. Verify no active duty session already exists.
4. Verify driver profile is active and not suspended/offboarded.
5. Verify eligibility and mandatory document expiry.
6. Resolve schedule requirement and active occurrence.
7. Resolve intended/admin asset assignment.
8. Resolve driver-selected or observed actual assets.
9. Verify vehicle master operational state.
10. Verify charger master operational state.
11. Verify required inspection/registration/insurance constraints.
12. Verify vehicle and charger are not actively claimed by another duty session.
13. Verify selected/observed vehicle-charger combination is permitted, or create mismatch workflow if policy permits deviation.
14. Verify charger identity is known to HAL.
15. If online HAL reachability is a hard policy requirement, query current HAL projection and reject if too stale/offline.
16. Derive effective service area as intersection of platform, admin, and driver constraints.
17. Atomically create the DutySession and exclusive asset claims.
18. Emit durable `DriverDutyStarted` domain event.
19. Publish realtime invalidations/projections.

If a HAL reachability check occurs before the DB transaction and the result can go stale, the persisted row MUST record the observation timestamp. Do not represent it as a permanent fact.

## 13.5 Asset claims

Use a dedicated table instead of trusting status flags:

```text
asset_claims
  id
  duty_session_id
  asset_type          # VEHICLE, CHARGER
  asset_id
  claim_mode          # EXCLUSIVE
  claimed_at
  released_at nullable
```

A PostgreSQL uniqueness/exclusion mechanism MUST prevent two live exclusive claims for the same asset.

The application must treat a uniqueness conflict as a normal concurrency result, not an internal server error.

## 13.6 Driver-selected vs observed temporary assets

If policy allows a driver to declare an asset not yet in master inventory:

- the duty session stores the observed asset snapshot;
- the system creates an `AssetMismatchReport` or `ObservedAssetReport`;
- dispatch eligibility can be reduced or blocked depending on missing compatibility evidence;
- Admin can later promote/reconcile it into master inventory;
- the historical duty session remains unchanged.

Unknown charger hardware MUST NOT become dispatchable for charging merely because a driver typed a label. It requires sufficient technical identity/capability and HAL recognition.

## 13.7 Breaks and availability intervals

Duty presence and dispatch availability are distinct.

Use append-only intervals/events to preserve why the driver was unavailable:

```text
driver_availability_intervals
  id
  duty_session_id
  type                # BREAK, UNAVAILABLE, ADMIN_HOLD, EMERGENCY
  started_at
  ended_at nullable
  reason_code nullable
  note nullable
  created_by_actor_type
  created_by_actor_id
```

An active interval blocks dispatch unless its type is explicitly configured otherwise.

## 13.8 Ending duty

A driver cannot normally end duty while responsible for an active ServiceJob.

The API returns a conflict with blocking job identifiers and recovery guidance.

Admin emergency override MAY terminate duty only after one of:

- active jobs are reassigned;
- active jobs are failed/cancelled under explicit reason;
- a technical incident workflow owns the unresolved job.

Ending duty:

- records actual end time;
- releases asset claims;
- closes active availability interval;
- finalizes duty-level aggregates asynchronously if needed;
- preserves all snapshots;
- emits durable event.

---

# 14. Location and Geospatial Blueprint

## 14.1 Location authority

Driver device location is an observation, not guaranteed truth.

Location samples MUST include:

```text
id
driver_id
duty_session_id
recorded_at        # device/source timestamp if trusted enough
received_at        # server timestamp
latitude
longitude
accuracy_m nullable
speed_mps nullable
heading_deg nullable
source             # DRIVER_APP, VEHICLE_GPS, ADMIN_CORRECTION, OTHER
```

Server receipt time is mandatory even when source timestamp is present.

## 14.2 Current location projection

Maintain a derived current row for efficient dispatch:

```text
driver_location_projection
  driver_id
  duty_session_id
  latest_sample_id
  latitude
  longitude
  accuracy_m
  recorded_at
  received_at
```

This projection is replaceable and rebuildable from durable samples within the chosen retention window.

## 14.3 Freshness

Dispatch policy MUST define a maximum location age, e.g. configuration:

```text
DISPATCH_MAX_LOCATION_AGE_SECONDS
```

The default should be conservative and environment-configurable. A stale driver is ineligible rather than assigned based on old location.

## 14.4 Effective service area

Effective dispatch area is:

```text
platform service eligibility
INTERSECT admin restriction
INTERSECT driver voluntary preference
```

Driver preference may narrow but never expand the platform/admin area.

Supported initial geometry modes:

- NONE
- RADIUS
- ADMIN_ZONE

Polygon support can be added without changing the conceptual contract.

## 14.5 Location privacy

User clients receive only the assigned operational unit/driver location needed for their current job.

Users MUST NOT query arbitrary driver locations.

Historical raw driver traces are Admin-only with explicit capability and retention policy.

---

# 15. Dispatch Blueprint

Dispatch is a durable business workflow, not a stateless nearest-driver query.

## 15.1 Inputs

A dispatch attempt is based on a frozen request context containing at least:

- ServiceJob ID.
- requested service location.
- customer vehicle snapshot.
- requested charging preference.
- connector requirements.
- minimum capability requirements.
- scheduling window/immediacy.
- customer priority if applicable.
- dispatch policy version.

## 15.2 Eligibility pipeline

Candidate eligibility MUST evaluate all relevant hard constraints before ranking:

1. Driver active and eligible.
2. Active DutySession.
3. DutySession dispatchable status.
4. No blocking break/unavailable interval.
5. Location fresh enough.
6. Within effective service area.
7. Vehicle active, not under blocking maintenance.
8. Charger active, not under blocking maintenance.
9. Exclusive claims valid.
10. Actual duty assets known.
11. Customer connector compatibility.
12. AC/DC compatibility.
13. Power/capability threshold.
14. HAL capability/connectivity policy satisfied.
15. No conflicting active assignment.
16. Mobile unit energy/capacity handled according to canonical Section 53 activation state.
17. Schedule commitment permits the job.
18. Any special customer/service requirement satisfied.

Eligibility result SHOULD store reason codes for rejected candidates during bounded diagnostic windows, at least in trace/audit form, so operations can explain why a nearby driver was skipped.

## 15.3 Ranking

Only eligible candidates are ranked.

Initial ranking function SHOULD be deterministic and explicit, for example lexicographic or weighted scoring over:

- ETA.
- route distance.
- current workload/queued jobs.
- schedule slack.
- asset capability fit.
- mobile energy reserve.
- job priority.
- admin priority.
- optional driver rating policy.

The exact coefficients are configuration/policy data and MUST be versioned if they materially affect operations.

Tie-breaking MUST be deterministic, e.g. `score DESC, estimated_eta ASC, driver_id ASC`.

## 15.4 DispatchAttempt

Persist every assignment cycle:

```text
dispatch_attempts
  id
  service_job_id
  attempt_number
  policy_version
  status              # RUNNING, OFFERING, ASSIGNED, EXHAUSTED, CANCELLED
  started_at
  ended_at nullable
  created_reason
```

## 15.5 DispatchCandidate

Persist the candidates selected for an attempt if offers are durable:

```text
dispatch_candidates
  id
  dispatch_attempt_id
  driver_id
  duty_session_id
  rank
  score_components jsonb
  eligibility_snapshot jsonb
  status              # ELIGIBLE, OFFERED, ACCEPTED, REJECTED, EXPIRED, SKIPPED
```

Do not store every ineligible driver forever. Diagnostic ineligibility may be logged/traced with bounded retention.

## 15.6 Offer strategy

The initial platform MUST use one normal dispatch strategy:

```text
SEQUENTIAL
```

Admin may also use an explicit `DIRECT_ASSIGNMENT` action for exceptional operations.

`BATCHED` multi-driver offers are a future extension, not part of the initial semantic contract. They may be added only with an explicit multi-offer race model and without changing the meaning of existing states. This avoids making `ASSIGNED` mean different things under different strategies.

Each DispatchOffer has:

```text
id
dispatch_attempt_id
service_job_id
driver_id
duty_session_id
sent_at
expires_at
status            # PENDING, ACCEPTED, REJECTED, EXPIRED, WITHDRAWN
response_at nullable
```

A driver MUST NOT accept an expired/withdrawn offer.

While one sequential offer is live, the ServiceJob is `ASSIGNED`: one specific driver has been selected and given the right to accept within the offer window, but the driver has not yet committed. The active DispatchOffer is the provisional assignment.

## 15.7 Acceptance race

Offer acceptance is transactionally serialized on the ServiceJob/DispatchAttempt.

On valid acceptance:

1. lock the ServiceJob and live DispatchOffer;
2. revalidate job, duty, driver, and asset state;
3. mark offer ACCEPTED;
4. create the durable JobAssignment;
5. set `current_assignment_id`;
6. clear `current_offer_id`;
7. transition ServiceJob `ASSIGNED -> ACCEPTED`;
8. transition DutySession `OFFERED -> ASSIGNED`;
9. commit one coherent result.

A concurrent or late second acceptance is impossible in the initial sequential strategy and must return `409 OFFER_NO_LONGER_AVAILABLE` if a duplicate/stale request reaches the server.

## 15.8 Rejection/timeout

A rejection or expiry advances the same dispatch attempt to the next candidate or starts a new attempt after re-evaluation if enough state has changed.

Do not indefinitely reuse a stale candidate list after location, duty, capability, or job state changes.

## 15.9 No candidates

When no eligible candidate exists:

- ServiceJob remains in `DISPATCHING` or enters a distinct operational wait condition represented by event/reason, not a fake assignment.
- User receives a truthful availability state.
- Admin receives an actionable queue item.
- retry cadence/backoff is bounded and observable.
- scheduled jobs may remain pending until their dispatch window.
- immediate jobs eventually expire or require admin intervention under explicit policy.

## 15.10 Reassignment

Reassignment does not create a new ServiceJob.

Create a new JobAssignment record and preserve the old one.

Reasons include:

- driver rejected/cancelled;
- driver unreachable;
- breakdown;
- charger incompatibility/fault;
- admin override;
- customer relocation beyond current assignment feasibility.

Current assignment changes atomically with ServiceJob transition to/from `REASSIGNING`.

---

# 16. Service Request, Quote, and ServiceJob Blueprint

## 16.1 ServiceRequest

A ServiceRequest is the customer's expressed request before an operational job is fully committed.

Fields:

```text
id
customer_id
request_type            # IMMEDIATE, SCHEDULED
requested_for nullable
requested_vehicle_source # SAVED, TEMPORARY
requested_address_source # SAVED, TEMPORARY
vehicle_input jsonb
address_input jsonb
charging_preference jsonb
status                  # DRAFT, QUOTED, CONFIRMED, EXPIRED, CANCELLED
created_at
updated_at
```

## 16.2 Quote

A Quote is a time-bounded commercial offer derived from current request facts and pricing policy.

`quotes`:

```text
id
service_request_id
customer_id
pricing_policy_id
pricing_policy_version
currency
estimated_components jsonb
estimated_total_minor
valid_until
assumptions jsonb
status                 # ACTIVE, ACCEPTED, EXPIRED, SUPERSEDED
created_at
```

A quote is an estimate unless the component is explicitly guaranteed.

The quote MUST disclose important non-guaranteed dimensions, for example energy/time finalization based on actual charging.

## 16.3 Job creation boundary

Accepting a valid quote creates the ServiceJob transactionally or through an idempotent orchestration boundary.

At creation, snapshot:

- customer identity relevant to service/invoice;
- service address;
- customer EV;
- requested charging preference;
- accepted quote/pricing inputs;
- initial tax context if applicable;
- scheduling target;
- source request and quote IDs.

## 16.4 ServiceJob record

`service_jobs` minimum durable shape:

```text
id
job_number
customer_id
service_request_id
accepted_quote_id
status
status_reason nullable
request_type
requested_for nullable

service_address_snapshot jsonb
customer_vehicle_snapshot jsonb
charging_preference_snapshot jsonb

current_offer_id nullable
current_assignment_id nullable
current_duty_session_id nullable
current_vehicle_id nullable
current_charger_id nullable

pricing_snapshot_id nullable
final_price_minor nullable
currency

created_at
confirmed_at
dispatch_started_at nullable
assigned_at nullable
accepted_at nullable
en_route_at nullable
arrived_at nullable
service_preparing_at nullable
charging_started_at nullable
charging_ended_at nullable
wrap_up_at nullable
completed_at nullable
cancelled_at nullable
failed_at nullable

version
```

Timestamps are facts for the first/authoritative transition where semantically appropriate; event history preserves all transitions.

## 16.5 ServiceJob state machine

Canonical states:

```text
REQUESTED
QUOTED
DISPATCHING
ASSIGNED
ACCEPTED
EN_ROUTE
ARRIVED
SERVICE_PREPARING
CHARGING
WRAP_UP
COMPLETED
REASSIGNING
CANCELLED
FAILED
NO_SHOW
EXPIRED
```

In the persisted implementation, `REQUESTED` and `QUOTED` may remain pre-Job request states if ServiceJob is only created on quote acceptance. If so, the ServiceJob itself begins at `DISPATCHING` (or scheduled equivalent). The public product lifecycle may still show request/quote phases. Do not duplicate objects merely to satisfy a label.

## 16.6 Required transition graph

Minimum legal path:

```text
DISPATCHING -> ASSIGNED | CANCELLED | EXPIRED | FAILED
ASSIGNED -> ACCEPTED | DISPATCHING | REASSIGNING | CANCELLED | FAILED
ACCEPTED -> EN_ROUTE | REASSIGNING | CANCELLED | FAILED
EN_ROUTE -> ARRIVED | REASSIGNING | CANCELLED | FAILED | NO_SHOW
ARRIVED -> SERVICE_PREPARING | REASSIGNING | CANCELLED | FAILED | NO_SHOW
SERVICE_PREPARING -> CHARGING | REASSIGNING | CANCELLED | FAILED
CHARGING -> WRAP_UP | FAILED
WRAP_UP -> COMPLETED | FAILED
REASSIGNING -> DISPATCHING | ASSIGNED | CANCELLED | FAILED
```

Additional transition from `ARRIVED` directly to `WRAP_UP` is permitted only for an explicit zero-charge/aborted-service closeout reason and commercial policy that can finalize it.

`COMPLETED`, `CANCELLED`, `FAILED`, `NO_SHOW`, `EXPIRED` are terminal for the job lifecycle. Corrections use administrative correction records, refunds/adjustments, support, or incident workflows rather than reopening history casually.

## 16.7 Transition authorization

Every transition declares allowed actor(s):

- Customer.
- Assigned Driver.
- Admin capability.
- System worker.
- HAL fact handler.

No generic `PATCH status` endpoint is allowed for User or Driver.

Admin overrides use explicit action endpoints with reason and audit trail.

## 16.8 Job event history

`service_job_events` is append-only:

```text
id
service_job_id
event_type
from_status nullable
to_status nullable
actor_type
actor_id nullable
occurred_at
reason_code nullable
metadata jsonb
request_id
```

This is not a substitute for domain-specific records such as assignments, payments, or charging sessions; it is the high-level job timeline.

---

# 17. Assignment, Arrival, and Field-Service Flow

## 17.1 JobAssignment

A JobAssignment is created when a driver accepts a live offer or when an authorized Admin performs a direct assignment. A pending offer is not yet a JobAssignment. Each created assignment is immutable identity/history with a lifecycle status:

```text
job_assignments
  id
  service_job_id
  dispatch_attempt_id nullable
  source_offer_id nullable
  driver_id
  duty_session_id
  vehicle_id
  charger_id
  status              # ACCEPTED, ACTIVE, REPLACED, CANCELLED, COMPLETED
  assigned_at
  accepted_at nullable
  ended_at nullable
  end_reason nullable
  asset_snapshot jsonb
```

Only one current active assignment per ServiceJob. While the ServiceJob is `ASSIGNED` awaiting driver acceptance, `current_offer_id` identifies the provisional selected driver and `current_assignment_id` remains null.

## 17.2 Driver acceptance

Acceptance of the live DispatchOffer MUST revalidate at commit time:

- offer still valid;
- job still assignable;
- same duty session still active;
- driver not already in incompatible active job;
- asset claims unchanged;
- essential compatibility still valid.

Do not rely solely on eligibility checked when the offer was generated.

## 17.3 En route

Driver action `start_navigation` or equivalent moves accepted assignment/job to EN_ROUTE.

Navigation itself may use an external maps provider on the client. The backend stores operational facts, not third-party turn-by-turn state.

## 17.4 Arrival

Driver can mark arrival only when assigned and EN_ROUTE.

The backend SHOULD compare current location to service location and record validation result:

```text
arrival_validation = WITHIN_RADIUS | OUTSIDE_RADIUS | LOCATION_STALE | LOCATION_UNAVAILABLE
```

Product policy MAY allow manual arrival outside radius with reason. It must remain auditable.

## 17.5 Service preparation

Preparation includes physical steps such as parking, cable/connector setup, safety checks, charger readiness, and customer confirmation as product requires.

The backend must not model these as charging facts.

Preparation is the correct place to resolve:

- actual connector chosen;
- actual charger availability;
- any final asset mismatch;
- inability to safely/technically charge;
- cancellation/failed-service reason before charging.

---

# 25. Driver Compensation Engine Blueprint

## 25.1 Scope

Driver compensation is calculation, explanation, aggregation, and correction only.

It MUST NOT represent bank/payment execution.

The word `paid` must not appear as a compensation lifecycle status unless a future accounting/payout module explicitly introduces and owns that truth.

## 25.2 Policy model

`compensation_policies`:

```text
id
name
status              # DRAFT, ACTIVE, RETIRED
currency
timezone
effective_from
effective_to nullable
version
created_by
created_at
activated_at nullable
```

`compensation_rules`:

```text
id
policy_id
component_type
operator
priority
scope jsonb
conditions jsonb
calculation jsonb
time_basis nullable
rule_version
is_enabled
created_at
```

## 25.3 Initial component types

```text
COMPLETED_JOB_BASE
TRAVEL_DISTANCE
TRAVEL_TIME
WAITING_TIME
CHARGING_TIME
ENERGY_DELIVERED
REVENUE_COMMISSION
PER_CHARGE
TIME_WINDOW_MODIFIER
DATE_WINDOW_MODIFIER
ZONE_MODIFIER
DRIVER_OVERRIDE
DRIVER_GROUP_MODIFIER
BONUS
PENALTY
MINIMUM_GUARANTEE
CAP
MANUAL_ADJUSTMENT
```

## 25.4 Rule operators

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM_GUARANTEE
CAP
```

Evaluation order MUST be explicitly deterministic.

Recommended order:

1. calculate base additive components;
2. apply explicit scoped overrides to rates/quantities;
3. calculate modifiers/multipliers in priority order;
4. apply minimum guarantee;
5. apply caps;
6. append manual adjustments separately.

## 25.5 Source facts

Compensation uses authoritative system facts wherever possible:

```text
travel distance         <- trusted location/route evidence under defined basis
travel time             <- job lifecycle timestamps
waiting time            <- defined ARRIVED/preparation/charging boundaries
charging time           <- HAL transaction evidence
energy delivered        <- HAL meter evidence
completed job           <- terminal ServiceJob fact
revenue                 <- finalized customer commercial line items
zone                    <- service location / defined operating zone snapshot
```

Driver-entered freeform values are not authoritative financial inputs without explicit Admin approval workflow.

## 25.6 Time basis

Every time-sensitive rule MUST declare one of:

```text
JOB_START
JOB_END
EVENT_TIME
INTERVAL_PRORATED
```

For `INTERVAL_PRORATED`, the engine splits the relevant measurable interval across local-time rule boundaries.

Example: 21:45-22:35 job with night rule at 22:00.

The engine must calculate pre-22:00 and post-22:00 quantities separately when the component is interval-prorated.

## 25.7 CompensationSnapshot

When a ServiceJob reaches the compensation finalization boundary, freeze:

```text
compensation_snapshots
  id
  service_job_id
  driver_id
  assignment_id
  policy_id
  policy_version
  timezone
  source_fact_snapshot jsonb
  rule_snapshot jsonb
  calculated_at
```

## 25.8 Ledger line items

`compensation_line_items`:

```text
id
compensation_snapshot_id
service_job_id
driver_id
component_type
rule_id
rule_version
quantity
unit
rate_minor nullable
operator
amount_minor
source_fact_refs jsonb
calculation_metadata jsonb
created_at
```

The total is derived from line items, not stored as the only truth.

## 25.9 Adjustments

A correction creates a new `compensation_adjustments` record/line item with reason, actor, and target prior calculation.

Never edit old finalized line items to make the total look correct.

## 25.10 Reassignment allocation

If more than one driver serves one ServiceJob, compensation MUST be attributable by assignment/duty interval.

Default rule:

- each driver receives only components supported by facts from their own assignment interval;
- completed-job base goes to the driver who completes the job unless policy explicitly defines split/credit semantics;
- travel distance/time are assignment-specific;
- charging metrics belong to the driver assignment active during those facts unless an Admin correction reallocates them.

This prevents a reassigned driver from receiving or losing unrelated work silently.

## 25.11 Summaries

Daily/weekly/monthly/custom-range views are aggregates over immutable line items and adjustments.

They must not be separately maintained money totals that can drift.

---

# 27. Support and Incident Blueprint

Support and incidents are separate concepts.

- Support: customer/driver asks for assistance or reports a service issue conversationally.
- Incident: operational/safety/technical event requiring structured investigation or resolution.

## 27.1 Support channels

Initial channels:

```text
CUSTOMER_PLATFORM
DRIVER_PLATFORM
```

A support ticket MUST have exactly one owner plane.

## 27.2 Ticket model

```text
support_tickets
  id
  channel
  customer_id nullable
  driver_id nullable
  service_job_id nullable
  subject
  status
  priority
  created_at
  updated_at
  closed_at nullable
```

Status:

```text
OPEN
IN_PROGRESS
RESOLVED
CLOSED
```

Customer/Driver replies to RESOLVED/CLOSED MAY reopen to OPEN under the same durable rules used in the mature EV-CMS support model.

## 27.3 Messages

`support_messages` is append-only.

App-side projections expose author class (`CUSTOMER`, `DRIVER`, `SUPPORT`) rather than unnecessary staff identity.

Private internal notes are separate records and MUST NOT leak to User/Driver clients or outbound mail.

## 27.4 Reply idempotency

Replies require idempotency key and durable uniqueness.

Duplicate retry must not create duplicate message, event, or notification intent.

## 27.5 Incident model

`incidents`:

```text
id
service_job_id nullable
duty_session_id nullable
driver_id nullable
vehicle_id nullable
charger_id nullable
type
severity
status              # OPEN, INVESTIGATING, MITIGATED, RESOLVED, CLOSED
reported_by_actor_type
reported_by_actor_id
reported_at
summary
resolution nullable
resolved_at nullable
```

Examples:

- vehicle breakdown;
- charger fault;
- asset mismatch;
- safety event;
- customer dispute;
- driver emergency;
- HAL unrecoverable fault.

High-severity incidents may block asset/driver eligibility through explicit operational holds rather than silently modifying unrelated master records.

---

# 28. Notification Blueprint

## 28.1 Durable notification intent

Important notifications are produced through a durable outbox after the authoritative transaction commits.

Channels may include:

- in-app;
- push;
- email;
- SMS if later integrated.

## 28.2 Notification content rule

Do not copy sensitive freeform support message bodies, raw KYC, auth data, or raw protocol payloads into external notification payloads.

Use bounded metadata and deep links.

## 28.3 Preference model

Customer/Driver notification preferences may disable optional categories, but mandatory security/safety/legal messages remain governed by platform policy.

Preferences are scoped by notification category and channel.

## 28.4 Delivery states

```text
PENDING
CLAIMED
SENT
FAILED_RETRYABLE
FAILED_TERMINAL
CANCELLED
```

`SENT` means accepted by the configured provider, not necessarily read by the human unless the provider supplies a separate delivery/read fact.

---

# 29. Realtime Blueprint

## 29.1 Purpose

Realtime improves responsiveness. It does not replace durable HTTP state.

## 29.2 Subscription scope

A client may subscribe only to resources it is authorized to read.

Suggested channels/topics:

```text
user:{customer_id}
job:{service_job_id}
driver:{driver_id}
duty:{duty_session_id}
admin:operations
admin:hal
```

Server authorization derives IDs from auth context and resource permissions. Clients cannot subscribe to arbitrary user/driver topics by guessing IDs.

## 29.3 Event envelope

```json
{
  "event_id": "...",
  "type": "service_job.updated",
  "resource_type": "service_job",
  "resource_id": "...",
  "occurred_at": "...",
  "version": 17,
  "request_id": "...",
  "data": { }
}
```

For important state, `data` may be only a compact projection. REST remains recovery authority.

## 29.4 Ordering

Per-resource version or sequence is recommended so clients can detect missed/out-of-order events.

Clients receiving version 15 after version 17 ignore stale data.

A gap can trigger REST refresh.

## 29.5 User realtime

User may receive:

- request/quote expiry;
- dispatch progress;
- assignment;
- driver/mobile unit public projection;
- ETA/location updates;
- arrival;
- charging readiness;
- physical charging start;
- live energy/power/SoC where available;
- projected cost;
- charging end;
- wrap-up/completion;
- payment/invoice changes;
- support updates.

## 29.6 Driver realtime

Driver may receive:

- schedule changes;
- offer created/withdrawn/expired;
- assignment changes;
- job/customer service-location projection;
- admin correction of pairing;
- HAL readiness/fault state;
- charging state;
- compensation calculation completion;
- support/incident updates.

## 29.7 Admin realtime

Admin may receive broad operational invalidations/projections by capability:

- online drivers;
- duty sessions;
- locations;
- dispatch queues;
- jobs;
- asset mismatch;
- charger/HAL connectivity;
- faults;
- payment exceptions;
- invoice failures;
- support/incident queues.

Do not push secrets or full sensitive records over a generic operations stream.

# 30. Unified Admin Product Blueprint

Admin is one product with capability-gated surfaces, not separate products pretending to be different authorities.

## 30.1 Admin home / operational dashboard

Must be able to answer quickly:

- How many drivers are currently on duty/available/busy/unavailable?
- Which ServiceJobs are dispatching, assigned, en route, at customer, charging, wrapping up, or exceptioned?
- Which vehicles/chargers are available, claimed, in use, under maintenance, offline, or faulted?
- Which chargers/HAL connections are stale/offline/faulted?
- Which payments/refunds/invoices require attention?
- Which asset mismatches/incidents/support tickets require attention?

Dashboard metrics are derived projections, not independent truth tables.

## 30.2 Driver recruitment

Admin can:

- list/search/filter applications;
- inspect current application and versioned documents;
- move through explicit review actions;
- request changes with structured reason;
- approve/reject;
- complete onboarding;
- inspect audit history;
- suspend/offboard an operational driver separately from application history.

## 30.3 Fleet

Admin can:

- CRUD/deactivate vehicles and chargers with optimistic concurrency;
- manage connectors/capabilities metadata;
- manage maintenance intervals;
- manage effective-dated pairings;
- inspect active claims and duty use;
- inspect HAL projection and last seen;
- search/filter/sort inventory;
- resolve observed mismatch reports without rewriting duty history.

## 30.4 Schedules and assignments

Admin can:

- create one-off/recurring schedules;
- materialize occurrences;
- assign/suggest assets;
- cancel future occurrences;
- inspect planned vs actual start/end;
- inspect deviations;
- not overwrite started/completed history.

## 30.5 Dispatch operations

Admin can:

- view candidate/offer/assignment state;
- retry dispatch;
- directly assign an eligible driver;
- override with explicit reason only when policy allows;
- reassign active work;
- see why candidates are ineligible when diagnostic evidence exists;
- never bypass physical compatibility silently.

## 30.6 Job operations

Admin may perform explicit actions such as:

- cancel job;
- mark no-show with evidence/reason;
- reassign;
- record operational correction;
- close exception after charging/field-service facts reconcile.

No generic unrestricted status editor is permitted.

## 30.7 Technical/HAL operations

Technical Admin may:

- view charger connection state;
- view normalized capabilities;
- inspect operation state and exact operation ID;
- inspect normalized facts;
- inspect protected raw trace/evidence;
- request supported technical commands with explicit reason;
- reconcile uncertain state.

Technical actions still respect ServiceJob/charging safety boundaries.

## 30.8 Finance/commercial

Finance Admin may:

- manage versioned pricing policies;
- inspect quotes/final charges;
- inspect payments;
- issue permitted refunds;
- inspect/generate/retry invoices;
- inspect tax snapshots;
- manage compensation policies separately;
- create compensation adjustments with reason.

## 30.9 Support/incident

Support/Admin can view and act according to channel/capability.

Incident actions are structured and audited.

---

# 32. Public API Surface - Driver App

## 32.1 Authentication/profile

```text
POST  /api/v1/driver/auth/login
POST  /api/v1/driver/auth/refresh
POST  /api/v1/driver/auth/logout
GET   /api/v1/driver/me
PATCH /api/v1/driver/me
```

Recruitment may use a pre-active account flow or a dedicated application token/session. The implementation must keep recruitment access distinct from operational authorization.

## 32.2 Recruitment

```text
GET  /api/v1/driver/application
PUT  /api/v1/driver/application
POST /api/v1/driver/application/documents
POST /api/v1/driver/application/submit
GET  /api/v1/driver/application/reviews
```

A rejected/offboarded driver cannot access operational endpoints merely because login still succeeds.

## 32.3 Schedule

```text
GET /api/v1/driver/schedules
GET /api/v1/driver/schedules/{occurrence_id}
```

## 32.4 Duty and assets

```text
GET  /api/v1/driver/duty/current
POST /api/v1/driver/duty/start
POST /api/v1/driver/duty/current/breaks
POST /api/v1/driver/duty/current/breaks/{break_id}/end
POST /api/v1/driver/duty/current/end
GET  /api/v1/driver/duty/current/eligible-assets
POST /api/v1/driver/duty/current/asset-mismatch
```

Duty start is idempotent and concurrency-safe.

## 32.5 Location

```text
POST /api/v1/driver/location
POST /api/v1/driver/location/batch
```

Batch is recommended for mobile connectivity recovery. Samples are bounded, validated, and associated only with the authenticated driver/current duty session.

## 32.6 Offers and jobs

```text
GET  /api/v1/driver/offers
GET  /api/v1/driver/offers/{offer_id}
POST /api/v1/driver/offers/{offer_id}/accept
POST /api/v1/driver/offers/{offer_id}/reject
GET  /api/v1/driver/jobs/current
GET  /api/v1/driver/jobs
GET  /api/v1/driver/jobs/{job_id}
POST /api/v1/driver/jobs/{job_id}/en-route
POST /api/v1/driver/jobs/{job_id}/arrive
POST /api/v1/driver/jobs/{job_id}/prepare
POST /api/v1/driver/jobs/{job_id}/report-problem
```

## 32.7 Charging controls

```text
POST /api/v1/driver/jobs/{job_id}/charging/start
POST /api/v1/driver/jobs/{job_id}/charging/stop
GET  /api/v1/driver/jobs/{job_id}/charging
```

Start/stop endpoints create intents. Their synchronous response MUST describe intent/command state truthfully, not fabricate physical start/end.

## 32.8 Wrap-up

```text
POST /api/v1/driver/jobs/{job_id}/wrap-up
POST /api/v1/driver/jobs/{job_id}/complete
```

`complete` is permitted only after all completion invariants pass.

## 32.9 Earnings

```text
GET /api/v1/driver/earnings/summary
GET /api/v1/driver/earnings/jobs
GET /api/v1/driver/earnings/jobs/{job_id}
GET /api/v1/driver/earnings/daily
```

Filters cover custom date ranges with bounded limits.

## 32.10 Driver support

```text
GET  /api/v1/driver/support/tickets
POST /api/v1/driver/support/tickets
GET  /api/v1/driver/support/tickets/{ticket_id}
POST /api/v1/driver/support/tickets/{ticket_id}/replies
```

---

# 33. Public API Surface - Admin

## 33.1 Admin auth and self

```text
POST /api/v1/admin/auth/login
POST /api/v1/admin/auth/refresh
POST /api/v1/admin/auth/logout
GET  /api/v1/admin/me
GET  /api/v1/admin/me/capabilities
```

## 33.2 Customers

```text
GET /api/v1/admin/customers
GET /api/v1/admin/customers/{customer_id}
GET /api/v1/admin/customers/{customer_id}/jobs
```

Sensitive account/security data remains in dedicated authorized endpoints if ever needed.

## 33.3 Driver applications and drivers

```text
GET  /api/v1/admin/driver-applications
GET  /api/v1/admin/driver-applications/{application_id}
POST /api/v1/admin/driver-applications/{application_id}/start-review
POST /api/v1/admin/driver-applications/{application_id}/request-action
POST /api/v1/admin/driver-applications/{application_id}/approve
POST /api/v1/admin/driver-applications/{application_id}/reject
POST /api/v1/admin/driver-applications/{application_id}/complete-onboarding
GET  /api/v1/admin/drivers
GET  /api/v1/admin/drivers/{driver_id}
POST /api/v1/admin/drivers/{driver_id}/suspend
POST /api/v1/admin/drivers/{driver_id}/reinstate
POST /api/v1/admin/drivers/{driver_id}/offboard
```

## 33.4 Vehicles

```text
GET   /api/v1/admin/vehicles
POST  /api/v1/admin/vehicles
GET   /api/v1/admin/vehicles/{vehicle_id}
PATCH /api/v1/admin/vehicles/{vehicle_id}
POST  /api/v1/admin/vehicles/{vehicle_id}/deactivate
POST  /api/v1/admin/vehicles/{vehicle_id}/reactivate
GET   /api/v1/admin/vehicles/{vehicle_id}/history
GET   /api/v1/admin/vehicles/{vehicle_id}/availability
```

## 33.5 Chargers/connectors

```text
GET   /api/v1/admin/chargers
POST  /api/v1/admin/chargers
GET   /api/v1/admin/chargers/{charger_id}
PATCH /api/v1/admin/chargers/{charger_id}
POST  /api/v1/admin/chargers/{charger_id}/deactivate
POST  /api/v1/admin/chargers/{charger_id}/reactivate
GET   /api/v1/admin/chargers/{charger_id}/history
GET   /api/v1/admin/chargers/{charger_id}/runtime
GET   /api/v1/admin/chargers/{charger_id}/capabilities
GET   /api/v1/admin/chargers/{charger_id}/connectors
POST  /api/v1/admin/chargers/{charger_id}/connectors
PATCH /api/v1/admin/chargers/{charger_id}/connectors/{connector_id}
```

## 33.6 Pairings/maintenance

```text
GET  /api/v1/admin/pairings
POST /api/v1/admin/pairings
POST /api/v1/admin/pairings/{pairing_id}/end
GET  /api/v1/admin/asset-mismatches
GET  /api/v1/admin/asset-mismatches/{mismatch_id}
POST /api/v1/admin/asset-mismatches/{mismatch_id}/resolve
POST /api/v1/admin/vehicles/{vehicle_id}/maintenance
POST /api/v1/admin/chargers/{charger_id}/maintenance
```

## 33.7 Schedules/duty

```text
GET   /api/v1/admin/schedules
POST  /api/v1/admin/schedules
GET   /api/v1/admin/schedules/{schedule_id}
PATCH /api/v1/admin/schedules/{schedule_id}
POST  /api/v1/admin/schedules/{schedule_id}/cancel
GET   /api/v1/admin/duty-sessions
GET   /api/v1/admin/duty-sessions/{duty_session_id}
POST  /api/v1/admin/duty-sessions/{duty_session_id}/hold
POST  /api/v1/admin/duty-sessions/{duty_session_id}/release-hold
```

Started historical occurrences are not destructively edited.

## 33.8 Dispatch/jobs

```text
GET  /api/v1/admin/jobs
GET  /api/v1/admin/jobs/{job_id}
GET  /api/v1/admin/jobs/{job_id}/timeline
GET  /api/v1/admin/jobs/{job_id}/dispatch
POST /api/v1/admin/jobs/{job_id}/dispatch/retry
POST /api/v1/admin/jobs/{job_id}/assign
POST /api/v1/admin/jobs/{job_id}/reassign
POST /api/v1/admin/jobs/{job_id}/cancel
POST /api/v1/admin/jobs/{job_id}/mark-no-show
POST /api/v1/admin/jobs/{job_id}/record-correction
```

## 33.9 Charging/HAL

```text
GET  /api/v1/admin/jobs/{job_id}/charging
GET  /api/v1/admin/charging-sessions
GET  /api/v1/admin/charging-sessions/{session_id}
GET  /api/v1/admin/hal/operations
GET  /api/v1/admin/hal/operations/{cms_operation_id}
GET  /api/v1/admin/hal/facts
GET  /api/v1/admin/hal/traces
POST /api/v1/admin/chargers/{charger_id}/commands/reset
POST /api/v1/admin/chargers/{charger_id}/commands/unlock
POST /api/v1/admin/chargers/{charger_id}/commands/change-availability
POST /api/v1/admin/hal/operations/{cms_operation_id}/reconcile
```

Admin command endpoints require technical capability, reason, and safety validation.

## 33.10 Pricing/payments/invoices

```text
GET   /api/v1/admin/pricing/policies
POST  /api/v1/admin/pricing/policies
GET   /api/v1/admin/pricing/policies/{policy_id}
PATCH /api/v1/admin/pricing/policies/{policy_id}
POST  /api/v1/admin/pricing/policies/{policy_id}/activate
POST  /api/v1/admin/pricing/policies/{policy_id}/retire

GET  /api/v1/admin/payments
GET  /api/v1/admin/payments/{payment_id}
GET  /api/v1/admin/refunds
POST /api/v1/admin/payments/{payment_id}/refunds

GET  /api/v1/admin/invoices
GET  /api/v1/admin/invoices/{invoice_id}
POST /api/v1/admin/invoices/{invoice_id}/retry-generation
GET  /api/v1/admin/invoices/{invoice_id}/download
```

## 33.11 Compensation

```text
GET   /api/v1/admin/compensation/policies
POST  /api/v1/admin/compensation/policies
GET   /api/v1/admin/compensation/policies/{policy_id}
PATCH /api/v1/admin/compensation/policies/{policy_id}
POST  /api/v1/admin/compensation/policies/{policy_id}/activate
POST  /api/v1/admin/compensation/policies/{policy_id}/retire
GET   /api/v1/admin/compensation/jobs
GET   /api/v1/admin/compensation/jobs/{job_id}
POST  /api/v1/admin/compensation/jobs/{job_id}/adjustments
GET   /api/v1/admin/compensation/drivers/{driver_id}/summary
```

## 33.12 Ratings/support/incidents/audit

```text
GET  /api/v1/admin/ratings
GET  /api/v1/admin/support/tickets
GET  /api/v1/admin/support/tickets/{ticket_id}
POST /api/v1/admin/support/tickets/{ticket_id}/replies
PATCH /api/v1/admin/support/tickets/{ticket_id}/status
GET  /api/v1/admin/incidents
GET  /api/v1/admin/incidents/{incident_id}
POST /api/v1/admin/incidents/{incident_id}/actions
GET  /api/v1/admin/audit
```

---

# 34. API Consumer Contracts and Projection Rules

## 34.1 User projection

User job projection may expose:

- job number/status;
- service location snapshot;
- own vehicle snapshot;
- public driver identity subset after assignment;
- public service vehicle identity subset;
- ETA/location only while operationally relevant;
- charging metrics;
- pricing/payment/invoice state;
- own support/rating.

It MUST NOT expose:

- driver KYC;
- driver phone/email unless explicitly required by product policy;
- Admin identities;
- internal dispatch scores;
- raw HAL traces;
- internal incident notes;
- internal compensation.

## 34.2 Driver projection

Driver may see only data necessary for current/own work:

- assigned customer display/contact information required for service;
- exact service location/instructions;
- customer vehicle snapshot;
- charging preference;
- job/payment information only to the extent operationally required;
- own compensation.

Driver MUST NOT see full customer account/security history.

## 34.3 Admin projection

Admin receives data by capability and need, not one giant universal object.

High-sensitivity KYC, payment, raw trace, and audit data should have separately authorized endpoints/fields.

---

# 35. Idempotency Matrix

At minimum, these operations require durable idempotency or stable operation identity:

| Operation | Mechanism |
| --- | --- |
| Quote acceptance / ServiceJob creation | `Idempotency-Key` |
| Driver duty start | `Idempotency-Key` + unique active-duty constraint |
| Driver offer accept | offer identity + transactional winner |
| Driver job transition actions | action idempotency / current-state same-result semantics |
| Charging start | `Idempotency-Key` -> `ChargingStartIntent` -> immutable `cms_command_id` -> one HAL start command |
| Charging stop | `Idempotency-Key` -> `ChargingStopRequest` -> immutable `cms_command_id` -> one HAL stop command; completion still requires physical completion evidence |
| Payment order creation | `Idempotency-Key` + provider order identity |
| Payment verification/webhook | provider event/payment identity |
| Refund | `Idempotency-Key` + provider refund identity |
| Invoice generation intent | unique invoice/job/version key |
| Support reply | `Idempotency-Key` |
| Notification/outbox delivery | outbox row/event identity |
| HAL fact ingest | immutable `fact_id` |
| HAL start/stop command | immutable `cms_command_id` plus durable `hal_command_id`; retry/reconcile same identity |
| Generic administrative HAL operation | immutable `cms_operation_id` plus durable HAL operation identity; no automatic replay after possible delivery |
| Promotion of temp vehicle/address | `Idempotency-Key` / unique promotion record |
| Compensation finalization | unique job/assignment calculation version |
| Compensation adjustment | `Idempotency-Key` |

Idempotency records MUST have a retention policy long enough to cover realistic mobile retry behavior and external provider retries.

---

# 36. Concurrency and Transaction Boundaries

## 36.1 Database as concurrency authority

Use PostgreSQL constraints/locking for invariants that must survive multiple API instances.

Do not rely on process mutexes for cross-instance business invariants.

## 36.2 Required protected races

Must explicitly handle:

- two duty starts for same driver;
- two drivers claiming same vehicle;
- two drivers claiming same charger;
- two offer acceptances;
- driver accepts offer while Admin reassigns/cancels;
- customer cancels while driver accepts;
- charging start retried during unknown HAL delivery;
- duplicate HAL transaction/fact;
- simultaneous payment callback + webhook;
- simultaneous rating PUT;
- simultaneous policy activation;
- invoice worker duplicate claim;
- compensation worker duplicate finalization.

## 36.3 Row locking

Use `SELECT ... FOR UPDATE` or equivalent narrowly around mutable aggregate roots where transition serialization is required.

Avoid holding DB transactions open across slow external network calls.

Correct pattern:

1. transactionally create durable intent/claim;
2. commit;
3. perform external I/O;
4. transactionally record outcome;
5. reconcile uncertainty asynchronously if needed.

## 36.4 Outbox atomicity

Any external side effect that must correspond to a committed business mutation is enqueued in the same DB transaction as that mutation.

No pattern of "commit DB, then maybe remember to send notification" is allowed for critical side effects.

---

# 39. Failure Classification and Recovery

Failures MUST be classified so retries do not make reality worse.

## 39.1 Classes

```text
VALIDATION
AUTHORIZATION
CONFLICT
TRANSIENT_INTERNAL
TRANSIENT_EXTERNAL
TERMINAL_EXTERNAL
OUTCOME_UNKNOWN
INTEGRITY_VIOLATION
```

## 39.2 Retry policy

- Validation/auth/conflict: caller must change state/input; no blind server retry.
- Transient internal: bounded automatic retry if operation is safe/idempotent.
- Transient external before known delivery: bounded retry.
- Outcome unknown after possible physical/payment side effect: reconcile by stable identity before retry.
- Integrity violation: stop, alert, preserve evidence.

## 39.3 Stop conditions

Workers MUST stop automatic retries and surface operational attention when:

- semantic conflict appears;
- same identity maps to conflicting payload;
- repeated failures exceed policy;
- physical command outcome remains unknown beyond reconciliation horizon;
- provider/charger reports impossible transition;
- database constraint indicates an unexpected invariant breach.

---

# 40. Security and Privacy Blueprint

## 40.1 Authentication secrets

Passwords, OTPs, refresh tokens, service credentials, Razorpay secrets, webhook secrets, and private keys MUST never be logged.

Store password hashes with a modern password hashing algorithm if passwords are used.

OTP codes are short-lived, rate-limited, and stored only in protected/hashed form where possible.

## 40.2 PII

Sensitive fields include:

- phone/email;
- addresses/location history;
- KYC documents/numbers;
- driving licence;
- bank information if stored;
- exact driver/customer traces;
- support free text;
- invoice/customer tax info.

APIs return the minimum projection required for that actor.

## 40.3 KYC document storage

- private object/file storage;
- random opaque object identifiers;
- MIME/type and size validation;
- malware scanning if infrastructure supports it;
- authorization on every fetch;
- short-lived signed URLs if used;
- audit reads for highly sensitive documents where practical.

## 40.4 Input safety

All user-generated free text is untrusted.

Frontend must escape reviews/support/notes.

Backend must use parameterized SQL and never interpolate user strings into queries.

## 40.5 Rate limiting

At minimum rate-limit:

- login/OTP/recovery;
- registration;
- quote creation abuse;
- support spam;
- location ingestion by device;
- provider callback endpoints according to provider expectations;
- HAL internal ingress by authenticated service/size limits.

## 40.6 Authorization test requirement

Every protected route family requires tests for:

- unauthenticated rejection;
- wrong principal type;
- wrong owner/resource;
- missing capability;
- positive allowed path.

---

# 41. Audit Blueprint

Audit is separate from ordinary application logs.

Audit records are durable and queryable for security/administrative actions.

Minimum fields:

```text
id
actor_type
actor_id nullable
action
target_type
target_id nullable
occurred_at
request_id
reason nullable
before_summary jsonb nullable
after_summary jsonb nullable
metadata jsonb
```

Audit at minimum:

- driver KYC review decision;
- driver suspension/reinstatement/offboarding;
- schedule/admin assignment edits;
- vehicle/charger changes;
- pairings/mismatch resolution;
- maintenance state changes;
- pricing policy activation/retirement;
- compensation policy activation/retirement;
- manual compensation adjustment;
- admin job cancel/reassign/override;
- technical charger commands;
- refund issuance;
- invoice manual retry/void if supported;
- incident resolution;
- permission/role changes;
- system setting changes.

Audit entries must not contain secret values.

---

# 42. Observability Blueprint

## 42.1 Structured logs

All services log structured fields such as:

```text
timestamp
level
service
environment
request_id
trace_id where available
actor_type safe
actor_id safe when appropriate
cms_command_id/cms_operation_id/hal_command_id/hal_transaction_id/fact_id/job_id where relevant
event
error_code
```

No raw request/response bodies by default.

## 42.2 Metrics

CMS metrics should include:

- HTTP rate/latency/error by route template;
- DB pool saturation/latency;
- active duties by status;
- jobs by status and oldest age;
- dispatch attempt success/time-to-assignment;
- offer accept/reject/expire rate;
- stale driver locations;
- payments pending/failed/reconciliation age;
- invoice queue depth/failure;
- notification queue depth/failure;
- compensation backlog/failure;
- support/incident queue age;
- realtime connections/publish failures.

HAL metrics should include:

- connected chargers;
- connection churn;
- stale chargers;
- operations by state;
- oldest queued operation;
- unknown outcomes;
- fact outbox backlog/oldest age;
- reconnect reconciliations;
- protocol errors;
- meter sample rate/drop/invalid counts.

## 42.3 Health and readiness

Each service exposes:

```text
/health/live
/health/ready
```

Liveness means process is alive.

Readiness checks dependencies required to safely accept traffic, without making fragile third-party APIs mandatory if requests can queue/reconcile safely.

## 42.4 Alerts

Alert on actionable conditions, including:

- service down/restart loop;
- DB unavailable;
- worker oldest age exceeds threshold;
- dispatch backlog/assignment time breach;
- payment reconciliation backlog;
- HAL fact backlog;
- charger unknown command outcomes;
- unusually high charger disconnect rate;
- invoice generation repeated failure;
- storage nearing capacity;
- migration/runtime mismatch.

---

# 43. Data Retention, Privacy, and Archival

Retention MUST be explicit per data class rather than "keep everything forever" by accident.

Suggested categories:

- legal/financial invoices/payments/refunds: long-term according to accounting/legal obligations;
- ServiceJob commercial history: long-term;
- compensation ledger: long-term business record;
- audit: long-term security/business record;
- raw driver GPS samples: bounded operational retention, with aggregates/history kept as needed;
- raw HAL protocol traces: bounded technical retention, longer around incidents;
- idempotency keys: bounded but long enough for retries;
- notification delivery attempts: bounded after terminal state;
- expired sessions/tokens: security retention as needed;
- KYC: lifecycle/legal retention policy with deletion/anonymization process.

A future privacy deletion/anonymization workflow must preserve legal/financial integrity while removing or pseudonymizing data that is no longer required.

---

# 48. End-to-End Driver Flow

```text
Driver applies
-> submits required KYC/documents
-> Admin reviews
-> action required or approved
-> onboarding
-> DriverProfile ACTIVE
-> driver logs in
-> sees schedule/eligibility
-> starts duty
-> backend validates eligibility + actual assets + exclusive claims
-> duty becomes AVAILABLE
-> driver sends location
-> dispatch offer received
-> driver accepts
-> duty/job becomes ASSIGNED
-> en route
-> arrival
-> service preparation
-> start charging intent
-> observe physical charging status
-> handle stop/fault/recovery
-> wrap-up
-> complete job
-> duty returns AVAILABLE if still valid
-> compensation calculated from authoritative facts
-> driver sees explainable line items and aggregates
-> driver ends duty after no active blocking job
```

Driver UI must make uncertain technical states explicit. After tapping Start, show start-progress state until the CMS reports `ACTUALLY_STARTED` with a materialized `session_id`. `ACCEPTED_FOR_DELIVERY` or `PROTOCOL_ACKNOWLEDGED` is still "waiting for charger"; `RECONCILIATION_REQUIRED` is "confirming charger state" and MUST NOT trigger another start.

---

# 49. End-to-End Admin Flow

Admin product combines multiple operational personas without losing capability boundaries.

Example live operations flow:

```text
Admin opens operations dashboard
-> sees dispatching job with no eligible candidate
-> inspects diagnostics
-> sees closest driver excluded because charger lacks connector
-> sees second driver location stale
-> third driver eligible but on break
-> Admin may contact/resolve actual operation
-> can release hold/end break only with proper authority/real-world confirmation
-> retry dispatch
-> assignment occurs
-> later charger faults
-> technical Admin sees HAL fact/trace
-> operations Admin reassigns if recovery cannot continue
-> original assignment preserved
-> customer job remains one ServiceJob
-> finance later sees final charge and refund/adjustment if needed
-> compensation reflects each driver's actual eligible work
```

This is why all actor views must compose the same durable domain truth rather than maintain separate contradictory copies.

# 50. Completion Invariants

A ServiceJob may transition to `COMPLETED` only when all applicable invariants are true.

Minimum invariants:

1. Job is in `WRAP_UP`.
2. No active physical charging transaction remains for the job.
3. No `ChargingStartIntent`, `ChargingStopRequest`, or physical-delivery command remains unresolved without an explicit reconciliation disposition. A start in `RECONCILIATION_REQUIRED` blocks replacement start on the same job/asset until exact evidence resolves it; an unresolved stop never allows CMS to claim physical completion. Generic administrative charger-operation ambiguity is tracked separately and blocks job completion only when that specific operation is defined as a safety prerequisite.
4. Final charging metrics have been frozen or explicitly marked unavailable with reason.
5. Final pricing has been calculated or a deliberate zero/exception commercial disposition exists.
6. The current assignment has a closeout disposition.
7. Required driver closeout fields are present.
8. Any mandatory incident/blocking exception is resolved or explicitly transferred to post-service handling.
9. Job history/event write succeeds in the same transaction.

Payment capture and invoice readiness SHOULD NOT be required to mark physical field service complete unless the business explicitly chooses a pre-completion collection rule. Their state remains visible independently.

Driver compensation MAY be calculated asynchronously after completion but must be derived from frozen source facts and eventually converge.

---

# 51. Cancellation, No-Show, and Failure Matrix

Cancellation semantics depend on actor and lifecycle state.

## 51.1 Customer cancellation

Customer MAY cancel when policy permits.

At minimum, cancellation should be possible before physical charging begins. After physical charging begins, use stop + wrap-up/commercial finalization rather than pretending the service never happened.

Recommended state handling:

```text
DISPATCHING -> CANCELLED
ASSIGNED -> CANCELLED
ACCEPTED -> CANCELLED
EN_ROUTE -> CANCELLED
ARRIVED -> CANCELLED or NO_SHOW depending facts
SERVICE_PREPARING -> CANCELLED if no physical charge started
CHARGING -> not direct CANCELLED; stop charging, finalize delivered service, then terminal disposition
```

Cancellation fee is pricing-policy driven.

## 51.2 Driver cancellation/unavailability

Driver cannot simply mark the customer job cancelled.

A driver unable to continue reports an operational reason. Backend/Admin decides:

- reassign job;
- fail job;
- cancel due platform/driver cause;
- create incident.

The assignment ends with reason; the ServiceJob remains independent.

## 51.3 Customer no-show

A no-show requires arrival/attempt evidence and policy-defined waiting threshold or Admin override.

Do not let Driver immediately mark NO_SHOW without server-side timing/location checks where available.

## 51.4 Driver no-show

If an assigned driver fails to progress/arrive:

- system/admin may mark assignment failed;
- job enters `REASSIGNING`;
- incident/driver performance evidence may be recorded;
- customer is not blamed commercially.

## 51.5 Failure taxonomy

`FAILED` job requires a reason code such as:

```text
NO_COMPATIBLE_DRIVER
VEHICLE_BREAKDOWN
CHARGER_FAULT
HAL_UNAVAILABLE
UNSAFE_SERVICE_CONDITIONS
CUSTOMER_VEHICLE_INCOMPATIBLE
LOCATION_INACCESSIBLE
PAYMENT_POLICY_BLOCK
PLATFORM_TECHNICAL_FAILURE
OTHER_ADMIN_RESOLVED_FAILURE
```

A human-readable note may supplement but never replace structured reason.

---

# 52. Asset Mismatch and Reconciliation Flow

## 52.1 Report

When actual assets differ from intended records:

1. Driver selects expected asset context.
2. Driver reports observed vehicle/charger.
3. Backend records mismatch with timestamps and evidence.
4. Backend decides whether safe temporary operation is permitted.
5. DutySession stores actual operational snapshot.
6. Admin queue receives mismatch.

## 52.2 Temporary operation decision

Temporary operation can continue only if all mandatory safety/technical identity facts are available.

For a charger, this means at minimum:

- stable physical/HAL identity known;
- required connector/capability known;
- current HAL state acceptable;
- no conflicting claim/use;
- policy allows observed mismatch operation.

Unknown/unmanaged charger identity blocks charging dispatch.

## 52.3 Admin resolution

Resolution actions:

```text
CONFIRM_MASTER_DATA_CORRECTION
RESTORE_EXPECTED_CONFIGURATION
CREATE_NEW_ASSET_AND_PAIR
REASSIGN_ASSET
REJECT_REPORT
CLOSE_NO_CHANGE
```

Resolution updates master data only through normal audited operations.

It never rewrites the old DutySession snapshot.

---

# 53. Mobile Unit Energy/Capacity Model (see canonical activation gate)

The planning baseline recognizes that a mobile charging unit may itself have an energy/capacity constraint.

This is a first-class extension point rather than an ignored TODO.

If Charger-on-Wheels hardware uses onboard battery/energy storage, add:

```text
mobile_energy_stores
energy_store_observations
energy_store_reservations
energy_store_capability_snapshots
```

Dispatch eligibility then requires sufficient deliverable reserve for the requested job plus configured safety reserve.

The authoritative input may come from vehicle telemetry, BMS integration, HAL/vendor telemetry, or validated manual state depending hardware.

Until such hardware facts are integrated, the system MUST NOT fabricate energy reserve. The dispatch policy can mark this criterion `NOT_MODELED` and rely on operational policy, but the limitation must be explicit in Admin.

---

# 54. Derived Projections and Rebuildability

Derived projections improve read performance but cannot become hidden sources of truth.

Candidate projections:

- current driver location;
- driver current duty summary;
- current job live projection;
- charger runtime projection;
- admin operations dashboard counters;
- driver earnings summaries;
- customer rating aggregates.

For each projection, document:

- source tables/events;
- update trigger/worker;
- staleness semantics;
- rebuild/reconciliation method;
- what happens if projection update fails.

A failed projection update must not roll back already committed physical/commercial truth unless the projection itself is part of the transaction intentionally.

---

# 55. Search, Filtering, and Operational Query Rules

Operational list APIs MUST be useful to real admins, not only technically paginated.

## 55.1 Drivers

Filter/sort by:

- recruitment status;
- operational status;
- eligibility;
- on-duty/off-duty;
- schedule window;
- active job;
- base zone;
- document expiry/block reason;
- name/phone/email search with privacy controls.

## 55.2 Fleet

Filter/sort by:

- active/retired;
- maintenance;
- availability derived state;
- vehicle/charger pairing;
- current driver/duty;
- connector type;
- power;
- protocol;
- HAL online/staleness;
- last activity.

## 55.3 Jobs

Filter/sort by:

- status;
- created/requested time;
- scheduled/immediate;
- customer;
- driver;
- vehicle;
- charger;
- payment state;
- invoice state;
- incident/support association;
- exception state;
- zone;
- age in current state.

## 55.4 Finance/compensation

Filter by date ranges using explicit timezone semantics and bounded exports.

Large exports should be asynchronous durable export jobs, not unbounded API responses.

---

# 56. Operational Exports

Admin may require CSV/structured exports for finance, driver compensation, jobs, and assets.

Exports SHOULD be modeled as asynchronous jobs for nontrivial ranges:

```text
export_jobs
  id
  type
  requested_by
  filters jsonb
  status
  storage_ref nullable
  checksum nullable
  created_at
  completed_at nullable
  expires_at
```

Export artifacts are private and time-bounded.

Export data must use the same authoritative queries/definitions as UI summaries to prevent inconsistent numbers.

---

# 57. Testing Strategy

Testing is layered by the kind of claim being made.

## 57.1 Unit tests

Mandatory areas:

- every state transition table;
- customer pricing rule evaluation;
- compensation rule evaluation;
- time-window/interval prorating;
- dispatch eligibility;
- dispatch ranking deterministic tie-break;
- geofence intersection;
- snapshot construction;
- authorization decisions;
- cancellation/no-show rules;
- HAL adapter normalization;
- payment/refund state transitions;
- invoice calculation inputs;
- privacy projection shaping.

## 57.2 PostgreSQL integration tests

Run against explicit disposable PostgreSQL.

Must test:

- migrations from empty DB;
- up/down where down is safe;
- uniqueness/exclusion constraints;
- active DutySession uniqueness;
- asset claim race;
- offer acceptance race;
- idempotency duplicate/conflict;
- outbox atomicity;
- duplicate HAL fact ingest;
- transaction rollback;
- version/optimistic concurrency;
- historical FK behavior;
- policy version immutability.

## 57.3 Service integration

CMS-HAL:

- mapping create/update and post-commit reconfirmation;
- start command durable acceptance without session materialization;
- protocol acknowledgement without session materialization;
- authoritative `transaction.started` materializes exactly one session;
- command explicit rejection;
- HTTP timeout before HAL durable acceptance;
- HTTP timeout after HAL persisted/possibly delivered command;
- exact `cms_command_id` reconciliation and confirmed absence;
- exact `cms_start_intent_id` transaction reconciliation;
- late start fact after rejected/expired intent;
- duplicate identical fact is success/no-op;
- same fact ID with changed digest is integrity conflict;
- out-of-order connection/connector/meter/SoC sequence cannot regress projection;
- stop acknowledgement does not complete session;
- spontaneous charger-originated completion is accepted when identity chain validates;
- missing completion fact recovered by exact `hal_transaction_id` and same finalizer;
- reconnect/restart during active transaction;
- CMS outage while HAL fact outbox accumulates;
- HAL outage while CMS preserves durable intent/session truth;
- generic admin charger operation uses pre-I/O delivery fence and no-replay exact-ID recovery;
- slow generic operation recovery cannot delay charging deadline/automatic-stop worker;
- multiple physical sessions under one ServiceJob.

Payments:

- order retry;
- callback success + webhook duplicate;
- webhook before client verify;
- provider timeout;
- captured payment with lost API response;
- refund timeout/reconciliation.

## 57.4 End-to-end simulator tests

At minimum script these flows:

### E2E-01 happy path saved data

Saved EV + saved address -> quote -> dispatch -> charge -> payment -> invoice -> compensation -> rating.

### E2E-02 temporary customer data

Temporary EV/address -> completed job -> history retains snapshots -> promote both -> old history unchanged.

### E2E-03 scheduled driver

Admin schedule + assigned assets -> driver starts occurrence -> job -> planned vs actual times preserved.

### E2E-04 unscheduled driver

Driver self-starts duty under permitted policy -> selects eligible assets -> receives job.

### E2E-05 pairing mismatch

Admin expects C1, driver observes C2 -> report -> allowed temporary operation -> job uses C2 snapshot -> Admin reconciles later -> old duty remains C2.

### E2E-06 no compatible charger

Nearby drivers exist but connector/capability incompatible -> no invalid offer -> Admin diagnostic explains exclusion.

### E2E-07 start response lost after possible physical success

CMS creates one ChargingStartIntent/command -> HAL durably persists and sends start -> response is lost -> CMS enters `RECONCILIATION_REQUIRED` without a replacement command -> exact command/transaction lookup or immutable `transaction.started` fact proves the same attempt -> exactly one ChargingSession materializes.

### E2E-08 charger fault and restart

Transaction S1 ends unexpectedly -> same ServiceJob remains active -> recovery -> S2 starts -> final billing aggregates eligible facts.

### E2E-09 driver reassignment

D1 en route then breaks down -> assignment closes -> D2 assigned -> one ServiceJob -> compensation split by authoritative intervals.

### E2E-10 customer cancel after dispatch

Cancellation policy line item applied, assignment closed, no charging started, no fake energy/invoice facts.

### E2E-11 customer no-show

Arrival evidence + waiting threshold -> no-show -> policy charge -> compensation rule as configured.

### E2E-12 policy changes mid-job

Pricing and compensation policy edited/activated after job started -> job uses frozen versions defined by snapshot boundary.

### E2E-13 time boundary compensation

Driver work crosses night-rate boundary -> interval-prorated line items match exact minutes/distance basis.

### E2E-14 payment duplicate/recovery

Captured payment, lost response, duplicate webhook -> one captured logical payment.

### E2E-15 realtime disconnect

User/Driver/Admin lose realtime -> reconnect -> REST current state is correct -> subsequent versioned events converge.

## 57.5 Physical hardware acceptance

Before production readiness for a charger model/protocol:

- connect/disconnect;
- remote start/stop;
- transaction IDs;
- meter values;
- SoC if claimed;
- faults;
- reconnect during transaction;
- network loss;
- charger reboot;
- uncertain command outcome;
- connector mapping;
- max power/capability reporting;
- repeated sessions;
- time synchronization behavior;
- vendor deviations.

Simulator acceptance is not physical hardware acceptance.

---

# 58. Verification Gates for Every Work Item

Every meaningful burner/work item has four separate gates.

## Gate A: semantic/design

- scope and non-goals explicit;
- domain owner clear;
- state transition defined;
- persistence/constraints defined;
- authorization defined;
- idempotency defined;
- failure/recovery defined;
- history/realtime/audit impact defined.

## Gate B: source

- formatting/lint;
- focused tests;
- broad unit/integration tests;
- OpenAPI/runtime parity;
- documentation verifier;
- migration checks;
- `git diff --check`;
- no unrelated changes.

## Gate C: integration/runtime

- migrations applied to target environment intentionally;
- service healthy/readiness;
- changed routes behave under auth boundaries;
- workers healthy;
- logs clean of new panics/fatals;
- external integration tested or explicitly marked unverified.

## Gate D: physical/external acceptance where relevant

- real Razorpay provider behavior;
- real email/push provider acceptance;
- real HAL-to-charger behavior;
- real hardware acceptance.

A feature can be source-complete but not physically accepted. The completion statement must say which gate was reached.

---

# 62. Project Documentation Set

The repository should maintain at minimum:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/DEVELOPMENT_PLAN.md
docs/AI_CHANGELOG.md

docs/architecture/SYSTEM_ARCHITECTURE.md
docs/architecture/DOMAIN_MODEL.md
docs/architecture/STATE_MACHINES.md
docs/architecture/CMS_HAL_BOUNDARY.md
docs/architecture/CHARGING_TRUTH_MODEL.md

docs/contracts/openapi/openapi.yaml
docs/contracts/api/user-app.md
docs/contracts/api/driver-app.md
docs/contracts/api/admin.md
docs/contracts/api/internal-hal.md
docs/contracts/hal/CMS_HAL_CHARGING_V1.md
docs/contracts/realtime/events.md
docs/contracts/configuration.md

docs/handoffs/USER_APP_FE_HANDOFF.md
docs/handoffs/DRIVER_APP_FE_HANDOFF.md
docs/handoffs/ADMIN_FE_HANDOFF.md

docs/guides/operations/dev-hosting.md
docs/guides/operations/deployment.md
docs/guides/operations/rollback-recovery.md
docs/guides/operations/charger-onboarding.md
docs/guides/operations/incident-response.md

docs/work/active/
docs/work/archive/
```

HAL repository has its own equivalent architecture, adapter, operation-state, simulator, and hosting docs.

---

# 64. Exact Implementation Program

The implementation sequence below converts architecture into buildable burners. It intentionally front-loads contracts and stable primitives that later domains depend on.

## Program 0 - Repository and engineering authority

### B00.1 CMS repository bootstrap

Deliver:

- Go module/repo structure;
- config loader;
- structured logging;
- graceful shutdown;
- health/readiness;
- PostgreSQL connection;
- migration command;
- request IDs;
- base error contract;
- OpenAPI serving/Swagger;
- CI baseline;
- AGENTS/project docs.

Exit gate: clean empty service deploys to dev, migration 1 applies, OpenAPI/runtime route test passes.

### B00.2 HAL repository bootstrap

Deliver same platform foundations separately, plus protocol adapter interfaces and simulator skeleton.

Exit gate: HAL dev service runs independently, simulator adapter can connect logically, CMS-HAL auth contract stub works.

### B00.3 Disposable integration DB harness

Deliver isolated PostgreSQL test database orchestration for CMS and HAL.

Exit gate: concurrency/migration tests can run without touching shared dev DB.

---

## Program 1 - Identity, auth, capabilities, audit, idempotency, outbox

### B01.1 Account/session authentication

Customer/Driver/Admin principal separation, session revocation/refresh, security tests.

### B01.2 Admin capability engine

Capability catalog, role bundles, effective authorization, explicit endpoint middleware.

### B01.3 Audit foundation

Append-only audit API/service and Admin query.

### B01.4 Durable idempotency primitive

Reusable idempotency storage/response binding for HTTP mutations.

### B01.5 Durable outbox and worker framework

Claim/lease/retry/backoff/metrics with one harmless test event.

Exit gate: later domains use these primitives instead of inventing local variants.

---

## Program 2 - Customer master data

### B02.1 Customer profile
### B02.2 Saved vehicles
### B02.3 Saved addresses/default handling
### B02.4 Snapshot schemas/builders
### B02.5 Temporary object and promotion behavior

Exit gate: API can create saved/temporary data, snapshot it, edit master data, and prove historical snapshot immutability.

---

## Program 3 - Driver recruitment and workforce

### B03.1 Driver application lifecycle
### B03.2 Secure document storage + versioned KYC review
### B03.3 Driver profile creation/onboarding
### B03.4 Eligibility engine + blocking reasons
### B03.5 Suspension/reinstatement/offboarding

Exit gate: an applicant can progress end-to-end and only an ACTIVE eligible driver reaches operational APIs.

---

## Program 4 - Fleet and inventory

### B04.1 Vehicle inventory/history
### B04.2 Charger inventory/connectors
### B04.3 Pairing history
### B04.4 Maintenance/lifecycle intervals
### B04.5 Admin asset assignment
### B04.6 Derived availability projection

Exit gate: Admin can answer current and historical vehicle/charger/assignment questions without overwriting history.

---

## Program 5 - Scheduling, duty, location

### B05.1 Schedules and materialized occurrences
### B05.2 DutySession lifecycle
### B05.3 Exclusive asset claim constraints/concurrency tests
### B05.4 Driver asset mismatch reporting
### B05.5 Break/availability intervals
### B05.6 Location ingestion/current projection/freshness
### B05.7 Driver geofence and effective area

Exit gate: scheduled and unscheduled eligible drivers can start duty safely, become dispatchable, move, pause, and end duty with exact asset history.

---

## Program 6 - Service request, pricing foundation, ServiceJob core

### B06.1 ServiceRequest
### B06.2 Serviceability validation
### B06.3 First production slice of the final pricing interface
### B06.4 Quote acceptance -> ServiceJob snapshots
### B06.5 ServiceJob state machine/event history
### B06.6 Cancellation/no-show reason framework

Exit gate: customer can create a job independent of dispatch and history is correct.

---

## Program 7 - Dispatch

### B07.1 Eligibility engine
### B07.2 Ranking engine
### B07.3 DispatchAttempt/Candidate persistence
### B07.4 Sequential offer workflow
### B07.5 Atomic offer acceptance
### B07.6 Assignment and Driver current-job contract
### B07.7 Reassignment
### B07.8 No-candidate retry/scheduled dispatch worker
### B07.9 Admin diagnostics/direct assignment

Exit gate: simulator drivers/duties can be dispatched under race, rejection, expiry, reassignment, and no-candidate tests.

---

## Program 8 - HAL core, CMS boundary, and OCPP 1.6 first vertical

This program begins only after CMS charger/connector identity and the internal contract version are frozen enough that both repositories can implement against the same fixtures. It may run in parallel with late dispatch work, but not before the identifier crosswalk and mapping semantics in Sections 18-20 are settled.

### B08.1 HAL repository/bootstrap contract

- independent Go module/service/database;
- configuration loader with fail-safe production PostgreSQL requirement;
- health/readiness split;
- migration runner/explicit migration command;
- structured logging with secret/body exclusions;
- worker lifecycle and graceful shutdown framework.

Exit: empty HAL starts against disposable PostgreSQL, migrations apply, readiness reflects DB/worker health, shutdown joins workers.

### B08.2 CMS-HAL service authentication

- distinct CMS->HAL command bearer;
- distinct HAL->CMS fact bearer;
- distinct HAL->CMS trace bearer;
- constant-time credential validation where applicable;
- no human/customer token reuse;
- configuration parity/docs/tests.

Exit: each credential can call only its intended plane; cross-use fails.

### B08.3 Charger/connector mapping registry

- `PUT /v1/mappings/chargers/{cms_charger_id}` or final equivalent;
- exact CMS charger/connector UUIDs;
- protocol identity and connector-number mapping;
- enabled state and optional expected serial;
- idempotent same-content replay;
- conflicting immutable identity change semantics;
- CMS durable mapping state + post-commit reconciler.

Exit: mapping create/replay/conflict/recovery pass across both services.

### B08.4 Connection runtime and restart fencing

- tracked transport connection identity;
- process-scoped generation guard for stale callbacks;
- durable connection sequence;
- startup projection to UNKNOWN until new evidence;
- Heartbeat/liveness renewal;
- connection fact outbox;
- CMS monotonic projection/freshness.

Exit: connect, stale disconnect callback, heartbeat, HAL restart, reconnect, delayed old fact all converge correctly.

### B08.5 Connector status runtime

- mapped protocol status ingestion;
- monotonic connector status sequence;
- parent connection freshness overlay;
- CMS historical-vs-live distinction;
- inventory eligibility overlay.

Exit: Available/Preparing/Charging/Finishing/Faulted/offline/stale scenarios produce truthful CMS projection.

### B08.6 Durable HAL command store and start/stop lifecycle

Implement exact states from Section 19.4:

```text
PERSISTED
PENDING_DELIVERY
DELIVERY_ATTEMPTED
OCPP_ACCEPTED
OCPP_REJECTED
AMBIGUOUS
EXPIRED
SUPERSEDED
MATERIALIZED
```

Include immutable request digest, exact CMS command identity, destination, expiry, attempts, result/error category, optional resulting transaction IDs, and database guards.

Exit: crash at every boundary cannot cause an unsafe replay.

### B08.7 One-use charging credential and OCPP authorization bridge

- CMS generation/hash persistence;
- HAL durable start-command value handling/redaction;
- OCPP 1.6 idTag translation;
- Authorize/StartTransaction correlation;
- expiry using trusted HAL receipt time and bounded charger clock-skew handling;
- replay prevention.

Exit: valid credential starts once; expired/replayed/wrong-mapping credential fails without identity leakage.

### B08.8 OCPP 1.6 transaction materialization

- charger-originated StartTransaction only;
- Central System exact transaction ID allocation;
- durable HAL transaction row;
- exact command/start-intent/credential/mapping chain;
- one immutable `transaction.started` fact reservation in the same durable operation.

Exit: RemoteStart accepted without StartTransaction never materializes transaction; duplicate StartTransaction cannot create a second logical transaction.

### B08.9 MeterValues normalization

- cumulative integer Wh selection;
- accepted-measurand rules;
- exact HAL transaction binding;
- monotonic meter sequence;
- consumed Wh relative to accepted start meter;
- invalid/decreasing/out-of-order evidence handling;
- immutable `transaction.meter` facts;
- optional instantaneous measurements kept non-authoritative.

Exit: valid, duplicate, delayed, decreasing, malformed, and unrelated meter samples are covered.

### B08.10 Independent SoC normalization

- OCPP SoC extraction when present;
- canonical decimal percent 0..100;
- independent SoC sequence/time;
- SoC-only fact allowed;
- no energy invention/cached SoC replay.

Exit: missing SoC remains unknown and energy/SoC streams cannot regress one another.

### B08.11 Stop workflow and automatic limit sources

- remote stop request persistence;
- spontaneous/local stop support;
- energy limit;
- duration limit;
- funding/commercial safety threshold only as an opaque CMS-derived bound;
- explicit threshold provenance;
- shared controlled idempotent stop workflow;
- no pricing/GST/payment interpretation in HAL.

Exit: customer/driver/admin/system/local/threshold stops preserve requested-vs-protocol provenance.

### B08.12 Transaction completion truth

- exact active transaction identity check;
- StopTransaction ordering;
- nondecreasing final meter;
- documented one-Wh quantization normalization only if retained/tested;
- duplicate/conflicting terminal evidence handling;
- canonical row-lock order;
- exactly one terminal fact aggregate.

Exit: retransmitted StopTransaction cannot produce duplicate completion fact; conflicting evidence enters reconciliation.

### B08.13 Durable fact outbox

- immutable fact envelope + canonical digest;
- per-fact idempotency identity;
- lease/claim token;
- retry/backoff;
- same identity on retry;
- stale worker fencing;
- terminal receiver error classification;
- poison isolation;
- worker health/readiness.

Exit: CMS outage/restart and HAL worker crash preserve exactly the same logical facts.

### B08.14 CMS fact ingress and projection transaction

- separate fact bearer;
- `Idempotency-Key == fact_id` validation;
- canonical digest recomputation;
- durable receipt/dedupe;
- same-ID altered-content conflict;
- type-specific mapping/identity checks;
- monotonic connection/connector/meter/SoC projection;
- session materialization/completion integration seam;
- operational event emitted in same CMS transaction.

Exit: crash-before/after commit, exact replay, altered replay, delayed sequence, unsupported fact all behave deterministically.

### B08.15 Exact command and transaction reconciliation APIs

- exact command GET by `cms_command_id`;
- exact transaction GET by `cms_start_intent_id`;
- exact transaction GET by `hal_transaction_id`;
- strict response shape/identity validation;
- canonical 404 semantics;
- no "latest" lookup.

Exit: CMS can recover start ambiguity and missing completion without direct HAL DB access or a new command.

### B08.16 Generic administrative charger operation boundary

Implement separate Reset/Unlock/Availability/diagnostic operation surface with frozen immutable destination and exact operation identity.

CMS states:

```text
PERSISTED
DISPATCH_CLAIMED
DELIVERY_ATTEMPTED
HAL_ACCEPTED
RECONCILIATION_REQUIRED
OCPP_CONFIRMED
CONFIRMED_ABSENT
```

HAL preserves pre-network replayability and post-attempt ambiguity rules.

Exit: generic operation uncertainty never mutates charging/commercial truth and never blindly replays.

### B08.17 Isolated charger-operation recovery worker

- independent from deadline/automatic-stop/pending-stop workers;
- bounded fair rotation across connected chargers;
- same atomic claim/dispatcher as immediate operation;
- request-detached bounded result persistence;
- shutdown cancellation/join;
- restart classification of attempted work to reconciliation.

Exit: intentionally slow admin OCPP command cannot delay charging stop deadline processing.

### B08.18 Diagnostic trace plane

- separate trace envelope/outbox/worker/bearer;
- sanitized CALL/CALLRESULT/CALLERROR evidence;
- bounded follow-on diagnostic windows if retained;
- CMS trace store/read capability;
- hard guarantee trace failure cannot block fact worker or mutate lifecycle state.

Exit: trace receiver outage has zero authoritative charging effect.

### B08.19 Scriptable simulator

Source-controlled scenarios cover every Section 19.18 case and expose deterministic timing/failure knobs.

Exit: CI can reproduce all command/fact/reconnect/ambiguity scenarios without physical hardware.

### B08.20 Cross-repository contract fixtures

- request/response/fact/error fixtures;
- canonical digest fixtures;
- schema version fixtures;
- CMS parser tests against HAL provider fixtures;
- HAL parser tests against CMS consumer fixtures;
- fixture version/digest guard.

Exit: incompatible drift fails CI before deployment.

Program 8 exit gate: disposable CMS + HAL PostgreSQL and virtual charger prove mapping, start command durability, real transaction start, meter/SoC, stop/completion, fact idempotency, restart/outage recovery, generic-operation worker isolation, and exact-ID reconciliation. This gate is not physical charger acceptance.

---

## Program 9 - CMS charging integration and app projections

### B09.1 Charging admission model

- ServiceJob/assignment/duty/asset authorization;
- compatibility revalidation;
- mapping prerequisite;
- frozen pricing/tax/admission context;
- selected funding-safety strategy integration without hard-coded wallet assumption;
- one-use credential generation;
- database constraints.

### B09.2 ChargingStartIntent state machine

Implement exact states/transitions from Section 18.6 plus DB/service guards and history/audit.

### B09.3 Immutable CMS START command record

Freeze command ID, start intent, HAL destination, connector number, request digest, correlation, expiry, limits/provenance before HAL I/O.

### B09.4 Start orchestration and post-commit mapping reconfirmation

Implement the exact sequence in Section 20.8, including safe cleanup when the post-commit mapping prerequisite fails before RequestStart.

### B09.5 Start ambiguity reconciler

- exact command lookup;
- confirmed-absence cleanup;
- exact transaction-by-start-intent lookup after threshold;
- late evidence handling;
- durable cursor/backoff/fairness;
- no blind new start.

### B09.6 `transaction.started` -> ChargingSession materialization

- full identity chain validation;
- exactly one session per start intent;
- exact HAL/protocol transaction IDs;
- ServiceJob transition to CHARGING only when legal;
- operational event/realtime invalidation.

### B09.7 Meter/SoC CMS projection

- independent sequences/freshness;
- accepted fact receipts;
- historical observation retention;
- user/driver/admin safe projections;
- stale parent connection semantics.

### B09.8 Charging stop request

- actor policy for Driver/User/Admin/system;
- durable stop request/command;
- optional bounded reason;
- `STOP_PENDING` projection;
- no completion from HAL/OCPP command acknowledgement.

### B09.9 `transaction.completed` finalization

- full identity/meter/time validation;
- requested-vs-protocol stop provenance;
- exactly-once session completion;
- final pricing source binding;
- payment/funding settlement seam;
- invoice intent seam;
- ServiceJob WRAP_UP gate;
- durable events.

### B09.10 Missing-completion recovery

- exact HAL transaction lookup by `hal_transaction_id`;
- same locked finalization path as normal fact;
- active/404/unavailable/malformed/conflict behaviors from Section 18.16;
- fair durable cursor.

### B09.11 Multiple ChargingSessions per ServiceJob

- separate start intent/session for later physical restart after prior session ended;
- aggregation for final pricing and compensation;
- UI/history representation;
- no transport-reconnect-induced false split.

### B09.12 Runtime availability and chargeability

- CMS inventory status;
- HAL connection freshness;
- connector protocol status/freshness;
- unresolved occupancy/start/session state;
- compatibility;
- asset mismatch;
- stable machine reason codes.

### B09.13 User charging read/progress contract

Implement Section 31.14-31.19: start progress distinct from session, exact unknown/stale behavior, materialized-session-only history, stop provenance, bounded pagination.

### B09.14 Driver charging contract

Driver Start/Stop/prepare UI consumes the same CMS domain methods and receives explicit requested/accepted/physical/reconciling states. Driver cannot force physical state by status mutation.

### B09.15 Admin technical charging views

Expose safe command/fact/runtime/trace projections with capability boundaries. Diagnostic trace is visibly labeled non-authoritative.

### B09.16 User live-job snapshot/SSE integration

- durable REST snapshot;
- full-replacement live jobs/session stream;
- generic event replay cursor;
- reconnect/token rotation/cursor expiry recovery;
- realtime outage fallback.

### B09.17 End-to-end charging acceptance

Run Section 20.18 matrix plus User/Driver/Admin projection agreement tests.

Program 9 exit gate: a virtual charger can drive a full ServiceJob charging lifecycle while every application sees the same CMS durable truth, all ambiguity is recoverable by exact identity, and no command acknowledgement is mistaken for physical charging state.

---

## Program 10 - Full pricing engine

### B10.1 Versioned pricing policy/rule persistence
### B10.2 Deterministic rule evaluator
### B10.3 Quote estimation line items
### B10.4 Final source-fact binding
### B10.5 Final pricing line items/snapshot
### B10.6 Cancellation/no-show components
### B10.7 Time/date/zone modifiers
### B10.8 Admin policy editor contract

Exit gate: fixed test fixtures prove same inputs + versions produce same result and historical jobs survive policy changes.

---

## Program 11 - Payments, refunds, tax, invoices

### B11.1 Razorpay order/payment integration
### B11.2 webhook/idempotent reconciliation
### B11.3 refund workflow
### B11.4 GST snapshot calculation
### B11.5 invoice renderer/storage/version/checksum
### B11.6 invoice worker/retry/download
### B11.7 mail/notification intent for invoice

Exit gate: provider sandbox/test environment and local artifact flow accepted end-to-end, with external acceptance boundary documented.

---

## Program 12 - Driver compensation

### B12.1 Versioned policy/rules
### B12.2 deterministic evaluator
### B12.3 time-boundary/interval prorating
### B12.4 source-fact binding
### B12.5 line-item ledger
### B12.6 reassignment allocation
### B12.7 adjustments
### B12.8 Driver summary/history
### B12.9 Admin views/exports

Exit gate: fixtures cover base, distance, time, night modifier, date bonus, driver override, minimum, cap, reassignment, and correction.

---

## Program 13 - Product completeness

### B13.1 User ratings/reviews
### B13.2 Customer support
### B13.3 Driver support
### B13.4 Incident management
### B13.5 Notification preferences/delivery
### B13.6 Admin operational dashboard
### B13.7 Async exports
### B13.8 retention/cleanup jobs

---

## Program 14 - Realtime hardening

Realtime basics may exist earlier, but this program makes it complete:

### B14.1 authenticated subscriptions
### B14.2 per-resource versioning
### B14.3 reconnect/catch-up guidance
### B14.4 user projections
### B14.5 driver projections
### B14.6 admin projections
### B14.7 backpressure/disconnect behavior
### B14.8 realtime-vs-REST consistency E2E tests

---

## Program 15 - Production hardening

### B15.1 security review
### B15.2 DB backup/restore drill
### B15.3 worker/backlog alerting
### B15.4 load tests for location/realtime/dispatch
### B15.5 Razorpay production-readiness checks
### B15.6 mail/push production acceptance
### B15.7 physical charger certification matrix
### B15.8 operational runbooks/on-call drills
### B15.9 staging full-day/long-session soak
### B15.10 release/rollback drill

---

## Program 16 - Protocol expansion

Only after core semantics are stable:

### B16.1 OCPP 2.0.1 adapter
### B16.2 adapter parity matrix
### B16.3 OCPP 2.1 if hardware/business requires
### B16.4 vendor-specific extensions behind adapter capability interfaces

Protocol expansion MUST NOT change CMS business semantics unless a genuinely new business capability is introduced deliberately.

---

# 65. Dependency Graph

High-level dependency order:

```text
Repository foundations
  -> auth/capability/audit/idempotency/outbox
     -> customer master data
     -> driver recruitment
        -> fleet
           -> schedule/duty/location
              -> service request/job
                 -> dispatch
                    -> charging integration

HAL foundations
  -> protocol-neutral core
     -> OCPP16/simulator
        -> CMS charging integration

ServiceJob + charging source facts
  -> final pricing
     -> payment/tax/invoice
  -> compensation

Core lifecycle
  -> ratings/support/incidents
  -> realtime completeness
  -> production hardening
```

The first production slice of the final pricing contract may begin before charging, but final pricing requires authoritative source facts.

HAL work can proceed in parallel after charger identity and CMS-HAL semantic contracts are frozen.

---

# 66. Phase Entrance and Exit Criteria

A later program may start only when its upstream semantic contracts are stable enough that proceeding will not force known rework.

Examples:

- Dispatch does not begin before DutySession + asset claim semantics exist.
- Charging integration does not begin before stable ServiceJob/assignment IDs and charger-HAL identity mapping exist.
- Compensation finalization does not begin before source facts/time boundaries are defined.
- Invoice generation does not begin before pricing/tax snapshots are frozen.
- Protocol 2.x adapters do not begin by duplicating OCPP 1.6 code before protocol-neutral core contracts are proven.

Parallel development is allowed when dependencies are interfaces already fixed and independently testable.

---

# 67. Definition of Done - Project Level

The project is not production-ready merely because all endpoints exist.

Production readiness requires:

1. User flow accepted end-to-end.
2. Driver recruitment + operational flow accepted end-to-end.
3. Admin can operate and recover abnormal flows.
4. Dispatch handles eligibility/races/reassignment.
5. Dedicated HAL survives reconnect/restart/uncertain operation tests.
6. At least one target physical charger model is hardware-accepted.
7. Pricing fixtures and real job calculations agree.
8. Razorpay production integration is verified at the intended flow boundary.
9. Refund flow verified.
10. Invoice artifact + download + delivery path verified.
11. Compensation ledger is explainable and stable across policy changes.
12. Realtime reconnects recover from REST.
13. Authorization/privacy tests cover all three human planes.
14. Backups and restore are tested.
15. Deployment/rollback runbook is exercised.
16. Monitoring alerts on critical backlogs/failures.
17. Documentation and OpenAPI match runtime.
18. No known unresolved integrity issue is hidden behind UI workarounds.
19. Known external/unverified boundaries are documented explicitly.

---

# 69. Decisions That Must Be Resolved Before Their Burner

These are genuine external/business/hardware inputs that cannot be truthfully invented in architecture:

1. Exact Charger-on-Wheels physical hardware models and connector configurations.
2. Whether the mobile unit has onboard energy storage and how its SoC/capacity is obtained.
3. Exact customer payment capture strategy supported/desired with Razorpay: upfront, deposit, authorization-like pattern, or post-service collection.
4. Legal/business invoice and GST classification details for mobility/service vs energy components.
5. Required KYC document set and storage/compliance retention requirements.
6. Client platform decisions that affect push provider/device token implementation.
7. Exact navigation/maps provider if server-side ETA/routing is required.
8. Production infrastructure/hostnames/secrets/storage provider.

The implementation program does not wait on these globally. It defers only the burner whose exact behavior depends on them, using explicit interfaces in the meantime.

---

# 71. Final Build Principle

Charger on Wheels must make the normal path easy without forcing abnormal real-world conditions into false data.

The implementation therefore preserves, separately and explicitly:

```text
what Admin intended
what Driver actually used
what the charger physically did
what the customer commercially owes
what the driver compensation engine calculated
what happened historically
what realtime currently projects
```

Then it composes those truths into User, Driver, and Admin experiences through explicit contracts.

The stable center is the ServiceJob. The operational driver context is the DriverDutySession. The physical charging authority is the dedicated HAL. PostgreSQL-backed durable state is the recovery authority. Realtime is an accelerator. Policies are versioned. History is not rewritten for convenience. Physical side effects are never inferred from optimistic UI actions.

That is the implementation blueprint.

---

# Appendix A. Normative State Machine Registry

This appendix is normative. Implementations must not add ad hoc transitions outside these graphs without updating the domain contract, tests, OpenAPI behavior, and this blueprint.

## A.1 DriverApplication

```text
DRAFT
  -> SUBMITTED
  -> WITHDRAWN

SUBMITTED
  -> UNDER_REVIEW
  -> WITHDRAWN

UNDER_REVIEW
  -> ACTION_REQUIRED
  -> APPROVED
  -> REJECTED

ACTION_REQUIRED
  -> SUBMITTED
  -> WITHDRAWN

APPROVED
  -> ONBOARDING

ONBOARDING
  -> ACTIVE

ACTIVE      terminal recruitment success state
REJECTED    terminal recruitment decision
WITHDRAWN   terminal applicant decision
```

Operational suspension/offboarding is not a recruitment-state transition.

## A.2 DriverDutySession

```text
STARTING
  -> AVAILABLE
  -> ABORTED

AVAILABLE
  -> OFFERED
  -> BREAK
  -> UNAVAILABLE
  -> ENDING

OFFERED
  -> ASSIGNED       accepted offer
  -> AVAILABLE      rejected/expired/withdrawn offer

ASSIGNED
  -> EN_ROUTE
  -> AVAILABLE      assignment ended before departure/reassigned/cancelled

EN_ROUTE
  -> AT_CUSTOMER
  -> AVAILABLE      job cancelled/reassigned/failed and assignment ended

AT_CUSTOMER
  -> SERVICING
  -> AVAILABLE      job terminal before service starts

SERVICING
  -> AVAILABLE      job terminal/completed and assignment ended

BREAK
  -> AVAILABLE
  -> ENDING

UNAVAILABLE
  -> AVAILABLE
  -> ENDING

ENDING
  -> ENDED

ABORTED             terminal emergency/failed start state
ENDED               terminal normal state
```

Rules:

- `ENDING` requires no active blocking assignment.
- `ABORTED` from an already operational state is an Admin/system emergency path only and requires active jobs/assets to be reconciled explicitly.
- Offer withdrawal occurs before entering BREAK/UNAVAILABLE if the driver is currently OFFERED.

## A.3 DispatchAttempt

```text
RUNNING
  -> OFFERING
  -> EXHAUSTED
  -> CANCELLED

OFFERING
  -> ASSIGNED
  -> RUNNING         recompute/continue after candidate result
  -> EXHAUSTED
  -> CANCELLED

ASSIGNED             terminal success
EXHAUSTED            terminal no-candidate result for this attempt
CANCELLED            terminal because job no longer needs this attempt
```

## A.4 DispatchOffer

```text
PENDING
  -> ACCEPTED
  -> REJECTED
  -> EXPIRED
  -> WITHDRAWN
```

All terminal. Exactly one ACCEPTED offer can become the current assignment for a given assignment cycle.

## A.5 ServiceJob

```text
DISPATCHING
  -> ASSIGNED         one sequential offer is live
  -> CANCELLED
  -> EXPIRED
  -> FAILED

ASSIGNED
  -> ACCEPTED         selected driver accepts; JobAssignment is created
  -> DISPATCHING      offer rejected/expired/withdrawn before acceptance
  -> REASSIGNING      provisional selection invalidated by operational change
  -> CANCELLED
  -> FAILED

ACCEPTED
  -> EN_ROUTE
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

EN_ROUTE
  -> ARRIVED
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

ARRIVED
  -> SERVICE_PREPARING
  -> REASSIGNING
  -> CANCELLED
  -> FAILED
  -> NO_SHOW

SERVICE_PREPARING
  -> CHARGING
  -> WRAP_UP          explicit zero-charge/aborted-service closeout only
  -> REASSIGNING
  -> CANCELLED
  -> FAILED

CHARGING
  -> WRAP_UP
  -> FAILED

WRAP_UP
  -> COMPLETED
  -> FAILED

REASSIGNING
  -> DISPATCHING
  -> ASSIGNED
  -> CANCELLED
  -> FAILED

COMPLETED            terminal
CANCELLED            terminal
FAILED               terminal
NO_SHOW              terminal
EXPIRED              terminal
```

No reopening a terminal ServiceJob. Corrections are separate records/workflows.

## A.6 ChargingStartIntent

```text
REQUESTED
  -> ACCEPTED_FOR_DELIVERY
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

ACCEPTED_FOR_DELIVERY
  -> PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> REJECTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

PROTOCOL_ACKNOWLEDGED
  -> ACTUALLY_STARTED
  -> EXPIRED
  -> RECONCILIATION_REQUIRED

REJECTED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

EXPIRED
  -> RECONCILIATION_REQUIRED    only if contrary late physical evidence arrives

RECONCILIATION_REQUIRED
  -> ACTUALLY_STARTED           exact authoritative transaction evidence
  -> REJECTED                   exact command absence/rejection proves safe terminal result
  -> EXPIRED                    exact absence plus elapsed start window

ACTUALLY_STARTED               terminal for the start-intent state machine
```

No normal ChargingSession exists before `ACTUALLY_STARTED`. RemoteStart/protocol acknowledgement never creates one.

## A.7 ChargingSession and ChargingStopRequest

ChargingSession:

```text
ABSENT
  -> ACTIVE                    only from authoritative `transaction.started` evidence

ACTIVE
  -> STOP_PENDING              durable stop requested; physical transaction still open
  -> RECONCILIATION_REQUIRED  contradictory/missing predecessor/final evidence
  -> COMPLETED                 spontaneous authoritative physical completion is valid
  -> FAILED                    only under explicitly defined non-settleable failure semantics

STOP_PENDING
  -> ACTIVE                    stop command definitively rejected while physical session remains active
  -> RECONCILIATION_REQUIRED
  -> COMPLETED                 authoritative physical completion

RECONCILIATION_REQUIRED
  -> ACTIVE                    exact evidence proves still active
  -> STOP_PENDING              exact evidence proves stop still pending
  -> COMPLETED                 exact completed transaction passes full identity/meter/time validation

COMPLETED                     terminal immutable physical/commercial completion
FAILED                        terminal only when policy explicitly permits; raw evidence remains retained
```

ChargingStopRequest is a separate durable command/request record. A RemoteStop acknowledgement can advance stop-command progress but cannot set the ChargingSession to `COMPLETED`.

## A.8 HAL Start/Stop Command and Generic Charger Operation

HAL charging command:

```text
PERSISTED
  -> PENDING_DELIVERY
  -> EXPIRED

PENDING_DELIVERY
  -> PERSISTED                 startup recovery only while transmission is proven not attempted
  -> DELIVERY_ATTEMPTED

DELIVERY_ATTEMPTED
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> AMBIGUOUS
  -> MATERIALIZED              authoritative start correlation may race command-result bookkeeping

OCPP_ACCEPTED
  -> MATERIALIZED
  -> AMBIGUOUS                 only when later command-result bookkeeping becomes uncertain

OCPP_REJECTED
  -> MATERIALIZED              contradictory later physical start is reconciliation evidence, never silently discarded

AMBIGUOUS
  -> OCPP_ACCEPTED
  -> OCPP_REJECTED
  -> MATERIALIZED
  -> EXPIRED                   only when exact evidence proves no physical materialization and contract permits terminalization

SUPERSEDED / EXPIRED / MATERIALIZED are non-dispatchable.
```

Generic administrative charger operations use the separate CMS dispatch states:

```text
PERSISTED
-> DISPATCH_CLAIMED
-> DELIVERY_ATTEMPTED
-> HAL_ACCEPTED | OCPP_CONFIRMED | RECONCILIATION_REQUIRED | CONFIRMED_ABSENT
```

A deadline or process restart MUST NOT make `DELIVERY_ATTEMPTED`, `HAL_ACCEPTED`, `AMBIGUOUS`, or `RECONCILIATION_REQUIRED` replayable. Exact-ID evidence resolves uncertainty.

## A.9 Payment

```text
CREATED
  -> PENDING
  -> FAILED
  -> CANCELLED

PENDING
  -> AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

AUTHORIZED
  -> CAPTURED
  -> FAILED
  -> CANCELLED

CAPTURED
  -> REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED

REFUND_PENDING
  -> PARTIALLY_REFUNDED
  -> REFUNDED
  -> CAPTURED          refund attempt failed; captured payment remains

PARTIALLY_REFUNDED
  -> REFUND_PENDING
  -> REFUNDED

FAILED                terminal payment attempt
CANCELLED             terminal payment attempt
REFUNDED              terminal fully refunded state
```

Provider events may arrive out of order. Transition logic uses provider identity and reconciled facts, not arrival order alone.

## A.10 Refund

```text
REQUESTED
  -> SUBMITTED
  -> CANCELLED

SUBMITTED
  -> SUCCEEDED
  -> FAILED

SUCCEEDED             terminal
FAILED                terminal for this refund operation; a new reconciled retry uses controlled identity semantics
CANCELLED             terminal
```

## A.11 Invoice

```text
PENDING
  -> GENERATING
  -> VOIDED

GENERATING
  -> READY
  -> FAILED

FAILED
  -> GENERATING       explicit retry
  -> VOIDED

READY
  -> VOIDED           only if business/legal process permits; artifact remains historical

VOIDED                terminal
```

READY artifact bytes are immutable.

## A.12 PricingPolicy and CompensationPolicy

```text
DRAFT -> ACTIVE -> RETIRED
```

A RETIRED policy is not reactivated. Create/activate a new version instead.

## A.13 SupportTicket

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> OPEN | CLOSED
CLOSED -> OPEN
```

Same-state mutation is side-effect-free.

## A.14 Incident

```text
OPEN
  -> INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

INVESTIGATING
  -> MITIGATED
  -> RESOLVED
  -> CLOSED

MITIGATED
  -> INVESTIGATING
  -> RESOLVED
  -> CLOSED

RESOLVED
  -> CLOSED
  -> INVESTIGATING    explicit reopen with reason

CLOSED
  -> INVESTIGATING    explicit reopen with reason
```

Reopen events are auditable.

## A.15 AssetMismatchReport

```text
MISMATCH_REPORTED
  -> ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

ACKNOWLEDGED
  -> CONFIRMED_CORRECTION
  -> EXPECTED_RESTORED
  -> REASSIGNED
  -> REJECTED_REPORT
  -> RESOLVED

CONFIRMED_CORRECTION -> RESOLVED
EXPECTED_RESTORED    -> RESOLVED
REASSIGNED           -> RESOLVED
REJECTED_REPORT      -> RESOLVED
RESOLVED             terminal
```

---

# Appendix B. Mandatory Database Constraints and Indexes

Application validation improves errors. PostgreSQL constraints preserve truth under concurrency.

## B.1 Identity/session

- unique normalized login identifier according to chosen auth strategy;
- session token identifiers unique;
- revoked/expired session indexes for cleanup;
- admin role/capability foreign keys;
- no capability name duplicates.

## B.2 Customer

- `customer_profiles.account_id` unique;
- active saved vehicle belongs to exactly one customer;
- active saved address belongs to exactly one customer;
- partial unique index: at most one active default address per customer;
- registration number uniqueness is not globally assumed for incomplete/temporary customer metadata unless business verification requires it.

## B.3 Driver

- `driver_profiles.account_id` unique;
- one driver profile per source application unless explicit migration path says otherwise;
- only one nonterminal application per account if repeat applications are not supported;
- licence/document identifiers may have uniqueness checks where legally/business appropriate, with careful privacy handling.

## B.4 Fleet

- service vehicle registration number unique among non-retired canonical inventory;
- charger asset tag unique;
- charger serial number unique where manufacturer serial is trusted/required;
- HAL identity unique among active charger mappings;
- `(charger_id, connector_number)` unique;
- no overlapping active exclusive charger-to-vehicle pairing periods when physical exclusivity applies.

## B.5 Duty/claims

- partial unique: one nonterminal DutySession per driver;
- partial unique: one unreleased exclusive vehicle claim per vehicle;
- partial unique: one unreleased exclusive charger claim per charger;
- claim foreign key to active DutySession;
- one open break/unavailability interval of the same incompatible class if semantics require.

## B.6 Dispatch

- `dispatch_attempts(service_job_id, attempt_number)` unique;
- one candidate row per attempt + duty session;
- one offer identity unique;
- one live provisional offer per ServiceJob in the initial sequential strategy;
- one current accepted/active assignment enforced through serialized job update + partial unique current-assignment constraint;
- offer acceptance cannot reference a different driver/duty than the offer row.

## B.7 ServiceJob

- `job_number` unique;
- immutable ownership customer ID after creation unless a dedicated migration/correction framework explicitly exists;
- current assignment FK nullable but must point to same ServiceJob, enforced using composite unique/FK pattern where practical;
- event IDs unique;
- event transition data check constraints for required fields where practical.

## B.8 Charging

- ChargingStartIntent idempotency unique in actor/job/start-attempt scope;
- at most one unresolved start intent for the same ServiceJob + effective charger/connector when policy forbids parallel starts;
- one immutable `cms_command_id` per logical start or stop command;
- one durable `hal_command_id` maps to only its originating CMS command identity;
- one-use charging credential hash is unique and cannot be rebound to another start intent;
- HAL `fact_id` unique; same fact ID with different immutable digest/content is an integrity violation, never overwrite;
- accepted fact receipt and its CMS projection/event commit atomically;
- connection, connector, meter, and SoC projections advance only on their own monotonic sequences;
- one `hal_transaction_id` and one exact OCPP transaction ID chain cannot materialize multiple CMS ChargingSessions;
- one ChargingSession belongs to exactly one ServiceJob, while one ServiceJob may own multiple sequential ChargingSessions;
- meter observation dedupe uses immutable fact/sample identity and sequence, not timestamp alone;
- completed session final meter cannot regress below accepted start/latest eligible cumulative meter except the explicitly documented one-Wh quantization normalization rule if that rule is implemented;
- generic administrative charger-operation dispatch destination/parameters become immutable before possible delivery.

## B.9 Pricing

- policy version unique per policy lineage/name as modeled;
- no mutation of ACTIVE/RETIRED rule version through normal update API;
- no overlapping ACTIVE policy effective windows for the same global scope unless the engine explicitly supports scoped multiple policies;
- finalized line items immutable.

## B.10 Payments/refunds

- provider order ID unique when non-null;
- provider payment ID unique when non-null;
- provider webhook event ID unique;
- idempotency key unique in actor/operation scope;
- refund provider reference unique when non-null;
- database or transactional check prevents cumulative successful/pending refundable amount from exceeding captured amount.

## B.11 Invoice

- one active canonical invoice per ServiceJob/document type unless version/corrective-document semantics explicitly allow more;
- READY invoice has non-null storage ref, checksum, renderer version, issued timestamp;
- artifact metadata immutable after READY except delivery metadata.

## B.12 Compensation

- one finalized compensation snapshot per ServiceJob + assignment + calculation version;
- line item belongs to snapshot driver/job;
- finalized line items immutable;
- adjustments append only.

## B.13 Rating

- unique `(service_job_id, customer_id)`;
- rating check `1 <= rating <= 5`.

## B.14 Support

- channel/owner checks ensure CUSTOMER_PLATFORM requires customer owner and no driver owner;
- DRIVER_PLATFORM requires driver owner and no customer owner;
- message actor ownership is tied to ticket owner where applicable;
- reply idempotency key unique within ticket/actor scope.

## B.15 Query indexes

Create indexes from actual query plans, but baseline indexes must support:

- jobs by status + updated/created time;
- jobs by customer/driver/current assignment;
- duty sessions by driver/status;
- active claims by asset;
- location projection by geospatial search strategy;
- schedules/occurrences by driver/time;
- offers by driver/status/expiry;
- payments by job/status/provider IDs;
- invoices by job/status;
- compensation by driver/date/job;
- support by owner/status/updated time;
- incidents by status/severity/job/asset;
- HAL facts by charger/time/transaction;
- HAL operations by charger/state/created time.

Use PostGIS only if geospatial complexity/query scale justifies it. If adopted, make it an explicit project dependency and use proper geography indexes rather than handwritten distance SQL everywhere.

---

# Appendix C. Canonical Error Code Registry

HTTP status and machine error code are both part of the contract.

## C.1 Common

```text
400 INVALID_REQUEST
400 VALIDATION_FAILED
401 UNAUTHENTICATED
403 FORBIDDEN
404 RESOURCE_NOT_FOUND
409 VERSION_CONFLICT
409 IDEMPOTENCY_KEY_REUSED
409 STATE_CONFLICT
422 SEMANTICALLY_INVALID
429 RATE_LIMITED
500 INTERNAL_ERROR
503 SERVICE_UNAVAILABLE
```

Privacy-sensitive ownership failures SHOULD use `404 RESOURCE_NOT_FOUND` instead of revealing that another user's resource exists.

## C.2 Driver/duty

```text
409 DRIVER_NOT_ELIGIBLE
409 DRIVER_ALREADY_ON_DUTY
409 DUTY_NOT_ACTIVE
409 DUTY_HAS_ACTIVE_JOB
409 VEHICLE_ALREADY_CLAIMED
409 CHARGER_ALREADY_CLAIMED
409 ASSET_NOT_OPERATIONAL
409 ASSET_PAIRING_MISMATCH_BLOCKED
409 CHARGER_HAL_IDENTITY_UNKNOWN
409 DRIVER_LOCATION_STALE
```

## C.3 Dispatch/job

```text
409 OFFER_EXPIRED
409 OFFER_NO_LONGER_AVAILABLE
409 JOB_NOT_ASSIGNABLE
409 JOB_INVALID_TRANSITION
409 JOB_ALREADY_TERMINAL
409 JOB_HAS_ACTIVE_CHARGING
422 NO_ELIGIBLE_DRIVER
422 CUSTOMER_LOCATION_UNSERVICEABLE
422 CUSTOMER_VEHICLE_INCOMPATIBLE
```

`NO_ELIGIBLE_DRIVER` may be represented as job/dispatch state rather than direct request failure depending on operation.

## C.4 Charging/HAL

```text
409 CHARGING_ALREADY_ACTIVE
409 CHARGING_NOT_ACTIVE
409 CHARGING_START_IN_PROGRESS
409 RECONCILIATION_REQUIRED
409 HAL_COMMAND_IDEMPOTENCY_CONFLICT
409 HAL_FACT_INTEGRITY_VIOLATION
409 HAL_START_EVIDENCE_CONFLICT
409 CHARGING_STOP_IN_PROGRESS
410 CHARGING_START_EXPIRED
422 CHARGER_CAPABILITY_UNSUPPORTED
422 CONNECTOR_INCOMPATIBLE
503 HAL_UNAVAILABLE
503 CHARGER_MAPPING_UNAVAILABLE
```

## C.5 Payments/invoices

```text
409 PAYMENT_ALREADY_CAPTURED
409 PAYMENT_AMOUNT_MISMATCH
409 REFUND_EXCEEDS_REFUNDABLE_AMOUNT
409 REFUND_ALREADY_IN_PROGRESS
422 PAYMENT_VERIFICATION_FAILED
503 PAYMENT_PROVIDER_UNAVAILABLE
409 INVOICE_NOT_READY
409 INVOICE_ALREADY_READY
```

## C.6 Policies

```text
409 POLICY_VERSION_CONFLICT
409 POLICY_EFFECTIVE_RANGE_CONFLICT
409 ACTIVE_POLICY_IMMUTABLE
422 RULE_CONFIGURATION_INVALID
```

---

# Appendix D. Initial Operational Defaults and Knobs

These values are implementation defaults, not eternal business rules. They live in validated configuration or Admin policy and can be changed without changing semantics.

## D.1 API

```text
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100
DEFAULT_TIMEZONE=Asia/Kolkata
```

## D.2 Dispatch

Initial normal strategy:

```text
SEQUENTIAL
```

`DIRECT_ASSIGNMENT` is an explicit Admin action. `BATCHED` is not implemented initially.

No hard-coded offer timeout or scheduled dispatch lead time is mandated by architecture because those materially affect field operations. They MUST be explicit configuration before shared staging is enabled. Startup should reject an environment that enables dispatch without required timing values.

Required knobs:

```text
DISPATCH_OFFER_TTL_SECONDS
DISPATCH_RETRY_MIN_SECONDS
DISPATCH_RETRY_MAX_SECONDS
SCHEDULED_DISPATCH_LEAD_MINUTES
DISPATCH_MAX_LOCATION_AGE_SECONDS
ARRIVAL_VALIDATION_RADIUS_METERS
```

## D.3 Location

Client reporting cadence is a mobile-product/battery tradeoff, so the server defines freshness/maximum ingest rate, while Driver App chooses cadence within contract.

Server MUST reject abusive/implausible rates and accept batch recovery for offline periods.

## D.4 Workers

Every worker has configurable:

```text
BATCH_SIZE
POLL_INTERVAL
LEASE_DURATION
MAX_ATTEMPTS or terminal policy
BACKOFF_MIN
BACKOFF_MAX
```

No worker may use an unbounded immediate retry loop.

## D.5 Realtime

Required knobs:

```text
MAX_CONNECTIONS_PER_ACCOUNT
HEARTBEAT_INTERVAL
CLIENT_IDLE_TIMEOUT
MAX_OUTBOUND_QUEUE_PER_CONNECTION
```

Backpressure disconnects a slow client rather than consuming unbounded memory. Client recovers with REST.

---

# Appendix E. Operational Recovery Playbooks

These are behavioral playbooks. Exact shell commands belong in environment-specific operations docs.

## E.1 Driver app loses connectivity while en route

1. Server keeps assignment/job authoritative.
2. Location becomes stale after configured threshold.
3. Admin sees stale-location warning.
4. Driver app reconnects and fetches current duty/job via REST.
5. Buffered valid location samples may upload in batch.
6. No assignment is automatically cancelled solely because one realtime socket dropped.
7. Escalation/reassignment follows dispatch operations policy if staleness exceeds business threshold.

## E.2 Driver app loses connectivity during charging

1. HAL continues owning physical charger truth independently of Driver App.
2. CMS continues ingesting HAL facts.
3. User/Admin can still see charging projection if CMS/HAL links remain healthy.
4. Reconnected Driver App fetches job/charging state.
5. Never infer stop/start from Driver App reconnect state.

## E.3 CMS temporarily unavailable during active charging

1. HAL persists operation/transaction/facts locally.
2. Charger session continues according to physical/protocol reality.
3. HAL fact outbox retries delivery.
4. CMS restart recovers database state.
5. HAL delivers missed facts idempotently.
6. CMS reconciles transaction links/projections.
7. No new physical command is replayed unless operation identity proves it safe.

## E.4 HAL restarts during active charging

1. HAL reconnect supervisor restores charger connection.
2. Protocol adapter reconciles active transaction state.
3. Existing stable HAL transaction is recovered or a reconciliation record explains identity change where protocol makes exact restoration impossible.
4. CMS receives no duplicate semantic start if same transaction is proven.
5. Raw evidence links restart/reconnect chain.

## E.5 Start command times out

1. CMS marks the existing ChargingStartIntent/command `RECONCILIATION_REQUIRED` when RequestStart may have crossed the boundary.
2. Keep the original `cms_command_id`, hold/reservation, start intent, one-use credential binding, and immutable destination evidence. Do not create a replacement start automatically.
3. Reconcile `GET /v1/remote-commands?cms_command_id={uuid}` by the exact original command identity.
4. If HAL returns the exact command, project that command state and continue waiting/reconciling for authoritative transaction evidence.
5. If HAL returns canonical `404` for that exact durable command and CMS proves no materialized session exists, atomically release only the still-reserved commercial hold/reservation and terminalize the intent `REJECTED` or `EXPIRED` according to its window.
6. For an accepted/unmaterialized start past the reconcile threshold, query `GET /v1/transactions?cms_start_intent_id={uuid}`. A matching transaction uses the same locked materializer as a normal `transaction.started` fact.
7. Any non-404 lookup failure or conflicting/malformed evidence keeps reconciliation state; it never becomes absence by timeout.
8. Late physical-start evidence after `REJECTED`/`EXPIRED` is retained and moves the attempt into reconciliation rather than silently fabricating a normal session.
9. If unresolved beyond the operational horizon, alert Technical Admin while continuing safe exact-ID recovery according to retention policy.

## E.6 Payment API response lost after capture

1. Keep logical payment identity/provider order.
2. Do not create a second charge automatically.
3. Reconcile provider state by provider identity/webhook/API.
4. Mark CAPTURED idempotently if proven.
5. User client retry returns same logical payment result.

## E.7 Invoice generation fails

1. Payment/job truth remains untouched.
2. Invoice stays FAILED/PENDING with error classification.
3. Worker retries retryable renderer/storage errors.
4. Admin sees failure and may explicitly retry.
5. READY is never set without verified artifact metadata/checksum.

## E.8 No drivers available

1. DispatchAttempt becomes EXHAUSTED.
2. Job remains truthfully unassigned/dispatching subject to policy.
3. User receives availability/delay state.
4. Retry worker reevaluates fresh candidates, not stale ranking.
5. Admin sees reason/age.
6. Job expires only under explicit policy/deadline.

## E.9 Assigned driver breaks down

1. Driver reports problem/incident.
2. Current assignment ends with reason.
3. Duty becomes UNAVAILABLE or ends depending reality.
4. Job enters REASSIGNING.
5. New dispatch attempt selects another eligible duty.
6. Historical assignment remains.
7. Compensation uses facts attributable to each assignment.

## E.10 Customer location changes after assignment

1. User cannot silently overwrite ServiceJob service-address snapshot.
2. Submit relocation/change request.
3. Backend assesses serviceability, price impact, and current assignment feasibility.
4. If accepted, create an explicit address-change event/new operational snapshot version while preserving original request snapshot.
5. Requote/reassign if required.
6. If not supported initially, customer must cancel and create a new request; API says so explicitly.

The initial implementation SHOULD choose one of these semantics before enabling mid-job relocation. Do not silently mutate coordinates.

---

# Appendix F. Acceptance Evidence Matrix

A claim of completion should name evidence level.

| Claim | Minimum evidence |
| --- | --- |
| Domain implemented | source + unit tests |
| DB invariant enforced | disposable PostgreSQL integration test |
| API contract implemented | OpenAPI/runtime parity + auth tests |
| Worker reliable | retry/lease/integration tests + runtime backlog metrics |
| CMS-HAL command flow works | service integration test |
| OCPP adapter works logically | scripted simulator acceptance |
| Charger model works physically | real hardware acceptance |
| Payment flow works | provider test/live acceptance at claimed boundary |
| Refund works | provider acceptance |
| Invoice generation works | generated artifact checksum + authorized download |
| Email/push works | provider accepted delivery request; do not claim recipient read |
| Deployment works | target runtime health + changed-feature smoke + logs |
| Rollback works | exercised compatible rollback/recovery path |
| Production ready | project-level Definition of Done plus all critical external boundaries accepted |

---

# Appendix G. Blueprint Change Control

Once implementation starts, this blueprint itself follows change discipline.

A semantic change must identify:

1. reason/new evidence;
2. affected actors;
3. affected state machines;
4. persistence/migration impact;
5. API/OpenAPI impact;
6. worker/realtime impact;
7. security/privacy impact;
8. historical compatibility;
9. rollout/rollback plan;
10. affected tests/docs;
11. whether existing mobile/frontends remain compatible.

Do not update only this document while leaving runtime semantics unchanged, and do not change runtime semantics without updating the authoritative contract set.

