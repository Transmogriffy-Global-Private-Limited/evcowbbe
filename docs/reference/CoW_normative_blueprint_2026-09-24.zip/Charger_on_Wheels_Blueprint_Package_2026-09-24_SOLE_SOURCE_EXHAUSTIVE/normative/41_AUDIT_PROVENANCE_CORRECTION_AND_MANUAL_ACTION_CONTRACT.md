# Audit, Provenance, Correction, and Manual Action Contract

**Status:** Normative scoped annex.
**Owns:** security/administrative audit records, provenance links, reason requirements, manual correction pattern and non-destructive history.

# 1. AuditEvent

AuditEvent is append-only and records consequential human/system actions. Minimum fields:

```text
audit_event_id
occurred_at
actor_plane            # CUSTOMER|DRIVER|ADMIN|SYSTEM|SERVICE
actor_id nullable
admin_capability nullable
action
resource_type
resource_id
request_id / correlation_id
reason_code nullable
reason_text nullable
before_summary jsonb nullable
after_summary jsonb nullable
source_ip_hash/prefix nullable by privacy policy
metadata jsonb
```

Secrets/raw credentials/body dumps are forbidden.

# 2. What must be audited

At minimum: Admin role/capability changes, Driver KYC decisions/suspension/offboarding, fleet create/change/deactivation/maintenance, pairings/assignments/mismatch resolution, schedule changes, manual dispatch/reassignment, manual job transitions, charger commands, pricing/tax/compensation activation, commercial adjustments/refunds, invoice interventions, support status/admin replies as policy requires, incident resolution, retention/legal-hold actions and security-sensitive session revocation.

High-frequency telemetry/location/meter samples are not AuditEvents; their own immutable facts/provenance are sufficient.

# 3. Provenance

Derived/finalized records keep source references/digests where correctness needs explainability: quote -> policy/rules/request snapshot, compensation -> source facts/rules, invoice -> final commercial model, realtime -> resource/version, normalized HAL fact -> raw evidence ref where retained.

# 4. Reason requirements

Every manual override/correction declares a machine reason code and optional bounded operator note. Security/safety/commercial corrections require non-empty reason text unless automated by a named SYSTEM rule.

# 5. Correction pattern

Prefer:

```text
observed contradiction
-> immutable discrepancy/evidence
-> corrective action/adjustment/version
-> current projection updated
-> old history preserved
-> audit link across all records
```

Never rewrite immutable historical actor, physical transaction, finalized price, finalized compensation, READY invoice or provider event to make history look clean.

# 6. Manual action safety

Admin UI/API exposes only specific actions, not arbitrary status setters. Each action revalidates current state and hard invariants server-side. `Full Admin` grants capability, not permission to violate DB/physical/commercial invariants.

# 7. Audit access

`audit.read` is capability-gated. Sensitive metadata is additionally redacted by category. Audit export is asynchronous, bounded and itself audited.

# 8. Integrity

Audit insert should occur in same transaction as authoritative CMS mutation where possible. External side-effect attempt/result can have follow-up audit records linked by correlation. Audit delivery failure must not be hidden; for same-DB audit it should fail the transaction when audit is required.

# 9. Verification

Mutation tests assert required AuditEvent exists with actor/action/resource/reason and no secret. Correction tests prove original history unchanged. Capability tests prevent ordinary Admin roles reading restricted audit classes.
