# Persistence Schema and Data Dictionary

**Status:** Normative scoped annex.
**Owns:** PostgreSQL type conventions, table/domain inventory, FK/delete/history principles and schema-level invariants. Exact migration DDL may evolve only without changing declared semantics.

# 1. PostgreSQL baseline

- PostgreSQL is durable business truth for CMS and separately durable HAL truth for HAL.
- UUID primary keys for domain entities unless a monotonically generated internal sequence is specifically useful (for example realtime replay seq).
- `timestamptz` for instants.
- `bigint` for money minor units, Wh counters, sequence/version when range warrants.
- `integer` for bounded counters/enums only when mapping explicit; text/check enum is acceptable initially when migration discipline is maintained.
- `jsonb` only for genuinely extensible/versioned payloads/conditions/evidence, not as replacement for query-critical columns.
- mutable rows carry `created_at`, `updated_at`, and `version` where optimistic concurrency applies.

# 2. Authentication/identity tables

```text
accounts
account_credentials / password_credentials
account_sessions
verification_challenges
customer_principals
admin_principals
admin_roles
admin_capabilities
admin_role_capabilities
admin_principal_roles (or equivalent explicit assignment)
```

DriverProfile is workforce domain and references account separately. One account may own multiple principal planes; no customer/driver/admin ID is silently interchangeable.

# 3. Customer master data

```text
customer_profiles
customer_vehicles
customer_addresses
```

Saved/temporary lifecycle is explicit. Job snapshots are separate immutable records/JSON typed snapshots so deleting/deactivating master data does not erase history.

# 4. Driver recruitment/workforce

```text
driver_applications
driver_application_history
driver_profiles
driver_documents
driver_document_reviews
driver_eligibility_reasons
driver_schedules
driver_schedule_occurrences
driver_duty_sessions
driver_availability_intervals
```

Application, profile and operational state remain separate.

# 5. Fleet/assets

```text
service_vehicles
chargers
charger_connectors
charger_capabilities
vehicle_charger_pairings
driver_asset_assignments
asset_claims
asset_mismatch_reports
asset_maintenance_periods
asset_lifecycle_events
```

Effective-dated history is never overwritten. Partial unique/exclusion constraints enforce active exclusive claims/pairings where required.

# 6. Location/zone

```text
driver_location_samples
driver_location_state
service_zones
service_zone_versions
```

Current location is projection from samples. Zone version used for historical decision is retained.

# 7. Request/dispatch/job

```text
service_requests
quotes
service_jobs
service_job_events
service_job_vehicle_snapshots
service_job_address_snapshots
job_assignments
dispatch_attempts
dispatch_candidates
dispatch_offers
```

One ServiceJob can have multiple assignments/charging sessions. Current projection may cache current assignment but history rows are authoritative.

# 8. CMS charging

```text
charging_start_intents
charging_stop_requests
charging_sessions
charging_meter_observations
charging_soc_observations
cms_hal_commands
cms_hal_fact_receipts
charger_runtime_projection
connector_runtime_projection
charging_runtime_projection
charger_mapping_delivery_state
```

`charging_sessions` only materialize from authoritative HAL physical start evidence. Facts have immutable identity/digest and monotonic sequences.

# 9. HAL database families

HAL has its own DB and at minimum:

```text
charger_mappings
charger_connections / connection projection
connector_status_observations
hal_commands
hal_command_delivery_attempts
hal_transactions
hal_meter_observations
hal_soc_observations
hal_facts
hal_fact_outbox
hal_trace_events
hal_trace_outbox
charger_operations
recovery_leases/state
```

No FK crosses CMS/HAL databases.

# 10. Pricing/commercial

```text
pricing_policies
pricing_rules
pricing_snapshots
pricing_evaluations
pricing_line_items
commercial_adjustments
tax_configurations / tax_snapshots
payments
payment_provider_events
refunds
invoices
invoice_artifacts
```

Finalized snapshots/line items/invoice artifacts are immutable except explicit correction/version metadata.

# 11. Compensation

```text
compensation_policies
compensation_rules
compensation_calculations
compensation_line_items
compensation_adjustments
```

Aggregates are query/projection over ledger, not independent mutable monetary truth.

# 12. Ratings/support/incidents

```text
ratings_reviews
support_tickets
support_messages
support_events
incidents
incident_events
incident_evidence
```

Owner/channel checks prevent cross-principal leakage.

# 13. Notification/realtime

Owned exactly by Annex 10:

```text
notifications
notification_deliveries
notification_preferences
device_registrations
realtime_events
realtime_event_targets
realtime_stream_tickets
```

# 14. Platform infrastructure

```text
idempotency_records
domain_events
outbox_deliveries
audit_events
async_exports
worker_checkpoints / reconciler cursors as needed
```

# 15. Mobile energy when REQUIRED

```text
mobile_energy_stores
mobile_energy_observations
mobile_energy_state
mobile_energy_reservations
```

Energy reservation uniqueness/concurrency is schema-enforced where possible.

# 16. FK/delete policy

Default for business/history records is RESTRICT or soft lifecycle, not cascade-delete history. CASCADE is reserved for true owned implementation detail that has no independent audit/history meaning, such as target rows of a bounded replay event.

Account closure does not hard-delete jobs, payments, invoices, physical charging evidence or legally retained records. It follows Annex 31 anonymization/retention policy.

# 17. Snapshots

Snapshot payload is versioned and contains all fields needed to understand historical decision without current master data. Snapshot is immutable after boundary except forward correction record; schema version is explicit.

# 18. Projections

Current/live projections are rebuildable from durable facts where feasible. A projection table is never only copy of irreplaceable evidence. Rebuild procedures preserve current version monotonicity semantics or reset with explicit generation/version plan.

# 19. Index baseline

Every FK used for joins/deletes has supporting index unless query planner evidence shows unnecessary. List endpoints have composite index matching filters/order, including tie-breaker. Worker due queues index state + due time. Idempotency/dedupe identities are UNIQUE.

# 20. Migration rules

Applied migrations are immutable. Each migration declares compatibility class from Annex 19, expected locks/table size impact, rollback/down safety and verification query. Consequential migration gets pre-change backup/restore path.

# 21. Database verification

Feature completion with DB behavior requires disposable real PostgreSQL tests for constraints, transaction rollback, concurrency and migration behavior. Never point `TEST_DATABASE_URL` to dev/staging/prod.
