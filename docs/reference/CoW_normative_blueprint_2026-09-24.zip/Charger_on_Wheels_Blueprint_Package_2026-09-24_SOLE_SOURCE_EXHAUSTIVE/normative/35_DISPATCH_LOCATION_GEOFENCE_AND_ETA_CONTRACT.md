# Dispatch, Location, Geofence, and ETA Contract

**Status:** Normative scoped annex.
**Owns:** location ingestion/freshness, service-area evaluation, candidate eligibility/ranking, dispatch offers, assignment races, ETA provenance, and dispatch recovery.

# 1. Location representation

Coordinates are WGS84 decimal degrees. API fields are `latitude` and `longitude`; database storage uses `double precision` initially or PostGIS `geography(Point,4326)` when activated. Latitude range [-90,90], longitude [-180,180]. Invalid coordinates are rejected.

A Driver location sample contains:

```text
id, driver_id, duty_session_id, observed_at, received_at,
latitude, longitude, accuracy_m, speed_mps nullable, heading_deg nullable,
source, sequence nullable
```

`observed_at` is device observation time; `received_at` is trusted server time. Future-skew/outlier policy is configurable. Samples beyond accepted skew may be stored as diagnostic evidence but MUST NOT advance current location.

# 2. Freshness

Dispatch uses current location only when `server_now - effective_observed_at <= DRIVER_LOCATION_FRESH_SECONDS` and accuracy is within configured dispatch tolerance. Default freshness is defined in Annex 17. Stale location makes candidate ineligible, not merely lower-ranked.

# 3. Ingestion

Driver location mutation is authenticated to that Driver's active duty session. It is naturally idempotent by `(duty_session_id, client_sample_id)` where client sample identity exists. Older observation/sequence cannot move the current projection backward.

Raw location retention and downsampling follow Annex 31. High-frequency data is never written into AuditEvent one row per sample.

# 4. Service areas

Three independent constraints exist:

```text
platform service eligibility
AND admin operational restriction
AND driver voluntary preference
```

A voluntary Driver geofence can narrow, never expand, the allowed area.

Supported v1 geometries:
- radius: center lat/lon + radius meters;
- named Admin zone: immutable zone-version reference;
- polygon only when PostGIS/geospatial support is explicitly activated.

Boundary points count as inside unless the zone contract explicitly says otherwise.

# 5. Candidate eligibility

Eligibility is deterministic and evaluated before ranking. A candidate requires all applicable checks to pass:

- Driver ACTIVE/eligible/not suspended;
- active dispatchable DutySession;
- operational state AVAILABLE;
- schedule/policy permits work now;
- fresh acceptable location;
- customer service location within effective area;
- unconflicted Vehicle/Charger claims;
- assets operational and active;
- expected/observed pairing allowed by policy;
- requested connector and charging mode compatible;
- HAL identity/capability freshness sufficient for admission;
- mobile-energy reservation feasible when energy model REQUIRED;
- no active conflicting job/offer state;
- customer/job not terminal/cancelled/expired.

The evaluator returns machine reason codes for every exclusion. Admin diagnostics may view exclusions; customers do not receive private Driver details.

# 6. Distance and ETA

Straight-line/Haversine distance MAY be used as a prefilter only. User-visible and ranking ETA/distance use the selected routing provider when configured.

Provider result records:

```text
provider, route_version, requested_at, origin, destination,
distance_m, duration_s, traffic_basis nullable, expires_at
```

If provider is unavailable:
- do not fabricate routed ETA;
- policy may allow Haversine-only fallback ranking with `eta_unavailable=true`;
- UI labels ETA as unavailable/approximate according to returned provenance.

# 7. Ranking

Only eligible candidates are ranked. V1 ranking is deterministic lexicographic unless an Admin-configured scoring policy is activated:

```text
1. priority class / explicit operational override
2. routed ETA when comparable and fresh
3. routed distance
4. current accepted workload / queued-job count
5. stable driver_id tie-break
```

A future weighted scorer must persist score components/version so an assignment can be explained.

Rating is not a default ranking factor. If business policy activates it later, that is a versioned ranking-policy change.

# 8. Dispatch attempt

One ServiceJob has at most one active DispatchAttempt. Attempt snapshot records eligibility/ranking policy version and candidate computation timestamp.

States: `RUNNING`, `OFFERING`, `ASSIGNED`, `EXHAUSTED`, `CANCELLED` per Appendix A.

# 9. Offer creation

An offer is immutable in identity and deadline:

```text
offer_id, dispatch_attempt_id, job_id, driver_id, duty_session_id,
rank, offered_at, expires_at, state, eligibility_snapshot_digest
```

Offer acceptance endpoint requires `Idempotency-Key`. Acceptance transaction locks the job/attempt/offer in canonical order, rechecks that job is still assignable and Driver/duty/assets are still eligible, creates assignment, marks winner accepted, invalidates competing offers, and commits atomically.

Two Drivers racing cannot both become assigned.

# 10. Offer modes

Deployment policy chooses one explicit mode:
- `SEQUENTIAL`: offer candidate N, wait for accept/reject/expiry, then next;
- `BATCHED`: offer bounded batch concurrently; first valid atomic acceptance wins.

Mode, batch size and timeout are validated config/Admin policy. UI/event behavior is derived from the same offer rows.

# 11. Cancellation and reassignment

Customer/Admin/job cancellation atomically makes outstanding offers non-acceptable.

Reassignment creates new assignment history and dispatch attempt as needed; it never edits old assignment ownership. If previous Driver has departed/arrived/started service, explicit transition/reason/evidence is required and compensation implications are recorded.

# 12. Scheduled jobs

Scheduled request admission stores requested service window separately from dispatch start time. A scheduler makes the job dispatchable according to configured lead-time policy. Repeated scheduler execution is idempotent.

# 13. Customer location changes

Before assignment, allowed location edit may invalidate quote/zone/dispatch and therefore creates a new service-address snapshot/quote decision according to policy. After assignment, location change is a controlled operation: it records old/new snapshots, revalidates serviceability/Driver route and may require Admin/Driver acknowledgement. It never silently rewrites historical origin.

# 14. Observability

Metrics include candidate counts by exclusion reason, dispatch attempts, offers, expiry/reject/accept latency, no-candidate rate, routing failures, stale-location exclusions and reassignment rate. Logs use job/attempt/offer IDs, never full customer address unless explicitly authorized.

# 15. Verification

Real PostgreSQL concurrency tests MUST include:
- two Drivers accepting same job;
- same Driver offered two incompatible jobs;
- asset becomes claimed between ranking and accept;
- Driver location becomes stale before accept;
- job cancelled while accept races;
- offer expiry boundary;
- routing provider timeout;
- geofence boundary;
- mobile-energy reservation race when REQUIRED;
- reassignment preserves old assignment facts.
