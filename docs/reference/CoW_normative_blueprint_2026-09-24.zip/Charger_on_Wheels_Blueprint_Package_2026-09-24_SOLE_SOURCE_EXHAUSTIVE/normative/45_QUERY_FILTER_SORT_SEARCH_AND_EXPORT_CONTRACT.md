# Query, Filter, Sort, Search, and Export Contract

**Status:** Normative scoped annex.
**Owns:** list semantics beyond generic cursor mechanics, consistent search/filter rules, large export behavior and query safety.

# 1. List contract

Every list operation declares:
- default sort;
- allowed alternate sorts;
- stable tie-breaker;
- filter fields/operators;
- searchable fields for `q`;
- max limit;
- ownership/capability scope;
- whether totals are provided.

Do not expose arbitrary column/sort/filter language.

# 2. Pagination

Default `limit=20`, max 100 unless a specific endpoint documents lower/higher safe bound. Keyset cursor from Annex 11. No total count by default because unbounded COUNT can be expensive/stale; provide `total_count` only where product explicitly needs and query is bounded/indexed.

# 3. Search

`q`:
- trim surrounding whitespace;
- minimum useful length 2 for broad text search unless exact ID/email allows 1;
- max 200 chars;
- case-insensitive normalized matching where appropriate;
- parameterized queries;
- email/phone/registration normalization uses domain-specific normalizer;
- privacy scope applied before/with search, never search globally then filter in app.

# 4. Common Admin list defaults

```text
drivers: updated_at DESC,id DESC; filters application/eligibility/operational/schedule; q name,email,phone,driver ID
vehicles: updated_at DESC,id DESC; filters operational/maintenance/active/assignment; q registration,asset tag,make/model
chargers: updated_at DESC,id DESC; filters operational/maintenance/connectivity/protocol/connector; q asset tag,serial,HAL identity,model
jobs: created_at DESC,id DESC; filters state,customer,driver,zone,time,charging/payment; q job ID/customer safe identity
charging sessions: started_at DESC,id DESC; filters active/terminal,charger,driver,job,time; q session/job/transaction IDs
payments: created_at DESC,id DESC; filters state,provider,time,job; q payment/provider order/job ID
support: updated_at DESC,id DESC; filters channel/status/owner/time; q ticket ID,subject,owner safe identity
incidents: updated_at DESC,id DESC; filters severity/status/resource/time; q incident/resource IDs,title
```

# 5. User/Driver lists

Ownership is implicit from auth. User job/history/rating/support/invoice lists never accept another customer ID. Driver earnings/jobs/support similarly own-scoped. Filters cannot widen scope.

# 6. Time ranges

Use `from` inclusive, `to` exclusive `[from,to)` unless endpoint legacy requires named fields. Reject `to <= from`. Maximum interactive range can be endpoint-configured; large history uses export.

# 7. Multi-value filters

OpenAPI freezes representation, preferably repeated query key or comma-separated encoded enum list consistently. Empty list does not mean "all" ambiguously; omit filter for all.

# 8. Null filters

If product needs null/non-null filter use explicit token, for example `assignment=UNASSIGNED`, not `field=null` magic unless documented.

# 9. Sort safety

Map public sort token to fixed SQL expression/index. Raw query field/direction never interpolated. Null ordering fixed per sort and included in cursor codec.

# 10. Export

Interactive endpoint does not raise limit to millions. `POST /api/v1/admin/exports` or domain-specific export creates async job containing normalized query/filter/sort, requester/capability snapshot policy, requested columns/format and expiry.

Export states:

```text
PENDING
RUNNING
READY
FAILED
EXPIRED
CANCELLED
```

Worker uses stable database snapshot strategy or records `as_of` boundary. READY artifact private and authorized. CSV prevents formula injection by escaping cells beginning `= + - @` when opened by spreadsheet software.

# 11. Export consistency

For financial/audit exports requiring exact reproducibility, pin query `as_of`/source versions and use immutable/finalized rows. Operational live export can document snapshot time rather than pretend ongoing changes are included.

# 12. Index requirement

Before adding filter/sort to production endpoint, inspect query plan with representative cardinality and add matching index if needed. Feature is incomplete if it works only by sequential scanning unbounded table.

# 13. Verification

Tests cover cursor no duplicates/misses across same snapshot assumptions, filter-before-limit, cursor query mismatch, null/tie ordering, unauthorized scope, q escaping, index/query plan baseline for large tables and export expiry/auth.
