# Reference Sequences and Failure Scenarios

**Status:** Normative scoped annex.
**Owns:** end-to-end orchestration examples that bind domain contracts together. Individual domain/state annexes remain authoritative if this summary is less detailed.

# 1. Signup/login

1. Account registration/challenge according to enabled identifier policy.
2. Verify challenge atomically.
3. Create Customer principal/profile if customer signup.
4. Login issues one plane-bound session/access+refresh.
5. Refresh rotates token; old refresh reuse revokes family.
6. Client bootstraps `/me` and relevant data.

# 2. Driver onboarding

Application DRAFT -> submit -> review -> action-required loop if needed -> approve -> onboarding -> DriverProfile/eligibility -> ACTIVE. No Driver becomes dispatchable until a valid DutySession later starts.

# 3. Go on duty

Authenticate Driver -> select schedule/asset context -> lock/validate eligibility and asset claims -> snapshot observed assets -> create mismatch if needed -> commit DutySession/claims/event -> begin location updates -> dispatch eligibility only when AVAILABLE + fresh location.

# 4. Immediate customer service

Customer chooses saved/temporary EV/address -> request -> serviceability/compatibility -> quote -> accept exact quote idempotently -> ServiceJob -> dispatch attempt.

# 5. Dispatch offer race

Candidate A/B offered. Both tap accept. DB locks/unique invariant allow one assignment. Winner gets assignment; loser receives `OFFER_NO_LONGER_AVAILABLE`; events notify User/Drivers. No compensating double assignment.

# 6. No candidate

Attempt exhausts candidate policy -> EXHAUSTED -> job remains explicit dispatch-failed/waiting state according to business policy -> User sees truthful delay/unavailability -> scheduler/Admin can start new attempt, preserving prior attempt evidence.

# 7. Reassignment

Current assignment ended with reason -> job enters REASSIGNING -> previous assignment history closed -> active physical charging must be stopped/reconciled before handing charger/customer responsibility as policy requires -> new attempt -> new assignment. Compensation allocates actual performed segments.

# 8. Arrival

Driver sends arrive action with current location -> server revalidates current assignment/proximity/freshness -> records ARRIVED. If outside radius, return validation error or require named Admin/Driver override reason per policy. Do not accept because frontend says at customer.

# 9. Charging start

Job SERVICE_PREPARING + compatible current asset -> CMS creates ChargingStartIntent -> post-commit command worker sends HAL -> HAL persists/fences delivery -> charger responds accepted/rejected/unknown -> CMS command projection updates -> only charger-originated transaction start fact creates ChargingSession -> job can enter CHARGING.

# 10. Start timeout after physical success

CMS worker times out after request may have reached HAL/charger. State OUTCOME_UNKNOWN/RECONCILIATION_REQUIRED. No new start command ID. Reconciler exact-looks-up command/start intent; later transaction.started fact materializes session once. If exact evidence proves absence and policy allows, same logical command may safely continue according to HAL contract.

# 11. Meter flow

HAL receives meter -> validates exact transaction -> durable observation/fact/outbox -> CMS ingests duplicate-safe -> monotonic projection -> domain event -> realtime publisher coalesces -> User/Driver/Admin displays latest while REST snapshot remains authority.

# 12. Stop

Customer/Driver/Admin/system limit creates StopRequest idempotently -> durable command -> HAL delivery -> command acceptance only pending -> charger transaction-ended fact -> CMS closes ChargingSession/final meter -> job WRAP_UP -> final pricing/comp/payment/invoice workflows.

# 13. HAL restart during charge

HAL durable transaction survives; connection projection becomes UNKNOWN until new transport evidence; charger reconnect/recovery matches exact transaction; facts/outbox resume. CMS retains last projection but marks freshness stale/unknown as horizons expire. No fake stop/start session unless physical evidence says so.

# 14. CMS unavailable

HAL continues protocol safety/transaction and queues facts. CMS User/Driver/Admin unavailable/degraded. On return fact outbox delivers same IDs; projections catch up; notifications/realtime derive from committed catch-up without losing durable physical history.

# 15. Payment response lost

CMS durable payment intent -> provider request -> provider captures but response lost -> state outcome unknown/pending -> reconciler/provider webhook exact identity -> CAPTURED once. Client retry uses same idempotency identity, not new payment.

# 16. Invoice worker crash

Render/write temporary artifact -> crash before READY -> lease expires -> retry detects/cleans temp as provider strategy permits -> generates/publishes -> checksum -> READY. If crash after READY commit before worker ack, retry observes READY no-op. Never overwrites READY bytes.

# 17. Realtime disconnect

Client has cursor -> network drops -> durable domain continues -> new ticket resume cursor -> replay then live. If cursor expired, 409 -> REST snapshot -> new stream. No screen requires missing ephemeral event.

# 18. Push provider down

Domain mutation creates inbox notification/delivery intent. Push worker retries/backlogs and alerts. User opening app still sees inbox. Provider outage does not roll back job/payment/support state.

# 19. Driver unexpectedly offline

Location/heartbeat/app state goes stale or Driver disconnects. Duty may become UNAVAILABLE after explicit policy threshold; active assignment/job remains a real problem, triggers ops incident/reassignment workflow rather than silently dropping assignment. Asset claims remain until reconciled.

# 20. Wrong charger observed

Driver reports Charger B instead of expected A. Duty snapshots both; policy validates B identity/capability and may block/allow temporary use; mismatch visible Admin; registry not silently mutated; eventual Admin resolution updates future master data only.

# 21. Mobile energy insufficient (conditional)

Dispatch candidate initially had sufficient reserved energy -> newer authoritative observation makes usable energy below required + reserve before assignment/start -> reservation/eligibility fails explicitly -> re-dispatch/recharge/ops policy. Never promise impossible service from stale capacity.

# 22. Saved vehicle/address later deleted

Master association becomes inactive/deleted according to privacy policy. Historical job renders immutable snapshot normally. Promotion/deletion never rewrites job.

# 23. Policy changes mid-job

New pricing/comp policy version activates. Existing job uses pinned applicable snapshot/rule version according to declared boundary; new jobs use new version. No silent historical repricing.

# 24. Admin capability revoked during SSE

Capability update commits/audits -> active stream authorization observer removes/terminates restricted subscriptions -> UI refetch/bootstrap -> subsequent restricted API 403. Existing cached restricted data should be cleared per frontend contract.
