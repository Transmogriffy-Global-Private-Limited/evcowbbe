# Repository Bootstrap, Coding, and Migration Standard

**Status:** Normative scoped annex.
**Owns:** initial repo split/layout, local authority files, Go coding boundaries, migration/OpenAPI discipline, work-item and CI baseline.

# 1. Frozen logical repository split

Create independent repositories/services:

```text
charger-on-wheels-cms
charger-on-wheels-hal
```

Names may gain organization prefix during bootstrap but CMS/HAL remain independent modules/deployments/databases.

# 2. CMS package baseline

```text
cmd/server
cmd/migrate
internal/auth
internal/customers
internal/drivers
internal/recruitment
internal/fleet
internal/schedules
internal/duty
internal/location
internal/dispatch
internal/servicejobs
internal/charging
internal/halclient
internal/halfacts
internal/pricing
internal/payments
internal/refunds
internal/invoices
internal/compensation
internal/ratings
internal/support
internal/incidents
internal/notifications
internal/realtime
internal/audit
internal/platform
internal/storage
internal/providers
migrations
docs/contracts/openapi
docs/work/active
docs/work/archive
```

Exact subpackage count can remain simple. Do not create god `service`/`utils` packages that erase semantic ownership.

# 3. HAL package baseline

```text
cmd/server
cmd/migrate
cmd/simulator optional
internal/core
internal/mappings
internal/connections
internal/commands
internal/transactions
internal/metering
internal/facts
internal/trace
internal/recovery
internal/protocols/ocpp16
internal/protocols/ocpp201 future
internal/vendors
internal/simulator
migrations
docs/contracts
```

Protocol adapter imports core contracts; core must not import concrete protocol package.

# 4. Repository authority

Each repo contains:

```text
AGENTS.md
README.md
docs/README.md
docs/PROJECT_STATE.md
docs/AI_CHANGELOG.md
docs/work/active/
docs/work/archive/
```

CMS additionally owns OpenAPI/human API config contracts. HAL owns CMS-HAL fixture/version and protocol architecture docs. Root package remains bootstrap source until corresponding repository-native contract is implemented; thereafter package change control aligns them.

# 5. AGENTS.md minimum

Carry project principles: reality-first evidence, recursive coverage, one burner at a time, no applied migration edits, no secrets, explicit ownership/contracts, idempotency/recovery, OpenAPI parity, no commit/push/deploy unless authorized, verify stronger boundary before claim.

# 6. Work item

Every burner starts a narrowly scoped `docs/work/active/WI-...md` using package template. It lists objective, claimed package sections/annexes/registry rows, invariants, scope/non-goals, migration/API/event changes, failure/recovery, verification target and runtime boundary.

# 7. Go baseline

- current supported Go release chosen at repo creation and pinned in `go.mod`/CI;
- `context.Context` first arg for request/IO methods, never stored in struct;
- wrap errors with semantic context, compare typed/sentinel categories with `errors.Is/As`;
- no panic for expected domain input;
- explicit constructors for dependencies;
- interfaces owned by consumer when abstraction useful;
- keep transactions in service/repository boundary with callback/helper that does not hide external I/O;
- structured logger passed/configured centrally;
- Clock/provider adapters injected where nondeterminism/external dependency matters.

# 8. SQL

Parameterized queries. Prefer explicit SQL/repository methods over magic ORM behavior that hides locking/constraints. Every list query matches documented filters/order/index. Transactions state lock order.

# 9. Migrations

Numbered immutable SQL migrations or chosen migration framework with exact files. Migration tool supports status/current/up and safe explicit down only where valid. App startup never silently edits migration ledger.

Migration review checks locks, table rewrite/backfill, FK validation, index build strategy, constraints and rollback/refusal semantics.

# 10. Config

Typed config struct loaded from ignored local env + process environment. `.env.example` generated/maintained from Annex 17. Startup validates all enabled-feature requirements. Tests can instantiate config without reading developer machine env unexpectedly.

# 11. Router/middleware order

Conceptual order:

```text
recovery/security headers
request ID
safe access logging/metrics
body size/CORS as route class needs
authentication
rate limiting/abuse (may need auth result)
authorization/ownership
handler
```

Internal HAL routes use service auth middleware distinct from human auth.

# 12. JSON/API types

Transport DTOs are explicit, not raw DB models. Domain enum validation centralized. Sensitive fields omitted by construction. OpenAPI schemas generated/verified from same contract approach, but generated output never silently becomes semantically stronger than domain code.

# 13. IDs/time

Follow Annex 43. No ad hoc `time.Now()` in deterministic domain evaluators. No sequential public IDs unless explicitly approved.

# 14. OpenAPI

Every implemented HTTP operation appears in canonical repository OpenAPI with auth, request/response, error codes, pagination/idempotency/version headers and examples for complex flows. Runtime route parity test fails on undocumented route or missing OpenAPI operation.

# 15. CI

Minimum Annex 18 commands plus:
- migration apply on fresh PostgreSQL;
- schema/registry consistency verifiers;
- CMS-HAL fixture compatibility in both repos;
- OpenAPI lint/parity in CMS;
- `git diff --check` and generated-artifact drift checks.

# 16. Commit discipline

Do not broad-stage unrelated changes. Inspect staged diff. Commit one coherent burner/corrective slice when authorized. Push then verify remote SHA. Deployment is a separate authorized action/evidence record.

# 17. Bootstrap first commit

B00.1/B00.2 establish repository docs, module, config skeleton, migration tool, DB connection, health/version, CI and package provenance marker before business features. Do not build speculative domain tables in bootstrap burner.
