# Frontend Projection and Integration Contracts

**Status:** Normative scoped annex.
**Owns:** common User/Driver/Admin client bootstrap, state/realtime reducer, action availability, offline/cache/error behavior and privacy handling.

# 1. Frontend law

Frontend is a first-class consumer but not authority. It uses server-provided state/action availability and cannot recreate business truth from button presses or SSE alone.

# 2. Shared bootstrap

For each plane:
1. restore secure refresh/session handle if platform permits;
2. refresh/login to obtain plane access token;
3. load `/me`/bootstrap capabilities/profile/current work summary;
4. load screen durable REST snapshots;
5. request realtime ticket for only subscriptions needed;
6. attach SSE and reduce events by resource version;
7. on gap/resync, refetch snapshot.

Do not open a global all-data realtime stream for every screen.

# 3. User projection

User app presents:
- profile/saved+temporary vehicles/addresses;
- create/scheduled service request and quote breakdown;
- current job snapshot: state, assigned Driver presentation, ETA/location freshness, service address/vehicle snapshot, charging projection, cost estimate/final, payment/invoice;
- history/invoices/ratings/support/notifications.

Driver personal/private fields are not cached merely because Admin has them elsewhere.

# 4. Driver projection

Driver app presents:
- recruitment/onboarding state;
- schedule/current duty and actual assets/mismatch;
- go online/offline readiness blockers;
- offers with expiry and explicit accept/reject result;
- current job/customer fulfillment data/navigation;
- arrival/service/charging controls based on server actions;
- HAL readiness/fault summary;
- earnings ledger/summary;
- incidents/support/notifications.

Receiving an SSE offer does not mark accepted locally. POST response/REST state is authority.

# 5. Admin projection

Admin bootstraps own capabilities, then navigation/actions are capability-aware. Hidden UI is ergonomics only; backend still enforces. Admin operations show intended vs observed vs runtime vs historical states distinctly, never one overloaded "status".

# 6. Server action availability

Detail projections SHOULD include `allowed_actions` or equivalent stable action descriptor where state-dependent workflows are complex. Client can also derive cosmetic state, but must handle server rejecting a stale action with machine error.

Example:

```json
{"allowed_actions":["cancel_job","start_charging"]}
```

Do not expose an action that backend can never accept under current state, but UI always handles races.

# 7. Optimistic UI

Allowed for reversible local presentation such as read notification, favorite/saved label where server contract permits. Not allowed to declare:
- job assigned/completed;
- charging physically started/stopped;
- payment captured/refunded;
- invoice ready;
- Driver offer accepted;
- Admin charger command physically executed.

Show pending intent until authoritative response/projection.

# 8. Realtime reducer

Store latest cursor separately from domain cache. For resource event:
- duplicate event ID -> ignore;
- resource version <= local -> ignore stale;
- safe next/delta -> reduce;
- unknown payload version/type -> do not corrupt state; refetch if resource relevant;
- gap/resync control -> refetch snapshot.

Terminal/fault event can trigger immediate refetch even if delta sufficient for safety.

# 9. Location UI

Every shown ETA/location has freshness/provenance. If stale/unavailable, say unavailable/stale rather than leaving moving marker as if live. User only sees assigned Driver location when server authorizes current job phase.

# 10. Charging UI

Separate:
- start/stop request pending;
- HAL command outcome if useful;
- physical charging state;
- meter/SoC freshness;
- cost projection;
- reconciliation/unknown state.

Never show "Charging" solely on HTTP start request success.

# 11. Error handling

Machine codes map to deterministic UX/recovery. Examples:

```text
UNAUTHENTICATED -> refresh/login
RESOURCE_NOT_FOUND -> remove/stale navigation or privacy-safe not found
RESOURCE_VERSION_MISMATCH -> refetch and reapply user edit intentionally
IDEMPOTENCY...DIFFERENT_REQUEST -> programming/client retry error
OFFER_NO_LONGER_AVAILABLE -> close offer and refresh duty
REALTIME_RESYNC_REQUIRED -> silent snapshot refresh + reconnect
HAL_UNAVAILABLE -> show command unavailable/pending truth, not fake failure if outcome unknown
```

# 12. Idempotency key lifecycle

Client generates one key when user starts one logical mutation. Same key survives retry after timeout/app reconnect until server outcome known. A genuinely new user action gets new key. Do not regenerate key for every network retry.

# 13. Cache/offline

Sensitive tokens stored only platform secure storage. Cached job/profile data is private local data and cleared on logout/account switch according to platform ability. Offline screens label data stale. Offline queued mutations are permitted only for explicitly safe/idempotent operations; charging/dispatch/payment state-changing actions are not blindly queued.

# 14. PII

Do not persist unnecessary KYC/support/address/location data in analytics, crash reports or unencrypted generic storage. Redact network logs in development tooling before sharing.

# 15. Compatibility

Client ignores additive unknown response fields. For enum/event it does not understand, choose safe generic rendering/refetch rather than crashing. Breaking contract requires coordinated version support.

# 16. Frontend acceptance

For each surface, integration tests cover auth refresh, bootstrap, normal mutation, same-key retry, stale version, SSE disconnect/replay/resync, permission change, offline/stale display and no exposure of prohibited fields. Use frontend handoff template for each implemented program/release.
