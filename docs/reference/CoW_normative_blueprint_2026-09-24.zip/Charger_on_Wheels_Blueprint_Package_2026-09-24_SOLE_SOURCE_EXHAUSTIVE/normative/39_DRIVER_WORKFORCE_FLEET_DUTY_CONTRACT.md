# Driver Workforce, Fleet, Scheduling, and Duty Contract

**Status:** Normative scoped annex.
**Owns:** recruitment/onboarding separation, fleet registry, assignment/pairing history, schedules, duty sessions, asset claims and mismatch handling.

# 1. Human identity separation

Account authentication is common, but DriverApplication, DriverProfile and Driver operational state are separate durable concepts. Approval is not current operational eligibility.

# 2. Recruitment

Canonical application transitions are Appendix A. Required KYC/document set is business/legal decision-gated. Document replacement creates new record/version and preserves review evidence. Admin decisions require reason and audit event.

`ACTIVE` recruitment/onboarding status is not a substitute for `driver_profiles.eligibility_status` or suspension/offboarding state.

# 3. Fleet master data

`ServiceVehicle`, `Charger`, `ChargerConnector` have stable identities independent of assignments. Soft lifecycle states preserve history. Registration/insurance/inspection/maintenance facts have explicit validity dates/status; a stale validity record does not magically mean valid.

# 4. Vehicle-Charger pairing

Pairing is effective-dated intended/master truth. At most one active exclusive pairing per Charger and, where business hardware implies it, per Vehicle slot. Re-pairing closes old effective period then creates new row atomically.

Historical ServiceJob/DutySession snapshots are never rewritten by later pairing edit.

# 5. Driver asset assignment

Assignment is Admin intent and can be schedule-bound/time-bound/mandatory/suggested. It is not a live exclusive claim. Driver can still report observed reality according to policy.

# 6. Schedule

Schedule stores planned start/end, optional asset assignment, operating area and constraints. Schedule occurrence is immutable identity for a concrete recurrence. Actual duty timestamps are separate.

Overlapping schedules can exist only if policy explicitly allows and no two mandatory occurrences require impossible simultaneous work. Validation happens at creation/activation.

# 7. Duty start

Duty start transaction:
1. authenticate Driver;
2. lock Driver current-duty guard;
3. validate eligibility/suspension/schedule policy;
4. resolve intended/selected/observed Vehicle+Charger;
5. lock claimable asset guards in canonical order `vehicle -> charger` sorted by UUID within class;
6. validate inventory/maintenance/validity/pairing/HAL identity;
7. create DutySession snapshot;
8. create exclusive claims;
9. record mismatch if observed differs;
10. commit operational event/outbox.

Two sessions cannot claim the same exclusive asset.

# 8. Duty operational state

State machine is Appendix A. `is_online` is not stored as independent truth; dispatchability is derived from active DutySession + operational state + eligibility/freshness/assets.

Break/Unavailable retains claims unless policy explicitly releases them. Duty cannot end with blocking active job/charging without an emergency reconciliation path.

# 9. Mismatch

Expected and observed Vehicle/Charger are both preserved. Driver report never silently edits registry. Temporary observed asset requires policy/capability/safety validation and enough identity/capability evidence to operate.

Admin resolution can confirm correction, restore expected, reassign, reject report or otherwise resolve. Resolution updates master data only through its own audited operation.

# 10. Maintenance/lifecycle

Entering MAINTENANCE/OUT_OF_SERVICE checks active claims/jobs. Unsafe immediate deactivation requires explicit emergency action and downstream job/Driver reconciliation. Normal maintenance scheduling cannot strand an active duty silently.

# 11. Eligibility derivation

Driver dispatch eligibility reason set includes recruitment/onboarding, suspension/offboarding, required-document expiry, schedule policy, active duty, operational state, fresh location, valid asset claims, unresolved blocking mismatch and any safety incident restriction.

Admin UI displays reasons, not one opaque boolean.

# 12. Verification

PostgreSQL race tests: duplicate duty start, same Vehicle/Charger claimed by two Drivers, schedule boundary, maintenance race, mismatch report during duty, Admin reassignment while active, document expiry affecting next duty but not historical session, and emergency duty termination recovery.
