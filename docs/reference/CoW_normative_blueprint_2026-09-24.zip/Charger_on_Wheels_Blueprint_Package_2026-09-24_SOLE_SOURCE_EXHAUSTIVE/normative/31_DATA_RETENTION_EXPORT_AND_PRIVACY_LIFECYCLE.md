# Data Retention, Export, and Privacy Lifecycle

**Status:** Normative scoped annex.
**Owns:** retention classes, deletion/anonymization principles, account closure, legal hold, cleanup and exports. Exact legal durations remain decision-gated where law/business input is required.

# 1. Retention classes

```text
CORE_BUSINESS_HISTORY
FINANCIAL_LEGAL
SECURITY_AUDIT
KYC_SENSITIVE
SUPPORT_INCIDENT
LOCATION_HIGH_VOLUME
HAL_RAW_TRACE
REALTIME_REPLAY
NOTIFICATION_INBOX
AUTH_EPHEMERAL
```

Each table/object maps to one class in repository data inventory.

# 2. Immutable business truth

ServiceJob snapshots, charging facts needed for settlement/history, finalized pricing/compensation, payment/refund and invoice legal history are not deleted merely because current master record is edited. Retention/anonymization must preserve required integrity.

# 3. Realtime replay

Default 24h then delete `realtime_events`/targets. This does not delete domain history or notifications.

# 4. Location

Raw high-frequency Driver location is privacy-sensitive and bounded. Initial development default 30 days is not production legal decision. Downsampled/derived route distance needed for finalized pricing/comp can be retained as source fact without retaining every raw point indefinitely, subject to dispute/legal policy.

User access to assigned Driver live location ends with allowed job phase; API never exposes historical Driver trace as customer feature by default.

# 5. HAL trace

Raw/sanitized protocol trace is technical evidence with bounded retention (initial 30d baseline). Immutable normalized facts required for charging/commercial truth have longer business-history retention. Cleanup never removes fact needed by retained session.

# 6. Auth ephemeral

Expired OTP/challenges, access token digests and expired realtime tickets are periodically purged after security investigation grace. Revoked session metadata may be retained longer for security audit without retaining usable token.

# 7. Notifications

Inbox can have product retention (initial 365d baseline) and user-facing cleanup. Deleting notification does not delete domain event/payment/job history it referenced. External provider delivery metadata follows similar bounded operational retention.

# 8. Support/incidents

Retention value decision-gated. Attachments may have shorter/stricter policy than ticket metadata. Incident evidence involving safety/legal dispute can be held explicitly.

# 9. KYC

Collect only decided required documents. Encryption/private storage/access audit. Retention/deletion after rejection/offboarding/legal expiry is a legal/business gate. Until resolved, production cleanup does not guess destructive duration.

# 10. Financial/legal

Invoices/tax/payment/refund retention follows applicable legal/accounting decision. Anonymization cannot invalidate legally required identity/artifact; lawful retention basis documented.

# 11. Account closure

Closure workflow:
1. authenticate/verify request according to policy;
2. block new activity;
3. end/reconcile active jobs/payments/duty as applicable;
4. revoke sessions/devices;
5. mark principals closed/inactive;
6. schedule deletable profile/preferences data;
7. anonymize retained business history where legally/operationally permissible using stable non-reversible subject token;
8. preserve legal/safety/financial records required;
9. record audit/closure result.

Do not cascade-delete jobs/payments/invoices.

# 12. Driver offboarding

Similar: revoke eligibility/sessions as policy, remove future schedules, reconcile active assets/jobs, retain historical duty/comp/incident records, clean KYC according to policy.

# 13. Legal hold

A hold can target account/Driver/job/incident/time/class and prevents cleanup of covered records/objects. Hold create/release is Admin legal/security capability, reasoned/audited. Cleanup queries exclude holds.

# 14. Cleanup workers

Small bounded batches, deterministic due criteria, metrics count/oldest, idempotent deletes/anonymizations, no huge table locks. Sensitive deletion has audit summary count/class, not copied PII.

# 15. Export privacy

Customer data export returns own supported profile/master/history according to product/privacy policy, not internal security secrets/raw Admin audit/other-user identities. Driver export similarly scoped. Admin bulk export capability-filtered and audited.

# 16. Backups

Backups can outlive primary-row deletion until backup retention expiry. Privacy docs state this. Restore into isolated environment applies access control and may require re-running deletion ledger/reconciliation if a backup predates privacy deletion.

# 17. Data inventory

Repository maintains table/object -> owner -> PII class -> retention class -> deletion/anonymization method -> legal hold support. Schema changes adding PII update inventory and frontend/API privacy projection.
