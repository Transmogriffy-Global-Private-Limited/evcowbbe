# API Endpoint and Payload Catalog

**Status:** Normative scoped annex.
**Owns:** representative/critical DTO shapes and endpoint-family semantics. `registries/api_endpoints.csv` is the machine inventory. Repository OpenAPI becomes field-level machine authority for implemented operations but cannot contradict this package.

# 1. Common DTOs

Money:

```json
{"amount_minor":12345,"currency":"INR"}
```

Geo point:

```json
{"latitude":22.57,"longitude":88.36,"accuracy_m":15.0}
```

Versioned resource metadata may include:

```json
{"id":"uuid","version":7,"created_at":"...","updated_at":"..."}
```

# 2. CustomerVehicle

```json
{
  "id":"uuid",
  "saved":true,
  "label":"My EV",
  "make":"...",
  "model":"...",
  "variant":null,
  "registration_number":"...",
  "battery_capacity_wh":50000,
  "connector_types":["CCS2"],
  "supports_ac":true,
  "supports_dc":true,
  "max_ac_power_w":11000,
  "max_dc_power_w":60000,
  "version":3
}
```

Unknown capability is null/empty with explicit semantics, not fabricated.

# 3. CustomerAddress

```json
{
  "id":"uuid",
  "saved":true,
  "label":"Home",
  "address_line1":"...",
  "address_line2":null,
  "locality":"...",
  "city":"...",
  "state":"West Bengal",
  "postal_code":"...",
  "country_code":"IN",
  "latitude":22.57,
  "longitude":88.36,
  "landmark":null,
  "access_instructions":null,
  "is_default":false,
  "version":2
}
```

# 4. Create service request

```json
{
  "vehicle": {"customer_vehicle_id":"uuid"},
  "service_address": {"customer_address_id":"uuid"},
  "schedule": {"mode":"IMMEDIATE"},
  "charging_preference": {
    "mode":"FASTEST_AVAILABLE",
    "target_energy_wh":20000,
    "target_soc_percent":80,
    "max_duration_seconds":null
  }
}
```

Temporary vehicle/address use inline typed object instead of saved ID; exactly one saved reference or inline object per concept.

Response includes request ID, compatibility/serviceability result and quote workflow link/state.

# 5. Quote

```json
{
  "id":"uuid",
  "service_request_id":"uuid",
  "status":"VALID",
  "expires_at":"...",
  "currency":"INR",
  "line_items":[
    {"type":"VISIT_FEE","amount_minor":5000,"estimated":false}
  ],
  "subtotal_minor":5000,
  "tax_minor":0,
  "total_minor":5000,
  "assumptions":[],
  "pricing_policy_version":4
}
```

Acceptance is idempotent and creates/returns ServiceJob.

# 6. User ServiceJob projection

```json
{
  "id":"uuid",
  "version":12,
  "state":"EN_ROUTE",
  "scheduled_window":null,
  "vehicle_snapshot":{},
  "service_address_snapshot":{},
  "assignment": {
    "driver":{"display_name":"..."},
    "service_vehicle":{"display_label":"..."},
    "eta":{"duration_s":600,"distance_m":4200,"observed_at":"...","approximate":false},
    "location":{"latitude":22.57,"longitude":88.36,"observed_at":"...","fresh":true}
  },
  "charging":null,
  "commercial":{"projected_total_minor":5000,"currency":"INR"},
  "allowed_actions":["cancel_job"],
  "updated_at":"..."
}
```

Projection omits Driver private contact/KYC/Admin notes.

# 7. Charging projection

```json
{
  "state":"CHARGING",
  "charging_session_id":"uuid",
  "started_at":"...",
  "energy_delivered_wh":4320,
  "soc_percent":44,
  "power_w":null,
  "meter_observed_at":"...",
  "meter_fresh":true,
  "soc_observed_at":"...",
  "soc_fresh":true,
  "stop_request_state":null,
  "reconciliation_required":false
}
```

# 8. Start charging

```text
POST /api/v1/app/jobs/{job_id}/charging/start
POST /api/v1/driver/jobs/{job_id}/charging/start   # if business flow permits Driver action
POST /api/v1/admin/jobs/{job_id}/charging/start    # capability-gated intervention
```

Body:

```json
{"connector_id":"uuid","target_energy_wh":20000,"target_soc_percent":80,"max_duration_seconds":7200}
```

Uses `Idempotency-Key`. Response returns start-intent/command projection, never claims physical session until fact arrives.

# 9. Stop charging

Plane-appropriate endpoint under job/charging session. Body includes reason enum. Uses idempotency. Response returns stop-request state; physical session can remain active until HAL evidence.

# 10. Driver duty start

```json
{
  "schedule_occurrence_id":"uuid|null",
  "asset_selection": {
    "service_vehicle_id":"uuid",
    "charger_id":"uuid",
    "observed_pairing_differs":false
  },
  "driver_geofence": null
}
```

Response includes DutySession, snapshotted assets, claim status, mismatch, readiness blockers and allowed actions.

# 11. Driver location ingest

```text
POST /api/v1/driver/duty/{duty_session_id}/location
```

```json
{
  "client_sample_id":"uuid",
  "observed_at":"...",
  "latitude":22.57,
  "longitude":88.36,
  "accuracy_m":12.0,
  "speed_mps":4.0,
  "heading_deg":110.0
}
```

Older sample returns success/no-op or accepted historical result per OpenAPI; never regresses current location.

# 12. DispatchOffer Driver projection

```json
{
  "id":"uuid",
  "job_id":"uuid",
  "expires_at":"...",
  "service_location_summary":{},
  "vehicle_requirement_summary":{},
  "estimated_route":{"distance_m":4200,"duration_s":600},
  "allowed_actions":["accept","reject"]
}
```

Accept/reject mutation uses idempotency. Customer identity fields beyond fulfillment need are omitted.

# 13. Arrival

Driver action records current location evidence and optional reason/override context. Server validates current assignment and proximity policy. Failure returns `422 ARRIVAL_VALIDATION_FAILED` with safe distance/required radius where useful.

# 14. Wrap-up/complete

Driver submits bounded closeout facts/notes permitted by policy. Server checks no active physical charging and required incident/commercial conditions. Job completion may be asynchronous if finalization/payment/invoice continues; public job state distinguishes operational complete vs commercial artifacts as canonical defines.

# 15. Admin assignment/reassignment

Request names job, target Driver/DutySession and reason. Backend validates eligibility/assets and writes assignment history. `force` boolean is not a generic bypass; any exceptional mode is a named action/reason with hard invariant checks.

# 16. Support reply

```json
{"body":"...","idempotency_key":"uuid-or-header-consistent"}
```

Prefer header idempotency as API-wide standard; body field must not create competing identity. OpenAPI chooses one. Message response uses audience-safe author projection.

# 17. Rating

```json
{"rating":5,"review":"optional"}
```

PUT/replace semantic can make edit naturally idempotent by job owner; API registry/OpenAPI freezes exact method.

# 18. Policy create/activate

Admin pricing/compensation policies use separate DRAFT creation/edit and named activate/retire actions. Activation response returns immutable active version/effective interval and validation summary.

# 19. Payment order/verification/refund

Payloads contain internal IDs/amount/currency/provider-safe client parameters only. Provider secret never exposed. Verification endpoint accepts provider evidence needed for adapter, but server rechecks amount/order/account from durable truth.

# 20. Realtime/device/notification

Owned exactly by Annex 10 and represented in `registries/api_endpoints.csv`.

# 21. Endpoint inventory rule

Every operation in `registries/api_endpoints.csv` has one repository OpenAPI operation when implemented. New implementation-discovered route must first be classified under package change control or be an implementation detail that does not alter external contract. No undocumented production handler.
