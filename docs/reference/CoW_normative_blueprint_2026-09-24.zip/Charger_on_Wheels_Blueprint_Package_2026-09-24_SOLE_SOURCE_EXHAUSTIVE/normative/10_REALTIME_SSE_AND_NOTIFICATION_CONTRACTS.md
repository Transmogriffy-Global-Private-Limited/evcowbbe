# Realtime SSE and Notification Contracts

**Status:** Normative scoped annex.
**Owns:** exact client realtime transport and human notification delivery semantics. HAL -> CMS fact/trace ingress is a separate service boundary owned by canonical Sections 19-20 and Annex 34.

# 1. Four separate event planes

Do not collapse these:

1. **HAL fact plane**: physical/protocol truth from HAL to CMS. Durable, service-authenticated, can change business state.
2. **CMS domain event/outbox plane**: internal durable events created with authoritative CMS mutations. Drives workers/projections.
3. **Client realtime plane**: audience-safe SSE hints/projections. Improves latency; never sole durable truth.
4. **Human notification plane**: durable in-app inbox plus optional push/email delivery. User-facing communication, not domain authority.

A message being delivered on one plane is never evidence that another plane succeeded.

# 2. Realtime transport choice

V1 client realtime transport is Server-Sent Events (SSE). WebSocket is not required for v1 because clients mainly receive server state changes and mutations already use HTTP. A future transport can be added behind the same event envelope/recovery semantics.

Exact endpoints:

```text
POST /api/v1/app/realtime/tickets
GET  /api/v1/app/realtime/stream?ticket={opaque_ticket}

POST /api/v1/driver/realtime/tickets
GET  /api/v1/driver/realtime/stream?ticket={opaque_ticket}

POST /api/v1/admin/realtime/tickets
GET  /api/v1/admin/realtime/stream?ticket={opaque_ticket}
```

The old EV-CMS `/operations/realtime/*` family is not part of this product.

# 3. Why tickets exist

Browser/native EventSource implementations cannot reliably attach arbitrary Authorization headers. The authenticated POST creates a short-lived, single-use stream ticket. The normal bearer access token MUST NOT be put in an SSE URL.

Ticket response:

```json
{
  "data": {
    "ticket": "opaque-secret",
    "expires_at": "...",
    "stream_url": "/api/v1/app/realtime/stream?ticket=...",
    "authorized_subscriptions": ["self", "job:uuid"],
    "resume_after": "rt1..."
  }
}
```

Ticket rules:
- at least 256 bits CSPRNG entropy;
- only a keyed hash/digest stored server-side;
- default TTL 60 seconds; configurable range 15..120 seconds;
- single-use atomic consumption;
- bound to account, principal plane, session ID, subscription set and optional resume cursor;
- expired/reused/wrong-plane/wrong-session/revoked ticket returns `401 REALTIME_TICKET_INVALID`;
- stream ticket is a secret and MUST be scrubbed from reverse-proxy/app access logs.

# 4. Subscription grammar

Ticket request:

```json
{
  "subscriptions": ["self", "notifications", "job:uuid"],
  "resume_after": "rt1..."
}
```

V1 topic grammar:

User:
```text
self
notifications
job:{service_job_id}
support:{ticket_id}
```

Driver:
```text
self
notifications
offers
job:{service_job_id}
duty:{duty_session_id}
support:{ticket_id}
```

Admin:
```text
self
notifications
operations
dispatch
fleet
hal
finance
support
job:{service_job_id}
driver:{driver_id}
charger:{charger_id}
```

Every requested subscription is server-authorized at ticket creation. An invalid/unauthorized subscription rejects the whole ticket request so the client never assumes partial coverage it did not explicitly process.

Admin broad topics require mapped capabilities. Resource IDs never grant access by possession.

# 5. SSE HTTP response

Successful stream response:

```text
HTTP/1.1 200 OK
Content-Type: text/event-stream
Cache-Control: no-cache, no-transform
Connection: keep-alive
X-Accel-Buffering: no
```

CORS/credentials follow Annex 11. Reverse proxy buffering MUST be disabled for stream route.

SSE record:

```text
id: rt1.<opaque-cursor>
event: job.state_changed
data: {"event_id":"uuid",...}

```

Heartbeat is a comment so it does not enter application reducers:

```text
: ping 2026-09-24T12:00:00Z

```

Default heartbeat: 15s. Client treats 45s with no bytes as dead and reconnects with bounded jittered backoff.

# 6. Event envelope

Every application event contains:

```json
{
  "event_id": "uuid",
  "type": "job.state_changed",
  "occurred_at": "...",
  "resource": {
    "type": "service_job",
    "id": "uuid",
    "version": 42
  },
  "correlation_id": "uuid|null",
  "payload_version": 1,
  "data": {},
  "recovery": {
    "snapshot_path": "/api/v1/app/jobs/uuid"
  }
}
```

Rules:
- `event_id` globally unique and immutable;
- `type` is from `registries/realtime_events.csv`;
- resource version is monotonic durable projection version;
- payload is audience-safe and intentionally smaller than full REST representation;
- snapshot path is authorized for the same audience or null when no resource snapshot exists;
- event never embeds access token, provider secret, raw HAL payload, KYC document or unnecessary PII.

# 7. Durable replay log

CMS stores a bounded client-realtime log separate from business event truth:

```text
realtime_events
  seq bigint generated monotonic primary replay sequence
  id uuid unique
  type text
  resource_type text
  resource_id uuid nullable
  resource_version bigint nullable
  occurred_at timestamptz
  payload_version int
  payload jsonb
  recovery_snapshot_path text nullable
  expires_at timestamptz

realtime_event_targets
  realtime_event_id uuid FK
  topic_type text
  topic_id text nullable
  required_capability text nullable
  primary key (...)

realtime_stream_tickets
  id uuid
  ticket_digest bytea unique
  account_id uuid
  principal_plane text
  session_id uuid
  subscriptions jsonb
  resume_after_seq bigint nullable
  expires_at timestamptz
  consumed_at timestamptz nullable
```

Default replay retention: 24 hours. Cleanup never deletes the underlying durable domain/job/payment/etc truth.

# 8. Opaque replay cursor

Public cursor is `rt1.<base64url-payload>.<base64url-hmac>` or equivalent signed opaque form. Payload can encode replay sequence and binding metadata, but clients MUST NOT parse it.

Cursor signature uses dedicated `REALTIME_CURSOR_HMAC_SECRET`. Cursor is bound to account/principal plane so one account cannot probe another stream history.

# 9. Replay and live handoff

When a ticket includes `resume_after`:
1. validate/bind cursor;
2. determine current high-water sequence in one consistent DB view;
3. replay authorized events `(cursor_seq, high_water]` in order;
4. attach to live publisher starting after high-water without a gap;
5. duplicates are allowed across a reconnect boundary, gaps are not.

If cursor is older than retained replay or references incompatible stream binding, return:

```text
409 REALTIME_RESYNC_REQUIRED
```

with safe recovery metadata. Client refetches durable snapshots, discards prior cursor, obtains a new ticket and reconnects.

# 10. Stream control events

Exact control events:

```text
stream.ready
stream.shutdown
stream.resync_required
access.revoked
```

`stream.ready` includes connection ID, server time, current cursor and heartbeat interval.

`stream.shutdown` is best-effort before planned server drain. Client reconnects.

`access.revoked` means the current subscription/session can no longer receive protected data. Client MUST stop using cached restricted state and rebootstrap auth/snapshots as applicable.

# 11. Ordering and duplicates

SSE order is replay-sequence order, not guaranteed business causal order across unrelated resources. For one resource, clients use `resource.version`:
- lower/equal version than local => ignore as duplicate/stale unless event is explicitly append-only;
- next/newer version => reduce or refetch according to frontend contract;
- suspicious version gap => refetch durable snapshot.

Clients MUST tolerate duplicate event IDs and connection retries.

# 12. Backpressure and connection bounds

Defaults:

```text
max connections per account: 4
max connections per session: 2
max subscriptions per connection: 32
outbound queue: 256 events OR 1 MiB, whichever first
```

A slow client that exceeds bounds is disconnected and must replay/resync. Server MUST NOT allow unbounded per-connection memory.

High-frequency coalescing defaults:

```text
User driver-location event:       minimum 3000 ms
Admin driver-location event:      minimum 2000 ms
charging meter projection event:  minimum 2000 ms
```

Coalescing may replace only superseded high-frequency projection updates. Terminal state, fault, security, payment, assignment and lifecycle transitions are never silently coalesced away.

# 13. Realtime event families

Registry owns exact names. Families include:

```text
account/session
service request/quote/job
assignment/dispatch offer
driver duty/location
fleet/charger availability
charging session/meter/SoC/fault
payment/refund/invoice
compensation refresh
rating/support/incident
notification inbox
```

HAL trace messages are NOT client realtime events. Technical Admin events summarize safe normalized changes and link to technical detail APIs.

# 14. Audience rules

User events reveal only own resources and safe Driver/service information required for fulfillment.

Driver events reveal only own duty, eligible offers, assigned jobs and permitted customer fulfillment fields.

Admin events are capability-filtered. Broad `operations` topic never automatically includes finance, KYC or raw technical evidence.

# 15. Notification model

Notifications are durable resources:

```text
notifications
  id
  account_id
  principal_plane
  trigger_key
  template_key
  template_version
  title
  body
  deep_link nullable
  params jsonb
  dedupe_key
  priority
  created_at
  read_at nullable

notification_deliveries
  id
  notification_id
  channel            # PUSH|EMAIL; SMS reserved
  destination_ref
  state
  attempt_count
  next_attempt_at
  provider_message_id nullable
  last_error_class nullable
  claimed_by/token/lease
  created_at/updated_at

notification_preferences
  account_id
  principal_plane
  category
  push_enabled
  email_enabled
  updated_at
```

IN_APP is the durable notification itself, not a `notification_deliveries` provider row.

# 16. Notification delivery states

```text
PENDING
CLAIMED
PROVIDER_ACCEPTED
DELIVERED
FAILED_RETRYABLE
FAILED_TERMINAL
SUPPRESSED
CANCELLED
```

Use DELIVERED only when provider supplies trustworthy delivery receipt semantics. Provider API 2xx acceptance maps to PROVIDER_ACCEPTED unless stronger evidence exists.

# 17. Dedupe

One logical notification trigger has deterministic dedupe key, for example:

```text
{trigger_key}:{recipient_account}:{resource_type}:{resource_id}:{resource_version-or-event-id}
```

Unique recipient+dedupe prevents duplicate logical notification from outbox retry. Each external channel has one logical delivery row per notification/channel/destination generation.

# 18. Device registration endpoints

User:
```text
GET    /api/v1/app/devices
POST   /api/v1/app/devices
DELETE /api/v1/app/devices/{device_id}
```

Driver:
```text
GET    /api/v1/driver/devices
POST   /api/v1/driver/devices
DELETE /api/v1/driver/devices/{device_id}
```

Admin, only if Admin client uses push:
```text
GET    /api/v1/admin/devices
POST   /api/v1/admin/devices
DELETE /api/v1/admin/devices/{device_id}
```

Registration request:

```json
{
  "platform": "ANDROID|IOS|WEB",
  "provider": "FCM|APNS|WEBPUSH",
  "token": "opaque-provider-token",
  "app_instance_id": "opaque-stable-install-id",
  "device_label": "optional-user-label"
}
```

Provider token is secret-like and never returned in list response. Upserting same provider token/app instance moves ownership only through authenticated current account and invalidates stale binding safely.

# 19. Notification inbox endpoints

For each plane under `/app`, `/driver`, `/admin`:

```text
GET  /notifications
GET  /notifications/unread-count
PATCH /notifications/{notification_id}/read
POST /notifications/read-all
GET  /notification-preferences
PUT  /notification-preferences
```

List uses signed keyset cursor ordered `created_at DESC, id DESC`. Read/read-all are idempotent.

# 20. Preferences

Trigger registry marks each class as:
- mandatory/security/critical: user cannot suppress required channel defined by policy;
- operational-important: configurable external channels, always in-app when recipient can access app;
- informational/marketing: fully preference-controlled and disabled unless business consent policy permits.

Preference changes affect future delivery attempts; they do not erase existing inbox history.

# 21. Push payload

Push is a wake-up/hint, not full truth. Payload maximum is intentionally small:

```json
{
  "notification_id": "uuid",
  "trigger_key": "JOB_ASSIGNED",
  "resource_type": "service_job",
  "resource_id": "uuid",
  "deep_link": "app://jobs/uuid"
}
```

Do not include address details, support body, KYC, payment secrets or raw charger trace.

# 22. Email

Email render uses versioned templates and bounded params. Domain transaction creates notification intent only; SMTP/provider network I/O is asynchronous. Email provider acceptance is distinct from local outbox success.

# 23. Retry defaults

Push: max 8 attempts across 24h.
Email: max 10 attempts across 72h.

Backoff is exponential with jitter and capped. Permanent invalid device token marks device unusable and delivery terminal. Authentication/provider configuration failure alerts operators and does not hot-loop.

# 24. Workers

`realtime_publisher` reads committed domain/outbox events and creates audience-safe replay events idempotently.

`notification_intent_worker` maps eligible domain event -> trigger -> recipients -> durable notifications/deliveries.

`push_delivery_worker` and `email_delivery_worker` use lease claims. Provider outage does not roll back domain mutation.

# 25. Authorization changes

Session revoke immediately prevents new tickets. Active stream is terminated as soon as revoke reaches stream auth observer; at worst within heartbeat/auth-refresh bound.

Admin capability changes cause broad restricted subscriptions to be reevaluated. Do not continue sending data until ticket expiry merely because ticket was once valid.

# 26. Reconnect algorithm for clients

1. load durable bootstrap/snapshot;
2. retain latest valid cursor from stream;
3. on disconnect request new ticket with `resume_after`;
4. if ticket/stream succeeds, consume duplicate-safe events;
5. if `REALTIME_RESYNC_REQUIRED`, refetch relevant snapshots and reconnect without cursor;
6. if 401/403, refresh/re-auth according to auth flow before retry;
7. exponential backoff on transport/server outage, capped with jitter.

# 27. Metrics

At minimum:

```text
realtime_connections_current{plane}
realtime_connection_attempts_total{plane,result}
realtime_events_persisted_total{type}
realtime_events_delivered_total{type,plane}
realtime_replay_events_total{plane}
realtime_resync_required_total{reason}
realtime_backpressure_disconnects_total{plane}
realtime_publish_lag_seconds
notification_created_total{trigger,plane}
notification_delivery_total{channel,state}
notification_delivery_attempt_total{channel,result}
notification_backlog_age_seconds{channel}
invalid_device_tokens_total
```

# 28. Acceptance

Service-integrated tests MUST prove single-use ticket race, unauthorized topic, replay/live no-gap, duplicate events, stale cursor resync, session/capability revoke, backpressure, server drain, process restart, notification dedupe, preferences, invalid device, provider timeout before/after acceptance, worker restart and final REST convergence.
