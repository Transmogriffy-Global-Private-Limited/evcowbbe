# Durable Domain Event and Outbox Registry

**Status:** Normative scoped annex.
**Owns:** internal domain-event envelope, event naming/versioning, durable consumer semantics and separation from realtime/notifications.

# 1. DomainEvent envelope

```json
{
  "event_id":"uuid",
  "event_type":"service_job.state_changed",
  "event_version":1,
  "aggregate_type":"service_job",
  "aggregate_id":"uuid",
  "aggregate_version":12,
  "occurred_at":"...",
  "actor":{"plane":"DRIVER","id":"uuid"},
  "correlation_id":"uuid|null",
  "causation_event_id":null,
  "payload":{}
}
```

Created transactionally with authoritative mutation when consumers/realtime/notification/audit need durable propagation.

# 2. Event naming

Lowercase dotted semantic names. Name describes committed fact, not imperative. Prefer `job.assignment_changed` over `update_job`.

Machine list is `registries/domain_events.csv`.

# 3. Event families

At minimum:

```text
account.session_revoked
customer.profile_changed
customer.vehicle_saved
customer.address_saved
driver.application_submitted
driver.application_reviewed
driver.eligibility_changed
driver.duty_started
driver.duty_state_changed
driver.duty_ended
driver.location_changed
fleet.vehicle_changed
fleet.charger_changed
fleet.pairing_changed
fleet.mismatch_reported
fleet.mismatch_resolved
service_request.created
quote.created
quote.expired
service_job.created
service_job.state_changed
dispatch.attempt_started
dispatch.offer_created
dispatch.offer_state_changed
job.assignment_changed
charging.start_intent_changed
charging.session_started
charging.session_updated
charging.session_ended
charging.meter_changed
charging.soc_changed
charging.fault_observed
payment.state_changed
refund.state_changed
invoice.state_changed
compensation.calculated
compensation.adjusted
rating.changed
support.ticket_changed
support.message_created
incident.changed
notification.created
```

Exact machine registry can contain more fine-grained rows.

# 4. Payload rule

Payload contains only immutable identifiers and small fields needed by internal consumers. Consumer can refetch aggregate. Do not copy secrets/large support bodies/KYC/raw HAL trace. If a consumer requires immutable before/after fact, include bounded safe typed field or source record reference.

# 5. Storage

Recommended:

```text
domain_events
  event_id uuid PK
  event_type
  event_version
  aggregate_type/id/version
  occurred_at
  actor_plane/id
  correlation_id
  payload jsonb

outbox_deliveries
  event_id
  consumer_key
  state
  attempts
  next_attempt_at
  claim token/lease
  last_error_class
  primary key(event_id, consumer_key)
```

Alternatively a unified outbox row can store event envelope, but immutable event identity and per-consumer retry state must not be overwritten.

# 6. Consumers

Representative mapping:

```text
realtime_publisher <- user/driver/admin relevant state events
notification_intent_worker <- only trigger registry events
analytics/export projections <- explicitly registered
compensation trigger <- finalized job/source-fact events
invoice trigger <- commercial finalization
```

Consumer registration is explicit. Adding consumer with side effect follows work item/verification.

# 7. Idempotency

Consumer output has unique `(consumer_key,event_id)` processing record or output natural unique key. Crash after output commit before delivery ack returns same logical output on retry.

# 8. Ordering

Global total event order is not business contract. Aggregate version orders one aggregate. Consumers needing cross-aggregate coordination use authoritative DB transaction/state or dedicated orchestrator, not hope that queue delivery order is causal.

# 9. Event schema evolution

Additive optional fields can retain version if consumers tolerate. Meaning/type change increments `event_version` and consumers support compatibility window. Do not reuse event name/version with different semantics.

# 10. Event vs Audit vs Realtime vs Notification

- DomainEvent: machine semantic propagation.
- AuditEvent: accountability/security history.
- RealtimeEvent: audience delivery projection.
- Notification: human inbox/message.

One mutation can create several through derived workers, but they are distinct IDs/retention/privacy.

# 11. Integrity tests

For every registered event producer: transaction rollback creates no event; success creates exactly one logical event; same idempotent mutation creates no duplicate semantic event; aggregate version matches committed state; consumer retry is duplicate-safe.
