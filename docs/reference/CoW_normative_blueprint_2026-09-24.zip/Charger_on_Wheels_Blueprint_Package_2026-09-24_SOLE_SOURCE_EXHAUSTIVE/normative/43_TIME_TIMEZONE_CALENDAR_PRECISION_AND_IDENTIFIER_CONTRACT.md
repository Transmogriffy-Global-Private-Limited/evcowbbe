# Time, Timezone, Calendar, Precision, and Identifier Contract

**Status:** Normative scoped annex.
**Owns:** clock semantics, timestamp storage, business timezone, interval boundaries, duration/energy precision and identifier generation.

# 1. Server time

Persist instants as PostgreSQL `timestamptz` in UTC semantics. API emits RFC3339 UTC `Z` unless an endpoint explicitly includes a separate business-local representation.

Business rules that depend on local clock/date reference an IANA timezone stored/pinned on the applicable policy or system setting. V1 default deployment timezone is `Asia/Kolkata`, but policies remain explicit.

# 2. Clock injection

Domain code does not call wall clock everywhere. It receives a Clock abstraction so tests can freeze/advance time. Database `now()` may be used inside one transaction when DB time is the chosen authoritative timestamp, but ownership is consistent within that workflow.

# 3. Trusted vs untrusted time

Server receipt/DB time is trusted for security expiry, leases and provider retry deadlines. Device/charger/customer timestamps are evidence and validated for skew; they never extend auth/session/lease validity.

# 4. Interval convention

Effective time ranges use half-open intervals `[start, end)` unless explicitly stated. Adjacent ranges can meet exactly without overlap. Null `end` means unbounded future.

This convention applies to policies, pairings, assignments, schedules, maintenance periods and retention windows.

# 5. Scheduled local time

Recurring/local business schedules preserve IANA timezone + local intended wall time, then materialize occurrence instants. Do not store only UTC recurrence and assume it will retain wall-clock meaning if timezone rules change.

# 6. Durations

Durations in APIs use integer seconds or milliseconds with unit in field name. Database may use interval only where query semantics are clear; calculated billable/compensable durations freeze integer milliseconds/seconds plus source timestamps.

Negative duration is invalid. End before start is integrity error.

# 7. Energy/power

Canonical energy accounting uses integer watt-hours (`*_wh`) for durable cumulative/delivered energy unless device precision requires a finer exact integer unit introduced versionedly. Power uses watts (`*_w`) or explicit decimal kW only at presentation boundary.

Cumulative meter must be nondecreasing within a transaction identity except explicit meter-reset/device-anomaly evidence handled by reconciliation. Never silently clamp a contradictory raw reading and discard evidence.

# 8. SoC

SoC percentage is integer 0..100 or exact decimal only if hardware meaningfully provides fractional percent and schema explicitly adopts it. Unknown is null, not zero.

# 9. Coordinates/physical decimals

Coordinates use double precision for geometry math or PostGIS. Commercial money never uses float. Rule quantities/rates requiring decimal use exact decimal/numeric with bounded scale defined by field.

# 10. IDs

Public/durable entity identities are UUID v4 or another package-approved random UUID implementation; do not expose sequential DB primary keys as public identity unless explicitly designed. Event/fact/idempotency logical IDs are globally unique and immutable.

Opaque tokens/cursors are cryptographically random/signed values, not UUIDs pretending to be secrets.

# 11. Sorting tie-breakers

Every keyset-paginated order has a stable unique tie-breaker, normally `id`. Timestamp-only cursor ordering is forbidden.

# 12. Tests

Boundary fixtures include exact expiry instant, midnight, month/year transition, policy adjacent intervals, clock skew, stale/fresh thresholds, long-duration charge, meter precision, null SoC and deterministic ID/clock injection.
