# Pricing, Tax, Payment, Refund, and Invoice Contract

**Status:** Normative scoped annex.
**Owns:** arithmetic/rounding, quote/final pricing, tax snapshots, customer payment state, refund safety, invoice finalization and immutable artifacts.

# 1. Money

All durable monetary amounts use integer minor units plus ISO currency. INR uses paise. Floating point is forbidden for money arithmetic. Percentage/rate arithmetic uses exact decimal or rational representation and a documented final rounding boundary.

Default rounding for INR line items/tax is half-up to the nearest paise unless a legally required tax/invoice rule overrides it. That override is a business/legal decision gate and is versioned.

# 2. Pricing evaluation

Every evaluation returns typed line items:

```text
line_item_id
component_type
label_key
quantity_decimal
unit
rate_minor_or_decimal
operator
amount_minor
rule_id / rule_version
source_fact_refs[]
assumption_refs[]
tax_class_ref nullable
```

Evaluation order is deterministic:
1. select one applicable policy version by effective time/scope;
2. evaluate eligibility/conditions;
3. compute base additive components;
4. apply explicit overrides to their target component/basis;
5. apply multipliers in ascending priority then stable rule ID;
6. apply discounts/promotions according to declared pre/post-tax basis;
7. compute taxable bases by tax class;
8. calculate tax using frozen tax snapshot;
9. apply final explicit adjustment rows if authorized;
10. assert subtotal/tax/total identities.

A rule MUST declare its basis and priority. Ambiguous composition is rejected at policy activation.

# 3. Quote

A Quote is an immutable evaluation snapshot with expiry and assumptions. It can include estimated/conditional line items when final quantities are unavailable, but every estimate is labeled. Quote acceptance references exact quote ID/version.

Changing relevant customer location/vehicle/service preference after quote can invalidate it by explicit policy. Expired quote cannot silently become job commercial terms.

# 4. Final pricing

Finalization uses authoritative source facts, not mutable master data:
- route/travel facts according to selected pricing basis;
- arrival/wait/service timestamps;
- HAL charging duration/energy;
- frozen policy/tax/customer/service snapshots;
- approved adjustments.

If a required authoritative fact is unknown/conflicted, finalization enters explicit pending/reconciliation state rather than guessing.

# 5. Tax

Tax configuration is snapshotted at finalization/invoice. Snapshot stores seller/issuer tax identity needed for the artifact, jurisdiction/classification, component tax treatment, rates and calculation basis. Later GST configuration changes never mutate historical finalized commercial rows.

Exact legal GST classification/rates/invoice wording are decision-gated until confirmed for the business model.

# 6. Payment intent/order

Customer collection provider is adapter-backed. Provider order creation is idempotent by internal `payment_id`/idempotency key. Local state is committed before or atomically around provider intent according to adapter contract so retries can reconcile exact provider identity.

Payment states include:

```text
CREATED
PROVIDER_PENDING
AUTHORIZED
CAPTURED
FAILED
CANCELLED
RECONCILIATION_REQUIRED
```

Provider webhook/API evidence is verified cryptographically where supported. Client success callback alone cannot mark CAPTURED.

# 7. Payment reconciliation

Timeout after provider request is outcome-unknown, not failure. Reconciler queries by exact provider order/payment identity. Duplicate webhook is a no-op. Same provider event ID with altered body is integrity conflict.

# 8. Refund

Refund request transaction locks payment/refund aggregate, computes remaining refundable amount from durable captured minus already-finalized/refund-in-flight amounts, creates one immutable refund intent and then calls provider asynchronously or post-commit.

`sum(non-terminal or succeeded refunds) <= refundable captured amount` is DB/service enforced. Duplicate same key returns original logical refund. Provider outcome unknown reconciles by exact provider refund identity.

# 9. Invoice

Invoice is generated only from finalized commercial truth. Invoice identity/version is durable. READY artifact is immutable.

Artifact metadata:

```text
invoice_id, invoice_number, renderer_version, mime_type,
storage_key, byte_size, sha256, generated_at, ready_at
```

Generation flow:
1. transaction claims invoice-generation work;
2. render from frozen invoice model;
3. write to temporary storage key/file;
4. fsync/provider-confirm as appropriate;
5. compute/verify checksum;
6. atomically publish/finalize storage object;
7. transaction marks READY with checksum/renderer version;
8. notification delivery is separate durable intent.

Crash before READY is retryable. Existing READY artifact is never regenerated in place.

# 10. Download authorization

User may download only invoice for own ServiceJob/account. Admin requires finance/invoice read capability. Driver does not gain customer invoice access merely by having serviced job. Storage path/key is never accepted directly from client.

# 11. Adjustments

Post-finalization corrections create explicit commercial adjustment/credit/refund artifacts and audit trail. They do not rewrite original source line items. If legal accounting later requires credit notes, introduce a versioned document type rather than mutating an invoice PDF.

# 12. Arithmetic invariants

Always verify:

```text
subtotal_minor == sum(non-tax priced line items after declared operators)
tax_minor      == sum(tax line items)
total_minor    == subtotal_minor + tax_minor + explicit final adjustments
captured_minor - successful_refund_minor >= 0
invoice.total_minor == finalized commercial total represented by invoice
```

# 13. Verification

Golden fixtures cover rounding boundaries, zero/negative-invalid quantities, discounts, time/date boundaries, quote vs final divergence, duplicate provider webhook, lost API response after capture, partial/full refunds, concurrent refunds, renderer crash, storage crash, checksum mismatch and historical immutability.
