# Physical Hardware Certification and Protocol Matrix

**Status:** Normative scoped annex.
**Owns:** how real charger models/firmware become supported, capability evidence, physical acceptance scenarios and vendor quirks.

# 1. Certification identity

One certification applies to exact tuple:

```text
manufacturer
model
hardware revision if relevant
firmware version/range
protocol family/version
connectivity configuration
critical vendor settings
HAL adapter revision
```

Do not assume same model new firmware behaves identically for critical charging/recovery.

# 2. Capability record

For each certified tuple record observed support:

```text
remote start
remote stop
unlock
availability
reset
diagnostics
smart charging/limit
SoC
meter measurands/units/resolution
connector inventory
transaction identity behavior
heartbeat/status behavior
reconnect behavior
local start/stop if possible
firmware/security features
vendor extensions/quirks
```

Runtime HAL capability can refine current device truth but certification states known tested baseline.

# 3. Required OCPP 1.6 physical scenarios

At minimum for a production-supported charging model:
- connect/BootNotification/heartbeat;
- StatusNotification available/preparing/charging/finishing/faulted where device emits;
- remote start accepted then real StartTransaction;
- remote start rejected;
- remote start response lost/timeout test where controllable;
- periodic MeterValues energy;
- SoC if advertised;
- remote stop then real StopTransaction;
- local unplug/stop;
- charger disconnect/reconnect idle;
- disconnect/reconnect active transaction;
- HAL process restart while charger reconnects;
- CMS outage while HAL fact outbox accumulates;
- duplicate/retransmitted messages if device does so;
- reset/unlock/availability operations actually supported;
- wrong/unknown connector behavior;
- power loss/reboot recovery where safe lab procedure permits.

# 4. OCPP 2.0.1/2.1

Adapter certification must prove semantic parity of normalized facts/commands rather than only protocol handshake. Differences in transaction model/message names stay adapter-internal. Same CMS tests run against protocol adapter fixture and physical device scenarios.

# 5. Meter certification

Record measurand/context/location/unit and whether values are cumulative/import register. Verify unit normalization to Wh, monotonic behavior, restart/reset behavior, final meter consistency and known rounding. If device energy cannot support commercial accuracy, do not silently use it for billing.

# 6. SoC

Record whether charger reports SoC, update cadence/freshness, integer/decimal precision and missing behavior. Never advertise target SoC control if device only reports/does not support enforceable stop semantics.

# 7. Reconnect recovery

Certification includes identity chain after reconnect: does protocol transaction ID persist, does charger replay status/meter/stop, can HAL discover active transaction, what happens after power cycle. Vendor quirk is modeled explicitly in adapter/capability, not generic core special-case.

# 8. Safety/limits

Any automatic energy/time/SoC stop used in production must be tested on real hardware including HAL restart/reconnect and command rejection. Software stop is not substitute for hardware electrical protection.

# 9. Mobile energy hardware

If finite onboard energy REQUIRED, certify telemetry sensor/source, units, update cadence, usable capacity calibration, recharge behavior, disconnect/restart, stale/invalid values and safety reserve. Dispatch must not rely on unverified telemetry path.

# 10. Evidence record

Use template with date/operator/environment, tuple, source revisions, scenario steps, expected/actual, result, trace/fact IDs/log artifact refs, photos if useful, known limitations and approval.

# 11. Support matrix

Maintain machine/human matrix:

```text
model/firmware | protocol | certified adapter rev | start | stop | meter | soc | reconnect | ops | status
```

Statuses: `UNTESTED`, `LAB_ONLY`, `CERTIFIED`, `CONDITIONAL`, `BLOCKED`, `RETIRED`.

# 12. Failure policy

A failed critical certification blocks model/firmware from production dispatch compatibility until adapter/config/hardware correction and re-test. Operations cannot override lack of safe charging capability merely with Admin role.
