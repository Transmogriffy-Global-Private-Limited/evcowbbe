# State Authorization and Transition Registry

**Status:** Normative scoped annex.
**Owns:** who/evidence may cause each major state transition, common transition execution order, and hard invariants not bypassable by Admin.

Canonical state graphs in Appendix A remain authoritative. This annex answers "who may cause this edge and what evidence is required?"

# 1. Transition execution order

Every named transition action follows:
1. authenticate principal/service;
2. authorize ownership/capability;
3. validate idempotency/version;
4. begin transaction and lock aggregate;
5. re-read current state;
6. validate edge + domain preconditions/evidence;
7. mutate authoritative row(s);
8. append immutable history/domain event/audit as required;
9. enqueue outbox/realtime/notification intent in same transaction where applicable;
10. commit;
11. external side effects happen after durable intent unless protocol contract explicitly requires otherwise.

Arbitrary `PATCH status` endpoints are forbidden for state machines.

# 2. DriverApplication

- DRAFT->SUBMITTED: applicant Driver, required fields/docs present per active onboarding policy.
- DRAFT/SUBMITTED/ACTION_REQUIRED->WITHDRAWN: applicant while not terminal/operationally active.
- SUBMITTED->UNDER_REVIEW: Admin `drivers.review` or deterministic system queue action.
- UNDER_REVIEW->ACTION_REQUIRED/APPROVED/REJECTED: Admin `drivers.review`, decision reason required.
- ACTION_REQUIRED->SUBMITTED: applicant after requested corrections.
- APPROVED->ONBOARDING: Admin/system onboarding action.
- ONBOARDING->ACTIVE: Admin/system only when configured onboarding/eligibility prerequisites pass.

Suspension/offboarding belongs DriverProfile operational lifecycle, not application rollback.

# 3. DriverDutySession

Driver may start/end/break/resume own duty subject to policy. Admin may force safety/unavailability/emergency end under `drivers.operate` with reason. System/dispatch drives OFFERED/ASSIGNED/EN_ROUTE/AT_CUSTOMER/SERVICING transitions according to accepted job actions.

No actor may end a duty that has unreconciled active job/charging merely to make status convenient; emergency path records incident and reconciliation obligations.

# 4. DispatchAttempt/Offer

Dispatch worker/system creates attempt/candidates/offers. Driver can accept/reject own unexpired offer. Expiry worker expires. Job cancellation/reassignment can withdraw. Atomic acceptance race determines one winner.

Admin can initiate/override dispatch using `dispatch.manage`, but cannot assign an ineligible/claimed asset/Driver unless explicit emergency/manual exception contract validates every non-bypassable safety invariant.

# 5. ServiceJob

Typical authority:

```text
REQUESTED/QUOTED: Customer + pricing/request system
DISPATCHING/ASSIGNED: dispatch system/Admin dispatch action
ACCEPTED/EN_ROUTE/ARRIVED/SERVICE_PREPARING: assigned Driver actions with evidence
CHARGING: CMS reacts to HAL-backed ChargingSession physical state
WRAP_UP: Driver/system after physical charging inactive and closeout prereqs
COMPLETED: CMS closeout action when operational/commercial prerequisites satisfied
CANCELLED: Customer/Admin/system according to cancellation policy
FAILED/NO_SHOW/EXPIRED: explicit Driver/Admin/system evidence/policy
REASSIGNING: dispatch/Admin workflow
```

A Driver button cannot manufacture CHARGING/COMPLETED when physical/commercial evidence disagrees.

# 6. ChargingStartIntent

Customer/Driver/Admin authorized start request creates durable intent. Worker/CMS->HAL responses can move command delivery/reconciliation states. Only HAL `transaction.started` materializes physical ChargingSession. Expiry does not erase possibility of late physical fact; late fact enters explicit reconciliation if inconsistent with local expired state.

# 7. ChargingSession

Physical lifecycle is HAL-fact driven. CMS/Admin may annotate/reconcile but cannot manually declare physical energy/start/end without an evidence-bearing correction flow. Stop request is separate state machine and command acceptance never equals session ended.

# 8. Generic HAL Operation

Admin with `charging.command` (or system safety controller) may request supported operation. HAL owns delivery/outcome. Possible-delivery uncertainty uses reconciliation, no blind resend.

# 9. Payment

Customer/system creates payment intent. Verified provider evidence drives authorization/capture/failure. Admin finance can initiate permitted reconciliation/refund/adjustment but cannot set CAPTURED by hand. Provider webhook signatures/lookup evidence are required.

# 10. Refund

Customer-support/Admin finance may request according to business policy/capability. Provider evidence drives final success/failure. Concurrent amount invariant cannot be overridden.

# 11. Invoice

System creates/generates from finalized commercial facts. Admin finance may retry failed generation or void/correct through explicit versioned accounting action if supported. READY artifact is immutable.

# 12. Pricing/compensation policy

Admin commercial capability creates DRAFT, validates, activates, retires. ACTIVE historical version cannot be destructively edited. New terms require new version/effective range.

# 13. Support

Ticket owner creates/replies own channel. Admin support reads/replies/status under capability. Owner reply to RESOLVED/CLOSED reopens atomically. Admin cannot access a different principal plane merely because ticket ID is known.

# 14. Incident

Driver/Admin/system may create as allowed. Admin operations/safety capability acknowledges/investigates/resolves. Closing requires resolution facts. Safety consequences are separate explicit actions.

# 15. Asset mismatch

Driver can report current observed mismatch for own duty. Admin fleet capability acknowledges/resolves and separately updates master data when warranted. Resolving report never retroactively changes DutySession snapshot.

# 16. Notification delivery

Only workers/provider callbacks move delivery states. Human Admin may cancel/retry through explicit notification operations if exposed, never set DELIVERED manually.

# 17. Hard invariants no Admin bypasses

No Admin role can:
- create two exclusive asset claims simultaneously;
- accept two winning assignments for one exclusive job state;
- turn HAL command acceptance into physical charging evidence;
- rewrite immutable HAL fact history;
- mutate finalized historical pricing/compensation source rows;
- over-refund captured amount;
- mutate READY invoice bytes in place;
- read a secret/provider credential through ordinary Admin API;
- bypass ownership privacy by guessing resource IDs.

If real-world emergency requires operation outside normal workflow, create explicit incident/correction records and new safe transition/action, not direct SQL/status hacking.
