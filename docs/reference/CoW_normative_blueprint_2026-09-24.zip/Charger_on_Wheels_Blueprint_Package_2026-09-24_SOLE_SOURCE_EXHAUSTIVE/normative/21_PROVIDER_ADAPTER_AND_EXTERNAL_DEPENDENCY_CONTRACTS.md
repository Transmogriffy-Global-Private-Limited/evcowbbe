# Provider Adapter and External Dependency Contracts

**Status:** Normative scoped annex.
**Owns:** common adapter result classes and provider-specific boundaries for payment, routing, push, mail and storage.

# 1. Adapter law

Domain services depend on semantic interfaces, not provider SDK types. Provider IDs/raw responses are stored only in provider integration records. Replacing provider must not rewrite ServiceJob/Payment/Notification semantics.

Every adapter method returns one of:

```text
SUCCESS
REJECTED_TERMINAL
RETRYABLE
RATE_LIMITED(retry_after)
OUTCOME_UNKNOWN
CONFIGURATION_ERROR
INTEGRITY_ERROR
```

Timeout after request may have been sent is OUTCOME_UNKNOWN unless provider idempotency guarantees safe repeat.

# 2. Timeouts

Every external call has connect/request timeout shorter than worker lease. No infinite default HTTP client. Retry happens outside call with durable state.

# 3. Circuit/degradation

Repeated provider failures may open bounded circuit/degraded state to prevent thundering retries. This changes attempt pacing, not durable logical outcome. Read surfaces remain available from local truth.

# 4. Razorpay/customer payment adapter

Semantic operations:

```text
CreateOrder/Intent(internal_payment_id, amount, currency, metadata)
VerifyClientEvidence(...)
LookupPayment(exact provider ids)
CreateRefund(internal_refund_id, provider_payment_id, amount)
LookupRefund(...)
VerifyWebhook(raw_body, headers)
```

Use provider idempotency/reference features where available. Client callback is insufficient for CAPTURED. Webhook identity/digest deduped. Exact collection flow and capture mode are decision-gated and then frozen in repository contract.

# 5. Routing/maps adapter

```text
Route(origin, destination, mode, departure_time) -> distance_m, duration_s, provenance
Geocode(optional if product uses it)
ReverseGeocode(optional)
```

Do not accept arbitrary provider URL from client. Cache bounded by coordinates/provider/options/time. Provider result is routing estimate, not proof Driver traveled that route; compensation travel distance uses authoritative trace policy.

# 6. Push adapter

Semantic operation:

```text
SendPush(delivery_id, device_token_ref, payload) -> provider_message_id/result
```

Payload is minimal hint from Annex 10. Invalid/unregistered token terminally deactivates that device token. Provider acceptance is not human delivery unless receipt exists.

# 7. Mail adapter

Semantic operation:

```text
SendMail(delivery_id, recipient, template_rendered_subject/body, attachments refs) -> provider_message_id/result
```

SMTP ambiguity after DATA/connection loss may be OUTCOME_UNKNOWN; retry policy accepts possible duplicate risk only if provider/message idempotency strategy is documented. Prefer provider API with idempotent message key where available.

# 8. Storage adapter

```text
PutPrivate(temp_or_final_key, stream, expected_size/checksum)
Promote/Commit(temp_key, final_key) where provider supports atomic strategy
OpenPrivate(key)
DeletePrivate(key)
Stat(key)
SignedReadURL(key, short_ttl) optional
```

Local adapter uses safe root + random server path, no client path. S3-compatible uses private bucket and server-side access. Immutable READY invoice object uses versioned unique key and checksum.

# 9. SMS

Reserved for future. Do not add SMS status/preferences/provider keys until business decision activates it. Notification schema can represent channel enum extension without redesign.

# 10. Provider webhooks

Raw body signature verification occurs before JSON normalization if provider requires. Persist event ID/digest, return success on exact duplicate, alert on same ID altered. Processing uses local transaction and durable state.

# 11. Provider decision gates

Before enabling a provider in production freeze:
- vendor/account/region;
- auth method/secret rotation;
- sandbox vs prod endpoints;
- idempotency/lookup guarantees;
- timeout/retry/rate-limit semantics;
- webhook signature/event identity;
- data residency/privacy implications;
- operational ownership/runbook.

# 12. Replacement

Adapter replacement runs dual contract fixtures. Existing provider IDs/history retain provider name/version. New provider is not allowed to reinterpret historical payment/route/message records.

# 13. Tests

Fake adapters support all result classes deterministically. Sandbox tests verify request mapping/signatures/webhooks. Production acceptance is separately labeled.
