# Sole-Source Coverage and Traceability Matrix

**Status:** Normative scoped annex for package navigation/coverage. It adds no new domain behavior; it proves where each implementation concern is owned.

# 1. Coverage matrix

| Concern | Primary authority |
| --- | --- |
| Product/domain architecture | `01_CANONICAL_FULL_BLUEPRINT.md` |
| Realtime SSE + notifications | Annex 10 |
| HTTP/auth/errors/idempotency/cursors | Annex 11 |
| Persistence/table families | Annex 12 |
| State transition actors/evidence | Annex 13 |
| Workers/recovery | Annex 14 |
| Security/privacy/abuse | Annex 15 |
| Observability/SLO/alerts | Annex 16 |
| Config/env/secrets | Annex 17 |
| Testing/simulator/acceptance | Annex 18 |
| Deployment/backup/restore | Annex 19 |
| Frontend integration | Annex 20 |
| External providers | Annex 21 |
| Repo/bootstrap/coding/migrations | Annex 22 |
| Vocabulary/enums | Annex 23 |
| API payload catalog | Annex 24 + endpoint registry |
| Domain events/outbox | Annex 25 + event registry |
| Notification triggers/templates | Annex 26 + notification registry |
| Genuine unresolved decisions | Annex 27 |
| Cross-domain reference sequences | Annex 28 |
| Burner execution process | Annex 29 + Appendix H |
| Admin/operations workflows | Annex 30 |
| Data retention/privacy lifecycle | Annex 31 |
| Physical hardware certification | Annex 32 |
| Package/repo change control | Annex 33 |
| CMS-HAL exact wire contract | Annex 34 |
| Dispatch/location/geofence/ETA | Annex 35 |
| Pricing/tax/payment/refund/invoice | Annex 36 |
| Driver compensation | Annex 37 |
| Ratings/support/incidents | Annex 38 |
| Recruitment/fleet/schedule/duty | Annex 39 |
| Customer/request/quote/ServiceJob | Annex 40 |
| Audit/provenance/corrections | Annex 41 |
| DB transactions/lock ordering | Annex 42 |
| Time/timezone/precision/IDs | Annex 43 |
| Admin capabilities/roles | Annex 44 + capability registry |
| Query/filter/sort/export | Annex 45 |

# 2. Cross-cutting checklist

Every burner asks whether it touches each of:

```text
actors/authorization
state transitions
persistence constraints/indexes
HTTP/internal service API
events/outbox
realtime
notifications
idempotency
concurrency/locks
external side effects/reconciliation
history/snapshots
audit
security/privacy
configuration
observability
retention
frontend/admin operations
tests/acceptance
deployment/migration
```

If no, mark N/A with reason in work item. This matrix exists to prevent a narrow handler-only implementation.

# 3. Machine registries

The following remove repeated-string drift:

```text
registries/api_endpoints.csv
registries/realtime_events.csv
registries/notifications.csv
registries/domain_events.csv
registries/config_keys.csv
registries/error_codes.csv
registries/admin_capabilities.csv
registries/workers.csv
registries/decision_gates.csv
registries/burners.csv
registries/state_transitions.csv
registries/package_manifest.json
```

Repository code/OpenAPI may eventually generate some of these, but until then the package verifier checks uniqueness/coverage where practical.

# 4. What remains legitimately unknown

Only Annex 27 decision gates and development/runtime discoveries not knowable before implementation. "Engineer preference" is not a decision gate when package already owns semantics.

# 5. Blind-followability test

Before final package handoff, a reviewer should be able to pick a random burner and answer from package alone:
- what exactly is being built;
- what exists first;
- tables/invariants/state;
- endpoints/events/auth;
- concurrency/idempotency;
- failures/recovery;
- logs/metrics/alerts;
- tests/evidence;
- migration/deploy/rollback impact;
- what external fact, if any, must still be decided.

If a material answer requires old chat/repository or guessing, coverage is incomplete and package must be corrected.


# 5. Exact machine envelope schemas

```text
schemas/realtime_event.schema.json
schemas/hal_fact_envelope.schema.json
schemas/notification_resource.schema.json
schemas/api_error.schema.json
schemas/canonical_json_rules.md
```

The JSON schemas are synchronized restatements of Annexes 10, 11 and 34. They do not create a new authority tier.
