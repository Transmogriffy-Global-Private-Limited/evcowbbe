# CMS-HAL Wire Contract and Reconciliation Specification

**Status:** Normative scoped annex.
**Owns:** exact Charger-on-Wheels CMS <-> dedicated HAL service boundary. Canonical Sections 19-20 own architectural authority. This annex removes wire-level ambiguity.

# 1. Boundary law

CMS and HAL are separately deployed services with separate PostgreSQL databases. CMS owns business/customer/driver/job/commercial truth. HAL owns charger connection/protocol/transaction/meter/raw-evidence truth. Neither reads the other's database.

Three independently rotatable TLS-protected opaque bearer credentials are required:

```text
CMS -> HAL command/mapping plane: HAL_COMMAND_BEARER
HAL -> CMS fact plane:          CMS_HAL_FACT_BEARER
HAL -> CMS trace plane:         CMS_HAL_TRACE_BEARER
```

A credential for one plane MUST fail on either other plane. Secrets are never query parameters or logs.

# 2. Common service headers

All state-changing cross-service calls use:

```text
Authorization: Bearer <plane credential>
Content-Type: application/json
X-Request-ID: <uuid>
Idempotency-Key: <immutable logical object id when specified>
X-Contract-Version: cow-hal-v1
```

`X-Request-ID` is correlation only. It is not an idempotency identity.

Responses use the standard success/error envelope from Annex 11. Unknown contract major version returns `409 STATE_CONFLICT` with safe details naming supported versions.

# 3. Charger mapping

## 3.1 PUT /v1/mappings/chargers/{cms_charger_id}

Idempotency identity: `cms_charger_id + mapping_version`.

Request:

```json
{
  "mapping_version": 17,
  "cms_charger_id": "uuid",
  "hal_charger_identity": "string",
  "enabled": true,
  "expected_protocol_family": "OCPP_1_6",
  "connectors": [
    {
      "cms_connector_id": "uuid",
      "connector_number": 1,
      "connector_type": "CCS2"
    }
  ],
  "effective_at": "2026-09-24T10:00:00Z"
}
```

Rules:
- path/body charger IDs must match;
- mapping versions are monotonically increasing per CMS charger;
- lower version is an idempotent stale no-op only when body digest matches historical mapping, otherwise conflict;
- same version + different digest is integrity conflict;
- HAL never invents CMS charger/connector IDs.

Response:

```json
{
  "data": {
    "cms_charger_id": "uuid",
    "mapping_version": 17,
    "status": "SYNCHRONIZED",
    "accepted_at": "..."
  }
}
```

# 4. Charging command contract

## 4.1 POST /v1/remote-commands/start

`Idempotency-Key` MUST equal `cms_start_intent_id`.

Request:

```json
{
  "cms_start_intent_id": "uuid",
  "cms_service_job_id": "uuid",
  "cms_charger_id": "uuid",
  "cms_connector_id": "uuid",
  "connector_number": 1,
  "hal_charger_identity": "string",
  "customer_authorization_ref": "opaque-non-secret-ref",
  "charging_limits": {
    "target_energy_wh": 20000,
    "target_soc_percent": 80,
    "max_duration_seconds": 7200
  },
  "requested_at": "...",
  "expires_at": "..."
}
```

Null charging-limit fields mean no limit of that type. At least one explicit business stop policy can be required by deployment policy, but HAL MUST NOT fabricate one.

Immediate response describes command persistence/acceptance, not physical start:

```json
{
  "data": {
    "cms_start_intent_id": "uuid",
    "hal_command_id": "uuid",
    "state": "QUEUED|DELIVERY_ATTEMPTED|ACCEPTED|REJECTED|OUTCOME_UNKNOWN",
    "accepted_at": null
  }
}
```

Physical start is established only by `transaction.started` fact.

## 4.2 POST /v1/remote-commands/stop

`Idempotency-Key` MUST equal `cms_stop_request_id`.

Request:

```json
{
  "cms_stop_request_id": "uuid",
  "cms_service_job_id": "uuid",
  "cms_charging_session_id": "uuid",
  "cms_start_intent_id": "uuid",
  "hal_transaction_id": "string",
  "cms_charger_id": "uuid",
  "cms_connector_id": "uuid",
  "reason": "CUSTOMER_REQUEST|DRIVER_REQUEST|ADMIN_REQUEST|LIMIT_REACHED|JOB_CANCELLED|SAFETY|SYSTEM_RECOVERY",
  "requested_at": "..."
}
```

Physical completion is established only by `transaction.ended` or exact reconciliation evidence.

# 5. Generic charger operation

## POST /v1/charger-operations

Used for reset, unlock, availability, diagnostics and other capability-backed operations.

Request:

```json
{
  "cms_operation_id": "uuid",
  "cms_charger_id": "uuid",
  "operation": "RESET|UNLOCK_CONNECTOR|CHANGE_AVAILABILITY|REQUEST_DIAGNOSTICS|SET_CHARGING_LIMIT",
  "connector_number": 1,
  "parameters": {},
  "requested_at": "..."
}
```

`Idempotency-Key == cms_operation_id`.

A possibly-delivered operation is NEVER blindly replayed. Exact lookup/reconciliation owns uncertainty.

# 6. Exact lookup endpoints

```text
GET /v1/remote-commands?cms_command_id={id}
GET /v1/transactions?cms_start_intent_id={id}
GET /v1/transactions/{hal_transaction_id}
GET /v1/charger-operations?cms_operation_id={id}
```

Lookup returns `404 RESOURCE_NOT_FOUND` only when HAL can authoritatively say no durable row/evidence with that exact identity exists. Timeout/unavailability is not absence.

# 7. HAL fact ingress

## POST /internal/v1/hal-facts

`Idempotency-Key == fact_id`.

Envelope:

```json
{
  "schema_version": 1,
  "fact_id": "uuid",
  "fact_type": "transaction.started",
  "occurred_at": "...",
  "observed_at": "...",
  "hal_charger_identity": "string",
  "cms_charger_id": "uuid",
  "cms_connector_id": "uuid",
  "connection_sequence": 91,
  "connector_status_sequence": 122,
  "transaction_sequence": 4,
  "correlation": {
    "cms_start_intent_id": "uuid",
    "cms_stop_request_id": null,
    "cms_operation_id": null,
    "hal_transaction_id": "string"
  },
  "payload": {},
  "canonical_digest": "sha256-hex"
}
```

Rules:
- `fact_id` immutable forever;
- same ID + same canonical digest = idempotent success;
- same ID + different digest = `409 HAL_FACT_INTEGRITY_VIOLATION` and no projection mutation;
- CMS recomputes canonical digest from normalized fields rather than trusting provided digest;
- unknown/unmapped identity never mutates another charger/session;
- sequence advancement is monotonic per owned projection.

Normalized fact types in v1:

```text
charger.connected
charger.disconnected
connector.status_changed
transaction.started
transaction.updated
transaction.ended
meter.sample_observed
soc.observed
fault.observed
capability.changed
command.updated
operation.updated
```

Fact-specific minimum payloads are versioned fixtures in the shared contract-fixture package. Schema additions are backward-compatible within major v1; semantic reinterpretation requires new payload version/contract change.

# 8. Trace ingress

## POST /internal/v1/hal-trace-events

Trace has separate auth, worker, retention and storage. It MUST NOT drive business state.

Envelope:

```json
{
  "trace_id": "uuid",
  "schema_version": 1,
  "occurred_at": "...",
  "hal_charger_identity": "string",
  "cms_charger_id": "uuid",
  "direction": "CHARGER_TO_HAL|HAL_TO_CHARGER|HAL_INTERNAL",
  "protocol_family": "OCPP_1_6",
  "message_kind": "CALL|CALLRESULT|CALLERROR|TRANSPORT|RECOVERY",
  "correlation_id": "string|null",
  "summary": "bounded sanitized text",
  "evidence": {}
}
```

Bodies are size-bounded and secret-sanitized. CMS technical Admin access is capability-gated.

# 9. Fact delivery transaction rule

HAL protocol processing that creates irreplaceable lifecycle evidence commits:

```text
HAL durable transaction/evidence row
+ immutable normalized fact
+ fact outbox row
```

in the same database transaction before acknowledging charger protocol input where the protocol permits. HAL fact delivery is at-least-once. CMS fact ingestion is idempotent.

# 10. Reconciliation state and no-replay rule

A cross-service command can be:

```text
NOT_SENT
DELIVERY_ATTEMPTED
ACCEPTED
REJECTED
OUTCOME_UNKNOWN
RECONCILIATION_REQUIRED
```

Only `NOT_SENT` and explicitly proven non-delivered cases may be safely attempted according to command policy. `DELIVERY_ATTEMPTED`/`OUTCOME_UNKNOWN` use exact lookup and physical evidence. Reconciliation retains the same CMS logical identity.

# 11. Outage/restart truth table

- CMS down: HAL continues charger safety/runtime and accumulates immutable facts in outbox.
- HAL down: CMS serves stale/unknown durable projections honestly; new physical commands do not pretend success.
- CMS crash after fact commit before response: HAL retries same fact, CMS no-ops.
- HAL crash after possible command send: recovered operation becomes reconciliation candidate, not automatic replay.
- both restart: exact durable identities and facts converge without generating replacement logical commands.

# 12. Contract fixture requirements

Shared golden fixtures MUST cover every endpoint, every fact type, accepted/rejected/unknown responses, same-ID same-body retry, same-ID different-body conflict, unknown charger mapping, stale sequence, late fact, duplicate/out-of-order fact, and version incompatibility.

The fixture digest/version is pinned independently in both repositories and checked in CI.
