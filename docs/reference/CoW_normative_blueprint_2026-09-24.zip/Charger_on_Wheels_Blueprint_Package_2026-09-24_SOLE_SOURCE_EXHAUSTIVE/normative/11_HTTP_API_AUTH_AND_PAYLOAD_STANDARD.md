# HTTP API, Authentication, and Payload Standard

**Status:** Normative scoped annex.
**Owns:** common HTTP conventions, human auth/session mechanics, errors, idempotency, optimistic concurrency, pagination, filtering, validation, uploads and API compatibility.

# 1. HTTP baseline

- HTTPS required outside local isolated development.
- public human APIs use `/api/v1/{plane}` where plane is `app`, `driver`, or `admin`.
- JSON keys are `snake_case`.
- request mutation bodies reject unknown fields by default with `400 VALIDATION_FAILED`.
- timestamps are RFC3339 UTC; time semantics in Annex 43.
- UUIDs are lowercase canonical text in APIs.
- `Content-Type: application/json` for JSON mutations.
- maximum JSON body defaults to 1 MiB unless endpoint explicitly needs more.

# 2. Request correlation

Client may send `X-Request-ID` UUID. Server validates format or generates one. Response echoes effective ID. Same request ID does not imply retry/idempotency.

# 3. Human authentication decision

V1 uses opaque random bearer access and refresh tokens, not self-contained JWT as authority.

Access token:
- 256-bit random minimum;
- store only cryptographic digest server-side;
- default lifetime 15 minutes;
- bound to session/account and one principal plane;
- revoked session invalidates access immediately at server lookup/cache bound.

Refresh token:
- 256-bit random minimum;
- default rolling lifetime 30 days;
- session absolute lifetime 90 days;
- rotate on every successful refresh;
- replacement link stored so reuse of already-rotated token revokes session token family and returns `401 REFRESH_TOKEN_REUSED`.

One Account can own Customer, Driver, Admin principals, but an access token is issued for one explicit plane and authorization context. Using a token on another plane returns `403 PRINCIPAL_PLANE_MISMATCH`.

# 4. Passwords

Argon2id baseline:

```text
memory_kib=65536
iterations=3
parallelism=1
salt_bytes=16
hash_bytes=32
```

Parameters are stored with hash and can be upgraded on login. Password policy is business/security config, but server rejects known grossly weak/compromised patterns where practical. Password is never logged.

# 5. OTP/challenges

Where OTP is used:

```text
6 numeric digits
TTL 10 minutes
max verify attempts 5
resend cooldown 60 seconds
```

Store HMAC-SHA256 of challenge/OTP with server pepper rather than plaintext. Verification consumes challenge atomically. Rate limit by account/identifier and network risk. Do not disclose whether an untrusted email/phone is registered beyond the chosen anti-enumeration policy.

# 6. Session record

Session stores:

```text
id, account_id, principal_plane, access_digest, refresh_digest,
created_at, access_expires_at, refresh_expires_at, absolute_expires_at,
last_seen_at, revoked_at, revoke_reason,
device_id nullable, refresh_generation
```

Logout revokes current session. "Logout all" revokes all account sessions. Security-sensitive credential change may revoke all or selected sessions according to explicit endpoint policy.

# 7. Success envelope

Single resource:

```json
{"data": {...}}
```

List:

```json
{
  "data": [...],
  "page": {"next_cursor": "opaque|null", "has_more": true}
}
```

Mutation may include `meta` for safe warnings/assumptions, but do not invent multiple competing shapes per endpoint family.

# 8. Error envelope

```json
{
  "error": {
    "code": "MACHINE_CODE",
    "message": "safe human summary",
    "details": {},
    "request_id": "uuid"
  }
}
```

Canonical machine codes are Appendix C / `registries/error_codes.csv`. Do not expose stack traces, SQL, secrets or private cross-tenant existence in errors.

# 9. HTTP status mapping

```text
200 read/update success
201 resource created
202 durable async intent accepted
204 successful no-body mutation/delete semantic
400 malformed/query/cursor syntax
401 no/invalid/expired authentication
403 authenticated but not authorized
404 absent OR privacy-safe inaccessible owned resource
409 state/idempotency/integrity conflict
410 intentionally expired resource such as start intent
412 If-Match/resource version mismatch
422 syntactically valid but domain admission invalid
429 rate limited
500 internal unexpected failure
503 dependency/readiness unavailable
```

# 10. Mutation idempotency

Endpoints marked idempotent require header:

```text
Idempotency-Key: <client generated 128-bit+ opaque key>
```

Server stores scope, account/principal, endpoint semantic key, request canonical digest, logical result reference/status and expiry.

Defaults:
- ordinary mutation retention: 24h;
- payment/refund/charging/dispatch/external-side-effect retention: 7d minimum or longer if reconciliation can outlive it.

Same key + same request returns original logical result. Same key + different request returns `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST`.

# 11. Optimistic concurrency

Mutable resources expose integer `version` and `ETag: "v{version}"` where lost-update risk matters. PATCH/replace operations marked concurrency-protected require `If-Match`. Mismatch returns `412 RESOURCE_VERSION_MISMATCH` with current safe version/ETag metadata.

No-op idempotent mutation does not increment version.

# 12. PATCH semantics

PATCH is JSON Merge Patch-like only where endpoint says so. Omitted field = unchanged. Explicit null = clear only if field nullable/clearable. Immutable fields reject attempts. State-machine transitions use named action endpoints, not arbitrary `status` PATCH.

# 13. Keyset pagination

Offset pagination is not used for unbounded operational/history tables.

Cursor is signed opaque and bound to:
- endpoint/list family;
- normalized sort;
- normalized filters/search;
- account/authorization scope where necessary;
- last ordering key(s).

Using cursor with different query returns `400 CURSOR_QUERY_MISMATCH`.

Every sort has stable unique tie-breaker, normally `id`.

# 14. Common list parameters

```text
limit             default 20, max 100 unless endpoint says otherwise
cursor            opaque
sort              allow-listed field or compound semantic sort
order             asc|desc when meaningful
q                 bounded search string
created_from/to   RFC3339
updated_from/to   RFC3339
status            repeatable or comma-list according to OpenAPI
```

Filters run in SQL before LIMIT. Search is escaped/parameterized and field set documented per list.

# 15. Validation

Validation layers:
1. parse/type/size;
2. field semantic range/format;
3. authenticated ownership/capability;
4. current state/preconditions;
5. concurrency/idempotency under transaction;
6. external admission if genuinely required.

Do not use 500 for client validation.

# 16. Strings

Trim human free-text where semantics permit. Names/labels retain Unicode in actual product data even though project documentation is ASCII-first. Define endpoint max lengths in OpenAPI/schema. Free-text rendered in UI/email is escaped by output context.

# 17. Money/measurements

Money is integer minor units + ISO currency. Energy is integer Wh. Power fields name unit. Distances use meters. Durations name seconds/milliseconds. Unknown values are null, never magic -1/0.

# 18. Boolean/null/enums

Booleans are real JSON booleans. Enums are uppercase snake tokens unless domain contract defines lowercase event names. Unknown future enum handling for clients is documented per frontend contract; server rejects unsupported mutation enum values.

# 19. File upload/download

Uploads use multipart only for actual files. Metadata is explicit JSON field/part or separate endpoint. Server validates MIME by content/signature where possible, size, extension policy and malware scanning policy if provider available. Original filename is metadata only, never filesystem path.

Downloads authorize by domain resource ID, set safe `Content-Type`, `Content-Disposition`, size and checksum where relevant. Client never submits raw storage path/key.

# 20. Rate limiting

Rate limiting is per endpoint risk class, account/principal and network signal, with configuration from Annex 17. 429 includes `Retry-After` when meaningful. Security challenges/login/OTP have stricter limits than normal reads.

# 21. CORS

Production allowed origins are explicit config allow-list. `*` is forbidden with credentials. SSE routes obey same origin policy. Preflight has bounded cache age. Internal HAL routes are not browser-CORS surfaces.

# 22. Health/readiness

```text
GET /health/live
GET /health/ready
GET /version
```

Liveness does not depend on optional external providers. Readiness checks ability to safely serve critical work, normally DB and required local initialization; provider outage is exposed separately unless product policy truly requires provider for all traffic.

# 23. API compatibility

OpenAPI is first-class source once repository exists. Backward-compatible additions can stay v1. Removing/renaming fields, changing meaning, narrowing enum unexpectedly or changing ownership semantics requires explicit compatibility/version decision.

# 24. Client retry rule

Clients may automatically retry safe GET and explicitly idempotent mutations using same idempotency key. They MUST NOT create a new key merely because response timed out for an external-effect operation. 409/412/422 are handled semantically, not blind-retried.

# 25. Verification

Route/OpenAPI parity, auth plane isolation, idempotency race, cursor/query binding, If-Match race, malformed/unknown fields, privacy-safe 404, rate limits, upload traversal/MIME/size, CORS and no-secret error/log tests are mandatory for relevant burners.
