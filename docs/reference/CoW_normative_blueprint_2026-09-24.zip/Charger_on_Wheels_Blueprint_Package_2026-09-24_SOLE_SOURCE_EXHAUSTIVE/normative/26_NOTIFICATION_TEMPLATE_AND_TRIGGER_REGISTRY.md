# Notification Template and Trigger Registry

**Status:** Normative scoped annex.
**Owns:** notification categories, trigger-to-recipient/channel/template semantics and safe template parameters. Machine rows are `registries/notifications.csv`.

# 1. Template rule

Templates are versioned source-controlled or versioned DB/admin assets with immutable version after activation. Render inputs are allow-listed named params. Freeform domain body is not implicitly passed to external channel.

# 2. Categories

```text
SECURITY_MANDATORY
OPERATIONAL_CRITICAL
OPERATIONAL
COMMERCIAL
SUPPORT
INFORMATIONAL
MARKETING_FUTURE
```

Marketing is not active without explicit consent/policy feature.

# 3. Initial trigger matrix

Representative exact triggers; registry is machine authority:

```text
ACCOUNT_PASSWORD_CHANGED            recipient account       IN_APP+EMAIL mandatory
ACCOUNT_SESSION_REVOKED             recipient account       IN_APP, email for security policy
DRIVER_APPLICATION_SUBMITTED        Driver                  IN_APP
DRIVER_APPLICATION_ACTION_REQUIRED  Driver                  IN_APP+PUSH+EMAIL preference rules
DRIVER_APPLICATION_APPROVED         Driver                  IN_APP+PUSH+EMAIL
DRIVER_SUSPENDED                    Driver                  IN_APP+PUSH+EMAIL mandatory operational
DRIVER_SCHEDULE_CHANGED             Driver                  IN_APP+PUSH
DISPATCH_OFFER_CREATED              Driver                  IN_APP+PUSH high priority
JOB_ASSIGNED_USER                   Customer                IN_APP+PUSH
JOB_REASSIGNED_USER                 Customer                IN_APP+PUSH
DRIVER_ARRIVED                      Customer                IN_APP+PUSH
CHARGING_STARTED                    Customer/Driver         IN_APP+PUSH
CHARGING_STOPPED                    Customer/Driver         IN_APP+PUSH
CHARGING_FAULT                      Customer/Driver/Admin    IN_APP+PUSH as appropriate
JOB_COMPLETED                       Customer/Driver         IN_APP+PUSH
PAYMENT_CAPTURED                    Customer                IN_APP
PAYMENT_FAILED                      Customer                IN_APP+PUSH
REFUND_COMPLETED                    Customer                IN_APP+EMAIL optional
INVOICE_READY                       Customer                IN_APP+EMAIL
SUPPORT_REPLY_CUSTOMER              Customer                IN_APP+PUSH+EMAIL preference
SUPPORT_REPLY_DRIVER                Driver                  IN_APP+PUSH+EMAIL preference
INCIDENT_STATUS_CHANGED             affected Driver/Admin   IN_APP+PUSH based severity
```

# 4. Recipient resolution

Recipient is derived from durable ownership/assignment at event time, not client-provided email/account ID in event payload. If ownership changed, trigger contract says whether recipient is historical actor or current owner; default is resource owner/participant at causal event.

# 5. Allowed template params

Safe examples:

```text
recipient_display_name
job_reference
charger/service vehicle display label
support_subject
status label
occurred_at formatted
amount/currency safe summary
invoice_number
deep_link
```

Forbidden external payload by default:

```text
access/refresh/service token
OTP/password
KYC/bank data
full support message body
full customer address unless a specific transactional mail genuinely requires it
raw HAL/OCPP trace
provider secrets
```

# 6. Deep links

Deep link is semantic app path, not pre-authenticated URL. App reauthorizes resource after opening. Email web links use ordinary authenticated frontend URL with resource ID, never bearer token.

# 7. Dispatch offer

Offer push is best-effort hint. Durable offer state/deadline and Driver REST/realtime are authority. Push delay does not extend offer expiry. Notification becoming unread/read does not affect offer.

# 8. Preferences

Registry marks `preference_mode`:

```text
MANDATORY
EXTERNAL_CHANNEL_CONFIGURABLE
FULLY_CONFIGURABLE
```

In-app operational history generally remains even when push/email disabled. Preference checked at notification intent time and may be rechecked before delayed external send for newly disabled optional channel.

# 9. Render failure

Missing invalid required template param is terminal configuration/integrity error, alerts operator, leaves notification durable, does not send malformed message. Template rendering is tested with golden fixtures.

# 10. Localization

V1 can start with one configured locale, but template identity includes locale and version so adding Bengali/Hindi/etc does not fork trigger semantics. Locale fallback is explicit configured default.

# 11. Acceptance

Every registry row has domain event source, recipient resolver, category, preference mode, in-app title/body template, external channel list, deep-link target and tests. A trigger with no defined recipient/template is disabled rather than guessed.
