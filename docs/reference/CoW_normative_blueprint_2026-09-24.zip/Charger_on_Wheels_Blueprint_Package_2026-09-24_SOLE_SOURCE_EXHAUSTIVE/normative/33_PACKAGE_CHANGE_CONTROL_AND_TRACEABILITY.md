# Package Change Control and Traceability

**Status:** Normative scoped annex.
**Owns:** sole-source package authority, semantic change procedure, repository transition, ADR/versioning and drift prevention.

# 1. Authority hierarchy before implementation

1. `01_CANONICAL_FULL_BLUEPRINT.md` architectural/domain laws and explicit top-level decisions.
2. `normative/*.md` within their declared scope, provided they do not contradict canonical law.
3. machine `registries/*` for the exact enumerated rows owned by corresponding annex; registry and annex must agree.
4. templates as required record shapes, not new semantics.
5. root 02-05 focused views are non-normative conveniences.
6. source snapshots 07-08 are provenance only.

If a scoped annex seems to contradict canonical, stop and correct package; do not choose whichever is convenient.

# 2. After repositories exist

For observed implementation/runtime claims, current repo/DB/runtime/physical evidence wins over stale package statement. For intended product semantics, a deliberate semantic change must update repository contract + package/ADR; runtime accident does not silently redefine design.

# 3. Change classes

```text
EDITORIAL: wording/links, no semantic change
CLARIFICATION: removes ambiguity without changing intended behavior
COMPATIBLE_EXTENSION: new optional field/event/operation/capability preserving old behavior
BREAKING_SEMANTIC: meaning/ownership/state/API compatibility changes
EXTERNAL_DECISION: resolves Annex 27 gate
CORRECTIVE_REALITY: package assumption proven wrong by implementation/provider/hardware evidence
```

# 4. Procedure

For material change:
1. identify authoritative sections/annex/registry rows;
2. explain evidence/intent and compatibility impact;
3. ADR for architecture/external decision/breaking change;
4. update canonical if top-level law/domain meaning changes;
5. update all scoped annexes/registries/templates affected;
6. update burner dependencies/Appendix H if implementation sequence changes;
7. update repository OpenAPI/schema/code/tests/docs if implementation exists;
8. run package verifier + repository verifiers;
9. record package version/hash in project state when adopted.

# 5. Repository-native transition

Once a burner implements contract, repository-native source/OpenAPI/migrations/tests become executable authority for that implemented surface, but must retain semantic trace to package section/annex. Future package can summarize current repo truth; do not maintain knowingly contradictory parallel copies.

# 6. ADR

ADR records context, decision, alternatives, consequences, migration/compatibility, affected contracts and verification. Reversal creates new ADR superseding old; do not rewrite historical rationale.

# 7. Traceability

Maintain mapping:

```text
requirement/domain law -> burner/work item -> migration/code/API/event -> tests -> release evidence
```

Appendix H starts this map. Repository work item cites exact package files/sections and closes with exact test/evidence references.

# 8. No silent contract rule

If implementing requires choosing between two materially different externally observable semantics not already resolved, it is not a private code detail. Classify ambiguity/decision and update contract before merging.

# 9. Compatibility

Compatible additive change still verifies old clients/provider fixture. Breaking change requires explicit version/migration/deprecation plan. Never reuse same event/API schema version for changed meaning.

# 10. Package versioning

Final ZIP filename includes version/revision label. `00_PACKAGE_INDEX.md` states package status/date. `99_SHA256SUMS.txt` covers every file except itself. Final ZIP SHA-256 is recorded at handoff.

# 11. Verifier responsibilities

Mechanical verifier checks at least:
- integrity manifest coverage/hash;
- retained original source digests;
- canonical required markers;
- focused-view non-normative banners;
- generated burner index exact equality;
- every Program burner has Appendix H card;
- required normative annexes/registries/templates exist;
- unique API endpoint/event/error/capability registry keys;
- no superseded old realtime handler declarations;
- ASCII project docs/scripts/registries per project convention;
- no unresolved authoring placeholders in authoritative authored files.

# 12. Definition of package consistency

A package is not "verified" merely because hashes match. It must also be semantically self-consistent: same state/event/error/capability names, one authority per fact, no focused doc claiming independent law, no dependency cycle hidden in program order, no external source required to discover intended behavior, and all genuine unknowns listed as decision gates.
