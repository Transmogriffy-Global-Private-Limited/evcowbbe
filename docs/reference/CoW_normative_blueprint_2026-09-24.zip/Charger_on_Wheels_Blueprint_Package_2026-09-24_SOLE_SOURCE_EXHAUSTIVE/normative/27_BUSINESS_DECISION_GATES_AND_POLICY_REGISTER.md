# Business Decision Gates and Policy Register

**Status:** Normative scoped annex.
**Owns:** the only classes of pre-implementation uncertainty that may legitimately remain unresolved because they require business, legal, provider, hardware or runtime facts. Engineers MUST NOT invent answers.

# 1. Gate rule

A burner may proceed around an unresolved gate only when its contract does not require that fact. When a gate becomes a dependency, stop that burner, gather/receive the decision, record it in repository ADR/config/policy, update affected contract/tests, then continue. Do not choose a plausible value silently.

# 2. Project identity/infrastructure gates

Before first real deployment:
- organization/repository final names;
- domains/hostnames;
- dev/staging/prod topology;
- hosting/VPS/container model;
- PostgreSQL hosting/backup target;
- reverse proxy/TLS provider;
- production RPO/RTO/capacity.

Architecture does not depend on exact hostnames.

# 3. Driver recruitment/legal gates

Before production onboarding:
- exact KYC/document set;
- Aadhaar/PAN/licence handling/legal basis;
- document retention;
- employment/contract classification;
- bank information need;
- age/licence/geography eligibility;
- training/terms acknowledgements.

Schema supports versioned requirements; do not collect sensitive fields "just in case."

# 4. Fleet/hardware gates

Before corresponding asset validation/certification:
- real ServiceVehicle types/fields;
- charger models/firmware/protocols;
- connector inventory;
- whether charger is permanently installed/swappable;
- physical safety/inspection requirements;
- HAL charger identity source;
- temporary observed unknown asset policy.

# 5. Mobile energy gate

Determine whether each mobile charging unit has finite onboard energy that constrains dispatch. If yes set `MOBILE_ENERGY_MODEL=REQUIRED` and freeze:
- energy store identity relation to Vehicle/Charger;
- telemetry source/provenance;
- usable/capacity/reserve computation;
- stale horizon;
- reservation policy/overhead;
- recharge/refill representation;
- fail-safe behavior on unknown/stale.

If no finite onboard store affects service, model is NOT_REQUIRED and energy-reservation burners are skipped with recorded evidence.

# 6. Service area/dispatch gates

Before real dispatch:
- platform service zones;
- scheduled service windows/lead time;
- sequential vs batched offer policy and timeout;
- Driver self-directed unscheduled operation allowed?
- Driver voluntary geofence allowed?
- arrival proximity/override policy;
- customer cancellation/no-show fees/policy;
- routing provider/fallback expectations.

Technical race/recovery remains as blueprint regardless of chosen values.

# 7. Pricing gates

Before customer quote in production:
- actual rate components/amounts;
- pricing zones/time/date rules;
- priority/emergency/fast premium;
- discounts/promotions;
- quote TTL/reprice conditions;
- minimum/maximum fees;
- cancellation/waiting calculation;
- tax inclusion display.

Rates live versioned policy, not code.

# 8. Charging business gates

Before live customer charging:
- who may initiate start (Customer, Driver, both, Admin intervention);
- plug/arrival/service-preparation sequence;
- mandatory stop limits/reserve/safety policy;
- target SoC availability when hardware lacks SoC;
- fast/normal preference mapping;
- when Driver can disconnect/close job;
- charger fault/customer unplug handling.

Physical truth ownership is not gated.

# 9. Customer payment gates

Before payment burner provider activation:
- Razorpay or alternate final choice;
- authorize/capture/order flow;
- prepayment/hold/deposit/postpay strategy;
- amount changes between quote/final;
- failed payment/job completion behavior;
- refund business authorization;
- webhook account/production credentials.

# 10. Tax/invoice legal gates

Before production invoice:
- GST registration/issuer identity;
- HSN/SAC/tax classification;
- place-of-supply rules;
- tax rates/exemptions;
- invoice numbering/legal fields;
- rounding/legal credit-note correction rules;
- artifact retention.

Never infer legal/tax answer from old EV-CMS if business model differs.

# 11. Driver compensation gates

Before real earnings display:
- actual policy/rates/components;
- travel distance authority;
- waiting rules;
- charging/revenue commission basis;
- time/date/zone bonuses;
- minimum/cap;
- reassignment allocation;
- adjustments approval.

No payout integration is in current scope.

# 12. Support/incident gates

- support SLA/categories/priority;
- whether customer/driver sees staff alias/name;
- attachment policy;
- incident severity/safety escalation rules;
- automated suspension/out-of-service thresholds.

Privacy/state mechanics are already fixed.

# 13. Provider gates

Before enabling each: routing/maps, push, mail, storage object provider, analytics/observability SaaS if any. Record credentials/auth, quotas, idempotency/lookup, webhook, privacy/residency and outage behavior.

# 14. Retention/privacy gates

Legal/business values for KYC, audit, invoices/tax records, support/incident, location traces, account closure/anonymization and backup retention. Cleanup job remains disabled for unresolved legally sensitive class rather than guessing deletion.

# 15. Hardware certification gate

Production charger model enters supported inventory only after Annex 32 certification for required protocol/start/stop/meter/reconnect/fault/safety scenarios. Known quirks become adapter capability/config, not hidden operator knowledge.

# 16. Protocol expansion gate

OCPP 2.0.1/2.1/vendor adapter implemented only when hardware/business requires it or deliberate roadmap authorizes. Core stays protocol-neutral meanwhile.

# 17. Decision record format

Each resolved gate records:

```text
decision_id/date
question
chosen value/policy
reason/evidence/source
owner/approver
scope/effective date
contracts/config/tables/endpoints affected
migration/backfill if any
verification required
```

# 18. Forbidden pseudo-gates

The following are NOT valid reasons to defer and are already decided by package: CMS/HAL ownership, separate DBs, physical proof semantics, idempotency/reconciliation, state-machine history, account/principal separation, SSE client realtime transport, notification durable inbox, API conventions, PostgreSQL, no Driver payout execution, immutable snapshots/artifacts.
