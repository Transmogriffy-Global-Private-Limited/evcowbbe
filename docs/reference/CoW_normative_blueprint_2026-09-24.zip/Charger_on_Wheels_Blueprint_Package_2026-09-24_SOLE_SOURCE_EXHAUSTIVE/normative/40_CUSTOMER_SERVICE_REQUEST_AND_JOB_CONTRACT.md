# Customer, Service Request, Quote, and ServiceJob Contract

**Status:** Normative scoped annex.
**Owns:** customer master data, temporary/saved semantics, request admission, immutable snapshots, quote acceptance and central ServiceJob lifecycle.

# 1. Customer profile

Customer principal belongs to one account. Profile changes are mutable current truth; historical jobs snapshot the fields needed for that job and do not join mutable profile to reconstruct history.

# 2. Vehicles

Saved and temporary vehicles use one normalized vehicle representation plus ownership/lifecycle metadata. Temporary input creates durable customer-scoped record/snapshot sufficient for history. Promotion to saved changes reusability/current master association, not old job snapshot.

Vehicle fields relevant to compatibility are validated and can be UNKNOWN. Unknown capability is not treated as compatible by default where safety/dispatch requires proof.

# 3. Addresses

Saved and temporary addresses follow the same rule. ServiceJob snapshot includes structured address, coordinates, landmark/gate/contact instructions and geocode provenance needed for fulfillment. Promotion never edits old snapshot.

# 4. Service request

Request is intent before commercial/dispatch commitment. It records customer, selected/temporary vehicle, address, desired schedule window, charging preference/targets and client idempotency identity.

Admission validates account/service area/basic compatibility/policy. It does not assign a Driver.

# 5. Quote

Quote uses exact request snapshot and pricing policy version. Quote expiry and invalidation are explicit. Customer acceptance requires exact quote ID/version; a stale/expired quote returns conflict rather than silently reprice and accept.

# 6. ServiceJob creation

Job creation transaction persists:
- request/quote references;
- immutable customer vehicle snapshot;
- immutable service address snapshot;
- accepted commercial snapshot/quote terms;
- requested service/charging preferences;
- initial lifecycle event;
- outbox/domain event.

At most one active job is created for a successful idempotent quote acceptance key.

# 7. ServiceJob lifecycle

Canonical state graph is Appendix A. State changes require actor/evidence from Annex 13. Assignment and ChargingSession have separate state machines.

Job can contain multiple assignments and multiple ChargingSessions. Neither reassignment nor charger transaction restart creates a new job by itself.

# 8. Cancellation

Cancellation policy is business-configurable by lifecycle point but technical semantics are fixed:
- cancellation is idempotent;
- records actor/reason/time/policy consequence;
- atomically invalidates future dispatch offers;
- active Driver/charging requires explicit stop/reconciliation workflow;
- cancellation never fabricates physical charging stop;
- commercial cancellation fee/refund is pricing/payment domain output, not job-state side effect guessed in handler.

# 9. Arrival/service preparation/wrap-up

Driver arrival is accepted only for current assignment and location/proximity policy, or audited override. Service preparation can validate connector/assets/customer presence. Wrap-up requires charging no longer physically active or an explicit incident/reconciliation state. Job completion requires defined operational/commercial prerequisites, not merely Driver button press.

# 10. History

Customer history is reconstructed from job snapshots/finalized projections. Deleting/deactivating current saved vehicle/address does not break it.

# 11. Verification

Tests cover saved vs temporary promotion, history immutability, duplicate quote acceptance, quote expiration race, customer ownership, location edit before/after assignment, cancellation at every lifecycle phase, reassignment, multiple ChargingSessions and completion precondition enforcement.
