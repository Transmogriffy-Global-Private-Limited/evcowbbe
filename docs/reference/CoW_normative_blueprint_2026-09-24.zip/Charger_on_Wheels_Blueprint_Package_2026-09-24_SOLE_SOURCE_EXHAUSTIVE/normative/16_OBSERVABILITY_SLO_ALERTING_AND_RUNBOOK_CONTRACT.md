# Observability, SLO, Alerting, and Runbook Contract

**Status:** Normative scoped annex.
**Owns:** structured logging, metrics, health/readiness, engineering SLO baselines, alert severity and operational evidence.

# 1. Observability law

A system is not operationally complete if failures can only be discovered from customer complaints. Important asynchronous/physical/provider boundaries require a state metric, backlog/age metric and actionable logs without secrets.

# 2. Structured logs

JSON or equivalently structured production logs. Common fields:

```text
timestamp
level
service            # cms|hal
component
message
request_id nullable
correlation_id nullable
account/principal ids only when safe/needed
service_job_id nullable
duty_session_id nullable
charger_id nullable
charging_session_id nullable
operation/fact/event id nullable
error_class nullable
attempt nullable
duration_ms nullable
```

Do not log secrets or unrestricted bodies. Error chain is safe categorized text; stack only in protected diagnostic channel if needed.

# 3. HTTP metrics

```text
http_requests_total{service,route,method,status_class}
http_request_duration_seconds{service,route,method}
http_in_flight_requests{service}
http_rate_limited_total{route_class}
```

Use normalized route labels, never raw resource IDs as metric labels.

# 4. Database metrics

Connection pool utilization/wait, transaction duration, query class latency, deadlocks, serialization retries, migration version, DB availability. Do not label by arbitrary SQL text.

# 5. Domain metrics

At minimum:
- active drivers/duties/jobs/charging sessions;
- dispatch attempts/offers/accept/reject/expiry/no-candidate;
- stale Driver location count;
- asset claim conflicts/mismatch open count;
- charging start/stop/reconciliation states;
- HAL connection online/offline/unknown and fact lag;
- payment/refund reconciliation backlog;
- invoice generation backlog/failures;
- notification/realtime metrics from Annex 10;
- outbox/worker due count + oldest age for every critical queue;
- mobile energy unknown/stale/insufficient/reservations when enabled.

# 6. HAL metrics

```text
hal_connections_current{protocol,state}
hal_commands_total{type,state}
hal_command_reconciliation_required
hal_active_transactions
hal_fact_outbox_due
hal_fact_outbox_oldest_seconds
hal_trace_outbox_due
hal_worker_last_success_timestamp{worker}
hal_protocol_messages_total{protocol,message,result}
```

Vendor/charger ID is not a high-cardinality general metric label. Use logs/technical query for individual device diagnosis.

# 7. Health endpoints

CMS/HAL each expose:

```text
/health/live
/health/ready
/version
```

`live`: process event loop/server alive; does not fail because optional external provider is down.

`ready`: DB reachable/migrations compatible/critical initialization complete and service can safely accept its critical work. Readiness semantics are documented by service.

# 8. Operations status

Admin/ops status endpoint or internal dashboard exposes sanitized component states:

```text
DB
migration version
critical worker freshness/backlog
HAL link summary
payment/mail/push adapter configured/degraded
realtime publisher lag
storage writable/available
build revision
```

Do not return secret/config values.

# 9. Initial engineering SLO targets

These are starting operational targets, not contractual customer SLA:

```text
CMS ordinary API availability: 99.9% monthly target excluding planned maintenance
HAL fact receiver availability: 99.9%
P95 ordinary read/write latency: < 500 ms excluding external async operations
realtime committed-state to publish P95: < 2 s under designed load
critical worker oldest-due age: within 2x normal polling/retry target
```

Physical charger/provider availability is measured separately from service availability.

# 10. Alert severity

```text
P1: active physical/commercial integrity/safety risk or broad outage; immediate response
P2: major feature degraded/backlog threatens recovery/SLO; prompt response
P3: non-critical degradation/capacity trend; business-hours action
P4: informational/maintenance
```

# 11. Mandatory alert classes

P1/P2 as appropriate:
- CMS/HAL readiness sustained failure;
- DB unavailable/near exhaustion;
- fact outbox oldest age beyond safe threshold;
- charging reconciliation backlog/age;
- automatic stop/deadline worker stale;
- payment/refund outcome-unknown backlog;
- invoice failures/backlog;
- dispatch no-candidate spike if service should be staffed;
- realtime publisher lag/backpressure spike;
- push/mail provider auth/config terminal failure;
- disk/storage low/unwritable;
- migration mismatch;
- repeated HAL fact integrity conflict;
- backup/restore verification failure;
- mobile energy telemetry stale fleetwide when REQUIRED.

# 12. Dashboards

At least:
1. product operations: Drivers/jobs/dispatch/charging;
2. HAL/charger operations;
3. commerce: pricing/payment/refund/invoice;
4. async infrastructure: workers/outbox/notifications/realtime;
5. service health/capacity.

# 13. Tracing

OpenTelemetry-compatible request/service tracing is recommended for cross-service debugging, but trace IDs are correlation not truth. Sampling policy must not drop all error/slow traces. Trace payload obeys PII/secret exclusions.

# 14. Runbook link requirement

Every page-level alert has owner, meaning, verification query/dashboard, safe first actions, escalation and "do not do" note. Alerts that simply say "something failed" without action are incomplete.

# 15. Release evidence

Deployment record captures source revision, binary/image digest, migration version, config key parity (not values), service health, worker health, critical route checks and known unverified external/physical boundaries.
