# Test, Fixture, Simulator, and Acceptance Specification

**Status:** Normative scoped annex.
**Owns:** required test layers, deterministic fixtures, simulator behavior, failure injection, load/soak, and evidence labels.

# 1. Evidence labels

Use exact labels in completion/release records:

```text
SOURCE_VERIFIED
UNIT_TESTED
POSTGRES_INTEGRATION_TESTED
SERVICE_INTEGRATION_TESTED
VIRTUAL_CHARGER_ACCEPTED
PROVIDER_SANDBOX_ACCEPTED
RUNTIME_VERIFIED
PHYSICAL_HARDWARE_ACCEPTED
PRODUCTION_PROVIDER_ACCEPTED
UNVERIFIED_EXTERNAL_BOUNDARY
```

One label does not imply a stronger one.

# 2. Unit tests

Pure deterministic tests for state transitions, pricing/compensation rule evaluation, compatibility, authorization helper logic, serialization/digests, cursor/token codecs, event projections and provider error classification.

# 3. Deterministic test infrastructure

Inject:
- Clock;
- UUID/ID generator where exact fixtures need stable IDs;
- random/secret generator interface for tests (production uses CSPRNG);
- routing/payment/push/mail/storage adapters;
- HAL client;
- failure injector hooks around important crash boundaries.

Tests MUST NOT sleep real minutes or depend on public internet.

# 4. PostgreSQL integration harness

Each repository has disposable database setup, migrations, cleanup and guard that refuses obvious non-test database names/hosts unless explicit destructive-test acknowledgment in isolated CI. CI spins real PostgreSQL.

Test migration up from zero and upgrade from supported previous schema snapshots. Down migrations only tested where explicitly safe; refusal is valid behavior for history-preserving migrations.

# 5. Concurrency tests

Use barriers/channels to cause actual overlapping transactions. Required race matrix comes from Annex 42 and burner contracts. Run enough repeated iterations to catch lock/constraint errors but keep deterministic assertions.

# 6. Golden cross-repo fixtures

Versioned directory/artifact contains:
- CMS->HAL mapping/start/stop/operation requests/responses;
- HAL->CMS every fact type;
- trace envelope;
- canonical digests;
- errors/version conflict;
- lookup responses.

Both repos pin fixture version+digest and run parser/producer compatibility tests.

# 7. Virtual charger simulator

Simulator supports deterministic script steps:

```text
connect / disconnect
boot/register
heartbeat
status
accept/reject/ignore command
start transaction
meter Wh sample
SoC sample
fault
stop transaction
local stop
reconnect
process restart simulation
message duplicate/reorder/delay
```

Script can assert received normalized command inputs and emit exact OCPP adapter messages.

# 8. Full E2E scenario catalog

At minimum:
1. new customer -> saved vehicle/address -> quote -> job;
2. temporary vehicle/address -> history -> promote;
3. Driver application/onboarding -> scheduled duty;
4. unscheduled duty if policy allows;
5. assigned expected assets;
6. observed asset mismatch and Admin reconciliation;
7. dispatch sequential accept;
8. accept race with one winner;
9. no candidate;
10. reassignment;
11. start charging happy path;
12. start response lost after possible delivery;
13. late transaction-start fact;
14. meter/SoC duplicate/out-of-order;
15. HAL reconnect/restart during charge;
16. multiple charging transactions in one job;
17. physical stop then final commercial calculation;
18. payment response loss/webhook duplicate;
19. invoice crash/retry immutable artifact;
20. Driver compensation with time boundary/reassignment;
21. support/rating/notification/realtime reconnect convergence.

When mobile energy REQUIRED, add reservation/insufficient/stale/telemetry-loss scenarios.

# 9. Provider failure fixtures

For every adapter:
- success;
- client-invalid terminal;
- provider auth/config terminal;
- rate limited with Retry-After;
- 5xx transient;
- timeout before connection;
- timeout after request may have been sent;
- malformed response;
- duplicate webhook/callback;
- same external event ID altered payload.

# 10. Realtime tests

Exact matrix from Annex 10: ticket race, auth, cursor tamper, replay/live no-gap, duplicate/out-of-order, retention resync, access revoke, backpressure, drain/restart, REST convergence.

# 11. Pricing/comp fixtures

Golden expected line items/totals rather than only final total. Include boundary instants, rounding and corrections.

# 12. Load tests

Before production-size acceptance, test:
- Driver location ingest expected fleet rate x safety factor;
- realtime concurrent connections/event burst/reconnect storm;
- dispatch candidate query under realistic fleet/zone indexes;
- meter fact ingest/outbox/realtime coalescing;
- Admin operational dashboard queries;
- background workers under backlog.

Record hardware/container resources, dataset size, offered load, latency/error/memory/DB metrics. "It felt fast" is not evidence.

# 13. Soak

Staging long-session/full-day soak includes active virtual charging, periodic reconnects, workers, notifications/realtime, DB pool and storage. Check memory/FD/goroutine growth, backlog convergence and projection correctness.

# 14. Physical hardware certification

Annex 32 defines device matrix. Physical acceptance cannot be claimed from simulator. Capture charger model/firmware/protocol/config, scenario result, raw evidence refs and known quirks.

# 15. Production provider acceptance

Sandbox success is not production acceptance. Production smoke uses smallest safe transaction/message where business permits and records exact evidence without secrets.

# 16. CI baseline

For each Go repo:

```bash
gofmt check
go test -p 1 ./...        # or measured safe parallelism
go vet -p 1 ./...
go build -p 1 ./...
go mod verify
git diff --check
contract/OpenAPI verifier
migration/schema verifier
```

Repository can increase parallelism after constrained-host/CI evidence.

# 17. Flake policy

A flaky test is a bug. Quarantine is temporary, documented with owner/work item and cannot silently count toward release acceptance of the affected invariant.

# 18. Completion evidence packet

Burner closeout records exact commands/tests, relevant DB/service/provider/simulator environment, source SHA, changed migrations/contracts, skipped boundaries and why. Never say "E2E passed" without naming what systems were actually in the E2E.
