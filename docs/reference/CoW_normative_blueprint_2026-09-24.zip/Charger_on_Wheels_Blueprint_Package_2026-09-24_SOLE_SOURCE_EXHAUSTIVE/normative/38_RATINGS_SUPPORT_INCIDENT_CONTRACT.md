# Ratings, Support, and Incident Contract

**Status:** Normative scoped annex.
**Owns:** customer rating ownership, support channel/privacy/lifecycle, operational incidents and their separation.

# 1. Ratings/reviews

One customer rating belongs to one completed ServiceJob owned by that customer. V1 scale is integer 1..5. Review text is optional, trimmed, size-bounded and treated as untrusted content.

Customer operations:
- create/replace own rating for eligible completed job;
- read own rating/history;
- cannot read another customer's identity through ratings.

Admin operations:
- read/search ratings with operationally required customer/job context under capability;
- cannot silently edit the customer's submitted rating/review; moderation, if added, is a separate audited visibility action preserving original content.

Charger/Driver aggregate ratings, if exposed, are read-time/materialized rebuildable projections from eligible ratings. Count is explicit; average is null when count=0. Deleting/invalidating a rating changes projection through durable source state, never manual counter edits.

# 2. Support channels

V1 channels are semantically distinct:

```text
CUSTOMER_PLATFORM
DRIVER_PLATFORM
```

Do not merge actor identity planes. A ticket stores owner customer or driver according to channel; Admin staff reply as ADMIN actor.

Ticket states:

```text
OPEN -> IN_PROGRESS | RESOLVED | CLOSED
IN_PROGRESS -> RESOLVED | CLOSED
RESOLVED -> OPEN | CLOSED
CLOSED -> OPEN
```

Same-state mutation is side-effect-free. Owner reply to RESOLVED/CLOSED atomically reopens OPEN and records immutable history. Admin reply alone does not silently change status.

# 3. Support message identity/privacy

Every message has immutable ID, ticket ID, actor plane, actor ID reference for internal audit, body, created_at. Customer-facing projection uses author category such as `CUSTOMER`/`SUPPORT`; Driver-facing uses `DRIVER`/`SUPPORT`. Admin internal identity/email is not leaked to ordinary app surfaces unless business policy explicitly exposes a display alias.

Support message bodies are not copied into push/email notification payloads.

# 4. Support idempotency/concurrency

Reply requires idempotency key. Transaction locks ticket, applies reopen if needed, inserts exactly one message/history/outbox. Same key + same body returns original; same key + different body conflicts.

List order is `updated_at DESC, id DESC` with keyset cursor. Filters execute before LIMIT.

# 5. Incident domain

Incident is operational/safety/problem management, not support chat. It may be created by Driver/Admin/system and reference job, duty session, vehicle, charger, charging session and support ticket.

Baseline states:

```text
OPEN
ACKNOWLEDGED
INVESTIGATING
MITIGATED
RESOLVED
CLOSED
```

Severity:

```text
INFO
LOW
MEDIUM
HIGH
CRITICAL
```

Safety-critical incident can make Driver/assets/jobs unavailable through explicit domain actions, not by mutating incident state alone.

# 6. Evidence and corrections

Incident attachments/evidence use secure storage refs and audit provenance. Resolution records cause/category/action and actor. Closing incident never deletes evidence. If an incident caused master-data correction, link the resulting asset/job/admin action.

# 7. Notification

Support and incident triggers use Annex 26. Notification summaries contain ticket/incident metadata and deep link, not sensitive body/evidence.

# 8. Verification

Tests include rating ownership/edit, aggregate consistency, support cross-owner 404 isolation, reply idempotency/reopen race, Admin capability deny, incident state transition, attachment auth, safety action audit and notification privacy.
