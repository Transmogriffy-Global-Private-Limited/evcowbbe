# Driver Compensation Engine Contract

**Status:** Normative scoped annex.
**Owns:** deterministic compensation policy selection, rule composition, source-fact binding, line-item ledger, corrections and Driver/Admin views. It does not execute payouts.

# 1. Non-payout law

Calculated compensation is not payment. No state or UI may call a figure `PAID` unless a future explicit accounting/payout feature introduces authoritative payment evidence.

# 2. Policy selection

One versioned CompensationPolicy is selected by job/duty/effective scope. Policy status is `DRAFT`, `ACTIVE`, or `RETIRED`. Activation validates overlapping rules and deterministic priority.

Historical calculation pins policy/version and rule versions.

# 3. Supported bases

```text
COMPLETED_JOB_COUNT
TRAVEL_DISTANCE_M
TRAVEL_TIME_S
WAITING_TIME_S
CHARGING_TIME_S
ENERGY_DELIVERED_WH
FINAL_REVENUE_MINOR
TIME_INTERVAL
DATE_WINDOW
ZONE
DRIVER
DRIVER_GROUP
```

Every basis names its authoritative source fact. Freeform Driver input never becomes financial authority without explicit reviewed adjustment.

# 4. Operators and order

Rules support:

```text
ADD
OVERRIDE
MULTIPLY
MINIMUM_GUARANTEE
CAP
```

Deterministic order:
1. derive source quantities;
2. calculate base ADD rules by ascending priority/stable rule ID;
3. apply scoped OVERRIDE to declared target rate/component;
4. apply MULTIPLY rules to declared eligible subtotal/component in priority order;
5. apply MINIMUM_GUARANTEE to declared scope;
6. apply CAP to declared scope;
7. append approved compensation adjustments separately.

Rule configuration must name target scope. A generic multiplier with no target is invalid.

# 5. Time boundaries

Each time rule declares one of:

```text
JOB_START
JOB_END
EVENT_TIME
INTERVAL_PRORATED
```

`INTERVAL_PRORATED` splits time exactly at timezone-aware boundaries. If distance must also be prorated, it uses trusted timestamped trace segments; absence of sufficient trace makes that component pending/unavailable rather than inventing proportional distance.

DST behavior uses IANA timezone rules, although India deployments normally use Asia/Kolkata with no DST.

# 6. Reassignment

Compensation belongs to actual work performed, not merely final assignment. Reassignment policy declares allocation bases, for example travel segment before handoff, waiting/charging performed after handoff, or explicit Admin adjustment. Historical assignment/duty references are retained in each line item.

# 7. Ledger

A finalized job compensation calculation stores one immutable calculation header and line items:

```text
calculation_id, job_id, driver_id, duty_session_id,
policy_id, policy_version, status, currency,
source_fact_digest, calculated_at, finalized_at

line_item:
component_type, rule_id, rule_version, source_refs,
quantity_decimal, unit, rate, operator, amount_minor,
explanation_params
```

Totals are derived from line items.

# 8. Recalculation and correction

Before finalization, deterministic recalculation may replace a draft calculation if source version changes. After finalization, source correction creates a new version plus compensating adjustment entries; old finalized ledger remains queryable/auditable.

# 9. Views

Driver sees own per-job line items and daily/weekly/monthly/custom aggregates, with human explanation. Admin sees same plus filters/export and adjustment provenance. Driver cannot see another Driver's compensation.

# 10. Invariants

- one current finalized calculation version per `(job, driver, compensation_basis_version)`;
- amount arithmetic uses integer minor currency units;
- source facts are frozen/referenced;
- no mutable current policy changes old totals;
- adjustment requires Admin compensation capability and reason;
- aggregate is sum of ledger, not separate mutable truth.

# 11. Verification

Golden fixtures cover additive base, distance/time, night boundary, date bonus, Driver override, group modifier, multiple multipliers, minimum, cap, zero-distance, reassignment, corrected source fact, manual adjustment, concurrent finalization and timezone boundary.
