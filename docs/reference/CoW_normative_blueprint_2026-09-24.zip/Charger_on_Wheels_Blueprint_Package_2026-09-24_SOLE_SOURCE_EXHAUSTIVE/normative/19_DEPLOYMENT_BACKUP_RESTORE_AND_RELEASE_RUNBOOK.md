# Deployment, Backup, Restore, and Release Runbook

**Status:** Normative scoped annex.
**Owns:** initial safe deployment shape, migration sequencing, backups, activation verification, rollback/forward-fix and disaster recovery discipline.

# 1. Initial topology

Recommended production/staging shape:

```text
Internet/native clients
  -> TLS reverse proxy/load balancer
  -> CMS loopback/private listener
  -> CMS PostgreSQL

Chargers
  -> TLS/WSS reverse proxy
  -> dedicated HAL listener
  -> HAL PostgreSQL

CMS <-> HAL over authenticated private/public TLS service routes
```

CMS and HAL can share one VPS early only if process, DB, ports, filesystem, service units and failure boundaries remain distinct. Production topology is decision-gated by capacity/RPO/RTO.

# 2. Service filesystem baseline

Example, not externally fixed host fact:

```text
/opt/charger-on-wheels-cms
/opt/charger-on-wheels-hal
/etc/charger-on-wheels/cms.env
/etc/charger-on-wheels/hal.env
/var/lib/charger-on-wheels/...
```

Secrets mode 0600; private artifacts least-privilege service user. Existing shared reverse proxy config is edited minimally and validated before reload.

# 3. Before every release

- explicit authorization to deploy/migrate;
- clean/intended git worktree and exact source SHA;
- review current work item/ADR/contracts;
- build/test/contract/migration checks;
- inspect current runtime revision/migration/service health;
- validate config key parity without values;
- disk/DB capacity;
- identify migration compatibility class;
- identify rollback/forward-fix path;
- create backup when schema/data consequence warrants;
- verify backup can be read/listed/checksummed;
- preserve current binary/image digest;
- verify dependent CMS/HAL mixed-version compatibility ordering.

# 4. Migration compatibility classes

```text
EXPAND_COMPATIBLE: additive nullable/table/index; old+new binaries safe
BEHAVIOR_SWITCH: schema supports both, deployment/config flips behavior after binaries
CONTRACTING: removes/changes old usage; only after all old binaries/workers gone and data migrated
HISTORY_LOCKING: down may be unsafe/refuse once history exists; forward fix preferred
```

Burner/release documents class before deploy.

# 5. Backup

CMS and HAL DB backups are separate. Use PostgreSQL custom-format or environment-approved consistent backup with checksum, restricted permissions and retention. Private object/file storage backup strategy matches provider.

A backup is not proven until periodic restore drill succeeds.

# 6. Deployment ordering

Use compatibility matrix. General expand/contract:
1. compatible migration;
2. deploy producer/consumer that can handle old+new;
3. verify;
4. switch behavior/config;
5. migrate/backfill in bounded worker if needed;
6. after compatibility window, contracting migration in separate release.

For CMS-HAL contract change, deploy side that can accept both old/new first, verify fixture/runtime, then producer. Never require simultaneous restart as only correctness mechanism unless unavoidable and documented.

# 7. Activation

Use established deployment helper/systemd/container mechanism, not ad hoc kill commands. Preserve previous artifact. Migrations run deliberately, not hidden unexpectedly inside every app boot in production unless explicitly chosen and safe.

# 8. CMS verification

After activation:
- service active/restart count expected;
- process artifact digest/source revision;
- local/public live+ready;
- version/migration endpoint;
- OpenAPI/docs if enabled;
- protected routes reject unauthenticated;
- DB migration ledger/constraints;
- critical workers fresh/backlogs sane;
- realtime ticket/SSE smoke;
- config parity;
- post-start journal no panic/fatal/repeating integrity error.

# 9. HAL verification

- service active/restart count;
- binary/source revision;
- API and WSS listener expected;
- DB migration;
- command/fact/trace workers fresh;
- known simulator/charger mapping/connectivity smoke as release requires;
- CMS fact receiver integration if contract changed;
- no old-process stale listener.

# 10. Feature verification

Exercise changed behavior at strongest safe boundary. A healthy `/ready` does not prove provider, HAL command or physical charging behavior.

# 11. Rollback decision

Before rollback ask:
- has new binary written data old binary cannot understand?
- did migration down explicitly refuse history?
- did external side effect happen?
- would rollback replay/loss be worse than forward fix?

Binary rollback is allowed only with schema/data compatibility. Otherwise disable feature if safe and forward-fix.

# 12. Release record

Use template. Include source SHA, artifact digest, migration high-water mark, config schema version/key parity, start/end, operator, backups/checksums, exact verification, external boundaries not tested, rollback asset/decision.

# 13. Backup schedule baseline

Until capacity/RPO policy supersedes:
- daily DB backup for active environments that matter;
- pre-consequential-migration backup;
- weekly restore verification in non-production disposable DB;
- retention at least 7 daily + 4 weekly where storage permits, subject to privacy/legal rules.

Production RPO/RTO is explicit decision gate, not implied by this baseline.

# 14. Disaster recovery priorities

1. preserve evidence/do not worsen physical/commercial uncertainty;
2. restore DB/storage from validated backup;
3. verify migrations/source compatibility;
4. restart CMS/HAL separately;
5. reconcile unresolved HAL/provider/outbox operations by exact identities;
6. rebuild projections;
7. verify critical customer/driver/admin views;
8. document data window and unresolved boundaries.

# 15. Reverse proxy/system service safety

Shared proxy config is treated as shared infrastructure. Validate config before reload, change only required host/routes, ensure SSE buffering/timeouts and WSS upgrade settings, do not disrupt unrelated services.

Do not run strict-shell options directly in interactive operator shell if they can terminate it unexpectedly; use reviewed child script for complex deployment steps.

# 16. Hotfix

Hotfix still requires work item/change record, focused tests, migration/rollback assessment and post-release verification. Emergency does not justify editing applied migration or direct DB history unless incident procedure explicitly records/manual correction and no safer path exists.
