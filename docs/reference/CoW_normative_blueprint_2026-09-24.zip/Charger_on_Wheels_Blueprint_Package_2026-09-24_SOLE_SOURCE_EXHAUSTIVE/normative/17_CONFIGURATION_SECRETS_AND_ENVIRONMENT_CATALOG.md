# Configuration, Secrets, and Environment Catalog

**Status:** Normative scoped annex.
**Owns:** configuration naming/validation, initial keys/defaults/ranges and environment parity. Actual secret values are never part of this package.

# 1. Configuration law

- non-secret configuration has typed defaults/ranges;
- secrets have no repository default;
- startup fails clearly for missing invalid required configuration;
- log key names/errors, never secret values;
- `.env.example` or generated schema contains the complete key set for each service;
- process environment overrides local ignored env file;
- runtime Admin business policy belongs DB when mutable/audited, not hidden env.

# 2. CMS core

```text
APP_ENV=development|staging|production
HTTP_LISTEN_ADDR=127.0.0.1:18080
DATABASE_URL=<secret>
LOG_LEVEL=INFO
PUBLIC_BASE_URL=<https-url>
BUILD_REVISION=<injected>
DEFAULT_TIMEZONE=Asia/Kolkata
SHUTDOWN_TIMEOUT_SECONDS=30
```

Production listener/topology is deployment-specific; do not blindly expose direct app port publicly.

# 3. Auth

```text
ACCESS_TOKEN_TTL_SECONDS=900
REFRESH_TOKEN_TTL_SECONDS=2592000
SESSION_ABSOLUTE_TTL_SECONDS=7776000
PASSWORD_ARGON2_MEMORY_KIB=65536
PASSWORD_ARGON2_ITERATIONS=3
PASSWORD_ARGON2_PARALLELISM=1
PASSWORD_PEPPER=<secret>
OTP_HMAC_PEPPER=<secret>
OTP_TTL_SECONDS=600
OTP_MAX_ATTEMPTS=5
OTP_RESEND_COOLDOWN_SECONDS=60
```

# 4. API/pagination

```text
API_DEFAULT_PAGE_LIMIT=20
API_MAX_PAGE_LIMIT=100
API_MAX_JSON_BODY_BYTES=1048576
CURSOR_HMAC_SECRET=<secret>
IDEMPOTENCY_DEFAULT_RETENTION_HOURS=24
IDEMPOTENCY_CRITICAL_RETENTION_HOURS=168
```

# 5. Rate limiting baseline

Exact limiter algorithm can be token bucket/sliding window but semantics/rates are validated:

```text
RATE_AUTH_PER_MINUTE=10
RATE_OTP_SEND_PER_HOUR=6
RATE_REFRESH_PER_MINUTE=12
RATE_NORMAL_READ_PER_MINUTE=300
RATE_NORMAL_MUTATION_PER_MINUTE=120
RATE_LOCATION_PER_MINUTE=120
RATE_REALTIME_TICKET_PER_MINUTE=30
RATE_SENSITIVE_COMMAND_PER_MINUTE=30
RATE_EXPORT_PER_HOUR=10
```

These are initial safety defaults and can be tuned by measured load without changing endpoint semantics.

# 6. CMS <-> HAL

CMS:

```text
HAL_BASE_URL=<https-url>
HAL_COMMAND_BEARER=<secret>
HAL_REQUEST_TIMEOUT_SECONDS=10
CMS_HAL_FACT_BEARER=<secret>
CMS_HAL_TRACE_BEARER=<secret>
HAL_FACT_MAX_BODY_BYTES=1048576
HAL_TRACE_MAX_BODY_BYTES=1048576
HAL_CONNECTION_STALE_SECONDS=180
HAL_RECONCILE_BATCH_SIZE=50
HAL_RECONCILE_POLL_SECONDS=5
```

HAL:

```text
HAL_DATABASE_URL=<secret>
HAL_LISTEN_ADDR=127.0.0.1:19080
HAL_WS_LISTEN_ADDR=127.0.0.1:19081
HAL_COMMAND_BEARER=<secret>
CMS_FACT_INGRESS_URL=<https-url>/internal/v1/hal-facts
CMS_TRACE_INGRESS_URL=<https-url>/internal/v1/hal-trace-events
CMS_HAL_FACT_BEARER=<secret>
CMS_HAL_TRACE_BEARER=<secret>
HAL_CMS_REQUEST_TIMEOUT_SECONDS=10
HAL_FACT_DELIVERY_POLL_MS=1000
HAL_TRACE_DELIVERY_POLL_MS=2000
HAL_OPERATION_WORKER_POLL_MS=2000
HAL_HEARTBEAT_STALE_MULTIPLIER=3
```

Plane credentials may have different actual secret values in each side's config but paired names must refer to corresponding credential.

# 7. Dispatch/location

```text
DRIVER_LOCATION_FRESH_SECONDS=30
DRIVER_LOCATION_MAX_ACCURACY_M=100
DRIVER_LOCATION_MAX_FUTURE_SKEW_SECONDS=30
DISPATCH_MODE=SEQUENTIAL
DISPATCH_OFFER_TTL_SECONDS=30
DISPATCH_BATCH_SIZE=1
DISPATCH_MAX_CANDIDATES=50
DISPATCH_ATTEMPT_MAX_SECONDS=300
SCHEDULE_DISPATCH_LEAD_SECONDS=900
ARRIVAL_DEFAULT_RADIUS_M=150
```

Business may change values via Admin policy later; source of authority must be one place, not env and DB simultaneously.

# 8. Routing/maps

```text
ROUTING_PROVIDER=NONE|<adapter-name>
ROUTING_API_BASE_URL=<trusted-url>
ROUTING_API_KEY=<secret>
ROUTING_TIMEOUT_SECONDS=5
ROUTING_RESULT_TTL_SECONDS=120
ROUTING_HAVERSINE_FALLBACK_ENABLED=true
```

Provider choice is decision gate. `NONE` is acceptable for early non-routing burners.

# 9. Realtime

```text
REALTIME_TICKET_TTL_SECONDS=60
REALTIME_HEARTBEAT_SECONDS=15
REALTIME_CLIENT_IDLE_TIMEOUT_SECONDS=45
REALTIME_REPLAY_RETENTION_HOURS=24
REALTIME_MAX_CONNECTIONS_PER_ACCOUNT=4
REALTIME_MAX_CONNECTIONS_PER_SESSION=2
REALTIME_MAX_SUBSCRIPTIONS_PER_CONNECTION=32
REALTIME_MAX_OUTBOUND_EVENTS=256
REALTIME_MAX_OUTBOUND_BYTES=1048576
REALTIME_USER_LOCATION_MIN_INTERVAL_MS=3000
REALTIME_ADMIN_LOCATION_MIN_INTERVAL_MS=2000
REALTIME_CHARGING_METER_MIN_INTERVAL_MS=2000
REALTIME_CURSOR_HMAC_SECRET=<secret>
```

# 10. Notifications

```text
PUSH_PROVIDER=NONE|FCM|APNS|WEBPUSH|MULTI
PUSH_PROVIDER_CREDENTIALS=<secret/provider-specific>
PUSH_MAX_ATTEMPTS=8
PUSH_RETRY_HORIZON_HOURS=24
MAIL_PROVIDER=NONE|SMTP|<adapter-name>
SMTP_HOST=<host>
SMTP_PORT=587
SMTP_USERNAME=<secret>
SMTP_PASSWORD=<secret>
MAIL_FROM_ADDRESS=<address>
MAIL_FROM_NAME=<name>
MAIL_MAX_ATTEMPTS=10
MAIL_RETRY_HORIZON_HOURS=72
```

# 11. Payments

```text
PAYMENT_PROVIDER=NONE|RAZORPAY
RAZORPAY_KEY_ID=<secret-like id>
RAZORPAY_KEY_SECRET=<secret>
RAZORPAY_WEBHOOK_SECRET=<secret>
PAYMENT_PROVIDER_TIMEOUT_SECONDS=10
PAYMENT_RECONCILE_POLL_SECONDS=30
```

Customer collection design must be activated only after business/provider decision gate.

# 12. Storage

```text
STORAGE_PROVIDER=LOCAL|S3_COMPATIBLE
PRIVATE_STORAGE_ROOT=/var/lib/charger-on-wheels
S3_ENDPOINT=<trusted-url>
S3_BUCKET=<name>
S3_REGION=<region>
S3_ACCESS_KEY=<secret>
S3_SECRET_KEY=<secret>
UPLOAD_MAX_KYC_BYTES=10485760
UPLOAD_MAX_INCIDENT_BYTES=10485760
```

Local production path is environment-specific; exact path above is a safe baseline example only when chosen.

# 13. Pricing/commercial

```text
DEFAULT_CURRENCY=INR
QUOTE_DEFAULT_TTL_SECONDS=900
PRICING_ENGINE_ENABLED=true
```

Rates/tax rules live in versioned DB policy, never env constants.

# 14. Mobile energy

```text
MOBILE_ENERGY_MODEL=NOT_REQUIRED|REQUIRED
MOBILE_ENERGY_OBSERVATION_STALE_SECONDS=60
MOBILE_ENERGY_RESERVATION_TTL_SECONDS=300
MOBILE_ENERGY_MIN_RESERVE_WH=<required if REQUIRED>
```

If REQUIRED, service startup/admin activation rejects missing critical values.

# 15. Worker defaults

```text
WORKER_DEFAULT_BATCH_SIZE=50
WORKER_DEFAULT_LEASE_SECONDS=60
WORKER_IDLE_POLL_MS=1000
WORKER_MAX_BACKOFF_SECONDS=300
WORKER_SHUTDOWN_GRACE_SECONDS=20
```

Critical worker can override with named key when needed.

# 16. Retention

```text
RETENTION_REALTIME_HOURS=24
RETENTION_LOCATION_RAW_DAYS=30
RETENTION_HAL_TRACE_DAYS=30
RETENTION_NOTIFICATION_DAYS=365
RETENTION_AUDIT_DAYS=<business/legal decision>
RETENTION_KYC_DAYS=<legal decision>
```

Unset legally dependent retention blocks production activation of corresponding cleanup, not startup of unrelated development.

# 17. CORS

```text
CORS_ALLOWED_ORIGINS=<comma-list exact origins>
CORS_PREFLIGHT_MAX_AGE_SECONDS=600
```

Production empty/invalid origin policy fails safe for browser integration rather than default `*`.

# 18. Feature gates

```text
FEATURE_REALTIME_ENABLED=true
FEATURE_PUSH_ENABLED=false until provider configured
FEATURE_MAIL_ENABLED=false until provider configured
FEATURE_MOBILE_ENERGY_ENABLED=<derived from model>
FEATURE_ROUTING_ENABLED=<derived from provider>
FEATURE_OCPP201_ENABLED=false initially
FEATURE_OCPP21_ENABLED=false initially
```

A feature flag does not change historical semantics. It enables a capability whose data migrations/contracts are already safe for that rollout.

# 19. Config validation/introspection

Provide startup validator and safe internal/admin diagnostics returning:
- expected key names;
- present/missing/blank state;
- parsed non-secret effective values where safe;
- secret fields as PRESENT/ABSENT only;
- source (default/env/policy) where useful.

Before deployment compare `.env.example` key set to actual names without printing values.
