# Project Execution Playbook

**Status:** Normative scoped annex.
**Owns:** how an engineer/AI uses this package burner-by-burner, handles discoveries and proves completion.

# 1. Start from package

1. Read `00_PACKAGE_INDEX.md`.
2. Read canonical Sections 0, 1, 64-72 and Appendix H.
3. For chosen burner, read Appendix H card + all cited canonical sections + scoped normative annexes + relevant registries/templates.
4. After repo exists, inspect repository AGENTS/current state/migrations/runtime because implementation reality can evolve.
5. Create repository work item before code.

# 2. Burner preflight

Work item must resolve before editing:
- exact objective and non-goals;
- dependencies implemented/verified;
- relevant authority files/registry rows;
- actors/ownership/privacy;
- state-machine edges;
- table/constraint/index impact;
- API/event/realtime/notification impact;
- idempotency/concurrency lock order;
- worker/external side effect/recovery;
- migration compatibility and rollback/forward fix;
- observability/alerts;
- test/evidence boundary;
- frontend/ops docs impact.

If a genuine external decision gate is needed, stop only that burner and record exact question. Do not invent answer.

# 3. Execution order inside burner

Recommended:
1. tests/fixtures for invariant/contract where practical;
2. migration/schema constraints;
3. domain/repository logic;
4. service transaction/state transition;
5. HTTP/internal adapter;
6. events/workers/recovery;
7. OpenAPI/registries/docs;
8. unit + real Postgres + contract tests;
9. runtime/provider/simulator acceptance only if authorized/required.

Order may adapt to reality but no layer is silently skipped.

# 4. Development discovery classification

When code/reality reveals something unexpected, classify:

```text
A. implementation detail fully consistent with package -> choose simplest clean implementation, document locally if needed
B. package ambiguity -> resolve by existing higher-order law/annex, then clarify package/repo contract
C. new external fact/business decision -> Decision Gate/ADR
D. package assumption false -> stop affected work, update root semantics and all downstream contracts/tests
E. unrelated bug/regression -> isolate corrective work item unless it blocks burner
```

Never preserve known error merely for document consistency.

# 5. Completion packet

Burner is done only when relevant:
- code formatted/builds;
- DB migration/constraints/indexes applied in disposable test;
- unit/state tests;
- concurrency/integration tests;
- OpenAPI/runtime route parity;
- event/registry/generated artifacts current;
- no secret/log issue;
- recovery/failure injection tested;
- frontend/ops handoff updated;
- work item archived with evidence labels;
- git diff/check/status clean of accidental files;
- runtime deployment only if explicitly authorized and verified separately.

# 6. Definition of Done categories

No feature is complete with only handler/service. Check:

```text
semantics
ownership/auth
persistence/invariants
API contract
idempotency
concurrency
failure/recovery
history/snapshots
realtime
notifications
audit
migration
observability
security/privacy
tests
OpenAPI/docs
frontend/ops consumer
runtime/external acceptance boundary
```

Feature with no impact on a category explicitly marks N/A with reason rather than forgetting it.

# 7. Commit/push/deploy authority

Implementing code does not imply authorization to commit, push, migrate dev/staging/prod, restart services or call real providers/hardware. Preserve user instruction. When authorized, source publication and runtime deployment are separate evidence steps.

# 8. Review questions

Before claiming done ask:
- what happens on duplicate request?
- what happens if two actors race?
- what happens if process dies before/after DB commit?
- what happens if external request times out after possible effect?
- what truth survives restart?
- can a different account/principal guess this resource ID?
- does current master-data edit rewrite history?
- does realtime/provider message become accidental authority?
- is there a bounded queue/page/retention?
- can ops detect/recover failure?
- did we verify with real Postgres/provider/simulator/physical boundary as claimed?

# 9. Stop conditions

Stop unsafe execution when:
- intended target DB/environment uncertain;
- destructive migration has no understood backup/recovery;
- secret would be exposed;
- current worktree contains unrelated unknown edits that would be overwritten;
- external effect identity/reconciliation unknown;
- package/runtime evidence conflict cannot be resolved safely;
- required external decision gate unresolved.

Stopping unsafe action is not deferral; continue all safe preparatory/verifiable work.

# 10. Change propagation

Semantic change updates all affected: canonical/package annex, DB schema, API/OpenAPI, events/registries, frontend contract, workers/recovery, tests, docs, ADR/project state. Package/repository change control prevents stale parallel truths.

# 11. Data migration/backfill

Backfill is idempotent/restartable, bounded, observable and source-of-truth preserving. Large backfill is worker/job, not one giant migration transaction, unless measured safe. Completion gate verifies counts/invariants before enforcing final constraint.

# 12. Frontend integration release

Backend exposes stable contract/handoff before frontend guesses. Frontend uses actual OpenAPI/examples/realtime registry; integration bugs drive corrective burner, not undocumented workaround.

# 13. Operational release

Use Annex 19. "Tests passed" is source evidence; "deployed" requires runtime evidence; "works on charger/provider" requires that boundary evidence.

# 14. Continuity

At end of meaningful work, repository `PROJECT_STATE`/work item records current source, migrations, implemented burners, verification boundaries, unresolved gates and next burner. Future AI/session should need repo + this sole-source package, not chat archaeology.
