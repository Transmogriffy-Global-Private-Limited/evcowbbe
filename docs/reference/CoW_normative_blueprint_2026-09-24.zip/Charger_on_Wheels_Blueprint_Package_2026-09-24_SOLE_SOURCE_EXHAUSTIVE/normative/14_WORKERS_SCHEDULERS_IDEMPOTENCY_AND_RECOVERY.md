# Workers, Schedulers, Idempotency, and Recovery Contract

**Status:** Normative scoped annex.
**Owns:** common durable background-processing framework, worker inventory, leases/retries/checkpoints and crash recovery.

# 1. Worker law

Important background work is DB-backed. Process memory/timers can wake workers but are not durable truth. Work survives restart and can be claimed idempotently by another instance.

# 2. Claim pattern

Workers use bounded query + transaction:

```sql
SELECT ...
FOR UPDATE SKIP LOCKED
LIMIT $batch;
```

Then set `claimed_by`, random `claim_token`, `lease_expires_at`, attempt metadata and commit before external I/O. Result update includes `WHERE claim_token = ?`; stale worker cannot overwrite reclaimed work.

# 3. Retry classification

```text
SUCCESS
RETRYABLE_TRANSIENT
RETRYABLE_RATE_LIMITED
OUTCOME_UNKNOWN_RECONCILE
TERMINAL_INPUT
TERMINAL_CONFIGURATION
TERMINAL_INTEGRITY
```

Backoff exponential with jitter, capped by worker type. Rate-limit `Retry-After` honored within policy. Poison row never blocks unrelated rows.

# 4. Generic worker health

Each worker exposes:
- enabled/disabled reason;
- last loop/start/success/error time;
- due backlog count;
- oldest due age;
- active claims;
- attempts/result metrics.

Readiness fails only when a worker required for safe operation is unhealthy beyond configured threshold, not for every optional provider outage.

# 5. CMS worker inventory

## 5.1 outbox_dispatcher
Publishes internal durable domain/outbox deliveries. Does not perform provider-specific semantics unless delivery target is explicitly that adapter.

## 5.2 realtime_publisher
Turns eligible committed domain events into bounded audience-safe realtime rows/targets idempotently. It never reads uncommitted domain state or creates a business transition.

## 5.3 notification_intent_worker
Maps domain event trigger to recipients/templates/preferences and creates notifications + external channel delivery rows.

## 5.4 push_delivery_worker
Calls push adapter. Invalid token is terminal and device is deactivated. Timeout after possible provider acceptance reconciles according to provider idempotency/lookup support.

## 5.5 email_delivery_worker
Renders/sends versioned template. Provider/SMTP acceptance is recorded separately from notification existence.

## 5.6 dispatch_scheduler
Wakes immediate/scheduled jobs, starts/restarts dispatch attempts idempotently, expires offers and never creates duplicate active attempt.

## 5.7 location_retention_cleanup
Deletes/downsamples expired high-frequency samples only after retention/legal-hold checks. Current location projection remains valid independently.

## 5.8 charging_command_dispatcher
Claims durable CMS->HAL commands that are safe for first delivery. Marks DELIVERY_ATTEMPTED before network I/O. Possible delivery is not blindly replayed.

## 5.9 charging_reconciler
Exact-ID lookup for start/stop/operation ambiguity, missing facts and late evidence. Fair bounded batches and persistent `recover_after` prevent hot looping.

## 5.10 mapping_reconciler
Synchronizes CMS charger mapping versions to HAL. Inventory commit does not wait on HAL.

## 5.11 payment_reconciler
Exact provider order/payment lookup for outcome unknown/stale pending states.

## 5.12 refund_reconciler
Exact provider refund lookup; amount invariants remain DB-backed.

## 5.13 invoice_generator
Lease-claims invoice job, writes immutable artifact atomically and marks READY only after checksum/storage success.

## 5.14 export_worker
Creates bounded authorized snapshot exports. Rechecks requester/capability or uses frozen authorization grant according to export policy; expiry/storage cleanup separate.

## 5.15 retention_cleanup
Executes retention class cleanup in small batches, respects legal hold and records metrics/audit for sensitive deletion.

## 5.16 realtime_retention_cleanup
Removes replay rows older than retention only; no durable domain truth.

## 5.17 mobile_energy_reconciler (conditional)
Refreshes/resolves energy observations/reservations when energy model REQUIRED.

# 6. HAL worker inventory

Keep independent worker loops so one blocked concern cannot starve another:

```text
command delivery worker
generic charger-operation worker
automatic charging deadline/limit ticker
reconnect/transaction recovery worker
fact outbox delivery worker
trace outbox delivery worker
retention/cleanup worker
```

Fact outbox and trace outbox are separate. Automatic safety/stop timing is never queued behind a long generic Admin operation queue.

# 7. Scheduler clocks

Schedulers are level-triggered: each run asks "what durable rows are due now?" rather than relying on one in-memory timer per row. Restart simply resumes due scan.

# 8. Idempotent consumers

Every domain-event consumer records deterministic consumer+event identity or produces a uniquely constrained output. At-least-once upstream must not duplicate logical notifications, invoices, dispatch attempts or projections.

# 9. Webhooks

Provider webhook receipt:
1. authenticate/signature verify against raw body;
2. enforce body size/content type;
3. derive immutable provider event identity;
4. persist receipt/digest transactionally;
5. same ID/same digest -> success no-op;
6. same ID/different digest -> integrity alert/conflict;
7. process state transition idempotently;
8. acknowledge only after durable acceptance required by provider.

# 10. Graceful shutdown

On SIGTERM:
- stop accepting new HTTP work as server drains;
- stop taking new worker claims;
- cancel/finish in-flight work within shutdown budget;
- do not mark unknown external outcome as failed merely due cancellation;
- release/allow leases to expire safely;
- join worker goroutines before closing DB clients.

# 11. Crash injection points

Integration tests inject crash/restart:
- after durable intent before external call;
- after request bytes may be sent before response;
- after external success before local result commit;
- after local result commit before HTTP/worker acknowledgement;
- during lease expiration;
- after artifact write before READY;
- during realtime replay/live handoff.

# 12. Recovery acceptance

For each external-effect worker, documentation states the exact answer to: "If process dies at every line around the external call, how do we know whether to retry, reconcile, or stop?" No worker is production-complete without that answer and tests at the strongest practical boundary.
