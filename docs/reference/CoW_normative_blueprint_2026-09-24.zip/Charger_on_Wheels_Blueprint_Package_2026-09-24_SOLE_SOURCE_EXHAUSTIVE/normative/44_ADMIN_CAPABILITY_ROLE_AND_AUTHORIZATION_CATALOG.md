# Admin Capability, Role, and Authorization Catalog

**Status:** Normative scoped annex.
**Owns:** exact v1 Admin capability namespace, default role bundles, DENY semantics and action mapping. Endpoint registry capability column must use this vocabulary.

# 1. Capability namespace

V1 capabilities:

```text
users.read
users.manage

drivers.read
drivers.review
drivers.manage
drivers.suspend

fleet.read
fleet.manage
fleet.maintenance
fleet.assign

schedules.read
schedules.manage

dispatch.read
dispatch.manage
dispatch.override

jobs.read
jobs.manage
jobs.cancel
jobs.reassign

charging.read
charging.command
charging.reconcile
charging.trace.read

pricing.read
pricing.manage

payments.read
payments.manage
refunds.manage
invoices.read
invoices.manage

compensation.read
compensation.manage
compensation.adjust

ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage

notifications.read
notifications.manage
exports.manage

system.settings.read
system.settings.manage
audit.read
```

Adding a new Admin operation either maps to one existing semantic capability or introduces a new capability through package/repository contract change. Do not authorize by role name.

# 2. Effective capability

For a principal, evaluate role default grants plus principal/membership overrides. Explicit DENY wins over all ALLOW/default grants for the same capability.

Pseudo-rule:

```text
if explicit DENY(cap): false
else if explicit ALLOW(cap): true
else if any assigned role default grants cap: true
else false
```

No wildcard `*` is persisted as a client-visible shortcut unless implementation expands it server-side to exact capabilities. Full Admin is a bundle, not bypass.

# 3. Default role bundles

`FULL_ADMIN`: all capabilities above.

`OPERATIONS`:

```text
users.read
drivers.read
drivers.manage
fleet.read
fleet.manage
fleet.maintenance
fleet.assign
schedules.read
schedules.manage
dispatch.read
dispatch.manage
dispatch.override
jobs.read
jobs.manage
jobs.cancel
jobs.reassign
charging.read
charging.command
charging.reconcile
ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage
notifications.read
exports.manage
system.settings.read
audit.read
```

`DRIVER_RECRUITMENT`:

```text
drivers.read
drivers.review
drivers.manage
drivers.suspend
schedules.read
fleet.read
incidents.read
support.read
audit.read
```

`FINANCE_COMMERCIAL`:

```text
users.read
jobs.read
pricing.read
pricing.manage
payments.read
payments.manage
refunds.manage
invoices.read
invoices.manage
compensation.read
compensation.manage
compensation.adjust
ratings.read
support.read
incidents.read
exports.manage
audit.read
```

`SUPPORT`:

```text
users.read
drivers.read
jobs.read
charging.read
payments.read
invoices.read
ratings.read
support.read
support.reply
support.manage
incidents.read
incidents.manage
notifications.read
```

`TECHNICAL_HAL`:

```text
fleet.read
charging.read
charging.command
charging.reconcile
charging.trace.read
jobs.read
incidents.read
incidents.manage
system.settings.read
audit.read
```

`READ_ONLY`:

```text
users.read
drivers.read
fleet.read
schedules.read
dispatch.read
jobs.read
charging.read
pricing.read
payments.read
invoices.read
compensation.read
ratings.read
support.read
incidents.read
notifications.read
system.settings.read
```

Read-only does not include `audit.read` by default because audit may contain security-sensitive operator metadata.

# 4. Sensitive action requirements

In addition to capability, these require reason/audit:
- Driver suspend/offboard;
- force/emergency duty/job action;
- dispatch override/manual assignment;
- charger reset/unlock/change availability;
- reconciliation/manual charging correction;
- refund/manual payment adjustment;
- invoice retry/correction action;
- compensation adjustment;
- policy activation/retirement;
- retention/legal hold;
- capability/role changes.

# 5. Capability inheritance is forbidden

Capabilities are flat semantic permissions. `fleet.manage` does not automatically imply `fleet.read` unless role bundle grants both; handler requiring read+write can check both or write capability by contract. This avoids hidden hierarchy.

# 6. API/UI behavior

Admin bootstrap returns sorted effective capabilities, not role-trust claims. UI gates navigation/actions for ergonomics. Backend checks every request. 403 does not reveal sensitive hidden resource details beyond safe error.

# 7. Realtime

Admin SSE topic targets carry required capability. Capability revoke prevents future restricted delivery and active stream is re-evaluated as Annex 10.

# 8. Verification

For every Admin endpoint registry row:
- named capability exists here;
- allow role test;
- no-capability 403;
- explicit DENY 403 even when role grants;
- sensitive reason/audit test where applicable.
