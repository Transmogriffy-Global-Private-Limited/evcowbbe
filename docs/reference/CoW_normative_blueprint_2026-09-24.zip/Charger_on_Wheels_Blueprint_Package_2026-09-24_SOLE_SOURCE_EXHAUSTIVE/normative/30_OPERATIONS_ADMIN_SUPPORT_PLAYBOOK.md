# Operations, Admin, and Support Playbook

**Status:** Normative scoped annex.
**Owns:** intended day-to-day operational workflows and safe manual interventions. UI can vary; backend actions/invariants do not.

# 1. Driver recruitment queue

Admin filters submitted/action-required/expiring documents, opens one application, reviews immutable document versions, records decision reason, requests correction/approves/rejects. Every decision audited. Never edit applicant document evidence to make it pass.

# 2. Driver suspension/offboarding

Before suspension, inspect active duty/job/assets. Normal suspension prevents new duty/dispatch and schedules safe end. Emergency suspension can block immediately but must reconcile active job/asset and create incident/reason. Offboarding closes future eligibility; historical jobs/earnings remain.

# 3. Fleet maintenance

Mark planned maintenance with effective interval/reason. System shows active claims/jobs before activation. Normal operation waits/reassigns safely. Emergency out-of-service triggers operations incident/reassignment/charging safety workflow; do not simply flip status and strand job.

# 4. Pairing correction

Admin sees intended pairing, active DutySession observed pairing and mismatch history. Correction closes old effective pairing and creates new one. It never edits old DutySession/ServiceJob snapshot.

# 5. Dispatch monitoring

Dashboard shows jobs by state, attempt/offer age, eligible/excluded candidate diagnostics, Driver location freshness, current assignment. Admin can restart dispatch/reassign with reason/capability. Manual assignment still validates hard safety/capability/claim invariants.

# 6. Live charging operations

Display separately:
- CMS intent/command state;
- HAL connection/connector state freshness;
- physical transaction/session state;
- meter/SoC freshness;
- stop request/reconciliation;
- raw technical trace link for technical capability.

Admin reset/unlock/availability commands are idempotent durable operations and never UI-only fire-and-forget.

# 7. Charging reconciliation

If start/stop uncertain, first inspect exact CMS IDs, HAL lookup/facts and current charger/session state. Do NOT create another command just because UI spinner timed out. Use named reconcile/retry-safe operation. Record incident if physical/commercial inconsistency persists.

# 8. Payment/refund exception

Finance inspects local payment + verified provider identity/events. Outcome unknown triggers exact provider reconcile. Manual refund uses bounded refundable amount and reason. Never mark captured/refunded based on customer screenshot alone.

# 9. Invoice exception

FAILED/PENDING invoice can be retried after root cause/storage fixed. READY artifact checksum/version is immutable. Correction uses explicit commercial/accounting mechanism, not overwrite PDF.

# 10. Compensation correction

Admin sees line items/source facts/rules. If source fact corrected, generate new calc/adjustment according to policy. Manual adjustment requires reason and capability. Do not change old finalized line item silently.

# 11. Support

Support queue separated customer vs driver ownership. Reply/status actions preserve channel privacy. If support reveals operational/payment/incident problem, link/create appropriate domain incident/action rather than using support status as operational fix.

# 12. Incident

Critical incident gets severity, affected resources, owner, evidence, mitigation, resolution. Safety action is explicit and audited. Closing requires resolution summary; linked corrections remain independently durable.

# 13. Audit investigation

Search by resource/request/correlation/actor/time/action. Audit explains admin/domain action; HAL trace explains protocol evidence; neither substitutes for other. Export sensitive audit only under capability and itself audited.

# 14. Manual data correction

Never direct-edit production DB as ordinary procedure. Use explicit correction endpoint/tool/work item that checks invariants and creates audit/history. If emergency SQL is truly unavoidable, stop writers where needed, back up, capture exact before/after, execute reviewed minimal transaction, verify and then implement durable corrective path so state remains supported.

# 15. Shift handoff

Operations handoff records:
- active/reconciling jobs/charges;
- unavailable Drivers/assets;
- unresolved mismatch/incidents;
- payment/refund/invoice exceptions;
- critical worker/provider degradation;
- known planned maintenance;
- exact IDs/runbook links, no secrets.

# 16. Exports

Large operational/finance exports are async, capability/ownership-filtered, snapshot/query parameters recorded, private storage, expiry and audit. CSV cells are escaped against spreadsheet formula injection when export may be opened in spreadsheet.

# 17. Acceptance

Admin surface is considered operationally complete only when ordinary exception workflows can be resolved through supported audited actions without SQL/log archaeology for routine cases, while technical raw evidence remains available to technical staff for true faults.
