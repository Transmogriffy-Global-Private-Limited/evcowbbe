# Domain Glossary, Naming, and Enum Registry

**Status:** Normative scoped annex.
**Owns:** canonical vocabulary, ID naming, ambiguous terms to avoid and shared enum semantics.

# 1. Identity terms

**Account**: credential-bearing human identity. One account may own multiple principal planes.

**Customer**: customer-domain principal/profile associated with Account. Customer ID is not Admin/Driver ID.

**DriverApplication**: recruitment application record. Not DriverProfile and not operational state.

**DriverProfile**: onboarded workforce identity. May be suspended/offboarded independent of historical application.

**AdminPrincipal**: administrative principal associated with Account and capabilities.

# 2. Operational terms

**ServiceVehicle**: road vehicle carrying mobile charging equipment.

**Charger**: physical charging unit/EVSE controlled via HAL. Not the ServiceVehicle.

**ChargerConnector**: concrete connector/port on Charger.

**VehicleChargerPairing**: intended/master effective-dated physical pairing.

**DriverAssetAssignment**: Admin intended Driver/Vehicle/Charger assignment.

**AssetClaim**: current exclusive operational reservation by DutySession.

**DriverDutySession**: actual period in which a Driver is operational with snapshotted current assets/rules.

**Schedule**: planned work. Not actual DutySession.

**ServiceRequest**: customer request intent before accepted quote/job.

**Quote**: commercial estimate/snapshot with expiry.

**ServiceJob**: central field-service business object from accepted service through dispatch, charging and closeout.

**JobAssignment**: effective-dated Driver/Duty assignment history for ServiceJob.

**DispatchAttempt**: one bounded attempt to find/assign eligible Driver.

**DispatchOffer**: time-bounded opportunity sent to one Driver.

# 3. Charging terms

**ChargingIntent / ChargingStartIntent**: CMS business intent to begin physical charging. Not a ChargingSession.

**ChargingSession**: CMS materialized physical charging session created only from HAL authoritative transaction-start evidence.

**HAL transaction**: HAL-owned protocol transaction identity. May map to one CMS ChargingSession.

**HAL command**: durable HAL request/delivery lifecycle. Command accepted is not physical effect.

**HAL fact**: immutable normalized authoritative physical/protocol evidence delivered HAL->CMS.

**HAL trace**: diagnostic/raw/sanitized technical evidence. Never business truth by itself.

**ChargingProjection**: rebuildable/current display state derived from facts; not replacement for evidence.

# 4. Commercial terms

**PricingPolicy/Rule**: versioned customer price logic.

**PricingSnapshot/Evaluation**: frozen result/terms for quote/finalization.

**Payment**: customer collection lifecycle. Not Driver compensation.

**Refund**: provider-backed return of captured customer money.

**Invoice**: immutable READY commercial artifact derived from finalized truth.

**CompensationPolicy/Rule**: versioned Driver earning calculation logic.

**CompensationCalculation/LineItem**: calculated Driver amount ledger. Not payout/payment proof.

# 5. Event terms

**DomainEvent**: durable internal semantic event from committed state change.

**OutboxDelivery**: durable delivery work for event/intent.

**RealtimeEvent**: audience-safe bounded replay projection sent by SSE.

**Notification**: durable human-facing in-app message, optionally delivered via external channel.

Do not call all four simply "event" in APIs/docs when ownership matters.

# 6. Ambiguous terms forbidden unless qualified

Avoid bare:
- `user` when Customer/Driver/Admin/Account matters;
- `vehicle` when customer EV vs ServiceVehicle matters;
- `session` when auth/Duty/Charging session matters;
- `status` without resource;
- `transaction` when DB/payment/HAL charging transaction matters;
- `online` without Driver-duty vs charger-connection meaning;
- `paid` for calculated Driver compensation;
- `completed charging` when only command accepted.

# 7. ID field naming

Use explicit IDs:

```text
account_id
customer_id
driver_id
admin_principal_id
service_vehicle_id
charger_id
connector_id
duty_session_id
service_request_id
quote_id
service_job_id
assignment_id
dispatch_attempt_id
offer_id
charging_start_intent_id
charging_session_id
hal_transaction_id
payment_id
refund_id
invoice_id
notification_id
```

Never overload `user_id` for different principal domains.

# 8. Common lifecycle enums

Resource-specific enums live canonical Appendix A/annexes. Shared state tokens:

```text
ACTIVE / INACTIVE
AVAILABLE / UNAVAILABLE
MAINTENANCE
OUT_OF_SERVICE
RETIRED
UNKNOWN
STALE
```

`UNKNOWN` = truth not established. `STALE` = previously observed truth too old for current use. Neither equals `OFFLINE` unless domain specifically establishes offline.

# 9. Connector examples

Canonical connector vocabulary should be normalized, for example:

```text
CCS2
TYPE2
CHADEMO
GB_T_DC
GB_T_AC
OTHER
UNKNOWN
```

Exact supported set evolves from hardware inventory but uses one normalized registry, not vendor spelling in business APIs.

# 10. Charging preference vocabulary

```text
FASTEST_AVAILABLE
DC_FAST
NORMAL
TARGET_ENERGY_WH
TARGET_SOC_PERCENT
MAX_DURATION_SECONDS
```

Preference is customer intent subject to EV/charger/business/safety capability.

# 11. Protocol family

```text
OCPP_1_6
OCPP_2_0_1
OCPP_2_1
VENDOR_PROPRIETARY
SIMULATOR
```

CMS should not branch business logic directly on protocol message names.

# 12. Normalized connector live state

```text
UNKNOWN
STALE
AVAILABLE
PREPARING
CHARGING
FINISHING
UNAVAILABLE
FAULTED
```

Mapping from protocol-specific values is HAL-owned; inventory administrative availability remains separate.

# 13. Notification channel

```text
IN_APP
PUSH
EMAIL
```

SMS is reserved future extension, not silently active.

# 14. Failure vocabulary

**Rejected**: authoritative negative outcome.
**Failed**: known terminal failure.
**Retryable**: known no-success outcome safe to retry according to identity.
**Outcome unknown**: external effect may or may not have happened; reconcile, do not assume failure.
**Reconciliation required**: durable state explicitly needs evidence/repair.

# 15. Evidence vocabulary

Use Section 0.5/Annex 18 labels. "Verified" without boundary is discouraged in engineering completion records.
