# Security, Privacy, Rate Limit, and Abuse Model

**Status:** Normative scoped annex.
**Owns:** trust boundaries, secret/PII classes, threat controls, logging exclusions, rate/abuse baseline and security acceptance.

# 1. Trust boundaries

Distinct trust zones:
- anonymous internet;
- authenticated User app;
- authenticated Driver app;
- authenticated Admin app;
- CMS internal workers;
- HAL service boundary;
- charger/device network;
- external providers;
- PostgreSQL/storage/backup operators.

A successful crossing of one boundary grants nothing about another.

# 2. Secret classes

Never return/log/store plaintext unnecessarily:
- passwords/OTP;
- access/refresh tokens;
- realtime tickets;
- CMS-HAL service bearers;
- payment webhook/provider secrets;
- SMTP/push credentials;
- storage credentials;
- encryption keys/peppers/cursor HMAC keys.

Secrets come from environment/secret manager, never repository. Startup validates presence but logs key names only.

# 3. Session/auth security

Use Annex 11 opaque tokens/rotation/reuse detection. Constant-time digest comparison where relevant. CSRF protection is required if browser auth ever uses cookies; bearer-header native clients are not protected by CORS alone. Login/OTP/reset endpoints have enumeration-aware responses and strict rate limits.

# 4. Authorization

Server derives principal/account/Driver/Admin context from authenticated session. Never trust client-supplied owner IDs to authorize. Admin capabilities are checked server-side at every route/action and explicit DENY semantics win if role override model supports DENY.

# 5. Internal service endpoints

HAL internal endpoints are not exposed as anonymous public browser APIs. TLS required outside isolated local environment, plane-specific bearer, body limits, request correlation, secret-safe logs. Optional future mTLS can harden transport without changing semantic plane auth unless package change explicitly adopts it.

# 6. PII classes

Examples:

```text
HIGH: KYC documents/numbers, bank info if collected, exact historical location traces, auth/security data
MODERATE: customer/driver contact, service address, vehicle registration, support body
LOWER but private: ratings tied to identity, operational schedules, invoice metadata
PUBLIC/operational only when intentionally exposed: aggregate rating, service availability summary
```

APIs project only fields needed by that plane. Lists are more minimal than details.

# 7. KYC/document security

Private object/storage path, random keys, MIME/signature/size validation, short-lived authorized download or streamed proxy, no public bucket, no original filename path use. Admin requires driver-recruitment capability. Audit views/downloads. Retention follows legal/business decision gate.

# 8. Location privacy

Driver live location is visible only while needed to assigned customer and authorized operations staff. Customer does not gain indefinite Driver location history. Raw trace retention is bounded. Notifications/push do not include exact coordinates/address.

# 9. Payment privacy

Do not store card PAN/CVV. Use provider tokens/IDs only. Verify provider webhook raw-body signature. Provider payload logging is redacted/allow-listed.

# 10. Support/review privacy

Support body never goes into email/push metadata. User cannot discover another customer's ticket/review identity. Admin access capability-scoped and auditable.

# 11. SSRF and outbound calls

Provider/HAL base URLs come from trusted validated config, not arbitrary client URL. Redirect policy is adapter-specific and restricted. Diagnostics/download proxy cannot fetch arbitrary URLs. DNS rebinding/private-network risks are considered for any future user-configurable callback.

# 12. SQL/file/template safety

Parameterized SQL only. Dynamic sort/filter uses allow-list, never raw client SQL fragments. File paths derive from server-owned IDs. HTML/email templates auto-escape untrusted content. Markdown, if ever accepted, sanitized.

# 13. Rate-limit risk classes

Initial categories:

```text
AUTH_STRICT       login/OTP/reset/refresh abuse-sensitive
MUTATION_NORMAL   ordinary authenticated writes
READ_NORMAL       normal lists/details
LOCATION_HIGH     authenticated Driver location ingest, higher allowed rate
REALTIME_TICKET   bounded ticket creation
COMMAND_SENSITIVE charging/admin commands/refunds/manual corrections
EXPORT_HEAVY      expensive exports/analytics
```

Exact initial values are config in Annex 17 and tuned with measurements. Limit keys combine authenticated account/principal and source/network risk; anonymous limits never rely on IP alone where abuse can rotate.

# 14. Abuse signals

Monitor repeated auth failures, OTP abuse, device-token churn, excessive realtime connections, impossible Driver location jumps, dispatch accept automation/anomalies, repeated payment/refund failures, command spam and Admin denied-action attempts. Signals inform alerts/rate policies but do not silently accuse/ban without explicit policy.

# 15. Security headers

HTTP UI/static host if applicable uses appropriate HSTS, X-Content-Type-Options, Referrer-Policy, CSP/frame policy according to frontend hosting. API responses do not rely on browser headers as authorization.

# 16. Logging exclusions

Never log:
- Authorization/Cookie headers;
- raw tokens/OTPs/passwords;
- request/response bodies by default;
- full provider secret payloads;
- KYC/bank documents;
- exact customer/Driver coordinates in general logs;
- support free text;
- SQL query values containing PII/secrets.

Use IDs, status, safe reason codes, durations, sizes, request/correlation IDs.

# 17. Security incidents

Suspected credential/key compromise has runbook: identify plane/key, rotate, revoke affected sessions/service credential, verify old credential rejected, inspect audit/metrics, assess data exposure, record incident. Do not rotate all unrelated secrets blindly unless threat warrants.

# 18. Verification

Security review includes auth plane confusion, IDOR, explicit DENY, token replay/refresh reuse, brute force/rate limits, cursor/ticket tamper, CORS, file traversal/MIME, webhook signature/replay, SQL sort injection, support XSS, secret log scan, provider URL SSRF config validation and backup/storage permissions.
