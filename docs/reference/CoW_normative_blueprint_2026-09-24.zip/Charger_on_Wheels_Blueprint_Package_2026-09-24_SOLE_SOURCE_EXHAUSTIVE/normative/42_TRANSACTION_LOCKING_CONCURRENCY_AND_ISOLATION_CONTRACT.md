# Transaction, Locking, Concurrency, and Isolation Contract

**Status:** Normative scoped annex.
**Owns:** PostgreSQL transaction boundaries, lock ordering, optimistic concurrency and race-test obligations.

# 1. Baseline isolation

Default PostgreSQL isolation is READ COMMITTED. Use row locks, unique/exclusion constraints and atomic predicates to establish invariants. SERIALIZABLE is allowed for a narrowly justified transaction with bounded retry, not as a substitute for understanding races.

# 2. General rules

- validate syntax/auth before transaction where safe;
- revalidate mutable business preconditions under lock before commit;
- external network I/O MUST NOT occur while holding DB locks unless a protocol impossibility is explicitly documented;
- create durable intent before external side effect, then reconcile outcome;
- `SELECT ... FOR UPDATE` lock target rows in one canonical order;
- DB constraints are final protection for uniqueness/exclusion;
- deadlock/serialization retry repeats only uncommitted DB work, never an uncertain physical/provider side effect.

# 3. Canonical resource lock order

When one transaction needs multiple classes, use this order unless a domain-specific stricter order below overrides:

```text
account/principal guard
service_job
dispatch_attempt
dispatch_offer/job_assignment
driver_duty_session
service_vehicle (UUID ascending)
charger (UUID ascending)
charging_session/start/stop aggregate
payment
refund
invoice
policy/version aggregate
support_ticket
```

Within same class lock IDs ascending. Do not acquire an earlier class after a later class. Domain-specific documented order can replace this if all paths use it.

# 4. Required race protections

## Duty/assets
Partial unique/exclusion constraints prevent two active exclusive claims for same Vehicle/Charger. Duty start rechecks under asset locks.

## Dispatch
Acceptance locks job -> attempt -> offer, rechecks assignability, and relies on unique active assignment/atomic state predicate.

## Charging
One active start intent/session per applicable job/connector according to canonical invariant. Start/stop request creation locks charging aggregate; HAL network call occurs after durable commit.

## Payment/refund
Payment state transition locks payment. Refund creation locks payment then existing active/success refund aggregate before calculating remaining refundable amount.

## Invoice
One active/final invoice identity per job/commercial finalization. Worker claims job/invoice row by lease, not process memory.

## Support
Reply locks ticket then inserts message/history/idempotency record.

## Policy activation
Locks policy scope/version guard so two overlapping ACTIVE policy versions cannot activate concurrently.

# 5. Optimistic versioning

Mutable HTTP resources expose integer `version` and ETag where useful. `If-Match` mismatch returns `412 RESOURCE_VERSION_MISMATCH`. Server-side commands that are naturally idempotent may use state predicates rather than requiring ETag.

Version increments only when authoritative representation changes. No-op idempotent repeats do not increment.

# 6. Idempotency transaction

Mutation idempotency record and authoritative mutation must be committed atomically where possible. Same key/request digest returns stored outcome. Same key/different digest returns `IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST`.

If response includes transient fields that cannot be stored safely, store a stable logical result reference and reconstruct authorized response.

# 7. Worker claims

Workers claim bounded rows using `FOR UPDATE SKIP LOCKED`, set owner token + lease expiry, commit, perform work, then conditionally write result only if token still owns claim. Expired stale worker cannot overwrite new owner result.

# 8. Transaction retries

Allowed automatic retries:
- deadlock detected before any external I/O;
- serialization failure before external I/O;
- connection failure where transaction is known rolled back.

Not automatically retried:
- provider/charger request after bytes may have been sent;
- uncertain commit where client cannot determine whether commit happened without idempotent lookup.

# 9. Race-test matrix

Every invariant-changing burner has real PostgreSQL tests with barriers/goroutines for at least:
- duplicate idempotency key;
- competing version PATCH;
- competing asset claim;
- dispatch accept race;
- start/stop duplicate/race;
- duplicate HAL fact;
- concurrent refund;
- policy activation overlap;
- support reply/reopen;
- worker lease expiry/stale completion.

A test passing on SQLite/in-memory storage is not evidence for PostgreSQL concurrency correctness.
