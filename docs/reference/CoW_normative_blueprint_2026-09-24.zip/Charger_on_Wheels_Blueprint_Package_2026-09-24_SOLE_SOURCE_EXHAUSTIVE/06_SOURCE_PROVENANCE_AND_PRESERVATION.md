> PACKAGE AUTHORITY NOTE: This file is provenance guidance only. Normative authority is defined by canonical Section 0.1 and the incorporated `normative/`, `registries/`, and `schemas/` set.

# Charger on Wheels - Source Provenance, Sole-Source Contract, and Preservation Map

**Package date:** 2026-09-24
**Status:** Non-normative provenance record. Canonical requirements live only in `01_CANONICAL_FULL_BLUEPRINT.md`.

## 1. The three supplied sources

This sole-source edition was built from exactly these inputs:

1. the previous `Charger_on_Wheels_Blueprint_Package_2026-09-24` ZIP;
2. the supplied consolidated planning baseline, retained byte-for-byte as `07_ORIGINAL_PLANNING_BASELINE.md`;
3. the supplied EV-CMS Go New full continuity handoff, retained byte-for-byte as `08_SOURCE_EVCMS_FULL_CONTINUITY_HANDOFF.md`.

The package now contains the two originally external text sources. A future working session does not need those original attachments or prior chat history.

Source SHA-256 values:

```text
07_ORIGINAL_PLANNING_BASELINE.md
  e0748d2dc4724a0628cd1ead333c4e7230b87661a436510d994d91d5ffd420f7

08_SOURCE_EVCMS_FULL_CONTINUITY_HANDOFF.md
  cba69afb7f9e0e14ff0d54e66033dbb737901089d68a34915717f309f1116a14
```

## 2. Sole-source authority rule

Before implementation exists, only `01_CANONICAL_FULL_BLUEPRINT.md` is normative.

Files 02-05 are focused reading views. Files 07-08 are immutable provenance snapshots. File 09 is mechanically generated from canonical Appendix H. None can add a hidden requirement.

After implementation exists, runtime/source/database/machine-contract evidence may supersede stale blueprint text for implemented behavior according to canonical Section 0.1. That is observation of the project itself, not a requirement to consult an old external project.

## 3. What was promoted from the planning baseline

The canonical blueprint preserves and concretizes the planning baseline's product model: User, Driver, unified Admin, ServiceJob, DriverDutySession, dedicated HAL, reusable/temporary customer data, driver recruitment, fleet inventory, pairings/mismatches, schedule-vs-duty separation, geofencing, two-stage dispatch, multiple charging sessions per job, composable pricing, compensation without payout execution, realtime recovery, protocol-neutral HAL, raw evidence, audit/history, implementation sequencing, and verification. Canonical Section 70.1 is the authoritative traceability map.

## 4. What was promoted from the EV-CMS continuity handoff

Only semantically reusable lessons were promoted. Canonical Section 70.2 records the mapping. Key promoted requirements include:

- PostgreSQL durable truth and immutable applied migrations;
- separate CMS/HAL ownership and databases;
- physical charging proof from charger-originated evidence, not command acknowledgement;
- exact-ID reconciliation and no blind replay after uncertain delivery;
- capability-based authorization and identity-plane separation;
- durable idempotency/outbox patterns;
- support privacy/ownership;
- ratings/reviews ownership and aggregates;
- immutable finalized invoice artifacts;
- external provider acceptance separate from enqueue/runtime health;
- secret-safe configuration parity;
- evidence-class separation;
- rollback/restore/post-deploy verification discipline;
- explicit OpenAPI path-vs-operation terminology.

## 5. Intentionally not inherited

The following EV-CMS-specific facts are retained only in the source snapshot and are not Charger-on-Wheels requirements:

- CPO tenancy and CPO-vs-SuperAdmin product split;
- old CPO-local customer identity model;
- old development hostnames, services, filesystem paths, database names, migration numbers, current SHAs, and rehost aliases;
- fixed-station discovery as the central customer journey;
- old CPO settlement model;
- any runtime claim about the old deployment.

The new product may reuse code patterns later, but only its own canonical semantics govern correctness.

## 6. Corrections made in the sole-source edition

The previous package review identified four residual ambiguity classes. This edition corrects them without redesigning the system:

1. **Authority ambiguity removed.** Old repos/chat are no longer a fallback design tier; the source snapshots are inside the ZIP and canonical is the only normative design source.
2. **Identity/auth decisions frozen.** V1 uses one credential-bearing account layer with separate domain principals, and three TLS-protected opaque CMS/HAL service bearer planes.
3. **Pricing shell removed.** B06.3 implements the first capability slice of the final pricing contract rather than disposable quote semantics.
4. **Mobile energy becomes an explicit activation gate.** If finite onboard energy is real hardware truth, energy identity/observation/reservation becomes a core dispatch dependency instead of a vague future extension.
5. **Burner ambiguity reduced.** Canonical Appendix H gives every burner the same execution/verification claim structure; file 09 is generated from it.
6. **Focused-doc drift neutralized.** Files 02-05 are explicitly non-normative; they cannot override or silently extend canonical semantics.

## 7. Independence goal

A new engineer or AI should be able to start with `00_PACKAGE_INDEX.md`, read `01_CANONICAL_FULL_BLUEPRINT.md`, and build the project without inspecting EV-CMS, the old HAL, the original planning attachment, or previous chats merely to discover behavior.

External systems are consulted only when the canonical blueprint says a runtime/business/hardware fact is genuinely required, such as a Razorpay capability, selected physical charger model, KYC/legal requirement, map provider, production infrastructure, or real hardware acceptance.
